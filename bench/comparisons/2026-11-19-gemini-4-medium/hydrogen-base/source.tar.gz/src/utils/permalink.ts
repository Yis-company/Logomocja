import type { Mode } from '../lang/types';

function toBase64Url(str: string): string {
  const bytes = new TextEncoder().encode(str);
  let bin = '';
  for (let i = 0; i < bytes.length; i++) {
    bin += String.fromCharCode(bytes[i]);
  }
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function fromBase64Url(b64: string): string {
  const padded = b64.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((b64.length + 3) % 4);
  const bin = atob(padded);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) {
    bytes[i] = bin.charCodeAt(i);
  }
  return new TextDecoder().decode(bytes);
}

export function encodePermalink(mode: Mode, code: string): string {
  const payload = JSON.stringify({ m: mode, c: code });
  const encoded = toBase64Url(payload);
  const url = new URL(window.location.href);
  url.hash = `p=${encoded}`;
  return url.toString();
}

export function decodePermalink(hash: string): { mode: Mode; code: string } | null {
  if (!hash || !hash.startsWith('#p=')) return null;
  try {
    const raw = fromBase64Url(hash.slice(3));
    const parsed = JSON.parse(raw);
    if (
      parsed &&
      (parsed.m === '2d' || parsed.m === '3d') &&
      typeof parsed.c === 'string'
    ) {
      return { mode: parsed.m, code: parsed.c };
    }
    return null;
  } catch {
    return null;
  }
}
