import { STANDARD_EXAMPLES } from '../data/examples';
import type { Mode } from '../lang/types';

const DRAFT_KEY_2D = 'logomocja.draft.2d';
const DRAFT_KEY_3D = 'logomocja.draft.3d';
const SAVED_SOURCE_KEY_2D = 'logomocja.savedSource.2d';
const SAVED_SOURCE_KEY_3D = 'logomocja.savedSource.3d';
const MODE_KEY = 'logomocja.mode';
const CHALLENGES_KEY = 'logomocja.challenges.solved';
const THEME_KEY = 'color-scheme';

export function getDefaultCode(mode: Mode): string {
  const id = mode === '2d' ? 'kwadrat' : 'schody';
  return STANDARD_EXAMPLES.find((e) => e.id === id)?.code ?? '';
}

export function loadDraft(mode: Mode): string {
  try {
    const key = mode === '2d' ? DRAFT_KEY_2D : DRAFT_KEY_3D;
    const val = localStorage.getItem(key);
    return val !== null ? val : getDefaultCode(mode);
  } catch {
    return getDefaultCode(mode);
  }
}

export function saveDraft(mode: Mode, code: string): void {
  try {
    const key = mode === '2d' ? DRAFT_KEY_2D : DRAFT_KEY_3D;
    localStorage.setItem(key, code);
  } catch {
    // Ignore storage quota / privacy mode errors
  }
}

export function loadBaselineCode(mode: Mode): string {
  try {
    const key = mode === '2d' ? SAVED_SOURCE_KEY_2D : SAVED_SOURCE_KEY_3D;
    return localStorage.getItem(key) ?? getDefaultCode(mode);
  } catch {
    return getDefaultCode(mode);
  }
}

export function saveBaselineCode(mode: Mode, code: string): void {
  try {
    const key = mode === '2d' ? SAVED_SOURCE_KEY_2D : SAVED_SOURCE_KEY_3D;
    localStorage.setItem(key, code);
  } catch {
    // Ignore
  }
}

export function loadMode(): Mode {
  try {
    const val = localStorage.getItem(MODE_KEY);
    return val === '3d' ? '3d' : '2d';
  } catch {
    return '2d';
  }
}

export function saveMode(mode: Mode): void {
  try {
    localStorage.setItem(MODE_KEY, mode);
  } catch {
    // Ignore
  }
}

export function loadSolvedChallenges(): Set<string> {
  try {
    const raw = localStorage.getItem(CHALLENGES_KEY);
    if (!raw) return new Set();
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? new Set(arr.filter((x) => typeof x === 'string')) : new Set();
  } catch {
    return new Set();
  }
}

export function saveSolvedChallenges(solved: Set<string>): void {
  try {
    localStorage.setItem(CHALLENGES_KEY, JSON.stringify([...solved]));
  } catch {
    // Ignore
  }
}

export type ThemeOverride = 'light' | 'dark' | null;

export function loadThemeOverride(): ThemeOverride {
  try {
    const v = localStorage.getItem(THEME_KEY);
    return v === 'light' || v === 'dark' ? v : null;
  } catch {
    return null;
  }
}

export function saveThemeOverride(theme: ThemeOverride): void {
  try {
    if (theme === null) {
      localStorage.removeItem(THEME_KEY);
    } else {
      localStorage.setItem(THEME_KEY, theme);
    }
  } catch {
    // Ignore
  }
}
