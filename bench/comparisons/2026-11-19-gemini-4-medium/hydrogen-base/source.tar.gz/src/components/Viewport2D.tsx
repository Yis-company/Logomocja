import React, {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react';
import { Maximize2, RotateCcw, ZoomIn, ZoomOut } from 'lucide-react';
import type { Segment, TurtleState } from '../lang/types';

export interface ViewportHandle {
  fit: (overrideSegments?: Segment[], overrideTurtle?: TurtleState) => void;
  resetView: () => void;
  getCanvas: () => HTMLCanvasElement | null;
}

interface Viewport2DProps {
  segments: Segment[];
  turtle: TurtleState;
  showTurtle?: boolean;
}

export const Viewport2D = forwardRef<ViewportHandle, Viewport2DProps>(
  ({ segments, turtle, showTurtle = true }, ref) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);

    // Camera state: world center (cx, cy) and zoom (px per world unit)
    const cameraRef = useRef({ cx: 0, cy: 0, zoom: 1.2 });
    const [zoomLabel, setZoomLabel] = useState('120%');
    const dragRef = useRef<{ active: boolean; lastX: number; lastY: number }>({
      active: false,
      lastX: 0,
      lastY: 0,
    });

    const draw = useCallback(() => {
      const canvas = canvasRef.current;
      const container = containerRef.current;
      if (!canvas || !container) return;

      const dpr = window.devicePixelRatio || 1;
      const width = container.clientWidth;
      const height = container.clientHeight;
      if (width === 0 || height === 0) return;

      if (canvas.width !== Math.floor(width * dpr) || canvas.height !== Math.floor(height * dpr)) {
        canvas.width = Math.floor(width * dpr);
        canvas.height = Math.floor(height * dpr);
      }

      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const isDark =
        getComputedStyle(document.documentElement).colorScheme === 'dark' ||
        (getComputedStyle(document.documentElement).colorScheme !== 'light' &&
          window.matchMedia('(prefers-color-scheme: dark)').matches);

      ctx.save();
      ctx.scale(dpr, dpr);

      // Background
      ctx.fillStyle = isDark ? '#11161b' : '#fbfaf7';
      ctx.fillRect(0, 0, width, height);

      const { cx, cy, zoom } = cameraRef.current;
      const toScreenX = (wx: number) => width / 2 + (wx - cx) * zoom;
      const toScreenY = (wy: number) => height / 2 - (wy - cy) * zoom;

      // Subtle grid
      const rawStep = 50;
      let step = rawStep;
      while (step * zoom < 28) step *= 2;
      while (step * zoom > 110) step /= 2;

      const minWX = cx - width / (2 * zoom);
      const maxWX = cx + width / (2 * zoom);
      const minWY = cy - height / (2 * zoom);
      const maxWY = cy + height / (2 * zoom);

      ctx.strokeStyle = isDark ? 'rgba(255,255,255,0.05)' : 'rgba(20,30,40,0.06)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      const startX = Math.floor(minWX / step) * step;
      for (let x = startX; x <= maxWX; x += step) {
        const sx = toScreenX(x);
        ctx.moveTo(sx, 0);
        ctx.lineTo(sx, height);
      }
      const startY = Math.floor(minWY / step) * step;
      for (let y = startY; y <= maxWY; y += step) {
        const sy = toScreenY(y);
        ctx.moveTo(0, sy);
        ctx.lineTo(width, sy);
      }
      ctx.stroke();

      // Origin axes & marker
      const ox = toScreenX(0);
      const oy = toScreenY(0);
      ctx.strokeStyle = isDark ? 'rgba(255,255,255,0.16)' : 'rgba(20,30,40,0.16)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(ox - 10, oy);
      ctx.lineTo(ox + 10, oy);
      ctx.moveTo(ox, oy - 10);
      ctx.lineTo(ox, oy + 10);
      ctx.stroke();

      ctx.fillStyle = isDark ? 'rgba(255,255,255,0.38)' : 'rgba(20,30,40,0.38)';
      ctx.beginPath();
      ctx.arc(ox, oy, 3, 0, Math.PI * 2);
      ctx.fill();

      // Drawn segments
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      for (const seg of segments) {
        ctx.strokeStyle = seg.color;
        ctx.lineWidth = seg.width;
        ctx.beginPath();
        ctx.moveTo(toScreenX(seg.from[0]), toScreenY(seg.from[1]));
        ctx.lineTo(toScreenX(seg.to[0]), toScreenY(seg.to[1]));
        ctx.stroke();
      }

      // Turtle marker
      if (showTurtle) {
        const tx = toScreenX(turtle.pos[0]);
        const ty = toScreenY(turtle.pos[1]);
        // heading in screen coords: (hx, -hy)
        const angle = Math.atan2(-turtle.heading[1], turtle.heading[0]);

        ctx.save();
        ctx.translate(tx, ty);
        ctx.rotate(angle);

        // Crisp turtle arrow / shell
        ctx.beginPath();
        ctx.moveTo(13, 0);
        ctx.lineTo(-9, -8);
        ctx.lineTo(-5, 0);
        ctx.lineTo(-9, 8);
        ctx.closePath();

        ctx.fillStyle = turtle.penDown ? turtle.color : 'transparent';
        ctx.fill();
        ctx.lineWidth = 2;
        ctx.strokeStyle = isDark ? '#e8f0f2' : '#1b242c';
        ctx.stroke();
        ctx.restore();
      }

      ctx.restore();
    }, [segments, turtle, showTurtle]);

    const fit = useCallback(
      (overrideSegments?: Segment[], overrideTurtle?: TurtleState) => {
        const container = containerRef.current;
        if (!container) return;
        const w = container.clientWidth || 600;
        const h = container.clientHeight || 400;
        const segs = overrideSegments ?? segments;
        const trt = overrideTurtle ?? turtle;

        let minX = 0;
        let maxX = 0;
        let minY = 0;
        let maxY = 0;
        let hasPts = false;

        for (const s of segs) {
          for (const p of [s.from, s.to]) {
            if (!hasPts) {
              minX = maxX = p[0];
              minY = maxY = p[1];
              hasPts = true;
            } else {
              if (p[0] < minX) minX = p[0];
              if (p[0] > maxX) maxX = p[0];
              if (p[1] < minY) minY = p[1];
              if (p[1] > maxY) maxY = p[1];
            }
          }
        }

        if (!hasPts) {
          minX = Math.min(0, trt.pos[0]) - 100;
          maxX = Math.max(0, trt.pos[0]) + 100;
          minY = Math.min(0, trt.pos[1]) - 100;
          maxY = Math.max(0, trt.pos[1]) + 100;
        }

        const spanX = Math.max(20, maxX - minX);
        const spanY = Math.max(20, maxY - minY);
        const pad = 48;
        const zoomX = (w - pad * 2) / spanX;
        const zoomY = (h - pad * 2) / spanY;
        const newZoom = Math.max(0.02, Math.min(8, Math.min(zoomX, zoomY)));

        cameraRef.current = {
          cx: (minX + maxX) / 2,
          cy: (minY + maxY) / 2,
          zoom: newZoom,
        };
        setZoomLabel(`${Math.round(newZoom * 100)}%`);
        draw();
      },
      [segments, turtle, draw],
    );

    const resetView = useCallback(() => {
      cameraRef.current = { cx: 0, cy: 0, zoom: 1.2 };
      setZoomLabel('120%');
      draw();
    }, [draw]);

    useImperativeHandle(
      ref,
      () => ({
        fit,
        resetView,
        getCanvas: () => canvasRef.current,
      }),
      [fit, resetView],
    );

    useEffect(() => {
      draw();
    }, [draw]);

    useEffect(() => {
      const container = containerRef.current;
      if (!container) return;
      const ro = new ResizeObserver(() => draw());
      ro.observe(container);
      return () => ro.disconnect();
    }, [draw]);

    const applyZoom = (factor: number) => {
      const cam = cameraRef.current;
      cam.zoom = Math.max(0.02, Math.min(20, cam.zoom * factor));
      setZoomLabel(`${Math.round(cam.zoom * 100)}%`);
      draw();
    };

    const handleWheel = (e: React.WheelEvent) => {
      e.preventDefault();
      const factor = e.deltaY < 0 ? 1.12 : 1 / 1.12;
      applyZoom(factor);
    };

    const handlePointerDown = (e: React.PointerEvent) => {
      e.currentTarget.setPointerCapture(e.pointerId);
      dragRef.current = { active: true, lastX: e.clientX, lastY: e.clientY };
    };

    const handlePointerMove = (e: React.PointerEvent) => {
      if (!dragRef.current.active) return;
      const dx = e.clientX - dragRef.current.lastX;
      const dy = e.clientY - dragRef.current.lastY;
      dragRef.current.lastX = e.clientX;
      dragRef.current.lastY = e.clientY;
      const cam = cameraRef.current;
      cam.cx -= dx / cam.zoom;
      cam.cy += dy / cam.zoom;
      draw();
    };

    const handlePointerUp = () => {
      dragRef.current.active = false;
    };

    return (
      <div className="viewport-container" ref={containerRef}>
        <canvas
          ref={canvasRef}
          className="viewport-canvas"
          onWheel={handleWheel}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          aria-label="Płótno 2D"
        />
        <div className="viewport-overlay-controls" role="group" aria-label="Widok 2D">
          <button
            type="button"
            className="icon-btn"
            onClick={() => applyZoom(1.25)}
            aria-label="Przybliż widok 2D"
            title="Przybliż"
          >
            <ZoomIn size={16} />
          </button>
          <span className="zoom-badge" aria-live="polite">
            {zoomLabel}
          </span>
          <button
            type="button"
            className="icon-btn"
            onClick={() => applyZoom(0.8)}
            aria-label="Oddal widok 2D"
            title="Oddal"
          >
            <ZoomOut size={16} />
          </button>
          <button
            type="button"
            className="icon-btn"
            onClick={() => fit()}
            aria-label="Dopasuj rysunek do widoku"
            title="Dopasuj"
          >
            <Maximize2 size={16} />
          </button>
          <button
            type="button"
            className="icon-btn"
            onClick={resetView}
            aria-label="Wyśrodkuj na początku układu (0, 0)"
            title="Środek (0, 0)"
          >
            <RotateCcw size={16} />
          </button>
        </div>
      </div>
    );
  },
);
Viewport2D.displayName = 'Viewport2D';
