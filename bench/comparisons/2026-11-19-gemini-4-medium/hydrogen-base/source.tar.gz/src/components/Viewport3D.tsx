import {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { LineMaterial } from 'three/examples/jsm/lines/LineMaterial.js';
import { LineSegments2 } from 'three/examples/jsm/lines/LineSegments2.js';
import { LineSegmentsGeometry } from 'three/examples/jsm/lines/LineSegmentsGeometry.js';
import { Maximize2, RotateCcw, ZoomIn, ZoomOut } from 'lucide-react';
import type { Segment, TurtleState } from '../lang/types';
import type { ViewportHandle } from './Viewport2D';

interface Viewport3DProps {
  segments: Segment[];
  turtle: TurtleState;
  showTurtle?: boolean;
}

export const Viewport3D = forwardRef<ViewportHandle, Viewport3DProps>(
  ({ segments, turtle, showTurtle = true }, ref) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const [webglError, setWebglError] = useState<string | null>(null);

    const sceneRef = useRef<{
      renderer: THREE.WebGLRenderer;
      scene: THREE.Scene;
      camera: THREE.PerspectiveCamera;
      controls: OrbitControls;
      linesGroup: THREE.Group;
      turtleGroup: THREE.Group;
      turtleBodyMat: THREE.MeshStandardMaterial;
      materials: LineMaterial[];
      grid: THREE.GridHelper;
    } | null>(null);

    const isDarkTheme = () =>
      getComputedStyle(document.documentElement).colorScheme === 'dark' ||
      (getComputedStyle(document.documentElement).colorScheme !== 'light' &&
        window.matchMedia('(prefers-color-scheme: dark)').matches);

    const syncThemeColors = useCallback(() => {
      const ctx = sceneRef.current;
      if (!ctx) return;
      const dark = isDarkTheme();
      ctx.scene.background = new THREE.Color(dark ? 0x11161b : 0xfbfaf7);
    }, []);

    useEffect(() => {
      const container = containerRef.current;
      if (!container) return;

      let renderer: THREE.WebGLRenderer;
      try {
        renderer = new THREE.WebGLRenderer({
          antialias: true,
          preserveDrawingBuffer: true,
        });
        if (!renderer.getContext()) {
          throw new Error('Brak kontekstu WebGL.');
        }
      } catch {
        setWebglError(
          'Widok 3D wymaga obsługi WebGL, która jest niedostępna w tym środowisku. Tryb 2D działa bez ograniczeń.',
        );
        return;
      }

      const width = container.clientWidth || 600;
      const height = container.clientHeight || 400;
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      renderer.setSize(width, height);
      renderer.domElement.className = 'viewport-canvas';
      renderer.domElement.setAttribute('aria-label', 'Scena 3D');
      container.appendChild(renderer.domElement);

      const scene = new THREE.Scene();
      scene.background = new THREE.Color(isDarkTheme() ? 0x11161b : 0xfbfaf7);

      const camera = new THREE.PerspectiveCamera(45, width / height, 0.5, 250000);
      camera.up.set(0, 0, 1);
      camera.position.set(160, -210, 150);

      const controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;
      controls.dampingFactor = 0.08;
      controls.target.set(0, 0, 0);
      controls.update();

      // Lighting for 3D turtle
      scene.add(new THREE.AmbientLight(0xffffff, 0.75));
      const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
      dirLight.position.set(150, -100, 300);
      scene.add(dirLight);

      // Ground grid on XY plane (z = 0)
      const grid = new THREE.GridHelper(400, 20, 0x8899aa, 0x556677);
      grid.rotation.x = Math.PI / 2;
      (grid.material as THREE.Material).transparent = true;
      (grid.material as THREE.Material).opacity = 0.28;
      scene.add(grid);

      // Axes helper (X red, Y green, Z blue)
      const axes = new THREE.AxesHelper(60);
      scene.add(axes);

      const linesGroup = new THREE.Group();
      scene.add(linesGroup);

      // 3D Turtle: cone nose along +Y, dorsal fin along +Z, wings along +/-X
      const turtleGroup = new THREE.Group();
      const turtleBodyMat = new THREE.MeshStandardMaterial({
        color: 0x16866a,
        roughness: 0.4,
        metalness: 0.1,
      });
      const coneGeo = new THREE.ConeGeometry(5.5, 16, 12);
      const coneMesh = new THREE.Mesh(coneGeo, turtleBodyMat);
      turtleGroup.add(coneMesh);

      const finGeo = new THREE.BoxGeometry(1.6, 8, 5);
      const finMat = new THREE.MeshStandardMaterial({ color: 0xc1763d, roughness: 0.4 });
      const finMesh = new THREE.Mesh(finGeo, finMat);
      finMesh.position.set(0, -2, 3.5);
      turtleGroup.add(finMesh);

      const wingGeo = new THREE.BoxGeometry(12, 3, 1.4);
      const wingMesh = new THREE.Mesh(wingGeo, turtleBodyMat);
      wingMesh.position.set(0, -3, 0);
      turtleGroup.add(wingMesh);

      scene.add(turtleGroup);

      sceneRef.current = {
        renderer,
        scene,
        camera,
        controls,
        linesGroup,
        turtleGroup,
        turtleBodyMat,
        materials: [],
        grid,
      };

      let animId = 0;
      const animate = () => {
        animId = requestAnimationFrame(animate);
        controls.update();
        renderer.render(scene, camera);
      };
      animate();

      const ro = new ResizeObserver(() => {
        const w = container.clientWidth;
        const h = container.clientHeight;
        if (w === 0 || h === 0) return;
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
        for (const mat of sceneRef.current?.materials ?? []) {
          mat.resolution.set(w, h);
        }
      });
      ro.observe(container);

      const mql = window.matchMedia('(prefers-color-scheme: dark)');
      mql.addEventListener('change', syncThemeColors);
      const obs = new MutationObserver(syncThemeColors);
      obs.observe(document.querySelector('meta[name="color-scheme"]')!, {
        attributes: true,
        attributeFilter: ['content'],
      });

      return () => {
        cancelAnimationFrame(animId);
        ro.disconnect();
        mql.removeEventListener('change', syncThemeColors);
        obs.disconnect();
        controls.dispose();
        renderer.dispose();
        if (renderer.domElement.parentNode === container) {
          container.removeChild(renderer.domElement);
        }
        sceneRef.current = null;
      };
    }, [syncThemeColors]);

    // Update segments & turtle
    useEffect(() => {
      const ctx = sceneRef.current;
      if (!ctx) return;

      // Clear old line meshes
      while (ctx.linesGroup.children.length > 0) {
        const child = ctx.linesGroup.children[0] as LineSegments2;
        child.geometry.dispose();
        ctx.linesGroup.remove(child);
      }
      for (const m of ctx.materials) m.dispose();
      ctx.materials = [];

      const w = containerRef.current?.clientWidth || 600;
      const h = containerRef.current?.clientHeight || 400;

      // Group segments by color|width
      const batches = new Map<string, { color: string; width: number; positions: number[] }>();
      for (const s of segments) {
        const key = `${s.color}|${s.width}`;
        let batch = batches.get(key);
        if (!batch) {
          batch = { color: s.color, width: s.width, positions: [] };
          batches.set(key, batch);
        }
        batch.positions.push(s.from[0], s.from[1], s.from[2], s.to[0], s.to[1], s.to[2]);
      }

      for (const batch of batches.values()) {
        const geom = new LineSegmentsGeometry();
        geom.setPositions(batch.positions);
        const mat = new LineMaterial({
          color: new THREE.Color(batch.color).getHex(),
          linewidth: batch.width,
          resolution: new THREE.Vector2(w, h),
        });
        ctx.materials.push(mat);
        const lines = new LineSegments2(geom, mat);
        ctx.linesGroup.add(lines);
      }

      // Update turtle
      ctx.turtleGroup.visible = showTurtle;
      ctx.turtleGroup.position.set(turtle.pos[0], turtle.pos[1], turtle.pos[2]);
      const basis = new THREE.Matrix4().makeBasis(
        new THREE.Vector3(...turtle.right),
        new THREE.Vector3(...turtle.heading),
        new THREE.Vector3(...turtle.up),
      );
      ctx.turtleGroup.quaternion.setFromRotationMatrix(basis);
      ctx.turtleBodyMat.color.set(turtle.penDown ? turtle.color : '#8899aa');

      ctx.renderer.render(ctx.scene, ctx.camera);
    }, [segments, turtle, showTurtle]);

    const fit = useCallback(
      (overrideSegments?: Segment[], overrideTurtle?: TurtleState) => {
        const ctx = sceneRef.current;
        if (!ctx) return;
        const segs = overrideSegments ?? segments;
        const trt = overrideTurtle ?? turtle;

        const box = new THREE.Box3();
        if (segs.length === 0) {
          box.expandByPoint(new THREE.Vector3(0, 0, 0));
          box.expandByPoint(new THREE.Vector3(...trt.pos));
          box.expandByScalar(80);
        } else {
          for (const s of segs) {
            box.expandByPoint(new THREE.Vector3(...s.from));
            box.expandByPoint(new THREE.Vector3(...s.to));
          }
        }

        const center = box.getCenter(new THREE.Vector3());
        const size = box.getSize(new THREE.Vector3());
        const maxDim = Math.max(size.x, size.y, size.z, 40);
        const fov = (ctx.camera.fov * Math.PI) / 180;
        const dist = (maxDim / 2 / Math.tan(fov / 2)) * 1.45;

        const dir = new THREE.Vector3(0.6, -0.8, 0.55).normalize();
        ctx.controls.target.copy(center);
        ctx.camera.position.copy(center).addScaledVector(dir, dist);
        ctx.controls.update();
        ctx.renderer.render(ctx.scene, ctx.camera);
      },
      [segments, turtle],
    );

    const resetView = useCallback(() => {
      const ctx = sceneRef.current;
      if (!ctx) return;
      ctx.controls.target.set(0, 0, 0);
      ctx.camera.position.set(160, -210, 150);
      ctx.controls.update();
      ctx.renderer.render(ctx.scene, ctx.camera);
    }, []);

    const zoomBy = (factor: number) => {
      const ctx = sceneRef.current;
      if (!ctx) return;
      const offset = ctx.camera.position.clone().sub(ctx.controls.target);
      offset.multiplyScalar(factor);
      ctx.camera.position.copy(ctx.controls.target).add(offset);
      ctx.controls.update();
    };

    useImperativeHandle(
      ref,
      () => ({
        fit,
        resetView,
        getCanvas: () => sceneRef.current?.renderer.domElement ?? null,
      }),
      [fit, resetView],
    );

    if (webglError) {
      return (
        <div className="viewport-container viewport-fallback" role="status">
          <div className="fallback-card">
            <h3>Tryb 3D niedostępny</h3>
            <p>{webglError}</p>
          </div>
        </div>
      );
    }

    return (
      <div className="viewport-container" ref={containerRef}>
        <div className="viewport-overlay-controls" role="group" aria-label="Widok 3D">
          <button
            type="button"
            className="icon-btn"
            onClick={() => zoomBy(0.8)}
            aria-label="Przybliż kamerę 3D"
            title="Przybliż"
          >
            <ZoomIn size={16} />
          </button>
          <button
            type="button"
            className="icon-btn"
            onClick={() => zoomBy(1.25)}
            aria-label="Oddal kamerę 3D"
            title="Oddal"
          >
            <ZoomOut size={16} />
          </button>
          <button
            type="button"
            className="icon-btn"
            onClick={() => fit()}
            aria-label="Dopasuj bryłę do widoku"
            title="Dopasuj"
          >
            <Maximize2 size={16} />
          </button>
          <button
            type="button"
            className="icon-btn"
            onClick={resetView}
            aria-label="Resetuj kamerę 3D"
            title="Reset kamery"
          >
            <RotateCcw size={16} />
          </button>
        </div>
      </div>
    );
  },
);
Viewport3D.displayName = 'Viewport3D';
