import React, { useMemo, useRef } from 'react';
import { isReservedWord } from '../lang/parser';
import type { LogoError } from '../lang/types';

interface EditorProps {
  value: string;
  onChange: (value: string) => void;
  activeLine: number | null;
  error: LogoError | null;
}

type HighlightKind =
  | 'plain'
  | 'comment'
  | 'string'
  | 'number'
  | 'keyword'
  | 'bracket'
  | 'name'
  | 'operator';

interface HighlightSpan {
  text: string;
  kind: HighlightKind;
}

function tokenizeLineForHighlight(lineText: string): HighlightSpan[] {
  const spans: HighlightSpan[] = [];
  let i = 0;

  while (i < lineText.length) {
    const ch = lineText[i];

    // Comment
    if (ch === ';') {
      spans.push({ text: lineText.slice(i), kind: 'comment' });
      break;
    }

    // String / colour literal
    if (ch === '"') {
      let j = i + 1;
      while (j < lineText.length && lineText[j] !== '"') j++;
      if (j < lineText.length) j++;
      spans.push({ text: lineText.slice(i, j), kind: 'string' });
      i = j;
      continue;
    }

    // Whitespace
    if (ch === ' ' || ch === '\t' || ch === '\r') {
      let j = i + 1;
      while (j < lineText.length && (lineText[j] === ' ' || lineText[j] === '\t' || lineText[j] === '\r')) {
        j++;
      }
      spans.push({ text: lineText.slice(i, j), kind: 'plain' });
      i = j;
      continue;
    }

    // Brackets & parens
    if (ch === '[' || ch === ']' || ch === '(' || ch === ')') {
      spans.push({ text: ch, kind: 'bracket' });
      i++;
      continue;
    }

    // Operators & comparisons
    if ('+-*/<>=,'.includes(ch)) {
      let j = i + 1;
      if ((ch === '<' && (lineText[j] === '=' || lineText[j] === '>')) || (ch === '>' && lineText[j] === '=')) {
        j++;
      }
      spans.push({ text: lineText.slice(i, j), kind: 'operator' });
      i = j;
      continue;
    }

    // Numbers
    if ((ch >= '0' && ch <= '9') || (ch === '.' && i + 1 < lineText.length && lineText[i + 1] >= '0' && lineText[i + 1] <= '9')) {
      let j = i;
      while (j < lineText.length && lineText[j] >= '0' && lineText[j] <= '9') j++;
      if (lineText[j] === '.') {
        j++;
        while (j < lineText.length && lineText[j] >= '0' && lineText[j] <= '9') j++;
      }
      spans.push({ text: lineText.slice(i, j), kind: 'number' });
      i = j;
      continue;
    }

    // Legacy :var
    if (ch === ':') {
      let j = i + 1;
      while (j < lineText.length && /[\p{L}0-9_]/u.test(lineText[j])) j++;
      spans.push({ text: lineText.slice(i, j), kind: 'name' });
      i = j;
      continue;
    }

    // Words
    if (/[\p{L}_]/u.test(ch)) {
      let j = i + 1;
      while (j < lineText.length && /[\p{L}0-9_]/u.test(lineText[j])) j++;
      let word = lineText.slice(i, j);
      if (word.toLowerCase() === 'ma' && lineText[j] === ':') {
        j++;
        word = lineText.slice(i, j);
      }
      const kind: HighlightKind = isReservedWord(word) ? 'keyword' : 'name';
      spans.push({ text: word, kind });
      i = j;
      continue;
    }

    spans.push({ text: ch, kind: 'plain' });
    i++;
  }

  return spans;
}

export const Editor: React.FC<EditorProps> = ({ value, onChange, activeLine, error }) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const highlightRef = useRef<HTMLDivElement>(null);
  const gutterRef = useRef<HTMLDivElement>(null);

  const lines = useMemo(() => value.split('\n'), [value]);
  const highlightedLines = useMemo(
    () => lines.map((line) => tokenizeLineForHighlight(line)),
    [lines],
  );

  const syncScroll = () => {
    const ta = textareaRef.current;
    if (!ta) return;
    if (highlightRef.current) {
      highlightRef.current.scrollTop = ta.scrollTop;
      highlightRef.current.scrollLeft = ta.scrollLeft;
    }
    if (gutterRef.current) {
      gutterRef.current.scrollTop = ta.scrollTop;
    }
  };

  return (
    <div className="editor-shell">
      <div className="editor-body">
        <div className="editor-gutter" ref={gutterRef} aria-hidden="true">
          {lines.map((_, idx) => {
            const lineNum = idx + 1;
            const isExec = activeLine === lineNum;
            const isErr = error?.line === lineNum;
            return (
              <div
                key={lineNum}
                className={`gutter-line${isExec ? ' is-exec' : ''}${isErr ? ' is-error' : ''}`}
              >
                {lineNum}
              </div>
            );
          })}
        </div>

        <div className="editor-code-area">
          <div className="editor-highlight" ref={highlightRef} aria-hidden="true">
            {highlightedLines.map((spans, idx) => {
              const lineNum = idx + 1;
              const isExec = activeLine === lineNum;
              const isErr = error?.line === lineNum;
              const errCol = isErr && error ? Math.max(1, error.column) : null;
              return (
                <div
                  key={lineNum}
                  className={`code-line${isExec ? ' is-exec' : ''}${isErr ? ' is-error' : ''}`}
                >
                  {spans.length === 0 ? (
                    <span>{'\u200b'}</span>
                  ) : (
                    spans.map((span, sIdx) => (
                      <span key={sIdx} className={`tok-${span.kind}`}>
                        {span.text}
                      </span>
                    ))
                  )}
                  {errCol !== null && (
                    <span
                      className="inline-error-caret"
                      style={{ left: `${errCol - 1}ch` }}
                      title={error?.message}
                    />
                  )}
                </div>
              );
            })}
          </div>

          <textarea
            ref={textareaRef}
            className="editor-textarea"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            onScroll={syncScroll}
            aria-label="Edytor programu Logo"
            spellCheck={false}
            autoCapitalize="off"
            autoComplete="off"
            autoCorrect="off"
            wrap="off"
          />
        </div>
      </div>

      {error && (
        <div className="editor-error-banner" role="alert">
          <span className="error-loc">
            Wiersz {error.line}, kolumna {error.column}:
          </span>{' '}
          <span>{error.message}</span>
        </div>
      )}
    </div>
  );
};
