import React, { useEffect, useRef, useState } from 'react';
import { X } from 'lucide-react';
import { STANDARD_EXAMPLES, type ExampleProgram } from '../data/examples';

interface ExamplesModalProps {
  open: boolean;
  onClose: () => void;
  hasUnsavedDraft: (mode: '2d' | '3d') => boolean;
  onSelectExample: (example: ExampleProgram) => void;
}

export const ExamplesModal: React.FC<ExamplesModalProps> = ({
  open,
  onClose,
  hasUnsavedDraft,
  onSelectExample,
}) => {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const [pendingExample, setPendingExample] = useState<ExampleProgram | null>(null);

  useEffect(() => {
    const dlg = dialogRef.current;
    if (!dlg) return;
    if (open && !dlg.open) {
      setPendingExample(null);
      dlg.showModal();
    } else if (!open && dlg.open) {
      dlg.close();
    }
  }, [open]);

  const handleChoose = (ex: ExampleProgram) => {
    if (hasUnsavedDraft(ex.mode)) {
      setPendingExample(ex);
    } else {
      onSelectExample(ex);
      onClose();
    }
  };

  return (
    <dialog
      ref={dialogRef}
      className="modal-dialog"
      aria-labelledby="examples-title"
      onClose={() => {
        setPendingExample(null);
        onClose();
      }}
    >
      <div className="modal-header">
        <h2 id="examples-title">Przykładowe programy</h2>
        <button
          type="button"
          className="icon-btn"
          onClick={onClose}
          aria-label="Zamknij okno przykładów"
        >
          <X size={18} />
        </button>
      </div>

      {pendingExample ? (
        <div className="confirm-box">
          <p>
            Masz niezapisane zmiany w trybie <strong>{pendingExample.mode.toUpperCase()}</strong>.
            Wczytanie przykładu <strong>„{pendingExample.title}”</strong> zastąpi obecny szkic.
          </p>
          <div className="confirm-actions">
            <button
              type="button"
              className="btn btn-secondary"
              autoFocus
              onClick={() => setPendingExample(null)}
            >
              Anuluj
            </button>
            <button
              type="button"
              className="btn btn-primary"
              onClick={() => {
                onSelectExample(pendingExample);
                setPendingExample(null);
                onClose();
              }}
            >
              Zastąp szkic
            </button>
          </div>
        </div>
      ) : (
        <div className="examples-grid">
          {STANDARD_EXAMPLES.map((ex) => (
            <button
              key={ex.id}
              type="button"
              className="example-card"
              onClick={() => handleChoose(ex)}
            >
              <div className="example-card-top">
                <span className="example-title">{ex.title}</span>
                <span className={`mode-pill mode-${ex.mode}`}>{ex.mode.toUpperCase()}</span>
              </div>
              <p className="example-desc">{ex.description}</p>
            </button>
          ))}
        </div>
      )}
    </dialog>
  );
};
