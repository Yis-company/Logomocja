import React, { useEffect, useRef } from 'react';
import { X } from 'lucide-react';

interface HelpModalProps {
  open: boolean;
  onClose: () => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({ open, onClose }) => {
  const dialogRef = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    const dlg = dialogRef.current;
    if (!dlg) return;
    if (open && !dlg.open) {
      dlg.showModal();
    } else if (!open && dlg.open) {
      dlg.close();
    }
  }, [open]);

  return (
    <dialog
      ref={dialogRef}
      className="modal-dialog modal-narrow"
      aria-labelledby="help-title"
      onClose={onClose}
    >
      <div className="modal-header">
        <h2 id="help-title">Skróty klawiszowe i pomoc</h2>
        <button
          type="button"
          className="icon-btn"
          onClick={onClose}
          aria-label="Zamknij okno skrótów"
        >
          <X size={18} />
        </button>
      </div>

      <div className="shortcuts-list">
        <div className="shortcut-row">
          <span>Uruchom program</span>
          <kbd>Ctrl / ⌘ + Enter</kbd>
        </div>
        <div className="shortcut-row">
          <span>Wykonaj jeden krok</span>
          <kbd>Alt + S</kbd>
        </div>
        <div className="shortcut-row">
          <span>Wstrzymaj / wznów animację</span>
          <kbd>Alt + P</kbd>
        </div>
        <div className="shortcut-row">
          <span>Resetuj rysunek i żółwia</span>
          <kbd>Alt + R</kbd>
        </div>
      </div>

      <p className="help-note">
        Szkice w trybach 2D i 3D oraz postęp wyzwań zapisują się automatycznie w pamięci
        przeglądarki (localStorage). Link z przycisku „Udostępnij” koduje aktualny program i tryb w
        adresie URL.
      </p>
    </dialog>
  );
};
