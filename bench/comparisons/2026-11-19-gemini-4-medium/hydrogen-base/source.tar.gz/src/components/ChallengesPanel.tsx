import React, { useMemo, useState } from 'react';
import { CheckCircle2, Play, Trophy } from 'lucide-react';
import {
  CHALLENGES,
  checkChallenge,
  type Challenge,
  type ChallengeCheckResult,
} from '../data/challenges';
import { runLogo } from '../lang/interpreter';

interface ChallengesPanelProps {
  currentCode: string;
  solvedIds: Set<string>;
  onMarkSolved: (id: string) => void;
  onLoadStarter: (challenge: Challenge) => void;
}

const ChallengePreviewSvg: React.FC<{ challenge: Challenge }> = ({ challenge }) => {
  const { paths, viewBox } = useMemo(() => {
    const res = runLogo(challenge.referenceCode, challenge.mode);
    const project = (p: [number, number, number]): [number, number] => {
      if (challenge.mode === '2d') {
        return [p[0], -p[1]];
      }
      // Simple isometric projection for 3D preview
      const x = (p[0] - p[1]) * 0.707;
      const y = (p[0] + p[1]) * 0.35 - p[2] * 0.9;
      return [x, y];
    };

    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    const segs = res.segments.map((s) => {
      const a = project(s.from);
      const b = project(s.to);
      minX = Math.min(minX, a[0], b[0]);
      minY = Math.min(minY, a[1], b[1]);
      maxX = Math.max(maxX, a[0], b[0]);
      maxY = Math.max(maxY, a[1], b[1]);
      return { a, b, color: s.color };
    });

    if (!Number.isFinite(minX)) {
      return { paths: [], viewBox: '0 0 100 100' };
    }
    const pad = 12;
    const w = Math.max(20, maxX - minX + pad * 2);
    const h = Math.max(20, maxY - minY + pad * 2);
    return {
      paths: segs,
      viewBox: `${minX - pad} ${minY - pad} ${w} ${h}`,
    };
  }, [challenge]);

  return (
    <svg className="challenge-svg" viewBox={viewBox} aria-hidden="true">
      {paths.map((seg, i) => (
        <line
          key={i}
          x1={seg.a[0]}
          y1={seg.a[1]}
          x2={seg.b[0]}
          y2={seg.b[1]}
          stroke={seg.color}
          strokeWidth={2.5}
          strokeLinecap="round"
          vectorEffect="non-scaling-stroke"
        />
      ))}
    </svg>
  );
};

export const ChallengesPanel: React.FC<ChallengesPanelProps> = ({
  currentCode,
  solvedIds,
  onMarkSolved,
  onLoadStarter,
}) => {
  const [selectedId, setSelectedId] = useState<string>(CHALLENGES[0].id);
  const [results, setResults] = useState<Record<string, ChallengeCheckResult>>({});

  const selected = CHALLENGES.find((c) => c.id === selectedId) ?? CHALLENGES[0];
  const result = results[selected.id];

  const handleCheck = () => {
    const res = checkChallenge(selected, currentCode);
    setResults((prev) => ({ ...prev, [selected.id]: res }));
    if (res.passed) {
      onMarkSolved(selected.id);
    }
  };

  return (
    <div className="side-panel">
      <div className="challenges-summary">
        <Trophy size={16} />
        <span>
          Ukończono {solvedIds.size} z {CHALLENGES.length} zadań
        </span>
      </div>

      <div className="challenge-tabs" role="tablist" aria-label="Lista wyzwań">
        {CHALLENGES.map((ch) => {
          const isSolved = solvedIds.has(ch.id);
          const isActive = ch.id === selected.id;
          return (
            <button
              key={ch.id}
              type="button"
              role="tab"
              aria-selected={isActive}
              className={`challenge-tab${isActive ? ' is-active' : ''}${isSolved ? ' is-solved' : ''}`}
              onClick={() => setSelectedId(ch.id)}
            >
              <span>{ch.title}</span>
              {isSolved && <CheckCircle2 size={14} aria-label="Zaliczono" />}
            </button>
          );
        })}
      </div>

      <div className="challenge-detail" role="tabpanel">
        <div className="challenge-meta">
          <span className={`mode-pill mode-${selected.mode}`}>{selected.mode.toUpperCase()}</span>
          <span className="diff-pill">{selected.difficulty}</span>
          {solvedIds.has(selected.id) && <span className="solved-pill">Zaliczono</span>}
        </div>

        <p className="challenge-prompt">{selected.prompt}</p>
        <p className="challenge-hint">
          <strong>Wskazówka:</strong> {selected.hint}
        </p>

        <div className="challenge-preview-box">
          <span className="preview-label">Wzór do narysowania:</span>
          <ChallengePreviewSvg challenge={selected} />
        </div>

        <div className="challenge-actions">
          <button
            type="button"
            className="btn btn-secondary"
            onClick={() => onLoadStarter(selected)}
          >
            Otwórz szablon w edytorze
          </button>
          <button type="button" className="btn btn-primary" onClick={handleCheck}>
            <Play size={15} />
            Sprawdź rozwiązanie
          </button>
        </div>

        {result && (
          <div
            className={`challenge-result ${result.passed ? 'is-pass' : 'is-fail'}`}
            role="status"
          >
            {result.reason}
          </div>
        )}
      </div>
    </div>
  );
};
