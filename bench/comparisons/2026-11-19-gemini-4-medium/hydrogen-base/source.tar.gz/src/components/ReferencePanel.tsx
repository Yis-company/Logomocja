import React from 'react';
import { COMMAND_DOCS, DIALECT_SECTIONS } from '../data/reference';

export const ReferencePanel: React.FC = () => {
  return (
    <div className="side-panel reference-panel">
      <p className="ref-intro">
        Wielkość liter nie ma znaczenia. Polskie polecenia (z polskimi znakami lub bez nich) oraz ich
        angielskie odpowiedniki działają identycznie.
      </p>

      <h3 className="ref-heading">Polecenia</h3>
      <div className="ref-table-wrap">
        <table className="ref-table">
          <thead>
            <tr>
              <th>Polskie</th>
              <th>Angielskie</th>
              <th>Argument</th>
              <th>Działanie i przykład</th>
            </tr>
          </thead>
          <tbody>
            {COMMAND_DOCS.map((cmd) => (
              <tr key={cmd.polish}>
                <td>
                  <code>{cmd.polish}</code>
                  {cmd.only3d && <span className="badge-3d">3D</span>}
                </td>
                <td>
                  <code>{cmd.english}</code>
                </td>
                <td>{cmd.arg}</td>
                <td>
                  <div>{cmd.summary}</div>
                  <code className="ref-example">{cmd.example}</code>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {DIALECT_SECTIONS.map((sec) => (
        <section key={sec.title} className="ref-section">
          <h3 className="ref-heading">{sec.title}</h3>
          {sec.body.map((p, idx) => (
            <p key={idx} className="ref-para">
              {p}
            </p>
          ))}
        </section>
      ))}
    </div>
  );
};
