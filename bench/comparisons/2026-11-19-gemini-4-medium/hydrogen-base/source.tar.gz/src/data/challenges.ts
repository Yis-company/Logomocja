import { runLogo } from '../lang/interpreter';
import type { Mode, Segment, Vec3 } from '../lang/types';

export interface Challenge {
  id: string;
  title: string;
  mode: Mode;
  difficulty: 'Łatwe' | 'Średnie' | 'Trudne';
  prompt: string;
  hint: string;
  referenceCode: string;
  starterCode: string;
}

export interface ChallengeCheckResult {
  passed: boolean;
  reason: string;
}

export const CHALLENGES: Challenge[] = [
  {
    id: 'wyzwanie-kwadrat',
    title: '1. Kwadrat o boku 100',
    mode: '2d',
    difficulty: 'Łatwe',
    prompt: 'Narysuj kwadrat o boku 100, zaczynając w punkcie (0, 0).',
    hint: 'Użyj pętli „powtórz 4 [ np 100 pw 90 ]” (albo skręcaj w lewo).',
    referenceCode: 'powtorz 4 [\n  np 100\n  pw 90\n]',
    starterCode: '; Narysuj kwadrat o boku 100\npowtorz 4 [\n  np 100\n  \n]',
  },
  {
    id: 'wyzwanie-trojkat',
    title: '2. Trójkąt równoboczny',
    mode: '2d',
    difficulty: 'Łatwe',
    prompt: 'Narysuj trójkąt równoboczny o boku 120.',
    hint: 'Żółw skręca o kąt zewnętrzny: 360 / 3 = 120 stopni.',
    referenceCode: 'powtorz 3 [\n  np 120\n  pw 120\n]',
    starterCode: '; Trójkąt równoboczny o boku 120\npowtorz 3 [\n  np 120\n  pw 120\n]',
  },
  {
    id: 'wyzwanie-szesciokat',
    title: '3. Sześciokąt foremny',
    mode: '2d',
    difficulty: 'Łatwe',
    prompt: 'Narysuj sześciokąt foremny o boku 70.',
    hint: 'Sześć boków, więc każdy skręt to 360 / 6 = 60 stopni.',
    referenceCode: 'powtorz 6 [\n  np 70\n  pw 60\n]',
    starterCode: '; Sześciokąt foremny o boku 70\n',
  },
  {
    id: 'wyzwanie-domek',
    title: '4. Domek z dachem',
    mode: '2d',
    difficulty: 'Średnie',
    prompt: 'Narysuj kwadrat o boku 100, a nad nim trójkątny dach o boku 100.',
    hint: 'Najpierw narysuj kwadrat (pw 90), potem przejdź na górną krawędź (np 100 pw 30) i narysuj dach.',
    referenceCode: `powtorz 4 [np 100 pw 90]
np 100
pw 30
np 100
pw 120
np 100`,
    starterCode: '; Kwadrat 100x100 i trójkątny dach o boku 100\npowtorz 4 [np 100 pw 90]\n',
  },
  {
    id: 'wyzwanie-wiatrak',
    title: '5. Wiatrak z czterech kwadratów',
    mode: '2d',
    difficulty: 'Średnie',
    prompt: 'Narysuj 4 kwadraty o boku 60 obrócone wokół środka co 90 stopni.',
    hint: 'Zdefiniuj procedurę „kwadrat” albo użyj zagnieżdżonej pętli „powtórz”.',
    referenceCode: `powtorz 4 [
  powtorz 4 [np 60 pw 90]
  pw 90
]`,
    starterCode: '; Cztery kwadraty o boku 60 obrócone co 90 stopni\n',
  },
  {
    id: 'wyzwanie-wieza3d',
    title: '6. Maszt 3D',
    mode: '3d',
    difficulty: 'Średnie',
    prompt: 'W trybie 3D narysuj podstawę (kwadrat o boku 60) i pionowy maszt o wysokości 90 ze środka (0, 0, 0) w górę (+Z).',
    hint: 'Najpierw narysuj kwadrat w płaszczyźnie XY, a potem „gora 90 np 90”.',
    referenceCode: `powtorz 4 [np 60 pw 90]
gora 90
np 90`,
    starterCode: '; Podstawa 60x60 i pionowy maszt wysokości 90 w +Z\n',
  },
];

function sampleSegments(segments: Segment[], step = 2): Vec3[] {
  const pts: Vec3[] = [];
  for (const s of segments) {
    const dx = s.to[0] - s.from[0];
    const dy = s.to[1] - s.from[1];
    const dz = s.to[2] - s.from[2];
    const len = Math.hypot(dx, dy, dz);
    const n = Math.max(1, Math.ceil(len / step));
    for (let i = 0; i <= n; i++) {
      const t = i / n;
      pts.push([s.from[0] + dx * t, s.from[1] + dy * t, s.from[2] + dz * t]);
    }
  }
  return pts;
}

function distSqPointToSeg(p: Vec3, a: Vec3, b: Vec3): number {
  const abx = b[0] - a[0];
  const aby = b[1] - a[1];
  const abz = b[2] - a[2];
  const lenSq = abx * abx + aby * aby + abz * abz;
  if (lenSq === 0) {
    const dx = p[0] - a[0];
    const dy = p[1] - a[1];
    const dz = p[2] - a[2];
    return dx * dx + dy * dy + dz * dz;
  }
  let t = ((p[0] - a[0]) * abx + (p[1] - a[1]) * aby + (p[2] - a[2]) * abz) / lenSq;
  t = Math.max(0, Math.min(1, t));
  const cx = a[0] + t * abx - p[0];
  const cy = a[1] + t * aby - p[1];
  const cz = a[2] + t * abz - p[2];
  return cx * cx + cy * cy + cz * cz;
}

function maxDistToSegments(points: Vec3[], segments: Segment[]): number {
  let maxSq = 0;
  for (const p of points) {
    let bestSq = Infinity;
    for (const s of segments) {
      const d = distSqPointToSeg(p, s.from, s.to);
      if (d < bestSq) bestSq = d;
    }
    if (bestSq > maxSq) maxSq = bestSq;
  }
  return Math.sqrt(maxSq);
}

export function checkChallenge(challenge: Challenge, userCode: string): ChallengeCheckResult {
  const userRes = runLogo(userCode, challenge.mode);
  if (userRes.error) {
    return {
      passed: false,
      reason: `Program zawiera błąd w wierszu ${userRes.error.line}: ${userRes.error.message}`,
    };
  }
  if (userRes.segments.length === 0) {
    return {
      passed: false,
      reason: 'Nic jeszcze nie narysowano. Napisz polecenia rysujące i spróbuj ponownie.',
    };
  }

  const refRes = runLogo(challenge.referenceCode, challenge.mode);
  const tol = 1.5;

  const refPts = sampleSegments(refRes.segments, 2);
  const userPts = sampleSegments(userRes.segments, 2);

  const missingDist = maxDistToSegments(refPts, userRes.segments);
  if (missingDist > tol) {
    return {
      passed: false,
      reason: 'Brakuje części wzorcowego rysunku lub wymiary/kąty różnią się od zadania.',
    };
  }

  const extraDist = maxDistToSegments(userPts, refRes.segments);
  if (extraDist > tol) {
    return {
      passed: false,
      reason: 'Rysunek zawiera dodatkowe linie, których nie ma we wzorze.',
    };
  }

  return {
    passed: true,
    reason: 'Brawo! Twój rysunek idealnie odpowiada wzorowi.',
  };
}
