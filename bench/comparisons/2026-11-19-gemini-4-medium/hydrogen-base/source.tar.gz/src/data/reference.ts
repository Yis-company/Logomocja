export interface CommandDoc {
  polish: string;
  english: string;
  arg: string;
  summary: string;
  example: string;
  only3d?: boolean;
}

export const COMMAND_DOCS: CommandDoc[] = [
  {
    polish: 'np, naprzod, naprzód',
    english: 'fd, forward',
    arg: 'wyrażenie',
    summary: 'Przesuwa żółwia do przodu o podaną odległość.',
    example: 'np 100',
  },
  {
    polish: 'ws, wstecz',
    english: 'bk, back',
    arg: 'wyrażenie',
    summary: 'Przesuwa żółwia do tyłu o podaną odległość.',
    example: 'ws 50',
  },
  {
    polish: 'pw, prawo',
    english: 'rt, right',
    arg: 'wyrażenie',
    summary: 'Obraca żółwia w prawo o podaną liczbę stopni.',
    example: 'pw 90',
  },
  {
    polish: 'lw, lewo',
    english: 'lt, left',
    arg: 'wyrażenie',
    summary: 'Obraca żółwia w lewo o podaną liczbę stopni.',
    example: 'lw 45',
  },
  {
    polish: 'pod, podnies, podnieś',
    english: 'pu, penup',
    arg: 'brak',
    summary: 'Podnosi pisak — ruchy żółwia nie zostawiają śladu.',
    example: 'pod np 40 opu',
  },
  {
    polish: 'opu, opusc, opuść',
    english: 'pd, pendown',
    arg: 'brak',
    summary: 'Opuszcza pisak — żółw znów rysuje podczas ruchu.',
    example: 'opu np 80',
  },
  {
    polish: 'kolor',
    english: 'color',
    arg: '"#rrggbb"',
    summary: 'Ustawia kolor pisaka jako sześciocyfrowy kod szesnastkowy w cudzysłowie.',
    example: 'kolor "#16866a"',
  },
  {
    polish: 'grubosc, grubość',
    english: 'width',
    arg: 'liczba całkowita 1–12',
    summary: 'Ustawia grubość linii od 1 do 12 pikseli.',
    example: 'grubosc 3',
  },
  {
    polish: 'powtorz, powtórz',
    english: 'repeat',
    arg: 'liczba 0–10000, [ blok ]',
    summary: 'Wykonuje blok poleceń zadaną liczbę razy. Wewnątrz działa licznik nrpowt (od 1).',
    example: 'powtorz 4 [np 80 pw 90]',
  },
  {
    polish: 'niech',
    english: 'let',
    arg: 'nazwa wyrażenie',
    summary: 'Tworzy lub zmienia wartość zmiennej (globalnej na poziomie głównym, lokalnej w procedurze).',
    example: 'niech bok 60',
  },
  {
    polish: 'jeśli, jesli',
    english: 'if',
    arg: 'warunek [ blok ]',
    summary: 'Wykonuje blok, gdy warunek jest spełniony.',
    example: 'jeśli bok > 10 [np bok]',
  },
  {
    polish: 'jeżeli, jezeli',
    english: 'ifelse',
    arg: 'warunek [ tak ] [ nie ]',
    summary: 'Wykonuje pierwszy blok, gdy warunek jest spełniony, w przeciwnym razie drugi.',
    example: 'jeżeli n > 0 [np 20] [ws 20]',
  },
  {
    polish: 'stop',
    english: 'stop',
    arg: 'brak',
    summary: 'Kończy bieżącą procedurę lub (na poziomie głównym) cały program.',
    example: 'jeśli dł < 5 [stop]',
  },
  {
    polish: 'dom',
    english: 'home',
    arg: 'brak',
    summary: 'Wraca do początku układu (0, 0, 0) i początkowej orientacji (rysuje, jeśli pisak jest opuszczony).',
    example: 'dom',
  },
  {
    polish: 'czyść, czysc',
    english: 'cs, clearscreen',
    arg: 'brak',
    summary: 'Usuwa wszystkie narysowane dotąd odcinki, nie zmieniając pozycji ani ustawień żółwia.',
    example: 'czyść',
  },
  {
    polish: 'gora, góra',
    english: 'pitchup',
    arg: 'wyrażenie',
    summary: 'Pochyla dziób żółwia w górę o podaną liczbę stopni.',
    example: 'gora 90',
    only3d: true,
  },
  {
    polish: 'dol, dół',
    english: 'pitchdown',
    arg: 'wyrażenie',
    summary: 'Pochyla dziób żółwia w dół o podaną liczbę stopni.',
    example: 'dol 45',
    only3d: true,
  },
  {
    polish: 'pp, przechylprawo',
    english: 'rr, rollright',
    arg: 'wyrażenie',
    summary: 'Obraca żółwia wokół osi jego kierunku ruchu w prawo.',
    example: 'pp 15',
    only3d: true,
  },
  {
    polish: 'pl, przechyllewo',
    english: 'rl, rollleft',
    arg: 'wyrażenie',
    summary: 'Obraca żółwia wokół osi jego kierunku ruchu w lewo.',
    example: 'pl 30',
    only3d: true,
  },
];

export const DIALECT_SECTIONS = [
  {
    title: 'Wyrażenia i operatory',
    body: [
      'W miejscach oczekujących liczby można używać liczb dziesiętnych (np. 80, 12.5, .5), nazw zmiennych lub parametrów (także w starszym zapisie :nazwa), licznika nrpowt (alias repcount), nawiasów ( ) oraz operatorów +, -, *, /.',
      'Mnożenie i dzielenie mają wyższy priorytet niż dodawanie i odejmowanie, a operatory o równym priorytecie łączą się od lewej: np 20 - 5 - 3 przesunie żółwia o 12.',
      'Operator dwuargumentowy (+, -, *, /) musi mieć odstęp po obu stronach albo po żadnej: np 10 - 5 i np 10-5 są poprawne, ale np 10 -5 jest błędem. Operatory jednoargumentowe (+ i -) można stawiać przed wyrażeniem, np. np -(3 - 5) lub np - -2.',
      'Dzielenie przez zero oraz wyniki nieliczbowe są błędami wykonania.',
    ],
  },
  {
    title: 'Zmienne i pętle',
    body: [
      'Zmienna zadeklarowana przez niech na poziomie głównym jest globalna. Zmienna utworzona przez niech wewnątrz procedury jest lokalna dla danego wywołania i przesłania zmienną globalną o tej samej nazwie.',
      'Wewnątrz pętli powtórz słowo nrpowt (alias repcount) daje numer bieżącego powtórzenia, licząc od 1. Użycie nrpowt poza leksykalnym blokiem powtórz (np. w procedurze wywoływanej z pętli) jest błędem.',
    ],
  },
  {
    title: 'Warunki',
    body: [
      'Warunek ma postać wyrażenie operator wyrażenie, gdzie operatorem porównania jest <, >, =, <=, >= lub <> (różne).',
      'Porównania są dokładne (np. 0.1 + 0.2 = 0.3 nie jest spełnione z powodu arytmetyki zmiennoprzecinkowej).',
    ],
  },
  {
    title: 'Procedury',
    body: [
      'Definicja procedury zaczyna się od słowa oto (alias to) na początku wiersza, po którym następuje nazwa oraz opcjonalnie ma: i lista parametrów oddzielonych przecinkami (lub starszy zapis :param1 :param2). Ciało procedury kończy się słowem już (aliasy juz, end) stojącym samodzielnie w wierszu.',
      'Procedury można definiować wyłącznie na poziomie głównym — przed lub po wywołaniach, które z nich korzystają. Procedura może wywoływać samą siebie (rekurencja).',
    ],
  },
  {
    title: 'Limity środowiska',
    body: [
      'Maksymalna długość kodu źródłowego: 50 000 znaków.',
      'Maksymalna liczba tokenów: 10 000.',
      'Maksymalna głębokość nawiasów kwadratowych [ ]: 32.',
      'Maksymalna liczba aktywnych ramek wywołań procedur i pętli powtórz: 32.',
      'Maksymalna liczba wykonanych operacji: 10 000.',
      'Maksymalna liczba przechowywanych odcinków: 10 000 (polecenie czyść zeruje licznik).',
      'Dozwolony zakres współrzędnych X, Y, Z: od -100 000 do +100 000.',
    ],
  },
];
