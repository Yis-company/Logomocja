import { LIMITS, tokenize } from './lexer';
import { parseProgram, toLogoError } from './parser';
import type {
  Condition,
  Expr,
  LogoError,
  Mode,
  Program,
  RunResult,
  Segment,
  Stmt,
  TurtleState,
  Vec3,
} from './types';

export class RuntimeError extends Error {
  readonly logoError: LogoError;
  constructor(message: string, line: number, column: number) {
    super(message);
    this.logoError = { message, line, column };
  }
}

export function createInitialTurtle(): TurtleState {
  return {
    pos: [0, 0, 0],
    heading: [0, 1, 0],
    right: [1, 0, 0],
    up: [0, 0, 1],
    penDown: true,
    color: '#16866a',
    width: 3,
  };
}

function cross(a: Vec3, b: Vec3): Vec3 {
  return [
    a[1] * b[2] - a[2] * b[1],
    a[2] * b[0] - a[0] * b[2],
    a[0] * b[1] - a[1] * b[0],
  ];
}

function dot(a: Vec3, b: Vec3): number {
  return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}

function normalize(v: Vec3): Vec3 {
  const len = Math.hypot(v[0], v[1], v[2]);
  if (len === 0) return [0, 0, 0];
  return [v[0] / len, v[1] / len, v[2] / len];
}

function rotateAroundAxis(v: Vec3, axis: Vec3, deg: number): Vec3 {
  const rad = (deg * Math.PI) / 180;
  const c = Math.cos(rad);
  const s = Math.sin(rad);
  const kCrossV = cross(axis, v);
  const kDotV = dot(axis, v);
  return [
    v[0] * c + kCrossV[0] * s + axis[0] * kDotV * (1 - c),
    v[1] * c + kCrossV[1] * s + axis[1] * kDotV * (1 - c),
    v[2] * c + kCrossV[2] * s + axis[2] * kDotV * (1 - c),
  ];
}

function orthonormalize(t: TurtleState): void {
  t.heading = normalize(t.heading);
  t.right = normalize(cross(t.heading, t.up));
  t.up = normalize(cross(t.right, t.heading));
}

type Frame =
  | { kind: 'top'; stmts: Stmt[]; ip: number }
  | { kind: 'proc'; stmts: Stmt[]; ip: number; locals: Map<string, number>; line: number; column: number }
  | { kind: 'repeat'; stmts: Stmt[]; ip: number; total: number; iter: number; line: number; column: number }
  | { kind: 'cond'; stmts: Stmt[]; ip: number; line: number; column: number };

export interface StepSnapshot {
  done: boolean;
  currentLine: number | null;
  segments: Segment[];
  turtle: TurtleState;
  error: LogoError | null;
}

export class LogoStepper {
  readonly program: Program;
  readonly mode: Mode;
  readonly segments: Segment[] = [];
  readonly turtle: TurtleState = createInitialTurtle();
  readonly globals = new Map<string, number>();
  private frames: Frame[];
  private opCount = 0;
  private finished = false;
  private error: LogoError | null = null;

  constructor(program: Program, mode: Mode) {
    this.program = program;
    this.mode = mode;
    this.frames = [{ kind: 'top', stmts: program.body, ip: 0 }];
  }

  isDone(): boolean {
    return this.finished || this.error !== null;
  }

  getCurrentLine(): number | null {
    if (this.isDone()) return null;
    for (let i = this.frames.length - 1; i >= 0; i--) {
      const f = this.frames[i];
      if (f.ip < f.stmts.length) {
        return f.stmts[f.ip].line;
      }
    }
    return null;
  }

  snapshot(): StepSnapshot {
    return {
      done: this.finished,
      currentLine: this.getCurrentLine(),
      segments: this.segments,
      turtle: {
        pos: [...this.turtle.pos],
        heading: [...this.turtle.heading],
        right: [...this.turtle.right],
        up: [...this.turtle.up],
        penDown: this.turtle.penDown,
        color: this.turtle.color,
        width: this.turtle.width,
      },
      error: this.error,
    };
  }

  private bumpOp(line: number, column: number): void {
    this.opCount++;
    if (this.opCount > LIMITS.MAX_OPS) {
      throw new RuntimeError(
        `Przekroczono limit wykonanych operacji (${LIMITS.MAX_OPS}).`,
        line,
        column,
      );
    }
  }

  private countActiveFrames(): number {
    let c = 0;
    for (const f of this.frames) {
      if (f.kind === 'proc' || f.kind === 'repeat') c++;
    }
    return c;
  }

  private lookupVar(name: string, rootLine: number, rootCol: number): number {
    for (let i = this.frames.length - 1; i >= 0; i--) {
      const f = this.frames[i];
      if (f.kind === 'proc') {
        if (f.locals.has(name)) {
          return f.locals.get(name)!;
        }
        break;
      }
    }
    if (this.globals.has(name)) {
      return this.globals.get(name)!;
    }
    throw new RuntimeError(`Zmienna „${name}” nie została jeszcze przypisana.`, rootLine, rootCol);
  }

  private assignVar(name: string, value: number): void {
    for (let i = this.frames.length - 1; i >= 0; i--) {
      const f = this.frames[i];
      if (f.kind === 'proc') {
        f.locals.set(name, value);
        return;
      }
    }
    this.globals.set(name, value);
  }

  private currentRepCount(): number {
    for (let i = this.frames.length - 1; i >= 0; i--) {
      const f = this.frames[i];
      if (f.kind === 'repeat') return f.iter;
      if (f.kind === 'proc') break;
    }
    throw new RuntimeError('Brak aktywnej pętli „powtórz”.', 1, 1);
  }

  private evalExpr(expr: Expr, rootLine: number, rootCol: number): number {
    switch (expr.kind) {
      case 'number':
        return expr.value;
      case 'var':
        return this.lookupVar(expr.name, rootLine, rootCol);
      case 'repcount':
        return this.currentRepCount();
      case 'unary': {
        const v = this.evalExpr(expr.expr, rootLine, rootCol);
        return expr.op === '-' ? -v : v;
      }
      case 'binary': {
        const l = this.evalExpr(expr.left, rootLine, rootCol);
        const r = this.evalExpr(expr.right, rootLine, rootCol);
        let res: number;
        if (expr.op === '+') res = l + r;
        else if (expr.op === '-') res = l - r;
        else if (expr.op === '*') res = l * r;
        else {
          if (r === 0) {
            throw new RuntimeError('Dzielenie przez zero.', rootLine, rootCol);
          }
          res = l / r;
        }
        if (!Number.isFinite(res)) {
          throw new RuntimeError('Wynik wyrażenia wykracza poza zakres liczbowy.', rootLine, rootCol);
        }
        return res;
      }
    }
  }

  private evalArg(expr: Expr): number {
    return this.evalExpr(expr, expr.line, expr.column);
  }

  private evalCondition(cond: Condition): boolean {
    const l = this.evalArg(cond.left);
    const r = this.evalArg(cond.right);
    switch (cond.op) {
      case '<':
        return l < r;
      case '>':
        return l > r;
      case '=':
        return l === r;
      case '<=':
        return l <= r;
      case '>=':
        return l >= r;
      case '<>':
        return l !== r;
    }
  }

  private moveTurtle(dist: number, line: number, column: number): void {
    if (dist === 0) return;
    const oldPos: Vec3 = [...this.turtle.pos];
    const newPos: Vec3 = [
      oldPos[0] + this.turtle.heading[0] * dist,
      oldPos[1] + this.turtle.heading[1] * dist,
      oldPos[2] + this.turtle.heading[2] * dist,
    ];
    if (
      !Number.isFinite(newPos[0]) ||
      !Number.isFinite(newPos[1]) ||
      !Number.isFinite(newPos[2]) ||
      Math.abs(newPos[0]) > LIMITS.MAX_COORD ||
      Math.abs(newPos[1]) > LIMITS.MAX_COORD ||
      Math.abs(newPos[2]) > LIMITS.MAX_COORD
    ) {
      throw new RuntimeError(
        `Żółw wyszedł poza dozwolony obszar (±${LIMITS.MAX_COORD}).`,
        line,
        column,
      );
    }
    this.turtle.pos = newPos;
    if (this.turtle.penDown) {
      if (this.segments.length >= LIMITS.MAX_SEGMENTS) {
        throw new RuntimeError(
          `Przekroczono limit odcinków (${LIMITS.MAX_SEGMENTS}).`,
          line,
          column,
        );
      }
      this.segments.push({
        from: oldPos,
        to: [...newPos],
        color: this.turtle.color,
        width: this.turtle.width,
      });
    }
  }

  /** Executes a single statement or frame transition. Returns true if still running. */
  step(): boolean {
    if (this.isDone()) return false;

    try {
      while (true) {
        const top = this.frames[this.frames.length - 1];
        if (top.ip >= top.stmts.length) {
          if (top.kind === 'top') {
            this.finished = true;
            return false;
          }
          if (top.kind === 'cond' || top.kind === 'proc') {
            this.bumpOp(top.line, top.column);
            this.frames.pop();
            continue;
          }
          if (top.kind === 'repeat') {
            this.bumpOp(top.line, top.column);
            if (top.iter < top.total) {
              top.iter++;
              top.ip = 0;
              continue;
            }
            this.frames.pop();
            continue;
          }
        }

        const stmt = top.stmts[top.ip++];
        this.bumpOp(stmt.line, stmt.column);

        switch (stmt.kind) {
          case 'fd':
            this.moveTurtle(this.evalArg(stmt.expr), stmt.line, stmt.column);
            return true;
          case 'bk':
            this.moveTurtle(-this.evalArg(stmt.expr), stmt.line, stmt.column);
            return true;
          case 'rt': {
            const a = this.evalArg(stmt.expr);
            this.turtle.heading = rotateAroundAxis(this.turtle.heading, this.turtle.up, -a);
            this.turtle.right = rotateAroundAxis(this.turtle.right, this.turtle.up, -a);
            orthonormalize(this.turtle);
            return true;
          }
          case 'lt': {
            const a = this.evalArg(stmt.expr);
            this.turtle.heading = rotateAroundAxis(this.turtle.heading, this.turtle.up, a);
            this.turtle.right = rotateAroundAxis(this.turtle.right, this.turtle.up, a);
            orthonormalize(this.turtle);
            return true;
          }
          case 'pitchup': {
            const a = this.evalArg(stmt.expr);
            this.turtle.heading = rotateAroundAxis(this.turtle.heading, this.turtle.right, a);
            this.turtle.up = rotateAroundAxis(this.turtle.up, this.turtle.right, a);
            orthonormalize(this.turtle);
            return true;
          }
          case 'pitchdown': {
            const a = this.evalArg(stmt.expr);
            this.turtle.heading = rotateAroundAxis(this.turtle.heading, this.turtle.right, -a);
            this.turtle.up = rotateAroundAxis(this.turtle.up, this.turtle.right, -a);
            orthonormalize(this.turtle);
            return true;
          }
          case 'rr': {
            const a = this.evalArg(stmt.expr);
            this.turtle.up = rotateAroundAxis(this.turtle.up, this.turtle.heading, a);
            this.turtle.right = rotateAroundAxis(this.turtle.right, this.turtle.heading, a);
            orthonormalize(this.turtle);
            return true;
          }
          case 'rl': {
            const a = this.evalArg(stmt.expr);
            this.turtle.up = rotateAroundAxis(this.turtle.up, this.turtle.heading, -a);
            this.turtle.right = rotateAroundAxis(this.turtle.right, this.turtle.heading, -a);
            orthonormalize(this.turtle);
            return true;
          }
          case 'pu':
            this.turtle.penDown = false;
            return true;
          case 'pd':
            this.turtle.penDown = true;
            return true;
          case 'color':
            this.turtle.color = stmt.color;
            return true;
          case 'width': {
            const w = this.evalArg(stmt.expr);
            if (!Number.isInteger(w) || w < 1 || w > 12) {
              throw new RuntimeError(
                'Grubość pisaka musi być liczbą całkowitą od 1 do 12.',
                stmt.expr.line,
                stmt.expr.column,
              );
            }
            this.turtle.width = w;
            return true;
          }
          case 'let': {
            const val = this.evalArg(stmt.expr);
            this.assignVar(stmt.name, val);
            return true;
          }
          case 'home': {
            const oldPos: Vec3 = [...this.turtle.pos];
            const moved = oldPos[0] !== 0 || oldPos[1] !== 0 || oldPos[2] !== 0;
            if (moved && this.turtle.penDown) {
              if (this.segments.length >= LIMITS.MAX_SEGMENTS) {
                throw new RuntimeError(
                  `Przekroczono limit odcinków (${LIMITS.MAX_SEGMENTS}).`,
                  stmt.line,
                  stmt.column,
                );
              }
              this.segments.push({
                from: oldPos,
                to: [0, 0, 0],
                color: this.turtle.color,
                width: this.turtle.width,
              });
            }
            this.turtle.pos = [0, 0, 0];
            this.turtle.heading = [0, 1, 0];
            this.turtle.right = [1, 0, 0];
            this.turtle.up = [0, 0, 1];
            return true;
          }
          case 'cs':
            this.segments.length = 0;
            return true;
          case 'stop': {
            while (this.frames.length > 0) {
              const f = this.frames[this.frames.length - 1];
              if (f.kind === 'top') {
                this.finished = true;
                return false;
              }
              this.frames.pop();
              if (f.kind === 'proc') {
                return true;
              }
            }
            this.finished = true;
            return false;
          }
          case 'repeat': {
            const count = this.evalArg(stmt.count);
            if (!Number.isInteger(count) || count < 0 || count > 10000) {
              throw new RuntimeError(
                'Liczba powtórzeń musi być liczbą całkowitą od 0 do 10000.',
                stmt.count.line,
                stmt.count.column,
              );
            }
            if (count > 0) {
              if (this.countActiveFrames() >= LIMITS.MAX_FRAMES) {
                throw new RuntimeError(
                  `Przekroczono limit zagnieżdżenia wywołań i pętli (${LIMITS.MAX_FRAMES}).`,
                  stmt.line,
                  stmt.column,
                );
              }
              this.frames.push({
                kind: 'repeat',
                stmts: stmt.body,
                ip: 0,
                total: count,
                iter: 1,
                line: stmt.line,
                column: stmt.column,
              });
            }
            return true;
          }
          case 'if': {
            if (this.evalCondition(stmt.cond)) {
              this.frames.push({
                kind: 'cond',
                stmts: stmt.body,
                ip: 0,
                line: stmt.line,
                column: stmt.column,
              });
            }
            return true;
          }
          case 'ifelse': {
            const body = this.evalCondition(stmt.cond) ? stmt.thenBody : stmt.elseBody;
            this.frames.push({
              kind: 'cond',
              stmts: body,
              ip: 0,
              line: stmt.line,
              column: stmt.column,
            });
            return true;
          }
          case 'call': {
            const proc = this.program.procedures.get(stmt.name)!;
            if (this.countActiveFrames() >= LIMITS.MAX_FRAMES) {
              throw new RuntimeError(
                `Przekroczono limit zagnieżdżenia wywołań i pętli (${LIMITS.MAX_FRAMES}).`,
                stmt.line,
                stmt.column,
              );
            }
            const locals = new Map<string, number>();
            for (let i = 0; i < proc.params.length; i++) {
              locals.set(proc.params[i], this.evalArg(stmt.args[i]));
            }
            this.frames.push({
              kind: 'proc',
              stmts: proc.body,
              ip: 0,
              locals,
              line: stmt.line,
              column: stmt.column,
            });
            return true;
          }
        }
      }
    } catch (err) {
      if (err instanceof RuntimeError) {
        this.error = err.logoError;
      } else {
        this.error = {
          message: err instanceof Error ? err.message : 'Nieznany błąd wykonania.',
          line: 1,
          column: 1,
        };
      }
      return false;
    }
  }
}

export function compileLogo(source: string, mode: Mode): { program: Program | null; error: LogoError | null } {
  try {
    const tokens = tokenize(source);
    const program = parseProgram(tokens, mode);
    return { program, error: null };
  } catch (err) {
    return { program: null, error: toLogoError(err) };
  }
}

export function runLogo(source: string, mode: Mode): RunResult {
  const { program, error } = compileLogo(source, mode);
  if (error || !program) {
    return { segments: [], error };
  }
  const stepper = new LogoStepper(program, mode);
  while (stepper.step()) {
    // run to completion
  }
  const snap = stepper.snapshot();
  return {
    segments: snap.segments,
    error: snap.error,
  };
}
