export type Mode = '2d' | '3d';

export type Vec3 = [number, number, number];

export interface Segment {
  from: Vec3;
  to: Vec3;
  color: string;
  width: number;
}

export interface TurtleState {
  pos: Vec3;
  heading: Vec3;
  right: Vec3;
  up: Vec3;
  penDown: boolean;
  color: string;
  width: number;
}

export interface LogoError {
  message: string;
  line: number;
  column: number;
}

export interface RunResult {
  segments: Segment[];
  error: LogoError | null;
}

export type TokenType =
  | 'NUMBER'
  | 'WORD'
  | 'LEGACY_VAR'
  | 'STRING'
  | 'LBRACKET'
  | 'RBRACKET'
  | 'LPAREN'
  | 'RPAREN'
  | 'COMMA'
  | 'OP'
  | 'CMP'
  | 'NEWLINE'
  | 'EOF';

export interface Token {
  type: TokenType;
  value: string;
  line: number;
  column: number;
  spaceBefore: boolean;
  spaceAfter: boolean;
  atLineStart: boolean;
}

export type BinOp = '+' | '-' | '*' | '/';
export type CmpOp = '<' | '>' | '=' | '<=' | '>=' | '<>';

export type Expr =
  | { kind: 'number'; value: number; line: number; column: number }
  | { kind: 'var'; name: string; line: number; column: number }
  | { kind: 'repcount'; line: number; column: number }
  | { kind: 'unary'; op: '+' | '-'; expr: Expr; line: number; column: number }
  | { kind: 'binary'; op: BinOp; left: Expr; right: Expr; line: number; column: number };

export interface Condition {
  left: Expr;
  op: CmpOp;
  right: Expr;
  line: number;
  column: number;
}

export type Stmt =
  | { kind: 'fd' | 'bk' | 'rt' | 'lt' | 'pitchup' | 'pitchdown' | 'rr' | 'rl'; expr: Expr; line: number; column: number }
  | { kind: 'pu' | 'pd' | 'stop' | 'home' | 'cs'; line: number; column: number }
  | { kind: 'color'; color: string; line: number; column: number }
  | { kind: 'width'; expr: Expr; line: number; column: number }
  | { kind: 'let'; name: string; expr: Expr; line: number; column: number }
  | { kind: 'repeat'; count: Expr; body: Stmt[]; line: number; column: number }
  | { kind: 'if'; cond: Condition; body: Stmt[]; line: number; column: number }
  | { kind: 'ifelse'; cond: Condition; thenBody: Stmt[]; elseBody: Stmt[]; line: number; column: number }
  | { kind: 'call'; name: string; args: Expr[]; line: number; column: number };

export interface ProcedureDef {
  name: string;
  params: string[];
  body: Stmt[];
  line: number;
  column: number;
}

export interface Program {
  procedures: Map<string, ProcedureDef>;
  body: Stmt[];
  topLevelVars: Set<string>;
}
