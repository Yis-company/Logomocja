import { describe, expect, test } from 'bun:test';
import { STANDARD_EXAMPLES } from '../../data/examples';
import { runLogo } from '../interpreter';

describe('Standard programs', () => {
  for (const ex of STANDARD_EXAMPLES) {
    test(`runs ${ex.id} (${ex.mode}) without error`, () => {
      const res = runLogo(ex.code, ex.mode);
      expect(res.error).toBeNull();
      expect(res.segments.length).toBeGreaterThan(0);
    });
  }

  test('kwadrat draws 4 segments of length 120 and closes at origin', () => {
    const kwadrat = STANDARD_EXAMPLES.find((e) => e.id === 'kwadrat')!;
    const res = runLogo(kwadrat.code, '2d');
    expect(res.error).toBeNull();
    expect(res.segments).toHaveLength(4);
    const last = res.segments[3].to;
    expect(last[0]).toBeCloseTo(0, 6);
    expect(last[1]).toBeCloseTo(0, 6);
    expect(last[2]).toBeCloseTo(0, 6);
  });

  test('sniezynka draws 768 segments', () => {
    const sniezynka = STANDARD_EXAMPLES.find((e) => e.id === 'sniezynka')!;
    const res = runLogo(sniezynka.code, '2d');
    expect(res.error).toBeNull();
    expect(res.segments).toHaveLength(768);
  });

  test('schody climbs in +Z', () => {
    const schody = STANDARD_EXAMPLES.find((e) => e.id === 'schody')!;
    const res = runLogo(schody.code, '3d');
    expect(res.error).toBeNull();
    expect(res.segments).toHaveLength(12);
    expect(res.segments[11].to[2]).toBeCloseTo(120, 6);
  });

  test('flat 2D programs produce identical coordinates in 2D and 3D', () => {
    for (const ex of STANDARD_EXAMPLES.filter((e) => e.mode === '2d')) {
      const r2 = runLogo(ex.code, '2d');
      const r3 = runLogo(ex.code, '3d');
      expect(r2.error).toBeNull();
      expect(r3.error).toBeNull();
      expect(r2.segments).toEqual(r3.segments);
    }
  });
});

describe('Lexical rules and expressions', () => {
  test('case-insensitive keywords and Polish/English aliases', () => {
    const res = runLogo('FD 50 RT 90 NAPRZÓD 50 PRAWO 90', '2d');
    expect(res.error).toBeNull();
    expect(res.segments).toHaveLength(2);
    expect(res.segments[1].to[0]).toBeCloseTo(50, 6);
    expect(res.segments[1].to[1]).toBeCloseTo(50, 6);
  });

  test('number literals: 80, 12.5, .5 valid; 1e3, 0x10, 12. invalid', () => {
    expect(runLogo('np .5', '2d').error).toBeNull();
    expect(runLogo('np 12.5', '2d').error).toBeNull();
    expect(runLogo('np 1e3', '2d').error).not.toBeNull();
    expect(runLogo('np 0x10', '2d').error).not.toBeNull();
    expect(runLogo('np 12.', '2d').error).not.toBeNull();
    expect(runLogo('np NaN', '2d').error).not.toBeNull();
    expect(runLogo('np Infinity', '2d').error).not.toBeNull();
  });

  test('operator precedence and associativity', () => {
    const r1 = runLogo('np 20 - 5 - 3', '2d');
    expect(r1.error).toBeNull();
    expect(r1.segments[0].to[1]).toBeCloseTo(12, 6);

    const r2 = runLogo('np 2 + 3 * 4', '2d');
    expect(r2.error).toBeNull();
    expect(r2.segments[0].to[1]).toBeCloseTo(14, 6);
  });

  test('binary operator whitespace rule', () => {
    expect(runLogo('np 10 - 5', '2d').segments[0].to[1]).toBeCloseTo(5, 6);
    expect(runLogo('np 10-5', '2d').segments[0].to[1]).toBeCloseTo(5, 6);
    expect(runLogo('np 10 + -5', '2d').segments[0].to[1]).toBeCloseTo(5, 6);
    expect(runLogo('np 10+-5', '2d').segments[0].to[1]).toBeCloseTo(5, 6);

    const errLeft = runLogo('np 10 -5', '2d');
    expect(errLeft.segments).toEqual([]);
    expect(errLeft.error).not.toBeNull();
    expect(errLeft.error?.line).toBe(1);
    expect(errLeft.error?.column).toBe(7);

    const errRight = runLogo('np 10- 5', '2d');
    expect(errRight.segments).toEqual([]);
    expect(errRight.error).not.toBeNull();
  });

  test('unary signs and stacking', () => {
    const r = runLogo('np -(3 - 5) np - -2', '2d');
    expect(r.error).toBeNull();
    expect(r.segments[0].to[1]).toBeCloseTo(2, 6);
    expect(r.segments[1].to[1]).toBeCloseTo(4, 6);
  });

  test('exact comparisons', () => {
    const r = runLogo('jeśli 0.1 + 0.2 = 0.3 [np 50]', '2d');
    expect(r.error).toBeNull();
    expect(r.segments).toHaveLength(0);

    const r2 = runLogo('jeśli 1 + 2 = 3 [np 50]', '2d');
    expect(r2.error).toBeNull();
    expect(r2.segments).toHaveLength(1);
  });
});

describe('3D turtle geometry', () => {
  test('pitchup, pitchdown, rollright, rollleft', () => {
    const r = runLogo('gora 90 np 10 pp 90 gora 90 np 10', '3d');
    expect(r.error).toBeNull();
    expect(r.segments).toHaveLength(2);
    // Start (0,0,0), heading +Y, right +X, up +Z.
    // gora 90 -> heading +Z, up -Y, right +X. np 10 -> (0, 0, 10).
    expect(r.segments[0].to[0]).toBeCloseTo(0, 6);
    expect(r.segments[0].to[1]).toBeCloseTo(0, 6);
    expect(r.segments[0].to[2]).toBeCloseTo(10, 6);
    // pp 90 -> up becomes right (+X), right becomes -up (+Y).
    // gora 90 -> heading becomes up (+X). np 10 -> (10, 0, 10).
    expect(r.segments[1].to[0]).toBeCloseTo(10, 6);
    expect(r.segments[1].to[1]).toBeCloseTo(0, 6);
    expect(r.segments[1].to[2]).toBeCloseTo(10, 6);
  });

  test('3D commands rejected at parse time in 2D mode', () => {
    const r = runLogo('np 20\ngora 90', '2d');
    expect(r.segments).toEqual([]);
    expect(r.error).not.toBeNull();
    expect(r.error?.line).toBe(2);
    expect(r.error?.column).toBe(1);
  });
});

describe('Procedures, variables, repeat, and czyść', () => {
  test('legacy procedure syntax and forward calls', () => {
    const code = `
      kreska 40
      oto kreska :dł
        np :dł
      już
    `;
    const r = runLogo(code, '2d');
    expect(r.error).toBeNull();
    expect(r.segments).toHaveLength(1);
    expect(r.segments[0].to[1]).toBeCloseTo(40, 6);
  });

  test('parameter sharing name with procedure', () => {
    const code = `
      oto f ma: f
        jeśli f > 0 [np 10 f f - 1]
      już
      f 3
    `;
    const r = runLogo(code, '2d');
    expect(r.error).toBeNull();
    expect(r.segments).toHaveLength(3);
  });

  test('stop inside repeat exits procedure, at top level exits program', () => {
    const code = `
      oto testproc
        powtorz 5 [
          np 10
          jeśli nrpowt = 2 [stop]
        ]
        np 100
      już
      testproc
      np 5
      stop
      np 999
    `;
    const r = runLogo(code, '2d');
    expect(r.error).toBeNull();
    expect(r.segments).toHaveLength(3); // 10, 10, 5
  });

  test('nrpowt outside lexical repeat is parse-time error', () => {
    const code = `
      oto p
        np nrpowt
      już
      powtorz 3 [p]
    `;
    const r = runLogo(code, '2d');
    expect(r.segments).toEqual([]);
    expect(r.error).not.toBeNull();
  });

  test('czyść clears segments and resets kept segment count', () => {
    const code = `
      np 50
      czyść
      np 25
    `;
    const r = runLogo(code, '2d');
    expect(r.error).toBeNull();
    expect(r.segments).toHaveLength(1);
    expect(r.segments[0].from[1]).toBeCloseTo(50, 6);
    expect(r.segments[0].to[1]).toBeCloseTo(75, 6);
  });
});

describe('Errors and limits', () => {
  test('runtime error keeps segments drawn so far and reports at first token of bad arg', () => {
    const code = `np 20
jeśli 1 = 2 [niech x 5]
np x + 1`;
    const r = runLogo(code, '2d');
    expect(r.segments).toHaveLength(1);
    expect(r.error).not.toBeNull();
    expect(r.error?.line).toBe(3);
    expect(r.error?.column).toBe(4);
  });

  test('division by zero at runtime keeps segments drawn before it', () => {
    const code = `np 10\nniech a 0\nnp 5 / a`;
    const r = runLogo(code, '2d');
    expect(r.segments).toHaveLength(1);
    expect(r.error).not.toBeNull();
    expect(r.error?.line).toBe(3);
    expect(r.error?.column).toBe(4);
  });

  test('missing argument reported at ] or command at EOF', () => {
    const r1 = runLogo('powtorz 2 [np]', '2d');
    expect(r1.error?.line).toBe(1);
    expect(r1.error?.column).toBe(14);

    const r2 = runLogo('np', '2d');
    expect(r2.error?.line).toBe(1);
    expect(r2.error?.column).toBe(1);
  });

  test('limits: bracket depth, frames, ops, coords', () => {
    // 33 nested repeats -> bracket depth > 32
    const deepBrackets = 'powtorz 1 ['.repeat(33) + 'np 1' + ']'.repeat(33);
    expect(runLogo(deepBrackets, '2d').error).not.toBeNull();

    // 33 recursive calls -> frame limit 32
    const deepRec = `
      oto rec ma: n
        jeśli n > 0 [rec n - 1]
      już
      rec 40
    `;
    expect(runLogo(deepRec, '2d').error).not.toBeNull();

    // > 10000 ops
    const manyOps = 'powtorz 6000 [np 1 pw 1]';
    const rOps = runLogo(manyOps, '2d');
    expect(rOps.error).not.toBeNull();
    expect(rOps.segments.length).toBeGreaterThan(0);

    // > 100000 coord
    const far = 'np 100001';
    expect(runLogo(far, '2d').error).not.toBeNull();
  });
});
