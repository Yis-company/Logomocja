import type { LogoError, Token, TokenType } from './types';

export const LIMITS = {
  MAX_CHARS: 50_000,
  MAX_TOKENS: 10_000,
  MAX_BRACKET_DEPTH: 32,
  MAX_FRAMES: 32,
  MAX_OPS: 10_000,
  MAX_SEGMENTS: 10_000,
  MAX_COORD: 100_000,
} as const;

export class LexerError extends Error {
  readonly logoError: LogoError;
  constructor(message: string, line: number, column: number) {
    super(message);
    this.logoError = { message, line, column };
  }
}

const isLetter = (ch: string): boolean => /\p{L}/u.test(ch);
const isDigit = (ch: string): boolean => ch >= '0' && ch <= '9';
const isIdentStart = (ch: string): boolean => ch === '_' || isLetter(ch);
const isIdentPart = (ch: string): boolean => ch === '_' || isDigit(ch) || isLetter(ch);
const isHorizSpace = (ch: string): boolean => ch === ' ' || ch === '\t' || ch === '\r';
const isAnySpace = (ch: string): boolean => isHorizSpace(ch) || ch === '\n';

export function tokenize(source: string): Token[] {
  if (source.length > LIMITS.MAX_CHARS) {
    let line = 1;
    let col = 1;
    for (let i = 0; i < LIMITS.MAX_CHARS; i++) {
      if (source[i] === '\n') {
        line++;
        col = 1;
      } else {
        col++;
      }
    }
    throw new LexerError(
      `Przekroczono limit długości programu (${LIMITS.MAX_CHARS} znaków).`,
      line,
      col,
    );
  }

  const tokens: Token[] = [];
  let tokenCount = 0;
  let i = 0;
  let line = 1;
  let column = 1;
  let seenNonSpaceOnLine = false;

  const pushToken = (
    type: TokenType,
    value: string,
    tokLine: number,
    tokCol: number,
    spaceBefore: boolean,
    atLineStart: boolean,
    endIndex: number,
  ) => {
    if (type !== 'NEWLINE' && type !== 'EOF') {
      tokenCount++;
      if (tokenCount > LIMITS.MAX_TOKENS) {
        throw new LexerError(
          `Przekroczono limit tokenów (${LIMITS.MAX_TOKENS}).`,
          tokLine,
          tokCol,
        );
      }
    }
    const nextCh = endIndex < source.length ? source[endIndex] : '';
    const spaceAfter = nextCh === '' || isAnySpace(nextCh) || nextCh === ';';
    tokens.push({
      type,
      value,
      line: tokLine,
      column: tokCol,
      spaceBefore,
      spaceAfter,
      atLineStart,
    });
  };

  let hadSpaceSinceLastToken = true;

  while (i < source.length) {
    const ch = source[i];

    if (isHorizSpace(ch)) {
      hadSpaceSinceLastToken = true;
      i++;
      column++;
      continue;
    }

    if (ch === ';') {
      hadSpaceSinceLastToken = true;
      while (i < source.length && source[i] !== '\n') {
        i++;
        column++;
      }
      continue;
    }

    if (ch === '\n') {
      pushToken('NEWLINE', '\n', line, column, hadSpaceSinceLastToken, !seenNonSpaceOnLine, i + 1);
      i++;
      line++;
      column = 1;
      seenNonSpaceOnLine = false;
      hadSpaceSinceLastToken = true;
      continue;
    }

    const tokLine = line;
    const tokCol = column;
    const spaceBefore = hadSpaceSinceLastToken;
    const atLineStart = !seenNonSpaceOnLine;
    seenNonSpaceOnLine = true;
    hadSpaceSinceLastToken = false;

    // Brackets, parens, comma
    if (ch === '[') {
      pushToken('LBRACKET', '[', tokLine, tokCol, spaceBefore, atLineStart, i + 1);
      i++;
      column++;
      continue;
    }
    if (ch === ']') {
      pushToken('RBRACKET', ']', tokLine, tokCol, spaceBefore, atLineStart, i + 1);
      i++;
      column++;
      continue;
    }
    if (ch === '(') {
      pushToken('LPAREN', '(', tokLine, tokCol, spaceBefore, atLineStart, i + 1);
      i++;
      column++;
      continue;
    }
    if (ch === ')') {
      pushToken('RPAREN', ')', tokLine, tokCol, spaceBefore, atLineStart, i + 1);
      i++;
      column++;
      continue;
    }
    if (ch === ',') {
      pushToken('COMMA', ',', tokLine, tokCol, spaceBefore, atLineStart, i + 1);
      i++;
      column++;
      continue;
    }

    // Operators
    if (ch === '+' || ch === '-' || ch === '*' || ch === '/') {
      pushToken('OP', ch, tokLine, tokCol, spaceBefore, atLineStart, i + 1);
      i++;
      column++;
      continue;
    }

    // Comparisons: <=, >=, <>, <, >, =
    if (ch === '<') {
      const next = source[i + 1];
      if (next === '=' || next === '>') {
        pushToken('CMP', ch + next, tokLine, tokCol, spaceBefore, atLineStart, i + 2);
        i += 2;
        column += 2;
      } else {
        pushToken('CMP', '<', tokLine, tokCol, spaceBefore, atLineStart, i + 1);
        i++;
        column++;
      }
      continue;
    }
    if (ch === '>') {
      const next = source[i + 1];
      if (next === '=') {
        pushToken('CMP', '>=', tokLine, tokCol, spaceBefore, atLineStart, i + 2);
        i += 2;
        column += 2;
      } else {
        pushToken('CMP', '>', tokLine, tokCol, spaceBefore, atLineStart, i + 1);
        i++;
        column++;
      }
      continue;
    }
    if (ch === '=') {
      pushToken('CMP', '=', tokLine, tokCol, spaceBefore, atLineStart, i + 1);
      i++;
      column++;
      continue;
    }

    // String / colour literal
    if (ch === '"') {
      let j = i + 1;
      let val = '';
      while (j < source.length && source[j] !== '"' && source[j] !== '\n') {
        val += source[j];
        j++;
      }
      if (j >= source.length || source[j] !== '"') {
        throw new LexerError('Niezamknięty literał koloru.', tokLine, tokCol);
      }
      const len = j - i + 1;
      pushToken('STRING', val, tokLine, tokCol, spaceBefore, atLineStart, j + 1);
      i = j + 1;
      column += len;
      continue;
    }

    // Numbers: 80, 12.5, .5 (no 1e3, 0x10, 12.)
    if (isDigit(ch) || (ch === '.' && i + 1 < source.length && isDigit(source[i + 1]))) {
      let j = i;
      while (j < source.length && isDigit(source[j])) {
        j++;
      }
      if (j < source.length && source[j] === '.') {
        j++;
        if (j >= source.length || !isDigit(source[j])) {
          throw new LexerError('Nieprawidłowy zapis liczby.', tokLine, tokCol);
        }
        while (j < source.length && isDigit(source[j])) {
          j++;
        }
      }
      if (j < source.length && (source[j] === '.' || isIdentStart(source[j]))) {
        throw new LexerError('Nieprawidłowy zapis liczby.', tokLine, tokCol);
      }
      const raw = source.slice(i, j);
      pushToken('NUMBER', raw, tokLine, tokCol, spaceBefore, atLineStart, j);
      column += j - i;
      i = j;
      continue;
    }

    // Legacy :name
    if (ch === ':') {
      let j = i + 1;
      if (j >= source.length || !isIdentStart(source[j])) {
        throw new LexerError('Nieprawidłowa nazwa po dwukropku.', tokLine, tokCol);
      }
      while (j < source.length && isIdentPart(source[j])) {
        j++;
      }
      const name = source.slice(i + 1, j).toLowerCase();
      pushToken('LEGACY_VAR', name, tokLine, tokCol, spaceBefore, atLineStart, j);
      column += j - i;
      i = j;
      continue;
    }

    // Words / identifiers (including ma:)
    if (isIdentStart(ch)) {
      let j = i;
      while (j < source.length && isIdentPart(source[j])) {
        j++;
      }
      let word = source.slice(i, j).toLowerCase();
      if (word === 'ma' && j < source.length && source[j] === ':') {
        j++;
        word = 'ma:';
      } else if (j < source.length && source[j] === ':') {
        throw new LexerError(`Nieoczekiwany dwukropek po „${source.slice(i, j)}”.`, tokLine, tokCol);
      }
      pushToken('WORD', word, tokLine, tokCol, spaceBefore, atLineStart, j);
      column += j - i;
      i = j;
      continue;
    }

    throw new LexerError(`Nieoczekiwany znak „${ch}”.`, tokLine, tokCol);
  }

  pushToken('EOF', '', line, column, true, !seenNonSpaceOnLine, source.length);
  return tokens;
}
