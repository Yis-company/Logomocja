import { LIMITS, LexerError } from './lexer';
import type {
  BinOp,
  CmpOp,
  Condition,
  Expr,
  LogoError,
  Mode,
  ProcedureDef,
  Program,
  Stmt,
  Token,
} from './types';

export class ParseError extends Error {
  readonly logoError: LogoError;
  constructor(message: string, line: number, column: number) {
    super(message);
    this.logoError = { message, line, column };
  }
}

type CmdKind =
  | 'fd'
  | 'bk'
  | 'rt'
  | 'lt'
  | 'pu'
  | 'pd'
  | 'color'
  | 'width'
  | 'repeat'
  | 'let'
  | 'if'
  | 'ifelse'
  | 'stop'
  | 'home'
  | 'cs'
  | 'pitchup'
  | 'pitchdown'
  | 'rr'
  | 'rl';

const COMMAND_ALIASES: Record<string, CmdKind> = {
  np: 'fd',
  naprzod: 'fd',
  naprzód: 'fd',
  fd: 'fd',
  forward: 'fd',

  ws: 'bk',
  wstecz: 'bk',
  bk: 'bk',
  back: 'bk',

  pw: 'rt',
  prawo: 'rt',
  rt: 'rt',
  right: 'rt',

  lw: 'lt',
  lewo: 'lt',
  lt: 'lt',
  left: 'lt',

  pod: 'pu',
  podnies: 'pu',
  podnieś: 'pu',
  pu: 'pu',
  penup: 'pu',

  opu: 'pd',
  opusc: 'pd',
  opuść: 'pd',
  pd: 'pd',
  pendown: 'pd',

  kolor: 'color',
  color: 'color',

  grubosc: 'width',
  grubość: 'width',
  width: 'width',

  powtorz: 'repeat',
  powtórz: 'repeat',
  repeat: 'repeat',

  niech: 'let',
  let: 'let',

  jeśli: 'if',
  jesli: 'if',
  if: 'if',

  jeżeli: 'ifelse',
  jezeli: 'ifelse',
  ifelse: 'ifelse',

  stop: 'stop',

  dom: 'home',
  home: 'home',

  czyść: 'cs',
  czysc: 'cs',
  cs: 'cs',
  clearscreen: 'cs',

  gora: 'pitchup',
  góra: 'pitchup',
  pitchup: 'pitchup',

  dol: 'pitchdown',
  dół: 'pitchdown',
  pitchdown: 'pitchdown',

  pp: 'rr',
  przechylprawo: 'rr',
  rr: 'rr',
  rollright: 'rr',

  pl: 'rl',
  przechyllewo: 'rl',
  rl: 'rl',
  rollleft: 'rl',
};

const STRUCTURAL_WORDS = new Set([
  'oto',
  'to',
  'już',
  'juz',
  'end',
  'ma:',
  'nrpowt',
  'repcount',
]);

export function isReservedWord(word: string): boolean {
  const lower = word.toLowerCase();
  return lower in COMMAND_ALIASES || STRUCTURAL_WORDS.has(lower);
}

interface RawProcedure {
  name: string;
  params: string[];
  bodyTokens: Token[];
  line: number;
  column: number;
}

function splitProcedures(tokens: Token[]): {
  topTokens: Token[];
  rawProcedures: Map<string, RawProcedure>;
} {
  const topTokens: Token[] = [];
  const rawProcedures = new Map<string, RawProcedure>();
  let i = 0;
  let bracketDepth = 0;

  while (i < tokens.length) {
    const tok = tokens[i];
    if (tok.type === 'EOF') break;

    if (tok.type === 'LBRACKET') {
      bracketDepth++;
      if (bracketDepth > LIMITS.MAX_BRACKET_DEPTH) {
        throw new ParseError(
          `Przekroczono maksymalną głębokość nawiasów [${LIMITS.MAX_BRACKET_DEPTH}].`,
          tok.line,
          tok.column,
        );
      }
      topTokens.push(tok);
      i++;
      continue;
    }

    if (tok.type === 'RBRACKET') {
      bracketDepth = Math.max(0, bracketDepth - 1);
      topTokens.push(tok);
      i++;
      continue;
    }

    if (tok.type === 'WORD' && (tok.value === 'oto' || tok.value === 'to')) {
      if (bracketDepth > 0) {
        throw new ParseError(
          'Definicja procedury nie może znajdować się wewnątrz nawiasów [ ].',
          tok.line,
          tok.column,
        );
      }
      if (!tok.atLineStart) {
        throw new ParseError(
          'Definicja procedury („oto”) musi zaczynać się na początku wiersza.',
          tok.line,
          tok.column,
        );
      }
      const defLine = tok.line;
      const defCol = tok.column;
      i++;

      // Procedure name
      const nameTok = tokens[i];
      if (!nameTok || nameTok.type === 'NEWLINE' || nameTok.type === 'EOF') {
        throw new ParseError('Brak nazwy procedury po „oto”.', defLine, defCol);
      }
      if (nameTok.type !== 'WORD') {
        throw new ParseError('Nieprawidłowa nazwa procedury.', nameTok.line, nameTok.column);
      }
      if (isReservedWord(nameTok.value)) {
        throw new ParseError(
          `Nazwa „${nameTok.value}” jest zarezerwowanym słowem kluczowym.`,
          nameTok.line,
          nameTok.column,
        );
      }
      if (rawProcedures.has(nameTok.value)) {
        throw new ParseError(
          `Procedura „${nameTok.value}” została już zdefiniowana.`,
          nameTok.line,
          nameTok.column,
        );
      }
      const procName = nameTok.value;
      i++;

      // Parameters
      const params: string[] = [];
      const paramSet = new Set<string>();
      const next = tokens[i];

      if (next && next.type === 'WORD' && next.value === 'ma:') {
        i++;
        // Expect at least one parameter, comma-separated
        while (true) {
          const pTok = tokens[i];
          if (!pTok || pTok.type === 'NEWLINE' || pTok.type === 'EOF') {
            if (params.length === 0) {
              throw new ParseError('Brak listy parametrów po „ma:”.', next.line, next.column);
            }
            break;
          }
          if (pTok.type !== 'WORD') {
            throw new ParseError('Oczekiwano nazwy parametru.', pTok.line, pTok.column);
          }
          if (isReservedWord(pTok.value)) {
            throw new ParseError(
              `Parametr nie może nazywać się „${pTok.value}”.`,
              pTok.line,
              pTok.column,
            );
          }
          if (paramSet.has(pTok.value)) {
            throw new ParseError(
              `Zduplikowana nazwa parametru „${pTok.value}”.`,
              pTok.line,
              pTok.column,
            );
          }
          params.push(pTok.value);
          paramSet.add(pTok.value);
          i++;

          const afterParam = tokens[i];
          if (afterParam && afterParam.type === 'COMMA') {
            i++;
            const afterComma = tokens[i];
            if (!afterComma || afterComma.type === 'NEWLINE' || afterComma.type === 'EOF') {
              throw new ParseError(
                'Oczekiwano nazwy parametru po przecinku.',
                afterParam.line,
                afterParam.column,
              );
            }
          } else {
            break;
          }
        }
      } else if (next && next.type === 'LEGACY_VAR') {
        while (tokens[i] && tokens[i].type === 'LEGACY_VAR') {
          const pTok = tokens[i];
          if (isReservedWord(pTok.value)) {
            throw new ParseError(
              `Parametr nie może nazywać się „${pTok.value}”.`,
              pTok.line,
              pTok.column,
            );
          }
          if (paramSet.has(pTok.value)) {
            throw new ParseError(
              `Zduplikowana nazwa parametru „${pTok.value}”.`,
              pTok.line,
              pTok.column,
            );
          }
          params.push(pTok.value);
          paramSet.add(pTok.value);
          i++;
        }
      }

      // Header must end with newline
      const endHeader = tokens[i];
      if (!endHeader || endHeader.type === 'EOF') {
        throw new ParseError(
          `Brak słowa „już” zamykającego procedurę „${procName}”.`,
          defLine,
          defCol,
        );
      }
      if (endHeader.type !== 'NEWLINE') {
        throw new ParseError(
          'Nieoczekiwany element w nagłówku procedury.',
          endHeader.line,
          endHeader.column,
        );
      }
      i++; // consume NEWLINE

      // Collect body tokens until `już` / `juz` / `end` alone on its own line
      const bodyTokens: Token[] = [];
      let closed = false;
      while (i < tokens.length && tokens[i].type !== 'EOF') {
        const bTok = tokens[i];
        if (
          bTok.type === 'WORD' &&
          (bTok.value === 'już' || bTok.value === 'juz' || bTok.value === 'end') &&
          bTok.atLineStart
        ) {
          const afterEnd = tokens[i + 1];
          if (!afterEnd || afterEnd.type === 'NEWLINE' || afterEnd.type === 'EOF') {
            closed = true;
            i++;
            if (afterEnd && afterEnd.type === 'NEWLINE') i++;
            break;
          }
          throw new ParseError(
            'Słowo „już” musi znajdować się samo w wierszu.',
            afterEnd.line,
            afterEnd.column,
          );
        }
        if (bTok.type === 'WORD' && (bTok.value === 'oto' || bTok.value === 'to') && bTok.atLineStart) {
          throw new ParseError(
            'Nie można definiować procedury wewnątrz innej procedury.',
            bTok.line,
            bTok.column,
          );
        }
        if (bTok.type !== 'NEWLINE') {
          bodyTokens.push(bTok);
        }
        i++;
      }

      if (!closed) {
        throw new ParseError(
          `Brak słowa „już” zamykającego procedurę „${procName}”.`,
          defLine,
          defCol,
        );
      }

      const eofTok: Token = tokens[tokens.length - 1];
      bodyTokens.push(eofTok);
      rawProcedures.set(procName, {
        name: procName,
        params,
        bodyTokens,
        line: defLine,
        column: defCol,
      });
      continue;
    }

    if (
      tok.type === 'WORD' &&
      (tok.value === 'już' || tok.value === 'juz' || tok.value === 'end')
    ) {
      throw new ParseError(
        'Nieoczekiwane słowo „już” poza definicją procedury.',
        tok.line,
        tok.column,
      );
    }

    if (tok.type !== 'NEWLINE') {
      topTokens.push(tok);
    }
    i++;
  }

  topTokens.push(tokens[tokens.length - 1]);
  return { topTokens, rawProcedures };
}

class TokenStream {
  private pos = 0;
  private bracketDepth = 0;
  private readonly tokens: Token[];
  private readonly procedures: Map<string, RawProcedure>;

  constructor(tokens: Token[], procedures: Map<string, RawProcedure>) {
    this.tokens = tokens;
    this.procedures = procedures;
  }

  peek(offset = 0): Token {
    const idx = Math.min(this.pos + offset, this.tokens.length - 1);
    return this.tokens[idx];
  }

  advance(): Token {
    const tok = this.peek();
    if (tok.type !== 'EOF') this.pos++;
    return tok;
  }

  parseStatements(stopAtRBracket: boolean): Stmt[] {
    const stmts: Stmt[] = [];
    while (true) {
      const tok = this.peek();
      if (tok.type === 'EOF') {
        if (stopAtRBracket) {
          throw new ParseError('Brak zamykającego nawiasu „]”.', tok.line, tok.column);
        }
        break;
      }
      if (tok.type === 'RBRACKET') {
        if (stopAtRBracket) {
          break;
        }
        throw new ParseError('Nieoczekiwany nawias zamykający „]”.', tok.line, tok.column);
      }
      stmts.push(this.parseStmt());
    }
    return stmts;
  }

  private parseStmt(): Stmt {
    const tok = this.peek();

    if (tok.type === 'WORD') {
      if (tok.value === 'oto' || tok.value === 'to') {
        throw new ParseError(
          'Definicja procedury nie może znajdować się wewnątrz bloku.',
          tok.line,
          tok.column,
        );
      }
      if (tok.value === 'już' || tok.value === 'juz' || tok.value === 'end') {
        throw new ParseError(
          'Nieoczekiwane słowo „już” wewnątrz bloku.',
          tok.line,
          tok.column,
        );
      }
      if (tok.value === 'nrpowt' || tok.value === 'repcount') {
        throw new ParseError(
          `„${tok.value}” jest wartością, a nie poleceniem.`,
          tok.line,
          tok.column,
        );
      }

      const cmd = COMMAND_ALIASES[tok.value];
      if (cmd) {
        this.advance();
        switch (cmd) {
          case 'fd':
          case 'bk':
          case 'rt':
          case 'lt':
          case 'pitchup':
          case 'pitchdown':
          case 'rr':
          case 'rl':
            return { kind: cmd, expr: this.parseExpr(tok), line: tok.line, column: tok.column };
          case 'pu':
          case 'pd':
          case 'stop':
          case 'home':
          case 'cs':
            return { kind: cmd, line: tok.line, column: tok.column };
          case 'color': {
            const cTok = this.peek();
            if (cTok.type === 'EOF') {
              throw new ParseError('Brak literału koloru po poleceniu „kolor”.', tok.line, tok.column);
            }
            if (cTok.type !== 'STRING' || !/^#[0-9a-fA-F]{6}$/.test(cTok.value)) {
              throw new ParseError(
                'Nieprawidłowy kolor. Oczekiwano sześciocyfrowego zapisu w cudzysłowie, np. "#16866a".',
                cTok.line,
                cTok.column,
              );
            }
            this.advance();
            return { kind: 'color', color: cTok.value.toLowerCase(), line: tok.line, column: tok.column };
          }
          case 'width':
            return { kind: 'width', expr: this.parseExpr(tok), line: tok.line, column: tok.column };
          case 'let': {
            const nameTok = this.peek();
            if (nameTok.type === 'EOF') {
              throw new ParseError('Brak nazwy zmiennej po „niech”.', tok.line, tok.column);
            }
            if (nameTok.type !== 'WORD') {
              throw new ParseError('Oczekiwano nazwy zmiennej po „niech”.', nameTok.line, nameTok.column);
            }
            if (isReservedWord(nameTok.value)) {
              throw new ParseError(
                `Zmienna nie może nazywać się „${nameTok.value}”.`,
                nameTok.line,
                nameTok.column,
              );
            }
            if (this.procedures.has(nameTok.value)) {
              throw new ParseError(
                `Nazwa „${nameTok.value}” jest już nazwą procedury.`,
                nameTok.line,
                nameTok.column,
              );
            }
            this.advance();
            const expr = this.parseExpr(nameTok);
            return { kind: 'let', name: nameTok.value, expr, line: tok.line, column: tok.column };
          }
          case 'repeat': {
            const count = this.parseExpr(tok);
            const body = this.parseBlock(tok);
            return { kind: 'repeat', count, body, line: tok.line, column: tok.column };
          }
          case 'if': {
            const cond = this.parseCondition(tok);
            const body = this.parseBlock(tok);
            return { kind: 'if', cond, body, line: tok.line, column: tok.column };
          }
          case 'ifelse': {
            const cond = this.parseCondition(tok);
            const thenBody = this.parseBlock(tok);
            const elseBody = this.parseBlock(tok);
            return { kind: 'ifelse', cond, thenBody, elseBody, line: tok.line, column: tok.column };
          }
        }
      }

      // Procedure call?
      const proc = this.procedures.get(tok.value);
      if (proc) {
        this.advance();
        const args: Expr[] = [];
        let lastAnchor = tok;
        for (let a = 0; a < proc.params.length; a++) {
          const argExpr = this.parseExpr(lastAnchor);
          args.push(argExpr);
          lastAnchor = this.tokens[Math.max(0, this.pos - 1)];
        }
        return { kind: 'call', name: proc.name, args, line: tok.line, column: tok.column };
      }

      throw new ParseError(`Nieznane polecenie „${tok.value}”.`, tok.line, tok.column);
    }

    throw new ParseError(
      `Oczekiwano polecenia, napotkano „${tok.value || tok.type}”.`,
      tok.line,
      tok.column,
    );
  }

  private parseBlock(anchor: Token): Stmt[] {
    const open = this.peek();
    if (open.type === 'EOF') {
      throw new ParseError('Oczekiwano bloku „[ ... ]”.', anchor.line, anchor.column);
    }
    if (open.type !== 'LBRACKET') {
      throw new ParseError('Oczekiwano nawiasu otwierającego „[”.', open.line, open.column);
    }
    this.advance();
    this.bracketDepth++;
    if (this.bracketDepth > LIMITS.MAX_BRACKET_DEPTH) {
      throw new ParseError(
        `Przekroczono maksymalną głębokość nawiasów [${LIMITS.MAX_BRACKET_DEPTH}].`,
        open.line,
        open.column,
      );
    }
    const body = this.parseStatements(true);
    const close = this.peek();
    if (close.type !== 'RBRACKET') {
      throw new ParseError('Brak zamykającego nawiasu „]”.', close.line, close.column);
    }
    this.advance();
    this.bracketDepth--;
    return body;
  }

  private parseCondition(anchor: Token): Condition {
    const left = this.parseExpr(anchor);
    const cmpTok = this.peek();
    if (cmpTok.type === 'EOF') {
      throw new ParseError('Oczekiwano operatora porównania (<, >, =, <=, >=, <>).', anchor.line, anchor.column);
    }
    if (cmpTok.type !== 'CMP') {
      throw new ParseError(
        `Oczekiwano operatora porównania, napotkano „${cmpTok.value}”.`,
        cmpTok.line,
        cmpTok.column,
      );
    }
    this.advance();
    const right = this.parseExpr(cmpTok);
    return {
      left,
      op: cmpTok.value as CmpOp,
      right,
      line: cmpTok.line,
      column: cmpTok.column,
    };
  }

  private parseExpr(anchor: Token): Expr {
    return this.parseAddSub(anchor);
  }

  private parseAddSub(anchor: Token): Expr {
    let left = this.parseMulDiv(anchor);
    while (true) {
      const tok = this.peek();
      if (
        tok.type === 'OP' &&
        (tok.value === '+' || tok.value === '-') &&
        tok.spaceBefore === tok.spaceAfter
      ) {
        this.advance();
        const right = this.parseMulDiv(tok);
        left = {
          kind: 'binary',
          op: tok.value as BinOp,
          left,
          right,
          line: left.line,
          column: left.column,
        };
      } else {
        break;
      }
    }
    return left;
  }

  private parseMulDiv(anchor: Token): Expr {
    let left = this.parseUnary(anchor);
    while (true) {
      const tok = this.peek();
      if (
        tok.type === 'OP' &&
        (tok.value === '*' || tok.value === '/') &&
        tok.spaceBefore === tok.spaceAfter
      ) {
        this.advance();
        const right = this.parseUnary(tok);
        left = {
          kind: 'binary',
          op: tok.value as BinOp,
          left,
          right,
          line: left.line,
          column: left.column,
        };
      } else {
        break;
      }
    }
    return left;
  }

  private parseUnary(anchor: Token): Expr {
    const tok = this.peek();
    if (tok.type === 'OP' && (tok.value === '+' || tok.value === '-')) {
      this.advance();
      const expr = this.parseUnary(tok);
      return {
        kind: 'unary',
        op: tok.value as '+' | '-',
        expr,
        line: tok.line,
        column: tok.column,
      };
    }
    return this.parsePrimary(anchor);
  }

  private parsePrimary(anchor: Token): Expr {
    const tok = this.peek();
    if (tok.type === 'EOF') {
      throw new ParseError('Brak wymaganego argumentu.', anchor.line, anchor.column);
    }
    if (tok.type === 'NUMBER') {
      this.advance();
      const value = Number(tok.value);
      if (!Number.isFinite(value)) {
        throw new ParseError('Nieprawidłowa liczba.', tok.line, tok.column);
      }
      return { kind: 'number', value, line: tok.line, column: tok.column };
    }
    if (tok.type === 'LEGACY_VAR') {
      this.advance();
      return { kind: 'var', name: tok.value, line: tok.line, column: tok.column };
    }
    if (tok.type === 'WORD') {
      if (tok.value === 'nrpowt' || tok.value === 'repcount') {
        this.advance();
        return { kind: 'repcount', line: tok.line, column: tok.column };
      }
      if (isReservedWord(tok.value)) {
        throw new ParseError(
          `Nieoczekiwane słowo kluczowe „${tok.value}” w wyrażeniu.`,
          tok.line,
          tok.column,
        );
      }
      this.advance();
      return { kind: 'var', name: tok.value, line: tok.line, column: tok.column };
    }
    if (tok.type === 'LPAREN') {
      this.advance();
      const inner = this.parseExpr(tok);
      const close = this.peek();
      if (close.type === 'EOF') {
        throw new ParseError('Brak zamykającego nawiasu „)”.', tok.line, tok.column);
      }
      if (close.type !== 'RPAREN') {
        throw new ParseError(`Oczekiwano „)”, napotkano „${close.value}”.`, close.line, close.column);
      }
      this.advance();
      return inner;
    }
    throw new ParseError(
      `Oczekiwano wartości lub wyrażenia, napotkano „${tok.value}”.`,
      tok.line,
      tok.column,
    );
  }
}

function collectDeclaredVars(stmts: Stmt[], out: Set<string>): void {
  for (const s of stmts) {
    if (s.kind === 'let') {
      out.add(s.name);
    } else if (s.kind === 'repeat' || s.kind === 'if') {
      collectDeclaredVars(s.body, out);
    } else if (s.kind === 'ifelse') {
      collectDeclaredVars(s.thenBody, out);
      collectDeclaredVars(s.elseBody, out);
    }
  }
}

function exprHasName(expr: Expr): boolean {
  switch (expr.kind) {
    case 'number':
      return false;
    case 'var':
    case 'repcount':
      return true;
    case 'unary':
      return exprHasName(expr.expr);
    case 'binary':
      return exprHasName(expr.left) || exprHasName(expr.right);
  }
}

function evalConstExpr(expr: Expr): number {
  switch (expr.kind) {
    case 'number':
      return expr.value;
    case 'unary': {
      const v = evalConstExpr(expr.expr);
      return expr.op === '-' ? -v : v;
    }
    case 'binary': {
      const l = evalConstExpr(expr.left);
      const r = evalConstExpr(expr.right);
      let res: number;
      if (expr.op === '+') res = l + r;
      else if (expr.op === '-') res = l - r;
      else if (expr.op === '*') res = l * r;
      else {
        if (r === 0) {
          throw new ParseError('Dzielenie przez zero.', expr.line, expr.column);
        }
        res = l / r;
      }
      if (!Number.isFinite(res)) {
        throw new ParseError('Wynik wyrażenia wykracza poza zakres liczbowy.', expr.line, expr.column);
      }
      return res;
    }
    default:
      throw new ParseError('Oczekiwano stałego wyrażenia.', expr.line, expr.column);
  }
}

function validateExpr(expr: Expr, allowedVars: Set<string>, inRepeat: boolean): void {
  switch (expr.kind) {
    case 'number':
      return;
    case 'repcount':
      if (!inRepeat) {
        throw new ParseError(
          '„nrpowt” może być użyte tylko wewnątrz pętli „powtórz”.',
          expr.line,
          expr.column,
        );
      }
      return;
    case 'var':
      if (!allowedVars.has(expr.name)) {
        throw new ParseError(
          `Niezadeklarowana zmienna „${expr.name}”.`,
          expr.line,
          expr.column,
        );
      }
      return;
    case 'unary':
      validateExpr(expr.expr, allowedVars, inRepeat);
      return;
    case 'binary':
      validateExpr(expr.left, allowedVars, inRepeat);
      validateExpr(expr.right, allowedVars, inRepeat);
  }
}

function validateStmts(
  stmts: Stmt[],
  allowedVars: Set<string>,
  inRepeat: boolean,
  mode: Mode,
): void {
  for (const s of stmts) {
    switch (s.kind) {
      case 'pitchup':
      case 'pitchdown':
      case 'rr':
      case 'rl':
        if (mode === '2d') {
          throw new ParseError(
            'Polecenia obrotu w przestrzeni (góra, dół, pp, pl) są dostępne tylko w trybie 3D.',
            s.line,
            s.column,
          );
        }
        validateExpr(s.expr, allowedVars, inRepeat);
        break;
      case 'fd':
      case 'bk':
      case 'rt':
      case 'lt':
      case 'let':
        validateExpr(s.expr, allowedVars, inRepeat);
        break;
      case 'width':
        validateExpr(s.expr, allowedVars, inRepeat);
        if (!exprHasName(s.expr)) {
          const val = evalConstExpr(s.expr);
          if (!Number.isInteger(val) || val < 1 || val > 12) {
            throw new ParseError(
              'Grubość pisaka musi być liczbą całkowitą od 1 do 12.',
              s.expr.line,
              s.expr.column,
            );
          }
        }
        break;
      case 'repeat':
        validateExpr(s.count, allowedVars, inRepeat);
        if (!exprHasName(s.count)) {
          const val = evalConstExpr(s.count);
          if (!Number.isInteger(val) || val < 0 || val > 10000) {
            throw new ParseError(
              'Liczba powtórzeń musi być liczbą całkowitą od 0 do 10000.',
              s.count.line,
              s.count.column,
            );
          }
        }
        validateStmts(s.body, allowedVars, true, mode);
        break;
      case 'if':
        validateExpr(s.cond.left, allowedVars, inRepeat);
        validateExpr(s.cond.right, allowedVars, inRepeat);
        validateStmts(s.body, allowedVars, inRepeat, mode);
        break;
      case 'ifelse':
        validateExpr(s.cond.left, allowedVars, inRepeat);
        validateExpr(s.cond.right, allowedVars, inRepeat);
        validateStmts(s.thenBody, allowedVars, inRepeat, mode);
        validateStmts(s.elseBody, allowedVars, inRepeat, mode);
        break;
      case 'call':
        for (const a of s.args) {
          validateExpr(a, allowedVars, inRepeat);
        }
        break;
      case 'pu':
      case 'pd':
      case 'color':
      case 'stop':
      case 'home':
      case 'cs':
        break;
    }
  }
}

export function parseProgram(tokens: Token[], mode: Mode): Program {
  const { topTokens, rawProcedures } = splitProcedures(tokens);
  const topStream = new TokenStream(topTokens, rawProcedures);
  const body = topStream.parseStatements(false);

  const procedures = new Map<string, ProcedureDef>();
  for (const [name, raw] of rawProcedures) {
    const procStream = new TokenStream(raw.bodyTokens, rawProcedures);
    const procBody = procStream.parseStatements(false);
    procedures.set(name, {
      name: raw.name,
      params: raw.params,
      body: procBody,
      line: raw.line,
      column: raw.column,
    });
  }

  const topLevelVars = new Set<string>();
  collectDeclaredVars(body, topLevelVars);

  // Static validation
  validateStmts(body, topLevelVars, false, mode);
  for (const proc of procedures.values()) {
    const allowed = new Set<string>(topLevelVars);
    for (const p of proc.params) allowed.add(p);
    collectDeclaredVars(proc.body, allowed);
    validateStmts(proc.body, allowed, false, mode);
  }

  return { procedures, body, topLevelVars };
}

export function toLogoError(err: unknown): LogoError {
  if (err instanceof LexerError || err instanceof ParseError) {
    return err.logoError;
  }
  return {
    message: err instanceof Error ? err.message : 'Nieznany błąd.',
    line: 1,
    column: 1,
  };
}
