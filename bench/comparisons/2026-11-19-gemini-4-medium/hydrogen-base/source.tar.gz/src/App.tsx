import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  BookOpen,
  Download,
  FolderOpen,
  HelpCircle,
  Image as ImageIcon,
  Layers,
  Moon,
  Pause,
  Play,
  RotateCcw,
  Share2,
  SkipForward,
  Sparkles,
  Sun,
  Trophy,
} from 'lucide-react';
import { ChallengesPanel } from './components/ChallengesPanel';
import { Editor } from './components/Editor';
import { ExamplesModal } from './components/ExamplesModal';
import { HelpModal } from './components/HelpModal';
import { ReferencePanel } from './components/ReferencePanel';
import { Viewport2D, type ViewportHandle } from './components/Viewport2D';
import { Viewport3D } from './components/Viewport3D';
import type { Challenge } from './data/challenges';
import type { ExampleProgram } from './data/examples';
import { compileLogo, createInitialTurtle, LogoStepper, runLogo } from './lang/interpreter';
import type { LogoError, Mode, RunResult, Segment, TurtleState } from './lang/types';
import { downloadCanvasPng, downloadLogoFile } from './utils/exportPng';
import { decodePermalink, encodePermalink } from './utils/permalink';
import {
  loadBaselineCode,
  loadDraft,
  loadMode,
  loadSolvedChallenges,
  loadThemeOverride,
  saveBaselineCode,
  saveDraft,
  saveMode,
  saveSolvedChallenges,
  saveThemeOverride,
  type ThemeOverride,
} from './utils/storage';

type ExecStatus = 'idle' | 'running' | 'paused' | 'finished';
type RightTab = 'canvas' | 'challenges' | 'reference';
type MobileTab = 'editor' | 'canvas' | 'challenges' | 'reference';

declare global {
  interface Window {
    logomocja?: {
      version: string;
      run: (source: string, mode: Mode) => RunResult;
      open: (source: string, mode: Mode) => Promise<RunResult>;
    };
  }
}

function getSystemIsDark(): boolean {
  return window.matchMedia('(prefers-color-scheme: dark)').matches;
}

function getEffectiveIsDark(override: ThemeOverride): boolean {
  return override ? override === 'dark' : getSystemIsDark();
}

function applyThemeMeta(override: ThemeOverride): void {
  const meta = document.querySelector('meta[name="color-scheme"]');
  if (meta) {
    meta.setAttribute('content', override ?? 'light dark');
  }
}

export function App() {
  const [mode, setMode] = useState<Mode>(() => {
    const perm = decodePermalink(window.location.hash);
    return perm ? perm.mode : loadMode();
  });

  const [code, setCode] = useState<string>(() => {
    const perm = decodePermalink(window.location.hash);
    if (perm) return perm.code;
    return loadDraft(loadMode());
  });

  const [segments, setSegments] = useState<Segment[]>([]);
  const [turtle, setTurtle] = useState<TurtleState>(() => createInitialTurtle());
  const [error, setError] = useState<LogoError | null>(null);
  const [activeLine, setActiveLine] = useState<number | null>(null);
  const [execStatus, setExecStatus] = useState<ExecStatus>('idle');
  const [speed, setSpeed] = useState<number>(85); // 1..100, 100 = instant

  const [rightTab, setRightTab] = useState<RightTab>('canvas');
  const [mobileTab, setMobileTab] = useState<MobileTab>('editor');
  const [examplesOpen, setExamplesOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  const [solvedChallenges, setSolvedChallenges] = useState<Set<string>>(() =>
    loadSolvedChallenges(),
  );
  const [themeOverride, setThemeOverride] = useState<ThemeOverride>(() => loadThemeOverride());

  const stepperRef = useRef<LogoStepper | null>(null);
  const timerRef = useRef<number | null>(null);
  const viewportRef = useRef<ViewportHandle>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const speedRef = useRef(speed);
  speedRef.current = speed;

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    window.setTimeout(() => {
      setToast((prev) => (prev === msg ? null : prev));
    }, 2600);
  }, []);

  const stopTimer = useCallback(() => {
    if (timerRef.current !== null) {
      window.clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const resetExecution = useCallback(() => {
    stopTimer();
    stepperRef.current = null;
    setSegments([]);
    setTurtle(createInitialTurtle());
    setError(null);
    setActiveLine(null);
    setExecStatus('idle');
  }, [stopTimer]);

  const runInstant = useCallback(
    (src: string, targetMode: Mode, fitAfter = false): RunResult => {
      stopTimer();
      stepperRef.current = null;
      const { program, error: compileErr } = compileLogo(src, targetMode);
      if (compileErr || !program) {
        setSegments([]);
        setTurtle(createInitialTurtle());
        setError(compileErr);
        setActiveLine(null);
        setExecStatus('finished');
        return { segments: [], error: compileErr };
      }
      const stepper = new LogoStepper(program, targetMode);
      while (stepper.step()) {
        // run to completion
      }
      const snap = stepper.snapshot();
      setSegments([...snap.segments]);
      setTurtle(snap.turtle);
      setError(snap.error);
      setActiveLine(null);
      setExecStatus('finished');

      if (fitAfter) {
        requestAnimationFrame(() => {
          viewportRef.current?.fit(snap.segments, snap.turtle);
        });
      }
      return { segments: snap.segments, error: snap.error };
    },
    [stopTimer],
  );

  const scheduleNextStep = useCallback(() => {
    stopTimer();
    const tick = () => {
      const stepper = stepperRef.current;
      if (!stepper) return;

      const curSpeed = speedRef.current;
      if (curSpeed >= 100) {
        while (stepper.step()) {
          // finish immediately
        }
        const snap = stepper.snapshot();
        setSegments([...snap.segments]);
        setTurtle(snap.turtle);
        setError(snap.error);
        setActiveLine(null);
        setExecStatus('finished');
        stepperRef.current = null;
        return;
      }

      // Batch steps at higher speeds so 768-segment fractals animate smoothly
      const batch = curSpeed >= 80 ? Math.ceil((curSpeed - 75) * 1.2) : 1;
      let alive = true;
      for (let i = 0; i < batch; i++) {
        alive = stepper.step();
        if (!alive) break;
      }

      const snap = stepper.snapshot();
      setSegments([...snap.segments]);
      setTurtle(snap.turtle);
      setError(snap.error);
      setActiveLine(snap.currentLine);

      if (!alive || snap.done || snap.error) {
        setExecStatus('finished');
        setActiveLine(null);
        stepperRef.current = null;
        return;
      }

      const delay = curSpeed >= 80 ? 16 : Math.round(340 - curSpeed * 4);
      timerRef.current = window.setTimeout(tick, Math.max(12, delay));
    };

    const delay = speedRef.current >= 100 ? 0 : 16;
    timerRef.current = window.setTimeout(tick, delay);
  }, [stopTimer]);

  const handleRun = useCallback(() => {
    if (speedRef.current >= 100) {
      runInstant(code, mode, false);
      return;
    }
    stopTimer();
    const { program, error: compileErr } = compileLogo(code, mode);
    if (compileErr || !program) {
      stepperRef.current = null;
      setSegments([]);
      setTurtle(createInitialTurtle());
      setError(compileErr);
      setActiveLine(null);
      setExecStatus('finished');
      return;
    }
    const stepper = new LogoStepper(program, mode);
    stepperRef.current = stepper;
    setSegments([]);
    setTurtle(createInitialTurtle());
    setError(null);
    setActiveLine(stepper.getCurrentLine());
    setExecStatus('running');
    scheduleNextStep();
  }, [code, mode, runInstant, scheduleNextStep, stopTimer]);

  const handleStep = useCallback(() => {
    stopTimer();
    let stepper = stepperRef.current;
    if (!stepper || execStatus === 'idle' || execStatus === 'finished') {
      const { program, error: compileErr } = compileLogo(code, mode);
      if (compileErr || !program) {
        stepperRef.current = null;
        setSegments([]);
        setTurtle(createInitialTurtle());
        setError(compileErr);
        setActiveLine(null);
        setExecStatus('finished');
        return;
      }
      stepper = new LogoStepper(program, mode);
      stepperRef.current = stepper;
    }

    const alive = stepper.step();
    const snap = stepper.snapshot();
    setSegments([...snap.segments]);
    setTurtle(snap.turtle);
    setError(snap.error);
    setActiveLine(snap.currentLine);
    setExecStatus(!alive || snap.done || snap.error ? 'finished' : 'paused');
    if (!alive || snap.done || snap.error) {
      stepperRef.current = null;
    }
  }, [code, mode, execStatus, stopTimer]);

  const handlePauseResume = useCallback(() => {
    if (execStatus === 'running') {
      stopTimer();
      setExecStatus('paused');
    } else if (execStatus === 'paused' && stepperRef.current) {
      setExecStatus('running');
      scheduleNextStep();
    }
  }, [execStatus, scheduleNextStep, stopTimer]);

  const handleCodeChange = useCallback(
    (nextCode: string) => {
      setCode(nextCode);
      saveDraft(mode, nextCode);
      if (execStatus === 'running' || execStatus === 'paused') {
        stopTimer();
        stepperRef.current = null;
        setActiveLine(null);
        setExecStatus('idle');
      }
    },
    [mode, execStatus, stopTimer],
  );

  const handleModeChange = useCallback(
    (nextMode: Mode) => {
      if (nextMode === mode) return;
      saveDraft(mode, code);
      saveMode(nextMode);
      resetExecution();
      setMode(nextMode);
      setCode(loadDraft(nextMode));
    },
    [mode, code, resetExecution],
  );

  // Initial permalink run
  useEffect(() => {
    const perm = decodePermalink(window.location.hash);
    if (perm) {
      saveDraft(perm.mode, perm.code);
      saveBaselineCode(perm.mode, perm.code);
      saveMode(perm.mode);
      runInstant(perm.code, perm.mode, true);
    } else {
      runInstant(code, mode, true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Theme sync across tabs
  useEffect(() => {
    applyThemeMeta(themeOverride);
    const onStorage = (e: StorageEvent) => {
      if (e.key === 'color-scheme') {
        const next = e.newValue === 'light' || e.newValue === 'dark' ? e.newValue : null;
        setThemeOverride(next);
        applyThemeMeta(next);
      }
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, [themeOverride]);

  const toggleTheme = () => {
    const currentlyDark = getEffectiveIsDark(themeOverride);
    const target = currentlyDark ? 'light' : 'dark';
    const sysDark = getSystemIsDark();
    const nextOverride: ThemeOverride = (target === 'dark') === sysDark ? null : target;
    saveThemeOverride(nextOverride);
    setThemeOverride(nextOverride);
    applyThemeMeta(nextOverride);
  };

  // Keyboard shortcuts
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        handleRun();
      } else if (e.altKey && (e.key === 's' || e.key === 'S')) {
        e.preventDefault();
        handleStep();
      } else if (e.altKey && (e.key === 'p' || e.key === 'P')) {
        e.preventDefault();
        handlePauseResume();
      } else if (e.altKey && (e.key === 'r' || e.key === 'R')) {
        e.preventDefault();
        resetExecution();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handleRun, handleStep, handlePauseResume, resetExecution]);

  // Testing hook: window.logomocja
  useEffect(() => {
    window.logomocja = {
      version: '1.0.0',
      run: (source: string, m: Mode) => runLogo(source, m),
      open: (source: string, m: Mode) =>
        new Promise((resolve) => {
          stopTimer();
          stepperRef.current = null;
          setMode(m);
          setCode(source);
          saveMode(m);
          saveDraft(m, source);
          saveBaselineCode(m, source);
          setRightTab('canvas');
          setMobileTab('canvas');

          const res = runLogo(source, m);
          setSegments(res.segments);
          if (res.error) {
            setTurtle(createInitialTurtle());
          } else {
            const { program } = compileLogo(source, m);
            if (program) {
              const st = new LogoStepper(program, m);
              while (st.step()) {
                // advance for final turtle pose
              }
              setTurtle(st.snapshot().turtle);
            }
          }
          setError(res.error);
          setActiveLine(null);
          setExecStatus('finished');

          requestAnimationFrame(() => {
            requestAnimationFrame(() => {
              viewportRef.current?.fit(res.segments);
              requestAnimationFrame(() => {
                resolve(res);
              });
            });
          });
        }),
    };
  }, [stopTimer]);

  const hasUnsavedDraft = (targetMode: Mode): boolean => {
    const draft = targetMode === mode ? code : loadDraft(targetMode);
    const baseline = loadBaselineCode(targetMode);
    return draft.trim() !== '' && draft !== baseline;
  };

  const handleSelectExample = (ex: ExampleProgram) => {
    stopTimer();
    stepperRef.current = null;
    setMode(ex.mode);
    setCode(ex.code);
    saveMode(ex.mode);
    saveDraft(ex.mode, ex.code);
    saveBaselineCode(ex.mode, ex.code);
    setRightTab('canvas');
    runInstant(ex.code, ex.mode, true);
  };

  const handleLoadChallengeStarter = (ch: Challenge) => {
    stopTimer();
    stepperRef.current = null;
    setMode(ch.mode);
    setCode(ch.starterCode);
    saveMode(ch.mode);
    saveDraft(ch.mode, ch.starterCode);
    saveBaselineCode(ch.mode, ch.starterCode);
    resetExecution();
    setMobileTab('editor');
  };

  const handleMarkSolved = (id: string) => {
    setSolvedChallenges((prev) => {
      const next = new Set(prev);
      next.add(id);
      saveSolvedChallenges(next);
      return next;
    });
  };

  const handleShare = async () => {
    const url = encodePermalink(mode, code);
    window.history.replaceState(null, '', url);
    try {
      await navigator.clipboard.writeText(url);
      showToast('Skopiowano link do schowka!');
    } catch {
      showToast('Zaktualizowano adres URL — możesz go skopiować z paska adresu.');
    }
  };

  const handleExportPng = () => {
    const canvas = viewportRef.current?.getCanvas();
    if (!canvas) {
      showToast('Brak płótna do zapisania.');
      return;
    }
    downloadCanvasPng(canvas, `logomocja-${mode}.png`);
  };

  const handleOpenLogoFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        const text = reader.result;
        setCode(text);
        saveDraft(mode, text);
        saveBaselineCode(mode, text);
        runInstant(text, mode, true);
        showToast(`Wczytano plik „${file.name}”.`);
      }
    };
    reader.readAsText(file, 'utf-8');
    e.target.value = '';
  };

  const effectiveDark = getEffectiveIsDark(themeOverride);

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand">
          <span className="brand-mark" aria-hidden="true">
            🐢
          </span>
          <span className="brand-name">Logomocja</span>
          <div className="mode-switch" role="group" aria-label="Tryb rysowania">
            <button
              type="button"
              className={`mode-btn${mode === '2d' ? ' is-active' : ''}`}
              aria-pressed={mode === '2d'}
              onClick={() => handleModeChange('2d')}
            >
              2D
            </button>
            <button
              type="button"
              className={`mode-btn${mode === '3d' ? ' is-active' : ''}`}
              aria-pressed={mode === '3d'}
              onClick={() => handleModeChange('3d')}
            >
              3D
            </button>
          </div>
        </div>

        <nav className="topbar-actions" aria-label="Narzędzia">
          <button
            type="button"
            className="btn btn-secondary"
            onClick={() => setExamplesOpen(true)}
          >
            <Sparkles size={16} />
            <span className="btn-label">Przykłady</span>
          </button>
          <button
            type="button"
            className="btn btn-secondary"
            onClick={() => fileInputRef.current?.click()}
            title="Otwórz plik .logo"
          >
            <FolderOpen size={16} />
            <span className="btn-label">Otwórz .logo</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".logo,.txt"
            className="sr-only"
            onChange={handleOpenLogoFile}
            aria-label="Wybierz plik .logo"
          />
          <button
            type="button"
            className="btn btn-secondary"
            onClick={() => downloadLogoFile(code)}
            title="Pobierz kod jako plik .logo"
          >
            <Download size={16} />
            <span className="btn-label">.logo</span>
          </button>
          <button
            type="button"
            className="btn btn-secondary"
            onClick={handleExportPng}
            title="Zapisz rysunek jako obraz PNG"
          >
            <ImageIcon size={16} />
            <span className="btn-label">PNG</span>
          </button>
          <button
            type="button"
            className="btn btn-secondary"
            onClick={handleShare}
            title="Utwórz link do programu"
          >
            <Share2 size={16} />
            <span className="btn-label">Udostępnij</span>
          </button>
          <button
            type="button"
            className="icon-btn"
            onClick={toggleTheme}
            aria-label={effectiveDark ? 'Przełącz na jasny motyw' : 'Przełącz na ciemny motyw'}
            title={effectiveDark ? 'Jasny motyw' : 'Ciemny motyw'}
          >
            {effectiveDark ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          <button
            type="button"
            className="icon-btn"
            onClick={() => setHelpOpen(true)}
            aria-label="Skróty klawiszowe i pomoc"
            title="Skróty klawiszowe"
          >
            <HelpCircle size={18} />
          </button>
        </nav>
      </header>

      <div className="mobile-tabs" role="tablist" aria-label="Widoki">
        <button
          type="button"
          role="tab"
          aria-selected={mobileTab === 'editor'}
          className={`mobile-tab${mobileTab === 'editor' ? ' is-active' : ''}`}
          onClick={() => setMobileTab('editor')}
        >
          Edytor
        </button>
        <button
          type="button"
          role="tab"
          aria-selected={mobileTab === 'canvas'}
          className={`mobile-tab${mobileTab === 'canvas' ? ' is-active' : ''}`}
          onClick={() => {
            setMobileTab('canvas');
            setRightTab('canvas');
          }}
        >
          Widok {mode.toUpperCase()}
        </button>
        <button
          type="button"
          role="tab"
          aria-selected={mobileTab === 'challenges'}
          className={`mobile-tab${mobileTab === 'challenges' ? ' is-active' : ''}`}
          onClick={() => {
            setMobileTab('challenges');
            setRightTab('challenges');
          }}
        >
          Wyzwania
        </button>
        <button
          type="button"
          role="tab"
          aria-selected={mobileTab === 'reference'}
          className={`mobile-tab${mobileTab === 'reference' ? ' is-active' : ''}`}
          onClick={() => {
            setMobileTab('reference');
            setRightTab('reference');
          }}
        >
          Polecenia
        </button>
      </div>

      <main className="workspace">
        <section
          className={`pane-editor${mobileTab === 'editor' ? ' is-mobile-visible' : ''}`}
          aria-label="Edytor i sterowanie"
        >
          <div className="exec-bar">
            <div className="exec-buttons">
              <button
                type="button"
                className="btn btn-primary"
                onClick={handleRun}
                title="Uruchom program (Ctrl+Enter)"
              >
                <Play size={15} />
                Uruchom
              </button>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={handleStep}
                title="Wykonaj jeden krok (Alt+S)"
              >
                <SkipForward size={15} />
                Krok
              </button>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={handlePauseResume}
                disabled={execStatus !== 'running' && execStatus !== 'paused'}
                title="Wstrzymaj lub wznów animację (Alt+P)"
              >
                <Pause size={15} />
                {execStatus === 'paused' ? 'Wznów' : 'Pauza'}
              </button>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={resetExecution}
                title="Resetuj rysunek i żółwia (Alt+R)"
              >
                <RotateCcw size={15} />
                Resetuj
              </button>
            </div>

            <label className="speed-control">
              <span>Tempo</span>
              <input
                type="range"
                min={1}
                max={100}
                value={speed}
                onChange={(e) => setSpeed(Number(e.target.value))}
                aria-label="Tempo animacji żółwia"
              />
              <span className="speed-val">{speed >= 100 ? 'Max' : `${speed}%`}</span>
            </label>
          </div>

          <Editor
            value={code}
            onChange={handleCodeChange}
            activeLine={activeLine}
            error={error}
          />
        </section>

        <section
          className={`pane-right${mobileTab !== 'editor' ? ' is-mobile-visible' : ''}`}
          aria-label="Podgląd i materiały"
        >
          <div className="right-tabs" role="tablist" aria-label="Panele prawe">
            <button
              type="button"
              role="tab"
              aria-selected={rightTab === 'canvas'}
              className={`right-tab${rightTab === 'canvas' ? ' is-active' : ''}`}
              onClick={() => setRightTab('canvas')}
            >
              <Layers size={15} />
              Płótno {mode.toUpperCase()}
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={rightTab === 'challenges'}
              className={`right-tab${rightTab === 'challenges' ? ' is-active' : ''}`}
              onClick={() => setRightTab('challenges')}
            >
              <Trophy size={15} />
              Wyzwania ({solvedChallenges.size}/6)
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={rightTab === 'reference'}
              className={`right-tab${rightTab === 'reference' ? ' is-active' : ''}`}
              onClick={() => setRightTab('reference')}
            >
              <BookOpen size={15} />
              Dokumentacja
            </button>
          </div>

          <div className="right-content">
            <div
              className={`tab-panel${rightTab === 'canvas' ? ' is-active' : ''}`}
              hidden={rightTab !== 'canvas'}
            >
              {mode === '2d' ? (
                <Viewport2D ref={viewportRef} segments={segments} turtle={turtle} />
              ) : (
                <Viewport3D ref={viewportRef} segments={segments} turtle={turtle} />
              )}
            </div>

            {rightTab === 'challenges' && (
              <ChallengesPanel
                currentCode={code}
                solvedIds={solvedChallenges}
                onMarkSolved={handleMarkSolved}
                onLoadStarter={handleLoadChallengeStarter}
              />
            )}

            {rightTab === 'reference' && <ReferencePanel />}
          </div>
        </section>
      </main>

      {toast && (
        <div className="toast" role="status" aria-live="polite">
          {toast}
        </div>
      )}

      <ExamplesModal
        open={examplesOpen}
        onClose={() => setExamplesOpen(false)}
        hasUnsavedDraft={hasUnsavedDraft}
        onSelectExample={handleSelectExample}
      />

      <HelpModal open={helpOpen} onClose={() => setHelpOpen(false)} />
    </div>
  );
}

export default App;
