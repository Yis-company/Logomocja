# Logomocja

Polskojęzyczne studio grafiki żółwia w przeglądarce — z trybem płaskim **2D** oraz przestrzennym **3D** (WebGL), bez kont, backendu i zapytań sieciowych w czasie działania.

## Wymagania

- [Bun](https://bun.sh/) (v1.0+)

## Uruchomienie, budowanie i testy

```sh
# Instalacja zależności
bun install

# Tryb deweloperski
bun run dev

# Testy interpretera i programów wzorcowych
bun run test

# Sprawdzenie typów TypeScript
bun run typecheck

# Budowa statycznej wersji produkcyjnej do katalogu dist/
bun run build
```

### Budowanie dla podkatalogu (`BASE_PATH`)

Aby wdrożyć aplikację pod podścieżką na statycznym serwerze bez reguł przepisywania adresów:

```sh
BASE_PATH=/Logomocja/builds/x/ bun run build
```

Linki udostępniania korzystają z fragmentu URL (`#p=...`), dzięki czemu odświeżenie strony działa poprawnie na dowolnym statycznym hoście.

## Skróty klawiszowe

- `Ctrl / ⌘ + Enter` — uruchom program
- `Alt + S` — wykonaj jeden krok
- `Alt + P` — wstrzymaj / wznów animację
- `Alt + R` — resetuj rysunek i żółwia

## Interfejs testowy (`window.logomocja`)

Po załadowaniu strony obiekt `window.logomocja` udostępnia:

- `version` — wersja aplikacji
- `run(source, mode)` — uruchamia kod w trybie `"2d"` lub `"3d"` bez ingerencji w UI i zwraca `{ segments, error }`
- `open(source, mode)` — wczytuje kod do edytora, uruchamia go bez animacji, dopasowuje widok i zwraca `Promise<{ segments, error }>`
