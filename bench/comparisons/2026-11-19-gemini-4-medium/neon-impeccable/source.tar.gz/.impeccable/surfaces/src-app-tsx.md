---
version: 1
slug: "src-app-tsx"
primary_target: "src/App.tsx"
related_targets: []
---

# Surface Brief: Logomocja Studio

- **Scope:** Main workspace (`src/App.tsx`), including Studio (2D/3D editor + canvas), Examples picker, Challenges workspace, and Polish Command Reference.
- **Visitor mode:** Operate
- **Audience & task:** Polish learners, students, educators, and Logo enthusiasts writing, stepping through, debugging, verifying, and sharing 2D and 3D turtle graphics programs on desktop and mobile.
- **Constraints:** Offline static bundle (`dist/`), `BASE_PATH` compatible via hash routing, Polish UI throughout, light/dark themes following system preference with manual toggle, full keyboard operability, WebGL graceful fallback, exact dialect semantics and `window.logomocja` testing hook.

## Direction contract

**THESIS:** Logomocja is a high-precision Polish drafting-and-chalkboard turtle studio where code and spatial geometry operate as one synchronized instrument, refusing both neon dark-IDE clichés and toy-like pastel coding blocks.

**OWN-WORLD:** Committed matte chalkboard pine-slate top shell (`#142b24`) anchoring a dual-theme workspace: daylight drafting-paper light mode (`#f5f4ee` ground, `#eaece6` rail, `#ffffff` canvas, `#16866a` pine accent, `#c1763d` ochre secondary) and authentic slate-green chalkboard dark mode (`#111e1a` ground, `#172823` panel, `#0d1714` canvas, `#25a886` emerald accent). Crisp 1px hairlines, restrained 6px/8px radii, workhorse Polish-complete sans UI type with tabular monospace strictly for code and telemetry, and a docked live Turtle Telemetry & Execution Strip as the signature move.

**STORY:** A learner opens the studio, sees an active Logo program already paired with its live canvas and turtle marker, runs or steps through commands while watching the active line and `(x, y, z)` telemetry update in lockstep, explores 2D/3D examples, solves auto-checked challenges, and shares work via permalink, `.logo`, or PNG.

**FIRST VIEWPORT:** A single-row 48px committed pine-slate top bar with the Logomocja wordmark, 2D/3D mode segmented switch, primary navigation tabs (Pracownia, Przykłady, Wyzwania, Słownik), file/share actions, and theme toggle. Below it, a full-height split workspace on desktop (42% code editor panel on the left with execution toolbar, line numbers, syntax highlighting, inline error marker, and keyboard shortcut legend; 58% interactive 2D/3D canvas on the right with viewport controls and the bottom-docked live Turtle Telemetry Strip). On mobile, stacked or tabbed Code/Canvas view with thumb-reachable execution controls.

**FORM:** Candidate 4 — Szkolna pracownia kreślarska (Tablica szkolna & drafting studio), adapted for Operate mode with standard web controls and dual light/dark themes. `seed:a4a42e852cefbc8d`

**FINISH:** unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, DESIGN.md, and every shipping raster carrying its provenance
