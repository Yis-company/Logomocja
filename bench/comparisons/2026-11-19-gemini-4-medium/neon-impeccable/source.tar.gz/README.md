# Logomocja

Polska pracownia języka Logo do rysowania żółwiem w 2D (płaszczyzna XY) i 3D (przestrzeń XYZ), działająca w całości w przeglądarce bez backendu i bez zapytań sieciowych w czasie działania.

## Funkcje

- **Edytor kodu Logo** — numery wierszy, kolorowanie składni polskiego i angielskiego dialektu, podświetlanie aktualnie wykonywanego wiersza oraz dokładny znacznik błędu z komunikatem po polsku (`W:K`).
- **Wykonywanie i debugowanie** — uruchamianie całości, wykonywanie krok po kroku (`F10` / `Alt+S`), pauza/wznawianie (`Alt+P`), reset (`Alt+R`) oraz płynna regulacja tempa animacji.
- **Widok 2D i 3D** — przesuwanie, przybliżanie, dopasowanie rysunku i widoczny początek układu w 2D; kamera orbitalna (obrót, przesuwanie, przybliżanie, reset), siatka i osie w 3D (WebGL z łagodnym komunikatem awaryjnym, gdy WebGL jest niedostępny).
- **13 wbudowanych przykładów** — 7 programów 2D i 6 programów 3D z ochroną przed przypadkowym nadpisaniem niezapisanego szkicu.
- **6 wyzwań rysunkowych** — podgląd kształtu docelowego, automatyczne sprawdzanie geometrii z tolerancją oraz zapis postępu w `localStorage`.
- **Udostępnianie i pliki** — stały link (permalink w hashu URL), eksport rysunku do PNG oraz zapis i odczyt plików `.logo`.
- **Słownik języka** — pełna dokumentacja poleceń, wyrażeń, zmiennych, warunków, procedur i limitów z przyciskami „Wypróbuj”.
- **Motyw jasny i ciemny** — automatyczne dopasowanie do ustawień systemu z ręcznym przełącznikiem oraz pełna obsługa klawiatury.

## Wymagania

- [Bun](https://bun.sh/) (v1.1+)

## Instalacja i uruchomienie

```bash
bun install
bun run dev
```

## Budowanie statycznej wersji (`dist/`)

```bash
bun run build
```

Budowanie respektuje zmienną środowiskową `BASE_PATH` (domyślnie `/`), dzięki czemu gotowe pliki w `dist/` działają w dowolnym podkatalogu statycznego serwera bez reguł przepisywania adresów:

```bash
BASE_PATH=/Logomocja/builds/x/ bun run build
```

## Testy

```bash
bun run test
```

Uruchamia testy interpretera Logo (wszystkie polecenia, priorytety i zasada spacji, zasięg zmiennych, rekurencja, limity, wszystkie 13 programów wzorcowych) oraz testy sprawdzarki wyzwań i permalinków.

## Interfejs testowy (`window.logomocja`)

Po załadowaniu strony dostępny jest obiekt `window.logomocja`:

- `window.logomocja.version` — wersja aplikacji (`"1.0.0"`),
- `window.logomocja.run(source, mode)` — wykonuje kod w trybie `"2d"` lub `"3d"` bez ingerencji w UI i zwraca `{ segments, error }`,
- `window.logomocja.open(source, mode)` — wczytuje kod do edytora w zadanym trybie, natychmiast uruchamia, dopasowuje widok i zwraca Promise z `{ segments, error }`.
