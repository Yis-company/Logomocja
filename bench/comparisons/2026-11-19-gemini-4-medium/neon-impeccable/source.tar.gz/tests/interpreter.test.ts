import { describe, expect, test } from 'bun:test';
import { runProgram, createStepper, LIMITS } from '../src/interpreter';
import { STANDARD_EXAMPLES } from '../src/data/examples';

describe('Interpreter — basic drawing & geometry', () => {
  test('empty program draws nothing without error', () => {
    const res = runProgram('; tylko komentarz\n   ', '2d');
    expect(res.error).toBeNull();
    expect(res.segments).toEqual([]);
  });

  test('initial state: origin, +Y heading, #16866a, width 3, pen down', () => {
    const res = runProgram('np 50', '2d');
    expect(res.error).toBeNull();
    expect(res.segments).toHaveLength(1);
    expect(res.segments[0].from).toEqual([0, 0, 0]);
    expect(res.segments[0].to[0]).toBeCloseTo(0, 9);
    expect(res.segments[0].to[1]).toBeCloseTo(50, 9);
    expect(res.segments[0].to[2]).toBeCloseTo(0, 9);
    expect(res.segments[0].color).toBe('#16866a');
    expect(res.segments[0].width).toBe(3);
  });

  test('zero move draws nothing', () => {
    const res = runProgram('np 0 ws 0', '2d');
    expect(res.error).toBeNull();
    expect(res.segments).toHaveLength(0);
  });

  test('pw rotates clockwise around +Z (from +Y to +X)', () => {
    const res = runProgram('pw 90 np 100', '2d');
    expect(res.error).toBeNull();
    expect(res.segments).toHaveLength(1);
    expect(res.segments[0].to[0]).toBeCloseTo(100, 9);
    expect(res.segments[0].to[1]).toBeCloseTo(0, 9);
    expect(res.segments[0].to[2]).toBeCloseTo(0, 9);
  });

  test('lw rotates counter-clockwise around +Z (from +Y to -X)', () => {
    const res = runProgram('lw 90 np 100', '2d');
    expect(res.error).toBeNull();
    expect(res.segments[0].to[0]).toBeCloseTo(-100, 9);
    expect(res.segments[0].to[1]).toBeCloseTo(0, 9);
  });

  test('pod / opu controls pen state', () => {
    const res = runProgram('np 10 pod np 20 opu np 30', '2d');
    expect(res.error).toBeNull();
    expect(res.segments).toHaveLength(2);
    expect(res.segments[0].to[1]).toBeCloseTo(10, 9);
    expect(res.segments[1].from[1]).toBeCloseTo(30, 9);
    expect(res.segments[1].to[1]).toBeCloseTo(60, 9);
  });

  test('dom returns to origin, draws if pen down and not at origin, resets orientation only', () => {
    const res = runProgram('kolor "#AA00BB" grubosc 5 pw 90 np 40 dom np 10', '2d');
    expect(res.error).toBeNull();
    expect(res.segments).toHaveLength(3);
    expect(res.segments[1].from[0]).toBeCloseTo(40, 9);
    expect(res.segments[1].to).toEqual([0, 0, 0]);
    expect(res.segments[2].to[0]).toBeCloseTo(0, 9);
    expect(res.segments[2].to[1]).toBeCloseTo(10, 9);
    expect(res.segments[2].color).toBe('#aa00bb');
    expect(res.segments[2].width).toBe(5);
  });

  test('czyść clears previously drawn segments only', () => {
    const res = runProgram('kolor "#c1763d" np 100 czyść np 20', '2d');
    expect(res.error).toBeNull();
    expect(res.segments).toHaveLength(1);
    expect(res.segments[0].from[1]).toBeCloseTo(100, 9);
    expect(res.segments[0].to[1]).toBeCloseTo(120, 9);
    expect(res.segments[0].color).toBe('#c1763d');
  });

  test('3D rotations: gora, dol, pp, pl', () => {
    // gora 90 pitches heading from +Y to +Z
    const r1 = runProgram('gora 90 np 50', '3d');
    expect(r1.error).toBeNull();
    expect(r1.segments[0].to[0]).toBeCloseTo(0, 9);
    expect(r1.segments[0].to[1]).toBeCloseTo(0, 9);
    expect(r1.segments[0].to[2]).toBeCloseTo(50, 9);

    // pp 90 rolls up (+Z) to right (+X), right (+X) to down (-Z), heading stays +Y
    // then pw 90 turns heading (+Y) toward new right (-Z)
    const r2 = runProgram('pp 90 pw 90 np 30', '3d');
    expect(r2.error).toBeNull();
    expect(r2.segments[0].to[0]).toBeCloseTo(0, 9);
    expect(r2.segments[0].to[1]).toBeCloseTo(0, 9);
    expect(r2.segments[0].to[2]).toBeCloseTo(-30, 9);
  });

  test('3D commands are parse-time errors in 2D mode', () => {
    for (const cmd of ['gora 10', 'góra 10', 'dol 10', 'dół 10', 'pp 10', 'pl 10', 'pitchup 10', 'rr 10']) {
      const res = runProgram(`np 10\n${cmd}`, '2d');
      expect(res.error).not.toBeNull();
      expect(res.error!.line).toBe(2);
      expect(res.error!.column).toBe(1);
      expect(res.segments).toEqual([]);
    }
  });

  test('flat programs produce identical coordinates in 2D and 3D mode', () => {
    const flatExamples = STANDARD_EXAMPLES.filter((e) => e.mode === '2d');
    for (const ex of flatExamples) {
      const r2d = runProgram(ex.source, '2d');
      const r3d = runProgram(ex.source, '3d');
      expect(r2d.error).toBeNull();
      expect(r3d.error).toBeNull();
      expect(r2d.segments).toEqual(r3d.segments);
    }
  });
});

describe('Interpreter — expressions, precedence & whitespace rules', () => {
  test('precedence and left associativity', () => {
    const r1 = runProgram('np 20 - 5 - 3', '2d');
    expect(r1.error).toBeNull();
    expect(r1.segments[0].to[1]).toBeCloseTo(12, 9);

    const r2 = runProgram('np 2 + 3 * 4', '2d');
    expect(r2.error).toBeNull();
    expect(r2.segments[0].to[1]).toBeCloseTo(14, 9);
  });

  test('binary operator whitespace rule', () => {
    expect(runProgram('np 10 - 5', '2d').segments[0].to[1]).toBeCloseTo(5, 9);
    expect(runProgram('np 10-5', '2d').segments[0].to[1]).toBeCloseTo(5, 9);

    // Asymmetric whitespace: `np 10 -5` is `np 10` followed by stray `-5`
    const bad = runProgram('np 10 -5', '2d');
    expect(bad.error).not.toBeNull();
    expect(bad.error!.line).toBe(1);
    expect(bad.error!.column).toBe(7);
    expect(bad.segments).toEqual([]);

    const bad2 = runProgram('np 10- 5', '2d');
    expect(bad2.error).not.toBeNull();
    expect(bad2.segments).toEqual([]);
  });

  test('stacked unary signs and parenthesized expressions', () => {
    expect(runProgram('np -(3 - 5)', '2d').segments[0].to[1]).toBeCloseTo(2, 9);
    expect(runProgram('np - -2', '2d').segments[0].to[1]).toBeCloseTo(2, 9);
    expect(runProgram('niech bok 15 np -bok', '2d').segments[0].to[1]).toBeCloseTo(-15, 9);
    expect(runProgram('np .5', '2d').segments[0].to[1]).toBeCloseTo(0.5, 9);
  });

  test('invalid number literals are errors', () => {
    for (const bad of ['np 1e3', 'np 0x10', 'np NaN', 'np Infinity', 'np 12.']) {
      const res = runProgram(bad, '2d');
      expect(res.error).not.toBeNull();
      expect(res.segments).toEqual([]);
    }
  });

  test('exact floating-point comparisons', () => {
    const res = runProgram('jeśli 0.1 + 0.2 = 0.3 [np 50]', '2d');
    expect(res.error).toBeNull();
    expect(res.segments).toHaveLength(0);

    const res2 = runProgram('jeśli 0.1 + 0.2 <> 0.3 [np 50]', '2d');
    expect(res2.error).toBeNull();
    expect(res2.segments).toHaveLength(1);
  });
});

describe('Interpreter — variables, repeat, conditionals & procedures', () => {
  test('nrpowt works lexically inside repeat and fails outside or inside called proc', () => {
    const ok = runProgram('powtorz 3 [np nrpowt * 10]', '2d');
    expect(ok.error).toBeNull();
    expect(ok.segments).toHaveLength(3);
    expect(ok.segments[2].to[1]).toBeCloseTo(60, 9);

    const badTop = runProgram('np nrpowt', '2d');
    expect(badTop.error).not.toBeNull();
    expect(badTop.error!.column).toBe(4);

    const badProc = runProgram('oto f\n  np nrpowt\njuż\npowtorz 2 [f]', '2d');
    expect(badProc.error).not.toBeNull();
    expect(badProc.error!.line).toBe(2);
  });

  test('variable scoping: global, local shadowing, forward declaration, unassigned runtime error', () => {
    // Local shadows global without mutating it
    const res = runProgram(
      `niech x 10
oto p
  niech x 25
  np x
już
p
np x`,
      '2d'
    );
    expect(res.error).toBeNull();
    expect(res.segments).toHaveLength(2);
    expect(res.segments[0].to[1]).toBeCloseTo(25, 9);
    expect(res.segments[1].to[1]).toBeCloseTo(35, 9);

    // Declared later at top level -> parse ok, runtime error when read before assignment
    const unassigned = runProgram('np 10\nnp x\nniech x 5', '2d');
    expect(unassigned.error).not.toBeNull();
    expect(unassigned.error!.line).toBe(2);
    expect(unassigned.error!.column).toBe(4);
    expect(unassigned.segments).toHaveLength(1); // runtime error keeps what was drawn!
  });

  test('legacy procedure syntax :param and parameter sharing name with procedure', () => {
    const res = runProgram(
      `oto krok :krok
  np :krok
już
krok 42`,
      '2d'
    );
    expect(res.error).toBeNull();
    expect(res.segments).toHaveLength(1);
    expect(res.segments[0].to[1]).toBeCloseTo(42, 9);
  });

  test('stop inside nested repeat ends enclosing procedure, not just repeat', () => {
    const res = runProgram(
      `oto testuj
  powtorz 5 [
    np 10
    jeśli nrpowt = 2 [stop]
  ]
  np 999
już
testuj
np 5`,
      '2d'
    );
    expect(res.error).toBeNull();
    expect(res.segments).toHaveLength(3);
    expect(res.segments[2].to[1]).toBeCloseTo(25, 9);
  });

  test('literal vs dynamic width/repeat validation', () => {
    // Parse-time error draws nothing
    const staticBad = runProgram('np 10\ngrubosc 13', '2d');
    expect(staticBad.error).not.toBeNull();
    expect(staticBad.error!.line).toBe(2);
    expect(staticBad.error!.column).toBe(9);
    expect(staticBad.segments).toEqual([]);

    // Runtime error keeps drawn segments and reports at first token of argument
    const dynBad = runProgram('niech w 13\nnp 10\ngrubosc (w)', '2d');
    expect(dynBad.error).not.toBeNull();
    expect(dynBad.error!.line).toBe(3);
    expect(dynBad.error!.column).toBe(9);
    expect(dynBad.segments).toHaveLength(1);
  });

  test('limits: operations, frames, coords', () => {
    const tooManyOps = runProgram('powtorz 10000 [np 1]', '2d');
    expect(tooManyOps.error).not.toBeNull();
    expect(tooManyOps.segments.length).toBeGreaterThan(0);

    const tooFar = runProgram('np 100001', '2d');
    expect(tooFar.error).not.toBeNull();
    expect(tooFar.error!.column).toBe(4);

    const tooDeep = runProgram('oto r\n  r\njuż\nr', '2d');
    expect(tooDeep.error).not.toBeNull();

    const tooBig = ' '.repeat(LIMITS.MAX_CHARS + 1);
    expect(runProgram(tooBig, '2d').error).not.toBeNull();
  });
});

describe('Standard programs (all 13 verbatim)', () => {
  for (const ex of STANDARD_EXAMPLES) {
    test(`runs "${ex.name}" (${ex.id}, ${ex.mode}) cleanly`, () => {
      const res = runProgram(ex.source, ex.mode);
      expect(res.error).toBeNull();
      expect(res.segments.length).toBeGreaterThan(0);
    });
  }

  test('stepper produces identical result to runProgram', () => {
    const drzewo = STANDARD_EXAMPLES.find((e) => e.id === 'drzewo')!;
    const full = runProgram(drzewo.source, '2d');
    const { stepper, error } = createStepper(drzewo.source, '2d');
    expect(error).toBeNull();
    expect(stepper).not.toBeNull();
    while (!stepper!.isDone()) {
      stepper!.step();
    }
    const snap = stepper!.getSnapshot();
    expect(snap.error).toBeNull();
    expect(snap.segments).toEqual(full.segments);
  });
});
