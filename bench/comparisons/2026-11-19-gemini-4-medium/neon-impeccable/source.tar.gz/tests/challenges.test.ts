import { describe, expect, test } from 'bun:test';
import { CHALLENGES, getChallengeTargetSegments } from '../src/data/challenges';
import { runProgram } from '../src/interpreter';
import { checkDrawingAgainstTarget } from '../src/utils/challengeChecker';
import { decodeProgramBase64Url, encodeProgramBase64Url, parseHashUrl } from '../src/utils/urlState';

describe('Challenges & geometric checker', () => {
  for (const ch of CHALLENGES) {
    test(`reference solution passes "${ch.title}" (${ch.mode})`, () => {
      const target = getChallengeTargetSegments(ch);
      const actual = runProgram(ch.referenceSolution, ch.mode);
      expect(actual.error).toBeNull();
      const verdict = checkDrawingAgainstTarget(actual.segments, target, ch.tolerance);
      expect(verdict.passed).toBe(true);
    });
  }

  test('empty drawing fails with clear Polish reason', () => {
    const target = getChallengeTargetSegments(CHALLENGES[0]);
    const verdict = checkDrawingAgainstTarget([], target, 2.5);
    expect(verdict.passed).toBe(false);
    expect(verdict.reason).toContain('nie narysował');
  });

  test('incomplete drawing fails', () => {
    const target = getChallengeTargetSegments(CHALLENGES[0]); // square 100
    const partial = runProgram('powtorz 2 [np 100 pw 90]', '2d').segments;
    const verdict = checkDrawingAgainstTarget(partial, target, 2.5);
    expect(verdict.passed).toBe(false);
  });
});

describe('Permalink & hash routing', () => {
  test('round-trips Polish source with diacritics', () => {
    const src = '; Żółć i gęślą jaźń\noto gałąź ma: dł\n  np dł\njuż\ngałąź 50';
    const enc = encodeProgramBase64Url(src);
    expect(decodeProgramBase64Url(enc)).toBe(src);
    const parsed = parseHashUrl(`#pracownia?m=3d&p=${enc}`);
    expect(parsed.route).toBe('pracownia');
    expect(parsed.sharedMode).toBe('3d');
    expect(parsed.sharedSource).toBe(src);
  });
});
