import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

function normalizeBasePath(raw?: string): string {
  if (!raw || raw.trim() === '') return '/';
  let base = raw.trim();
  if (!base.startsWith('/')) base = '/' + base;
  if (!base.endsWith('/')) base = base + '/';
  return base;
}

export default defineConfig({
  base: normalizeBasePath(process.env.BASE_PATH),
  plugins: [react()],
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    sourcemap: false,
  },
});
