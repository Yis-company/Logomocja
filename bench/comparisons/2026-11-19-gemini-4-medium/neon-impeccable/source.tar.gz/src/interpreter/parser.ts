import {
  ArithOp,
  CanonicalCommand,
  CompareOp,
  Condition,
  Expr,
  LIMITS,
  LogoError,
  Mode,
  ProcedureDef,
  Program,
  Stmt,
  Token,
} from './types';
import { lex } from './lexer';

export const COMMAND_ALIASES: Record<string, CanonicalCommand> = {
  np: 'fd',
  naprzod: 'fd',
  naprzód: 'fd',
  fd: 'fd',
  forward: 'fd',

  ws: 'bk',
  wstecz: 'bk',
  bk: 'bk',
  back: 'bk',

  pw: 'rt',
  prawo: 'rt',
  rt: 'rt',
  right: 'rt',

  lw: 'lt',
  lewo: 'lt',
  lt: 'lt',
  left: 'lt',

  pod: 'pu',
  podnies: 'pu',
  podnieś: 'pu',
  pu: 'pu',
  penup: 'pu',

  opu: 'pd',
  opusc: 'pd',
  opuść: 'pd',
  pd: 'pd',
  pendown: 'pd',

  kolor: 'color',
  color: 'color',

  grubosc: 'width',
  grubość: 'width',
  width: 'width',

  powtorz: 'repeat',
  powtórz: 'repeat',
  repeat: 'repeat',

  niech: 'let',
  let: 'let',

  jeśli: 'if',
  jesli: 'if',
  if: 'if',

  jeżeli: 'ifelse',
  jezeli: 'ifelse',
  ifelse: 'ifelse',

  stop: 'stop',

  dom: 'home',
  home: 'home',

  czyść: 'cs',
  czysc: 'cs',
  cs: 'cs',
  clearscreen: 'cs',

  gora: 'pitchup',
  góra: 'pitchup',
  pitchup: 'pitchup',

  dol: 'pitchdown',
  dół: 'pitchdown',
  pitchdown: 'pitchdown',

  pp: 'rollright',
  przechylprawo: 'rollright',
  rr: 'rollright',
  rollright: 'rollright',

  pl: 'rollleft',
  przechyllewo: 'rollleft',
  rl: 'rollleft',
  rollleft: 'rollleft',
};

const RESERVED_KEYWORDS = new Set<string>([
  ...Object.keys(COMMAND_ALIASES),
  'oto',
  'to',
  'już',
  'juz',
  'end',
  'nrpowt',
  'repcount',
]);

const COMPARE_TOKEN_MAP: Partial<Record<Token['type'], CompareOp>> = {
  LT: '<',
  GT: '>',
  EQ: '=',
  LTE: '<=',
  GTE: '>=',
  NEQ: '<>',
};

export function isReservedWord(normalized: string): boolean {
  return RESERVED_KEYWORDS.has(normalized);
}

class ParseException extends Error {
  line: number;
  column: number;
  constructor(message: string, line: number, column: number) {
    super(message);
    this.line = line;
    this.column = column;
  }
}

interface RawProcedure {
  name: string;
  displayName: string;
  params: string[];
  bodyTokens: Token[];
  line: number;
  column: number;
}

interface ParseContext {
  mode: Mode;
  procedures: Map<string, { params: string[]; displayName: string }>;
  globalVars: Set<string>;
  localVars: Set<string>;
  params: Set<string>;
  repeatDepth: number;
  bracketDepth: number;
}

function isProcStart(tok: Token): boolean {
  return tok.type === 'WORD' && (tok.normalized === 'oto' || tok.normalized === 'to');
}

function isProcEnd(tok: Token): boolean {
  return tok.type === 'WORD' && (tok.normalized === 'już' || tok.normalized === 'juz' || tok.normalized === 'end');
}

function isRepcount(tok: Token): boolean {
  return tok.type === 'WORD' && (tok.normalized === 'nrpowt' || tok.normalized === 'repcount');
}

function isBinaryArithOp(tok: Token): boolean {
  if (tok.type !== 'PLUS' && tok.type !== 'MINUS' && tok.type !== 'STAR' && tok.type !== 'SLASH') {
    return false;
  }
  return tok.spaceBefore === tok.spaceAfter;
}

function isConstExpr(expr: Expr): boolean {
  switch (expr.kind) {
    case 'number':
      return true;
    case 'var':
    case 'repcount':
      return false;
    case 'unary':
      return isConstExpr(expr.operand);
    case 'binary':
      return isConstExpr(expr.left) && isConstExpr(expr.right);
  }
}

function evalConstExpr(expr: Expr, originLine: number, originCol: number): number {
  switch (expr.kind) {
    case 'number':
      return expr.value;
    case 'unary': {
      const v = evalConstExpr(expr.operand, originLine, originCol);
      return expr.op === '-' ? -v : v;
    }
    case 'binary': {
      const l = evalConstExpr(expr.left, originLine, originCol);
      const r = evalConstExpr(expr.right, originLine, originCol);
      let res: number;
      switch (expr.op) {
        case '+':
          res = l + r;
          break;
        case '-':
          res = l - r;
          break;
        case '*':
          res = l * r;
          break;
        case '/':
          if (r === 0) {
            throw new ParseException('Dzielenie przez zero w wyrażeniu.', originLine, originCol);
          }
          res = l / r;
          break;
      }
      if (!Number.isFinite(res)) {
        throw new ParseException('Wynik wyrażenia nie jest skończoną liczbą.', originLine, originCol);
      }
      return res;
    }
    default:
      throw new ParseException('Wyrażenie nie jest stałe.', originLine, originCol);
  }
}

function collectDeclaredVars(tokens: Token[]): Set<string> {
  const vars = new Set<string>();
  for (let i = 0; i < tokens.length - 1; i++) {
    const t = tokens[i];
    if (t.type === 'WORD' && (t.normalized === 'niech' || t.normalized === 'let')) {
      const next = tokens[i + 1];
      if (next && next.type === 'WORD') {
        vars.add(next.normalized);
      }
    }
  }
  return vars;
}

function splitTopLevelAndProcedures(tokens: Token[]): {
  topLevelTokens: Token[];
  rawProcedures: RawProcedure[];
} {
  const topLevelTokens: Token[] = [];
  const rawProcedures: RawProcedure[] = [];
  const seenNames = new Set<string>();
  const eofTok = tokens[tokens.length - 1];

  let i = 0;
  let bracketDepth = 0;

  while (i < tokens.length - 1) {
    const tok = tokens[i];

    if (tok.type === 'LBRACKET') {
      bracketDepth++;
      topLevelTokens.push(tok);
      i++;
      continue;
    }
    if (tok.type === 'RBRACKET') {
      if (bracketDepth > 0) bracketDepth--;
      topLevelTokens.push(tok);
      i++;
      continue;
    }

    if (isProcEnd(tok)) {
      throw new ParseException(
        `Nieoczekiwane „${tok.value}” poza definicją procedury.`,
        tok.line,
        tok.column
      );
    }

    if (isProcStart(tok)) {
      if (bracketDepth > 0) {
        throw new ParseException(
          'Definicje procedur („oto”) mogą występować wyłącznie na poziomie głównym programu.',
          tok.line,
          tok.column
        );
      }
      if (!tok.atLineStart) {
        throw new ParseException(
          `Definicja procedury „${tok.value}” musi zaczynać się na początku wiersza.`,
          tok.line,
          tok.column
        );
      }

      const headerLine = tok.line;
      i++;
      const nameTok = tokens[i];
      if (!nameTok || nameTok.type === 'EOF' || nameTok.line !== headerLine) {
        throw new ParseException(
          'Oczekiwano nazwy procedury w tym samym wierszu co „oto”.',
          tok.line,
          tok.column
        );
      }
      if (nameTok.type !== 'WORD') {
        throw new ParseException(
          `Nieprawidłowa nazwa procedury „${nameTok.value}”.`,
          nameTok.line,
          nameTok.column
        );
      }
      if (isReservedWord(nameTok.normalized)) {
        throw new ParseException(
          `Nazwa procedury „${nameTok.value}” jest zarezerwowanym słowem języka.`,
          nameTok.line,
          nameTok.column
        );
      }
      if (seenNames.has(nameTok.normalized)) {
        throw new ParseException(
          `Procedura „${nameTok.value}” została już zdefiniowana.`,
          nameTok.line,
          nameTok.column
        );
      }
      seenNames.add(nameTok.normalized);
      i++;

      const params: string[] = [];
      const paramSet = new Set<string>();

      if (i < tokens.length - 1 && tokens[i].line === headerLine) {
        const next = tokens[i];
        if (next.type === 'MA_COLON') {
          i++;
          // Expect comma-separated parameter names on headerLine
          if (i >= tokens.length - 1 || tokens[i].line !== headerLine) {
            throw new ParseException(
              'Po „ma:” oczekiwano co najmniej jednego parametru.',
              next.line,
              next.column
            );
          }
          while (true) {
            const pTok = tokens[i];
            if (!pTok || pTok.type === 'EOF' || pTok.line !== headerLine) {
              throw new ParseException(
                'Po przecinku oczekiwano kolejnej nazwy parametru.',
                tokens[i - 1].line,
                tokens[i - 1].column
              );
            }
            if (pTok.type !== 'WORD') {
              throw new ParseException(
                `Nieprawidłowa nazwa parametru „${pTok.value}”.`,
                pTok.line,
                pTok.column
              );
            }
            if (isReservedWord(pTok.normalized)) {
              throw new ParseException(
                `Nazwa parametru „${pTok.value}” jest zarezerwowanym słowem języka.`,
                pTok.line,
                pTok.column
              );
            }
            if (paramSet.has(pTok.normalized)) {
              throw new ParseException(
                `Powtórzona nazwa parametru „${pTok.value}”.`,
                pTok.line,
                pTok.column
              );
            }
            paramSet.add(pTok.normalized);
            params.push(pTok.normalized);
            i++;

            if (i < tokens.length - 1 && tokens[i].line === headerLine) {
              if (tokens[i].type === 'COMMA') {
                i++;
                continue;
              }
              throw new ParseException(
                `W nagłówku procedury po „ma:” parametry należy rozdzielać przecinkiem, napotkano „${tokens[i].value}”.`,
                tokens[i].line,
                tokens[i].column
              );
            }
            break;
          }
        } else if (next.type === 'COLON_WORD') {
          while (i < tokens.length - 1 && tokens[i].line === headerLine) {
            const pTok = tokens[i];
            if (pTok.type !== 'COLON_WORD') {
              throw new ParseException(
                `Oczekiwano parametru w formacie „:nazwa”, napotkano „${pTok.value}”.`,
                pTok.line,
                pTok.column
              );
            }
            if (isReservedWord(pTok.normalized)) {
              throw new ParseException(
                `Nazwa parametru „:${pTok.value}” jest zarezerwowanym słowem języka.`,
                pTok.line,
                pTok.column
              );
            }
            if (paramSet.has(pTok.normalized)) {
              throw new ParseException(
                `Powtórzona nazwa parametru „:${pTok.value}”.`,
                pTok.line,
                pTok.column
              );
            }
            paramSet.add(pTok.normalized);
            params.push(pTok.normalized);
            i++;
          }
        } else {
          throw new ParseException(
            `Nieoczekiwany token „${next.value}” w nagłówku procedury. Użyj „ma: parametr” lub „:parametr”.`,
            next.line,
            next.column
          );
        }
      }

      // Collect body tokens until standalone `już` / `juz` / `end`
      const bodyTokens: Token[] = [];
      let foundEnd = false;
      while (i < tokens.length - 1) {
        const bt = tokens[i];
        if (isProcStart(bt)) {
          throw new ParseException(
            'Nie można definiować procedury wewnątrz innej procedury.',
            bt.line,
            bt.column
          );
        }
        if (isProcEnd(bt)) {
          const nextAfter = tokens[i + 1];
          const aloneOnLine =
            bt.atLineStart && (!nextAfter || nextAfter.type === 'EOF' || nextAfter.line > bt.line);
          if (!aloneOnLine) {
            throw new ParseException(
              `Słowo „${bt.value}” kończące procedurę musi stać samodzielnie w osobnym wierszu.`,
              bt.line,
              bt.column
            );
          }
          i++;
          foundEnd = true;
          break;
        }
        bodyTokens.push(bt);
        i++;
      }

      if (!foundEnd) {
        throw new ParseException(
          `Brak zakończenia „już” dla procedury „${nameTok.value}”.`,
          tok.line,
          tok.column
        );
      }

      bodyTokens.push({
        ...eofTok,
        line: bodyTokens.length > 0 ? bodyTokens[bodyTokens.length - 1].line : tok.line,
        column: bodyTokens.length > 0 ? bodyTokens[bodyTokens.length - 1].column : tok.column,
      });

      rawProcedures.push({
        name: nameTok.normalized,
        displayName: nameTok.value,
        params,
        bodyTokens,
        line: tok.line,
        column: tok.column,
      });
      continue;
    }

    topLevelTokens.push(tok);
    i++;
  }

  topLevelTokens.push(eofTok);
  return { topLevelTokens, rawProcedures };
}

class StreamParser {
  private tokens: Token[];
  private pos = 0;
  private ctx: ParseContext;

  constructor(tokens: Token[], ctx: ParseContext) {
    this.tokens = tokens;
    this.ctx = ctx;
  }

  private peek(offset = 0): Token {
    const idx = this.pos + offset;
    return idx < this.tokens.length ? this.tokens[idx] : this.tokens[this.tokens.length - 1];
  }

  private advance(): Token {
    const tok = this.peek();
    if (this.pos < this.tokens.length - 1) this.pos++;
    return tok;
  }

  parseStatements(stopAtRBracket: boolean): Stmt[] {
    const stmts: Stmt[] = [];
    while (true) {
      const tok = this.peek();
      if (tok.type === 'EOF') {
        if (stopAtRBracket) {
          throw new ParseException('Niezamknięty nawias kwadratowy `[` — brakuje `]`.', tok.line, tok.column);
        }
        break;
      }
      if (tok.type === 'RBRACKET') {
        if (stopAtRBracket) {
          break;
        }
        throw new ParseException('Nieoczekiwany zamykający nawias `]` bez otwierającego `[`.', tok.line, tok.column);
      }
      stmts.push(this.parseStatement());
    }
    return stmts;
  }

  private parseStatement(): Stmt {
    const tok = this.peek();

    if (isProcStart(tok)) {
      throw new ParseException(
        'Definicje procedur („oto”) mogą występować wyłącznie na poziomie głównym programu.',
        tok.line,
        tok.column
      );
    }

    if (tok.type !== 'WORD') {
      throw new ParseException(
        `Oczekiwano polecenia, a napotkano „${tok.value || 'koniec programu'}”.`,
        tok.line,
        tok.column
      );
    }

    const cmd = COMMAND_ALIASES[tok.normalized];
    if (cmd) {
      this.advance();
      return this.parseBuiltin(cmd, tok);
    }

    const proc = this.ctx.procedures.get(tok.normalized);
    if (proc) {
      this.advance();
      const args: Expr[] = [];
      for (let a = 0; a < proc.params.length; a++) {
        args.push(this.parseRequiredExpr(tok, `argumentu ${a + 1} dla procedury „${tok.value}”`));
      }
      return {
        kind: 'call',
        name: tok.normalized,
        displayName: tok.value,
        args,
        line: tok.line,
        column: tok.column,
      };
    }

    throw new ParseException(
      `Nieznane polecenie lub procedura „${tok.value}”.`,
      tok.line,
      tok.column
    );
  }

  private parseBuiltin(cmd: CanonicalCommand, tok: Token): Stmt {
    switch (cmd) {
      case 'fd':
        return { kind: 'move', dir: 1, expr: this.parseRequiredExpr(tok, 'odległości'), line: tok.line, column: tok.column };
      case 'bk':
        return { kind: 'move', dir: -1, expr: this.parseRequiredExpr(tok, 'odległości'), line: tok.line, column: tok.column };
      case 'rt':
        return { kind: 'turn', axis: 'yaw', dir: 1, expr: this.parseRequiredExpr(tok, 'kąta'), line: tok.line, column: tok.column };
      case 'lt':
        return { kind: 'turn', axis: 'yaw', dir: -1, expr: this.parseRequiredExpr(tok, 'kąta'), line: tok.line, column: tok.column };
      case 'pitchup':
      case 'pitchdown':
      case 'rollright':
      case 'rollleft': {
        if (this.ctx.mode === '2d') {
          throw new ParseException(
            `Polecenie „${tok.value}” działa wyłącznie w trybie 3D.`,
            tok.line,
            tok.column
          );
        }
        const axis = cmd === 'pitchup' || cmd === 'pitchdown' ? 'pitch' : 'roll';
        const dir: 1 | -1 = cmd === 'pitchup' || cmd === 'rollright' ? 1 : -1;
        return { kind: 'turn', axis, dir, expr: this.parseRequiredExpr(tok, 'kąta'), line: tok.line, column: tok.column };
      }
      case 'pu':
        return { kind: 'pen', down: false, line: tok.line, column: tok.column };
      case 'pd':
        return { kind: 'pen', down: true, line: tok.line, column: tok.column };
      case 'home':
        return { kind: 'home', line: tok.line, column: tok.column };
      case 'cs':
        return { kind: 'cs', line: tok.line, column: tok.column };
      case 'stop':
        return { kind: 'stop', line: tok.line, column: tok.column };
      case 'color': {
        const next = this.peek();
        if (next.type === 'EOF') {
          throw new ParseException('Brakuje koloru po poleceniu „kolor” (np. "#16866a").', tok.line, tok.column);
        }
        if (next.type !== 'COLOR') {
          throw new ParseException(
            `Oczekiwano koloru w formacie "#rrggbb", napotkano „${next.value}”.`,
            next.line,
            next.column
          );
        }
        this.advance();
        return { kind: 'color', color: next.value, line: tok.line, column: tok.column };
      }
      case 'width': {
        const expr = this.parseRequiredExpr(tok, 'grubości (liczba całkowita 1–12)');
        if (isConstExpr(expr)) {
          const val = evalConstExpr(expr, expr.line, expr.column);
          if (!Number.isInteger(val) || val < LIMITS.MIN_WIDTH || val > LIMITS.MAX_WIDTH) {
            throw new ParseException(
              `Grubość pisaka musi być liczbą całkowitą od ${LIMITS.MIN_WIDTH} do ${LIMITS.MAX_WIDTH} (otrzymano ${val}).`,
              expr.line,
              expr.column
            );
          }
        }
        return { kind: 'width', expr, line: tok.line, column: tok.column };
      }
      case 'let': {
        const nameTok = this.peek();
        if (nameTok.type === 'EOF') {
          throw new ParseException('Brakuje nazwy zmiennej po „niech”.', tok.line, tok.column);
        }
        if (nameTok.type !== 'WORD') {
          throw new ParseException(
            `Oczekiwano nazwy zmiennej po „niech”, napotkano „${nameTok.value}”.`,
            nameTok.line,
            nameTok.column
          );
        }
        if (isReservedWord(nameTok.normalized)) {
          throw new ParseException(
            `Nazwa zmiennej „${nameTok.value}” jest zarezerwowanym słowem języka.`,
            nameTok.line,
            nameTok.column
          );
        }
        if (this.ctx.procedures.has(nameTok.normalized)) {
          throw new ParseException(
            `Nazwa zmiennej „${nameTok.value}” koliduje z nazwą zdefiniowanej procedury.`,
            nameTok.line,
            nameTok.column
          );
        }
        this.advance();
        const expr = this.parseRequiredExpr(nameTok, `wartości zmiennej „${nameTok.value}”`);
        return {
          kind: 'let',
          name: nameTok.normalized,
          displayName: nameTok.value,
          expr,
          line: tok.line,
          column: tok.column,
        };
      }
      case 'repeat': {
        const countExpr = this.parseRequiredExpr(tok, 'liczby powtórzeń (0–10000)');
        if (isConstExpr(countExpr)) {
          const val = evalConstExpr(countExpr, countExpr.line, countExpr.column);
          if (!Number.isInteger(val) || val < LIMITS.MIN_REPEAT || val > LIMITS.MAX_REPEAT) {
            throw new ParseException(
              `Liczba powtórzeń musi być liczbą całkowitą od ${LIMITS.MIN_REPEAT} do ${LIMITS.MAX_REPEAT} (otrzymano ${val}).`,
              countExpr.line,
              countExpr.column
            );
          }
        }
        this.ctx.repeatDepth++;
        let body: Stmt[];
        try {
          body = this.parseBracketBlock(tok, 'bloku powtórzeń `[ ... ]`');
        } finally {
          this.ctx.repeatDepth--;
        }
        return { kind: 'repeat', countExpr, body, line: tok.line, column: tok.column };
      }
      case 'if': {
        const condition = this.parseCondition(tok);
        const body = this.parseBracketBlock(tok, 'bloku instrukcji `[ ... ]` po warunku „jeśli”');
        return { kind: 'if', condition, body, line: tok.line, column: tok.column };
      }
      case 'ifelse': {
        const condition = this.parseCondition(tok);
        const thenBody = this.parseBracketBlock(tok, 'pierwszego bloku `[ ... ]` dla „jeżeli”');
        const elseBody = this.parseBracketBlock(tok, 'drugiego bloku `[ ... ]` dla „jeżeli”');
        return { kind: 'ifelse', condition, thenBody, elseBody, line: tok.line, column: tok.column };
      }
    }
  }

  private parseBracketBlock(ownerTok: Token, label: string): Stmt[] {
    const openTok = this.peek();
    if (openTok.type === 'EOF') {
      throw new ParseException(`Brakuje ${label}.`, ownerTok.line, ownerTok.column);
    }
    if (openTok.type !== 'LBRACKET') {
      throw new ParseException(
        `Oczekiwano nawiasu otwierającego „[” dla ${label}, napotkano „${openTok.value}”.`,
        openTok.line,
        openTok.column
      );
    }
    this.advance();
    this.ctx.bracketDepth++;
    if (this.ctx.bracketDepth > LIMITS.MAX_BRACKET_DEPTH) {
      throw new ParseException(
        `Przekroczono maksymalną głębokość zagnieżdżenia nawiasów (${LIMITS.MAX_BRACKET_DEPTH}).`,
        openTok.line,
        openTok.column
      );
    }
    let body: Stmt[];
    try {
      body = this.parseStatements(true);
    } finally {
      this.ctx.bracketDepth--;
    }
    const closeTok = this.peek();
    if (closeTok.type !== 'RBRACKET') {
      throw new ParseException('Niezamknięty nawias kwadratowy `[` — oczekiwano `]`.', openTok.line, openTok.column);
    }
    this.advance();
    return body;
  }

  private parseCondition(ownerTok: Token): Condition {
    const left = this.parseRequiredExpr(ownerTok, 'lewej strony warunku');
    const opTok = this.peek();
    const op = COMPARE_TOKEN_MAP[opTok.type];
    if (!op) {
      if (opTok.type === 'EOF') {
        throw new ParseException(
          'Brakuje operatora porównania (`<`, `>`, `=`, `<=`, `>=`, `<>`) w warunku.',
          ownerTok.line,
          ownerTok.column
        );
      }
      throw new ParseException(
        `Oczekiwano operatora porównania (<, >, =, <=, >=, <>), napotkano „${opTok.value}”.`,
        opTok.line,
        opTok.column
      );
    }
    this.advance();
    const right = this.parseRequiredExpr(opTok, 'prawej strony warunku');
    return { left, op, right, line: left.line, column: left.column };
  }

  private parseRequiredExpr(ownerTok: Token, expectedDesc: string): Expr {
    const next = this.peek();
    if (next.type === 'EOF') {
      throw new ParseException(`Brakuje ${expectedDesc}.`, ownerTok.line, ownerTok.column);
    }
    return this.parseAddSub(expectedDesc);
  }

  private parseAddSub(expectedDesc: string): Expr {
    let left = this.parseMulDiv(expectedDesc);
    while (true) {
      const tok = this.peek();
      if ((tok.type === 'PLUS' || tok.type === 'MINUS') && isBinaryArithOp(tok)) {
        this.advance();
        const op: ArithOp = tok.type === 'PLUS' ? '+' : '-';
        const right = this.parseMulDiv(`prawego argumentu operatora „${op}”`);
        left = { kind: 'binary', op, left, right, line: left.line, column: left.column };
      } else {
        break;
      }
    }
    return left;
  }

  private parseMulDiv(expectedDesc: string): Expr {
    let left = this.parseUnary(expectedDesc);
    while (true) {
      const tok = this.peek();
      if ((tok.type === 'STAR' || tok.type === 'SLASH') && isBinaryArithOp(tok)) {
        this.advance();
        const op: ArithOp = tok.type === 'STAR' ? '*' : '/';
        const right = this.parseUnary(`prawego argumentu operatora „${op}”`);
        left = { kind: 'binary', op, left, right, line: left.line, column: left.column };
      } else {
        break;
      }
    }
    return left;
  }

  private parseUnary(expectedDesc: string): Expr {
    const tok = this.peek();
    if (tok.type === 'MINUS' || tok.type === 'PLUS') {
      this.advance();
      const op: '+' | '-' = tok.type === 'MINUS' ? '-' : '+';
      const next = this.peek();
      if (next.type === 'EOF') {
        throw new ParseException(`Brakuje wyrażenia po operatorze jednoargumentowym „${op}”.`, tok.line, tok.column);
      }
      const operand = this.parseUnary(`argumentu po operatorze „${op}”`);
      return { kind: 'unary', op, operand, line: tok.line, column: tok.column };
    }
    return this.parsePrimary(expectedDesc);
  }

  private parsePrimary(expectedDesc: string): Expr {
    const tok = this.peek();

    if (tok.type === 'NUMBER') {
      this.advance();
      const val = Number(tok.value);
      if (!Number.isFinite(val)) {
        throw new ParseException(`Nieprawidłowa liczba „${tok.value}”.`, tok.line, tok.column);
      }
      return { kind: 'number', value: val, line: tok.line, column: tok.column };
    }

    if (tok.type === 'LPAREN') {
      this.advance();
      const next = this.peek();
      if (next.type === 'RPAREN') {
        throw new ParseException('Puste nawiasy `()` nie są prawidłowym wyrażeniem.', tok.line, tok.column);
      }
      if (next.type === 'EOF') {
        throw new ParseException('Niezamknięty nawias `(` — oczekiwano wyrażenia i `)`.', tok.line, tok.column);
      }
      const inner = this.parseAddSub('wyrażenia w nawiasach');
      const closeTok = this.peek();
      if (closeTok.type !== 'RPAREN') {
        throw new ParseException(
          closeTok.type === 'EOF'
            ? 'Niezamknięty nawias „(” — brakuje „)”.'
            : `Oczekiwano zamykającego nawiasu „)”, napotkano „${closeTok.value}”.`,
          closeTok.type === 'EOF' ? tok.line : closeTok.line,
          closeTok.type === 'EOF' ? tok.column : closeTok.column
        );
      }
      this.advance();
      // Preserve the first token position of the argument expression
      return { ...inner, line: tok.line, column: tok.column };
    }

    if (isRepcount(tok)) {
      if (this.ctx.repeatDepth <= 0) {
        throw new ParseException(
          `Wartość „${tok.value}” może być używana wyłącznie wewnątrz pętli „powtorz”.`,
          tok.line,
          tok.column
        );
      }
      this.advance();
      return { kind: 'repcount', line: tok.line, column: tok.column };
    }

    if (tok.type === 'WORD' || tok.type === 'COLON_WORD') {
      const name = tok.normalized;
      if (tok.type === 'WORD' && isReservedWord(name)) {
        throw new ParseException(
          `Oczekiwano ${expectedDesc}, a napotkano słowo kluczowe „${tok.value}”.`,
          tok.line,
          tok.column
        );
      }
      if (
        !this.ctx.params.has(name) &&
        !this.ctx.localVars.has(name) &&
        !this.ctx.globalVars.has(name)
      ) {
        if (name === 'nan' || name === 'infinity') {
          throw new ParseException(
            `„${tok.value}” nie jest prawidłową liczbą ani zadeklarowaną zmienną.`,
            tok.line,
            tok.column
          );
        }
        throw new ParseException(
          `Nieznana zmienna lub parametr „${tok.value}”. Użyj „niech ${tok.value} ...”, aby ją zadeklarować.`,
          tok.line,
          tok.column
        );
      }
      this.advance();
      return { kind: 'var', name, displayName: tok.value, line: tok.line, column: tok.column };
    }

    throw new ParseException(
      `Oczekiwano ${expectedDesc}, napotkano „${tok.value || 'koniec programu'}”.`,
      tok.line,
      tok.column
    );
  }
}

export interface ParseResult {
  program: Program | null;
  error: LogoError | null;
}

export function parseProgram(source: string, mode: Mode): ParseResult {
  const lexed = lex(source);
  if (lexed.error) {
    return { program: null, error: lexed.error };
  }

  try {
    const { topLevelTokens, rawProcedures } = splitTopLevelAndProcedures(lexed.tokens);

    const procSigMap = new Map<string, { params: string[]; displayName: string }>();
    for (const rp of rawProcedures) {
      procSigMap.set(rp.name, { params: rp.params, displayName: rp.displayName });
    }

    const globalVars = collectDeclaredVars(topLevelTokens);

    // Parse top-level statements
    const topCtx: ParseContext = {
      mode,
      procedures: procSigMap,
      globalVars,
      localVars: new Set<string>(),
      params: new Set<string>(),
      repeatDepth: 0,
      bracketDepth: 0,
    };
    const topParser = new StreamParser(topLevelTokens, topCtx);
    const statements = topParser.parseStatements(false);

    // Parse each procedure body
    const procedures = new Map<string, ProcedureDef>();
    for (const rp of rawProcedures) {
      const localVars = collectDeclaredVars(rp.bodyTokens);
      const procCtx: ParseContext = {
        mode,
        procedures: procSigMap,
        globalVars,
        localVars,
        params: new Set(rp.params),
        repeatDepth: 0,
        bracketDepth: 0,
      };
      const bodyParser = new StreamParser(rp.bodyTokens, procCtx);
      const body = bodyParser.parseStatements(false);
      procedures.set(rp.name, {
        name: rp.name,
        displayName: rp.displayName,
        params: rp.params,
        body,
        line: rp.line,
        column: rp.column,
      });
    }

    return {
      program: { procedures, statements },
      error: null,
    };
  } catch (err) {
    if (err instanceof ParseException) {
      return {
        program: null,
        error: {
          message: err.message,
          line: err.line,
          column: err.column,
        },
      };
    }
    throw err;
  }
}
