export type Mode = '2d' | '3d';

export type Vec3 = [number, number, number];

export interface Segment {
  from: Vec3;
  to: Vec3;
  color: string;
  width: number;
}

export interface LogoError {
  message: string;
  line: number;
  column: number;
}

export interface RunResult {
  segments: Segment[];
  error: LogoError | null;
}

export interface TurtleState {
  pos: Vec3;
  heading: Vec3;
  right: Vec3;
  up: Vec3;
  penDown: boolean;
  color: string;
  width: number;
}

export type TokenType =
  | 'WORD'
  | 'COLON_WORD'
  | 'MA_COLON'
  | 'NUMBER'
  | 'COLOR'
  | 'LBRACKET'
  | 'RBRACKET'
  | 'LPAREN'
  | 'RPAREN'
  | 'COMMA'
  | 'PLUS'
  | 'MINUS'
  | 'STAR'
  | 'SLASH'
  | 'EQ'
  | 'NEQ'
  | 'LT'
  | 'GT'
  | 'LTE'
  | 'GTE'
  | 'EOF';

export interface Token {
  type: TokenType;
  value: string;
  normalized: string;
  line: number;
  column: number;
  atLineStart: boolean;
  spaceBefore: boolean;
  spaceAfter: boolean;
}

export type CompareOp = '<' | '>' | '=' | '<=' | '>=' | '<>';
export type ArithOp = '+' | '-' | '*' | '/';

export type Expr =
  | { kind: 'number'; value: number; line: number; column: number }
  | { kind: 'var'; name: string; displayName: string; line: number; column: number }
  | { kind: 'repcount'; line: number; column: number }
  | { kind: 'unary'; op: '+' | '-'; operand: Expr; line: number; column: number }
  | { kind: 'binary'; op: ArithOp; left: Expr; right: Expr; line: number; column: number };

export interface Condition {
  left: Expr;
  op: CompareOp;
  right: Expr;
  line: number;
  column: number;
}

export type CanonicalCommand =
  | 'fd'
  | 'bk'
  | 'rt'
  | 'lt'
  | 'pu'
  | 'pd'
  | 'color'
  | 'width'
  | 'repeat'
  | 'let'
  | 'if'
  | 'ifelse'
  | 'stop'
  | 'home'
  | 'cs'
  | 'pitchup'
  | 'pitchdown'
  | 'rollright'
  | 'rollleft';

export type Stmt =
  | { kind: 'move'; dir: 1 | -1; expr: Expr; line: number; column: number }
  | { kind: 'turn'; axis: 'yaw' | 'pitch' | 'roll'; dir: 1 | -1; expr: Expr; line: number; column: number }
  | { kind: 'pen'; down: boolean; line: number; column: number }
  | { kind: 'color'; color: string; line: number; column: number }
  | { kind: 'width'; expr: Expr; line: number; column: number }
  | { kind: 'home'; line: number; column: number }
  | { kind: 'cs'; line: number; column: number }
  | { kind: 'stop'; line: number; column: number }
  | { kind: 'let'; name: string; displayName: string; expr: Expr; line: number; column: number }
  | { kind: 'repeat'; countExpr: Expr; body: Stmt[]; line: number; column: number }
  | { kind: 'if'; condition: Condition; body: Stmt[]; line: number; column: number }
  | { kind: 'ifelse'; condition: Condition; thenBody: Stmt[]; elseBody: Stmt[]; line: number; column: number }
  | { kind: 'call'; name: string; displayName: string; args: Expr[]; line: number; column: number };

export interface ProcedureDef {
  name: string;
  displayName: string;
  params: string[];
  body: Stmt[];
  line: number;
  column: number;
}

export interface Program {
  procedures: Map<string, ProcedureDef>;
  statements: Stmt[];
}

export interface StepSnapshot {
  done: boolean;
  line: number | null;
  column: number | null;
  operations: number;
  turtle: TurtleState;
  segments: Segment[];
  error: LogoError | null;
}

export const LIMITS = {
  MAX_CHARS: 50_000,
  MAX_TOKENS: 10_000,
  MAX_BRACKET_DEPTH: 32,
  MAX_ACTIVE_FRAMES: 32,
  MAX_OPERATIONS: 10_000,
  MAX_SEGMENTS: 10_000,
  MAX_COORD: 100_000,
  MIN_WIDTH: 1,
  MAX_WIDTH: 12,
  MIN_REPEAT: 0,
  MAX_REPEAT: 10_000,
} as const;

export const DEFAULT_COLOR = '#16866a';
export const DEFAULT_WIDTH = 3;
