import { LIMITS, LogoError, Token, TokenType } from './types';

const IDENT_START = /^[\p{L}_]$/u;
const IDENT_PART = /^[\p{L}\p{N}_]$/u;
const HEX_COLOR = /^#[0-9a-fA-F]{6}$/;

export interface LexResult {
  tokens: Token[];
  error: LogoError | null;
}

function isWhitespace(ch: string): boolean {
  return ch === ' ' || ch === '\t' || ch === '\r' || ch === '\n';
}

function isDigit(ch: string): boolean {
  return ch >= '0' && ch <= '9';
}

export function normalizeName(raw: string): string {
  return raw.toLocaleLowerCase('pl-PL');
}

export function lex(source: string): LexResult {
  if (source.length > LIMITS.MAX_CHARS) {
    return {
      tokens: [],
      error: {
        message: `Program przekracza limit ${LIMITS.MAX_CHARS.toLocaleString('pl-PL')} znaków.`,
        line: 1,
        column: 1,
      },
    };
  }

  const tokens: Token[] = [];
  let i = 0;
  let line = 1;
  let column = 1;
  let lineHasToken = false;
  let sawSpaceBefore = true;

  const pushToken = (
    type: TokenType,
    value: string,
    tokLine: number,
    tokCol: number,
    atLineStart: boolean,
    spaceBefore: boolean,
    nextChar: string | undefined
  ): LogoError | null => {
    if (type !== 'EOF' && tokens.length >= LIMITS.MAX_TOKENS) {
      return {
        message: `Program przekracza limit ${LIMITS.MAX_TOKENS.toLocaleString('pl-PL')} tokenów.`,
        line: tokLine,
        column: tokCol,
      };
    }
    const spaceAfter =
      nextChar === undefined || isWhitespace(nextChar) || nextChar === ';';
    tokens.push({
      type,
      value,
      normalized: normalizeName(value),
      line: tokLine,
      column: tokCol,
      atLineStart,
      spaceBefore,
      spaceAfter,
    });
    return null;
  };

  while (i < source.length) {
    const ch = source[i];

    // Whitespace
    if (ch === ' ' || ch === '\t' || ch === '\r') {
      sawSpaceBefore = true;
      i++;
      column++;
      continue;
    }

    if (ch === '\n') {
      sawSpaceBefore = true;
      lineHasToken = false;
      i++;
      line++;
      column = 1;
      continue;
    }

    // Comment
    if (ch === ';') {
      sawSpaceBefore = true;
      while (i < source.length && source[i] !== '\n') {
        i++;
        column++;
      }
      continue;
    }

    const tokLine = line;
    const tokCol = column;
    const atLineStart = !lineHasToken;
    const spaceBefore = sawSpaceBefore;
    lineHasToken = true;
    sawSpaceBefore = false;

    // Single-char delimiters
    if (ch === '[') {
      i++;
      column++;
      const err = pushToken('LBRACKET', '[', tokLine, tokCol, atLineStart, spaceBefore, source[i]);
      if (err) return { tokens: [], error: err };
      continue;
    }
    if (ch === ']') {
      i++;
      column++;
      const err = pushToken('RBRACKET', ']', tokLine, tokCol, atLineStart, spaceBefore, source[i]);
      if (err) return { tokens: [], error: err };
      continue;
    }
    if (ch === '(') {
      i++;
      column++;
      const err = pushToken('LPAREN', '(', tokLine, tokCol, atLineStart, spaceBefore, source[i]);
      if (err) return { tokens: [], error: err };
      continue;
    }
    if (ch === ')') {
      i++;
      column++;
      const err = pushToken('RPAREN', ')', tokLine, tokCol, atLineStart, spaceBefore, source[i]);
      if (err) return { tokens: [], error: err };
      continue;
    }
    if (ch === ',') {
      i++;
      column++;
      const err = pushToken('COMMA', ',', tokLine, tokCol, atLineStart, spaceBefore, source[i]);
      if (err) return { tokens: [], error: err };
      continue;
    }

    // Arithmetic operators
    if (ch === '+' || ch === '-' || ch === '*' || ch === '/') {
      i++;
      column++;
      const type: TokenType =
        ch === '+' ? 'PLUS' : ch === '-' ? 'MINUS' : ch === '*' ? 'STAR' : 'SLASH';
      const err = pushToken(type, ch, tokLine, tokCol, atLineStart, spaceBefore, source[i]);
      if (err) return { tokens: [], error: err };
      continue;
    }

    // Comparisons
    if (ch === '=') {
      i++;
      column++;
      const err = pushToken('EQ', '=', tokLine, tokCol, atLineStart, spaceBefore, source[i]);
      if (err) return { tokens: [], error: err };
      continue;
    }
    if (ch === '<') {
      if (source[i + 1] === '=') {
        i += 2;
        column += 2;
        const err = pushToken('LTE', '<=', tokLine, tokCol, atLineStart, spaceBefore, source[i]);
        if (err) return { tokens: [], error: err };
      } else if (source[i + 1] === '>') {
        i += 2;
        column += 2;
        const err = pushToken('NEQ', '<>', tokLine, tokCol, atLineStart, spaceBefore, source[i]);
        if (err) return { tokens: [], error: err };
      } else {
        i++;
        column++;
        const err = pushToken('LT', '<', tokLine, tokCol, atLineStart, spaceBefore, source[i]);
        if (err) return { tokens: [], error: err };
      }
      continue;
    }
    if (ch === '>') {
      if (source[i + 1] === '=') {
        i += 2;
        column += 2;
        const err = pushToken('GTE', '>=', tokLine, tokCol, atLineStart, spaceBefore, source[i]);
        if (err) return { tokens: [], error: err };
      } else {
        i++;
        column++;
        const err = pushToken('GT', '>', tokLine, tokCol, atLineStart, spaceBefore, source[i]);
        if (err) return { tokens: [], error: err };
      }
      continue;
    }

    // Colour literal: "#rrggbb"
    if (ch === '"') {
      i++;
      column++;
      let raw = '';
      let closed = false;
      while (i < source.length && source[i] !== '\n') {
        if (source[i] === '"') {
          i++;
          column++;
          closed = true;
          break;
        }
        raw += source[i];
        i++;
        column++;
      }
      if (!closed) {
        return {
          tokens: [],
          error: {
            message: 'Niezamknięty literał koloru — oczekiwano zamykającego cudzysłowu `"` oraz formatu `"#rrggbb"`.',
            line: tokLine,
            column: tokCol,
          },
        };
      }
      if (!HEX_COLOR.test(raw)) {
        return {
          tokens: [],
          error: {
            message: `Nieprawidłowy kolor "${raw}". Podaj sześć cyfr szesnastkowych w formacie "#rrggbb", np. "#16866a".`,
            line: tokLine,
            column: tokCol,
          },
        };
      }
      const err = pushToken('COLOR', raw.toLowerCase(), tokLine, tokCol, atLineStart, spaceBefore, source[i]);
      if (err) return { tokens: [], error: err };
      continue;
    }

    // Number literal: 80, 12.5, .5
    if (isDigit(ch) || (ch === '.' && i + 1 < source.length && isDigit(source[i + 1]))) {
      let raw = '';
      let seenDot = false;
      if (ch === '.') {
        seenDot = true;
        raw += '.';
        i++;
        column++;
      }
      while (i < source.length && isDigit(source[i])) {
        raw += source[i];
        i++;
        column++;
      }
      if (!seenDot && i < source.length && source[i] === '.') {
        seenDot = true;
        raw += '.';
        i++;
        column++;
        if (i >= source.length || !isDigit(source[i])) {
          return {
            tokens: [],
            error: {
              message: `Nieprawidłowa liczba „${raw}”. Po kropce dziesiętnej musi wystąpić cyfra.`,
              line: tokLine,
              column: tokCol,
            },
          };
        }
        while (i < source.length && isDigit(source[i])) {
          raw += source[i];
          i++;
          column++;
        }
      }
      // Reject trailing letters/dots/underscores like 1e3, 0x10, 1.2.3
      if (i < source.length && (IDENT_PART.test(source[i]) || source[i] === '.')) {
        let bad = raw;
        while (i < source.length && (IDENT_PART.test(source[i]) || source[i] === '.')) {
          bad += source[i];
          i++;
          column++;
        }
        return {
          tokens: [],
          error: {
            message: `Nieprawidłowy zapis liczby „${bad}”. Dozwolone są wyłącznie liczby dziesiętne (np. 80, 12.5, .5).`,
            line: tokLine,
            column: tokCol,
          },
        };
      }

      const err = pushToken('NUMBER', raw, tokLine, tokCol, atLineStart, spaceBefore, source[i]);
      if (err) return { tokens: [], error: err };
      continue;
    }

    // Legacy parameter/variable reference :name
    if (ch === ':') {
      i++;
      column++;
      if (i >= source.length || !IDENT_START.test(source[i])) {
        return {
          tokens: [],
          error: {
            message: 'Po dwukropku `:` oczekiwano nazwy parametru lub zmiennej.',
            line: tokLine,
            column: tokCol,
          },
        };
      }
      let name = '';
      while (i < source.length && IDENT_PART.test(source[i])) {
        name += source[i];
        i++;
        column++;
      }
      const err = pushToken('COLON_WORD', name, tokLine, tokCol, atLineStart, spaceBefore, source[i]);
      if (err) return { tokens: [], error: err };
      continue;
    }

    // Identifier or keyword (or `ma:`)
    if (IDENT_START.test(ch)) {
      let word = '';
      while (i < source.length && IDENT_PART.test(source[i])) {
        word += source[i];
        i++;
        column++;
      }
      if (i < source.length && source[i] === ':') {
        if (normalizeName(word) === 'ma') {
          i++;
          column++;
          const err = pushToken('MA_COLON', word + ':', tokLine, tokCol, atLineStart, spaceBefore, source[i]);
          if (err) return { tokens: [], error: err };
          continue;
        }
        return {
          tokens: [],
          error: {
            message: `Nieoczekiwany dwukropek po „${word}”. Dwukropek na końcu słowa jest dozwolony tylko w „ma:”.`,
            line: tokLine,
            column: tokCol + word.length,
          },
        };
      }
      const err = pushToken('WORD', word, tokLine, tokCol, atLineStart, spaceBefore, source[i]);
      if (err) return { tokens: [], error: err };
      continue;
    }

    return {
      tokens: [],
      error: {
        message: `Nieoczekiwany znak „${ch}”.`,
        line: tokLine,
        column: tokCol,
      },
    };
  }

  tokens.push({
    type: 'EOF',
    value: '',
    normalized: '',
    line,
    column,
    atLineStart: !lineHasToken,
    spaceBefore: sawSpaceBefore,
    spaceAfter: true,
  });

  return { tokens, error: null };
}
