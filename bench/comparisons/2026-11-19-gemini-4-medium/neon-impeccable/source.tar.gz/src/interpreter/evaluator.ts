import {
  Condition,
  DEFAULT_COLOR,
  DEFAULT_WIDTH,
  Expr,
  LIMITS,
  LogoError,
  Mode,
  Program,
  RunResult,
  Segment,
  StepSnapshot,
  Stmt,
  TurtleState,
  Vec3,
} from './types';
import { parseProgram } from './parser';

class RuntimeException extends Error {
  line: number;
  column: number;
  constructor(message: string, line: number, column: number) {
    super(message);
    this.line = line;
    this.column = column;
  }
}

type Frame =
  | { kind: 'top'; stmts: Stmt[]; index: number }
  | { kind: 'proc'; name: string; stmts: Stmt[]; index: number; locals: Map<string, number>; line: number; column: number }
  | { kind: 'repeat'; stmts: Stmt[]; index: number; total: number; repcount: number; line: number; column: number }
  | { kind: 'cond'; stmts: Stmt[]; index: number; line: number; column: number };

export function createInitialTurtle(): TurtleState {
  return {
    pos: [0, 0, 0],
    heading: [0, 1, 0],
    right: [1, 0, 0],
    up: [0, 0, 1],
    penDown: true,
    color: DEFAULT_COLOR,
    width: DEFAULT_WIDTH,
  };
}

function cloneTurtle(t: TurtleState): TurtleState {
  return {
    pos: [t.pos[0], t.pos[1], t.pos[2]],
    heading: [t.heading[0], t.heading[1], t.heading[2]],
    right: [t.right[0], t.right[1], t.right[2]],
    up: [t.up[0], t.up[1], t.up[2]],
    penDown: t.penDown,
    color: t.color,
    width: t.width,
  };
}

function normalizeVec(v: Vec3): Vec3 {
  const len = Math.hypot(v[0], v[1], v[2]);
  if (len === 0) return [0, 1, 0];
  return [v[0] / len, v[1] / len, v[2] / len];
}

function cross(a: Vec3, b: Vec3): Vec3 {
  return [
    a[1] * b[2] - a[2] * b[1],
    a[2] * b[0] - a[0] * b[2],
    a[0] * b[1] - a[1] * b[0],
  ];
}

function dot(a: Vec3, b: Vec3): number {
  return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}

function orthonormalize(turtle: TurtleState): void {
  const h = normalizeVec(turtle.heading);
  // Keep up perpendicular to heading
  const uh = dot(turtle.up, h);
  const uRaw: Vec3 = [
    turtle.up[0] - uh * h[0],
    turtle.up[1] - uh * h[1],
    turtle.up[2] - uh * h[2],
  ];
  const u = normalizeVec(uRaw);
  // In right-handed coordinates: heading × up = right?
  // Check initial: heading = (0,1,0), up = (0,0,1) => heading × up = (1,0,0) = right!
  const r = normalizeVec(cross(h, u));
  turtle.heading = h;
  turtle.up = u;
  turtle.right = r;
}

function rotateInPlane(a: Vec3, b: Vec3, deg: number): [Vec3, Vec3] {
  const rad = (deg * Math.PI) / 180;
  const c = Math.cos(rad);
  const s = Math.sin(rad);
  const newA: Vec3 = [a[0] * c + b[0] * s, a[1] * c + b[1] * s, a[2] * c + b[2] * s];
  const newB: Vec3 = [b[0] * c - a[0] * s, b[1] * c - a[1] * s, b[2] * c - a[2] * s];
  return [newA, newB];
}

export class LogoStepper {
  private program: Program;
  private stack: Frame[] = [];
  private activeFrames = 0;
  private globals = new Map<string, number>();
  private turtle: TurtleState = createInitialTurtle();
  private segments: Segment[] = [];
  private operations = 0;
  private done = false;
  private error: LogoError | null = null;
  private lastLine: number | null = null;
  private lastColumn: number | null = null;

  constructor(program: Program) {
    this.program = program;
    this.stack.push({ kind: 'top', stmts: program.statements, index: 0 });
    if (program.statements.length === 0) {
      this.done = true;
    }
  }

  getSnapshot(): StepSnapshot {
    return {
      done: this.done,
      line: this.lastLine,
      column: this.lastColumn,
      operations: this.operations,
      turtle: cloneTurtle(this.turtle),
      segments: this.segments.slice(),
      error: this.error,
    };
  }

  getSegmentsRef(): Segment[] {
    return this.segments;
  }

  getTurtle(): TurtleState {
    return cloneTurtle(this.turtle);
  }

  isDone(): boolean {
    return this.done;
  }

  getError(): LogoError | null {
    return this.error;
  }

  getOperations(): number {
    return this.operations;
  }

  getCurrentLine(): number | null {
    return this.lastLine;
  }

  private countOp(line: number, column: number): void {
    this.operations++;
    if (this.operations > LIMITS.MAX_OPERATIONS) {
      throw new RuntimeException(
        `Przekroczono limit ${LIMITS.MAX_OPERATIONS.toLocaleString('pl-PL')} wykonanych operacji (możliwa nieskończona pętla lub rekurencja).`,
        line,
        column
      );
    }
  }

  private currentProcFrame(): Extract<Frame, { kind: 'proc' }> | null {
    for (let i = this.stack.length - 1; i >= 0; i--) {
      const f = this.stack[i];
      if (f.kind === 'proc') return f;
    }
    return null;
  }

  private currentRepcount(): number | null {
    for (let i = this.stack.length - 1; i >= 0; i--) {
      const f = this.stack[i];
      if (f.kind === 'repeat') return f.repcount;
      if (f.kind === 'proc') return null;
    }
    return null;
  }

  private lookupVar(name: string, displayName: string, originLine: number, originCol: number): number {
    const proc = this.currentProcFrame();
    if (proc && proc.locals.has(name)) {
      return proc.locals.get(name)!;
    }
    if (this.globals.has(name)) {
      return this.globals.get(name)!;
    }
    throw new RuntimeException(
      `Zmienna „${displayName}” została użyta przed przypisaniem wartości.`,
      originLine,
      originCol
    );
  }

  private evalExpr(expr: Expr, originLine: number, originCol: number): number {
    switch (expr.kind) {
      case 'number':
        return expr.value;
      case 'var':
        return this.lookupVar(expr.name, expr.displayName, originLine, originCol);
      case 'repcount': {
        const rc = this.currentRepcount();
        if (rc === null) {
          throw new RuntimeException(
            'Wartość „nrpowt” jest dostępna wyłącznie wewnątrz pętli „powtorz”.',
            originLine,
            originCol
          );
        }
        return rc;
      }
      case 'unary': {
        const v = this.evalExpr(expr.operand, originLine, originCol);
        const res = expr.op === '-' ? -v : v;
        if (!Number.isFinite(res)) {
          throw new RuntimeException('Wynik wyrażenia nie jest skończoną liczbą.', originLine, originCol);
        }
        return res;
      }
      case 'binary': {
        const l = this.evalExpr(expr.left, originLine, originCol);
        const r = this.evalExpr(expr.right, originLine, originCol);
        let res: number;
        switch (expr.op) {
          case '+':
            res = l + r;
            break;
          case '-':
            res = l - r;
            break;
          case '*':
            res = l * r;
            break;
          case '/':
            if (r === 0) {
              throw new RuntimeException('Dzielenie przez zero.', originLine, originCol);
            }
            res = l / r;
            break;
        }
        if (!Number.isFinite(res)) {
          throw new RuntimeException('Wynik wyrażenia nie jest skończoną liczbą.', originLine, originCol);
        }
        return res;
      }
    }
  }

  private evalCondition(cond: Condition): boolean {
    const l = this.evalExpr(cond.left, cond.left.line, cond.left.column);
    const r = this.evalExpr(cond.right, cond.right.line, cond.right.column);
    switch (cond.op) {
      case '<':
        return l < r;
      case '>':
        return l > r;
      case '=':
        return l === r;
      case '<=':
        return l <= r;
      case '>=':
        return l >= r;
      case '<>':
        return l !== r;
    }
  }

  private checkCoords(pos: Vec3, line: number, col: number): void {
    for (let i = 0; i < 3; i++) {
      if (!Number.isFinite(pos[i]) || Math.abs(pos[i]) > LIMITS.MAX_COORD) {
        throw new RuntimeException(
          `Żółw wyszedł poza dozwolony obszar (±${LIMITS.MAX_COORD.toLocaleString('pl-PL')}).`,
          line,
          col
        );
      }
    }
  }

  private pushSegment(from: Vec3, to: Vec3, line: number, col: number): void {
    if (from[0] === to[0] && from[1] === to[1] && from[2] === to[2]) {
      return;
    }
    if (this.segments.length >= LIMITS.MAX_SEGMENTS) {
      throw new RuntimeException(
        `Przekroczono limit ${LIMITS.MAX_SEGMENTS.toLocaleString('pl-PL')} narysowanych odcinków.`,
        line,
        col
      );
    }
    this.segments.push({
      from: [from[0], from[1], from[2]],
      to: [to[0], to[1], to[2]],
      color: this.turtle.color,
      width: this.turtle.width,
    });
  }

  /**
   * Executes one single statement (unwinding any completed frames along the way).
   * Returns true if still running, false if done or errored.
   */
  step(): boolean {
    if (this.done) return false;

    try {
      while (this.stack.length > 0) {
        const frame = this.stack[this.stack.length - 1];

        if (frame.index >= frame.stmts.length) {
          if (frame.kind === 'top') {
            this.stack.pop();
            this.done = true;
            return false;
          }
          if (frame.kind === 'repeat') {
            this.countOp(frame.line, frame.column);
            if (frame.repcount < frame.total) {
              frame.repcount++;
              frame.index = 0;
              continue;
            }
            this.stack.pop();
            this.activeFrames--;
            continue;
          }
          if (frame.kind === 'cond') {
            this.countOp(frame.line, frame.column);
            this.stack.pop();
            continue;
          }
          if (frame.kind === 'proc') {
            this.countOp(frame.line, frame.column);
            this.stack.pop();
            this.activeFrames--;
            continue;
          }
        }

        const stmt = frame.stmts[frame.index++];
        this.lastLine = stmt.line;
        this.lastColumn = stmt.column;
        this.executeStmt(stmt);

        // Drain immediately finished frames only when checking done at top
        if (this.stack.length === 0) {
          this.done = true;
          return false;
        }
        return !this.done;
      }
      this.done = true;
      return false;
    } catch (err) {
      if (err instanceof RuntimeException) {
        this.error = {
          message: err.message,
          line: err.line,
          column: err.column,
        };
        this.lastLine = err.line;
        this.lastColumn = err.column;
        this.done = true;
        return false;
      }
      throw err;
    }
  }

  private executeStmt(stmt: Stmt): void {
    this.countOp(stmt.line, stmt.column);

    switch (stmt.kind) {
      case 'move': {
        const dist = this.evalExpr(stmt.expr, stmt.expr.line, stmt.expr.column) * stmt.dir;
        if (!Number.isFinite(dist)) {
          throw new RuntimeException('Odległość musi być skończoną liczbą.', stmt.expr.line, stmt.expr.column);
        }
        const from = this.turtle.pos;
        const to: Vec3 = [
          from[0] + this.turtle.heading[0] * dist,
          from[1] + this.turtle.heading[1] * dist,
          from[2] + this.turtle.heading[2] * dist,
        ];
        this.checkCoords(to, stmt.expr.line, stmt.expr.column);
        if (this.turtle.penDown && dist !== 0) {
          this.pushSegment(from, to, stmt.line, stmt.column);
        }
        this.turtle.pos = to;
        break;
      }
      case 'turn': {
        const angle = this.evalExpr(stmt.expr, stmt.expr.line, stmt.expr.column) * stmt.dir;
        if (!Number.isFinite(angle)) {
          throw new RuntimeException('Kąt obrotu musi być skończoną liczbą.', stmt.expr.line, stmt.expr.column);
        }
        if (stmt.axis === 'yaw') {
          const [newH, newR] = rotateInPlane(this.turtle.heading, this.turtle.right, angle);
          this.turtle.heading = newH;
          this.turtle.right = newR;
        } else if (stmt.axis === 'pitch') {
          const [newH, newU] = rotateInPlane(this.turtle.heading, this.turtle.up, angle);
          this.turtle.heading = newH;
          this.turtle.up = newU;
        } else {
          // roll: rotates up towards right around heading
          const [newU, newR] = rotateInPlane(this.turtle.up, this.turtle.right, angle);
          this.turtle.up = newU;
          this.turtle.right = newR;
        }
        orthonormalize(this.turtle);
        break;
      }
      case 'pen': {
        this.turtle.penDown = stmt.down;
        break;
      }
      case 'color': {
        this.turtle.color = stmt.color;
        break;
      }
      case 'width': {
        const val = this.evalExpr(stmt.expr, stmt.expr.line, stmt.expr.column);
        if (!Number.isInteger(val) || val < LIMITS.MIN_WIDTH || val > LIMITS.MAX_WIDTH) {
          throw new RuntimeException(
            `Grubość pisaka musi być liczbą całkowitą od ${LIMITS.MIN_WIDTH} do ${LIMITS.MAX_WIDTH} (otrzymano ${val}).`,
            stmt.expr.line,
            stmt.expr.column
          );
        }
        this.turtle.width = val;
        break;
      }
      case 'home': {
        const from = this.turtle.pos;
        const origin: Vec3 = [0, 0, 0];
        if (this.turtle.penDown && (from[0] !== 0 || from[1] !== 0 || from[2] !== 0)) {
          this.pushSegment(from, origin, stmt.line, stmt.column);
        }
        this.turtle.pos = origin;
        this.turtle.heading = [0, 1, 0];
        this.turtle.right = [1, 0, 0];
        this.turtle.up = [0, 0, 1];
        break;
      }
      case 'cs': {
        this.segments.length = 0;
        break;
      }
      case 'stop': {
        while (this.stack.length > 0) {
          const popped = this.stack.pop()!;
          if (popped.kind === 'repeat') {
            this.activeFrames--;
          } else if (popped.kind === 'proc') {
            this.activeFrames--;
            return;
          } else if (popped.kind === 'top') {
            this.done = true;
            return;
          }
        }
        this.done = true;
        break;
      }
      case 'let': {
        const val = this.evalExpr(stmt.expr, stmt.expr.line, stmt.expr.column);
        const proc = this.currentProcFrame();
        if (proc) {
          proc.locals.set(stmt.name, val);
        } else {
          this.globals.set(stmt.name, val);
        }
        break;
      }
      case 'repeat': {
        const count = this.evalExpr(stmt.countExpr, stmt.countExpr.line, stmt.countExpr.column);
        if (!Number.isInteger(count) || count < LIMITS.MIN_REPEAT || count > LIMITS.MAX_REPEAT) {
          throw new RuntimeException(
            `Liczba powtórzeń musi być liczbą całkowitą od ${LIMITS.MIN_REPEAT} do ${LIMITS.MAX_REPEAT} (otrzymano ${count}).`,
            stmt.countExpr.line,
            stmt.countExpr.column
          );
        }
        if (count === 0) break;
        if (this.activeFrames >= LIMITS.MAX_ACTIVE_FRAMES) {
          throw new RuntimeException(
            `Przekroczono limit ${LIMITS.MAX_ACTIVE_FRAMES} aktywnych ramek wywołań i pętli.`,
            stmt.line,
            stmt.column
          );
        }
        this.activeFrames++;
        this.stack.push({
          kind: 'repeat',
          stmts: stmt.body,
          index: 0,
          total: count,
          repcount: 1,
          line: stmt.line,
          column: stmt.column,
        });
        break;
      }
      case 'if': {
        if (this.evalCondition(stmt.condition)) {
          this.stack.push({
            kind: 'cond',
            stmts: stmt.body,
            index: 0,
            line: stmt.line,
            column: stmt.column,
          });
        }
        break;
      }
      case 'ifelse': {
        const branch = this.evalCondition(stmt.condition) ? stmt.thenBody : stmt.elseBody;
        this.stack.push({
          kind: 'cond',
          stmts: branch,
          index: 0,
          line: stmt.line,
          column: stmt.column,
        });
        break;
      }
      case 'call': {
        const procDef = this.program.procedures.get(stmt.name);
        if (!procDef) {
          throw new RuntimeException(
            `Nieznana procedura „${stmt.displayName}”.`,
            stmt.line,
            stmt.column
          );
        }
        const argVals: number[] = [];
        for (const arg of stmt.args) {
          argVals.push(this.evalExpr(arg, arg.line, arg.column));
        }
        if (this.activeFrames >= LIMITS.MAX_ACTIVE_FRAMES) {
          throw new RuntimeException(
            `Przekroczono limit ${LIMITS.MAX_ACTIVE_FRAMES} aktywnych ramek wywołań i pętli (zbyt głęboka rekurencja).`,
            stmt.line,
            stmt.column
          );
        }
        const locals = new Map<string, number>();
        for (let i = 0; i < procDef.params.length; i++) {
          locals.set(procDef.params[i], argVals[i]);
        }
        this.activeFrames++;
        this.stack.push({
          kind: 'proc',
          name: procDef.name,
          stmts: procDef.body,
          index: 0,
          locals,
          line: stmt.line,
          column: stmt.column,
        });
        break;
      }
    }
  }

  runToEnd(): RunResult {
    while (!this.done) {
      this.step();
    }
    return {
      segments: this.segments.slice(),
      error: this.error,
    };
  }
}

export function runProgram(source: string, mode: Mode): RunResult {
  const parsed = parseProgram(source, mode);
  if (parsed.error || !parsed.program) {
    return {
      segments: [],
      error: parsed.error,
    };
  }
  const stepper = new LogoStepper(parsed.program);
  return stepper.runToEnd();
}

export function createStepper(
  source: string,
  mode: Mode
): { stepper: LogoStepper | null; error: LogoError | null } {
  const parsed = parseProgram(source, mode);
  if (parsed.error || !parsed.program) {
    return { stepper: null, error: parsed.error };
  }
  return { stepper: new LogoStepper(parsed.program), error: null };
}
