import { Mode, runProgram, Segment } from '../interpreter';

export interface Challenge {
  id: string;
  title: string;
  mode: Mode;
  difficulty: 'Podstawowe' | 'Średnie' | 'Przestrzenne';
  prompt: string;
  hint: string;
  starterCode: string;
  referenceSolution: string;
  tolerance: number;
}

export const CHALLENGES: Challenge[] = [
  {
    id: 'ch-kwadrat-100',
    title: 'Kwadrat o boku 100',
    mode: '2d',
    difficulty: 'Podstawowe',
    prompt:
      'Narysuj kwadrat o boku 100 jednostek, zaczynając od środka układu (0, 0) w górę (+Y) i skręcając w prawo.',
    hint: 'Użyj pętli `powtorz 4 [ ... ]` z poleceniami `np 100` oraz `pw 90`.',
    starterCode: `; Narysuj kwadrat o boku 100
powtorz 4 [
  np 100
  
]`,
    referenceSolution: `powtorz 4 [np 100 pw 90]`,
    tolerance: 2.5,
  },
  {
    id: 'ch-trojkat',
    title: 'Trójkąt równoboczny',
    mode: '2d',
    difficulty: 'Podstawowe',
    prompt:
      'Narysuj trójkąt równoboczny o boku 120 jednostek, zaczynając w górę (+Y) i skręcając w prawo.',
    hint: 'Żółw skręca o kąt zewnętrzny: 360 / 3 = 120 stopni.',
    starterCode: `; Trójkąt równoboczny o boku 120
powtorz 3 [
  np 120
  pw 60
]`,
    referenceSolution: `powtorz 3 [np 120 pw 120]`,
    tolerance: 2.5,
  },
  {
    id: 'ch-dwa-kwadraty',
    title: 'Dwa osobne kwadraty',
    mode: '2d',
    difficulty: 'Średnie',
    prompt:
      'Narysuj kwadrat o boku 60 w punkcie startowym, a następnie bez rysowania przejdź w prawo o 100 jednostek i narysuj drugi taki sam kwadrat.',
    hint: 'Po pierwszym kwadracie podnieś pisak (`pod`), obróć się w prawo (`pw 90`), przejdź `np 100`, wróć do kierunku w górę (`lw 90`) i opuść pisak (`opu`).',
    starterCode: `; Dwa kwadraty o boku 60 rozdzielone przerwą
oto kw
  powtorz 4 [np 60 pw 90]
już

kw
; Przejdź w prawo bez rysowania i narysuj drugi kwadrat`,
    referenceSolution: `oto kw
  powtorz 4 [np 60 pw 90]
już
kw
pod pw 90 np 100 lw 90 opu
kw`,
    tolerance: 2.5,
  },
  {
    id: 'ch-szesciokat',
    title: 'Sześciokąt foremny',
    mode: '2d',
    difficulty: 'Średnie',
    prompt:
      'Narysuj sześciokąt foremny o boku 70 jednostek, zaczynając od (0, 0) w górę i skręcając w prawo.',
    hint: 'Dla 6 boków kąt skrętu wynosi 360 / 6 = 60 stopni.',
    starterCode: `; Sześciokąt foremny o boku 70
powtorz 6 [
  
]`,
    referenceSolution: `powtorz 6 [np 70 pw 60]`,
    tolerance: 2.5,
  },
  {
    id: 'ch-bramka-3d',
    title: 'Pionowa bramka 3D',
    mode: '3d',
    difficulty: 'Przestrzenne',
    prompt:
      'W trybie 3D wznieś pionowy słupek o wysokości 80 jednostek w górę (+Z), przejdź poprzeczką 100 jednostek w przód (+Y), a następnie zejdź pionowo 80 jednostek w dół (-Z).',
    hint: 'Użyj `gora 90`, aby skierować nos żółwia wzdłuż osi +Z, potem `dol 90`, aby wrócić do poziomu (+Y), i jeszcze raz `dol 90`, aby zejść w dół.',
    starterCode: `; Pionowa bramka w przestrzeni 3D
gora 90
np 80
; Dokończ poprzeczkę (100) i drugi słupek (80)`,
    referenceSolution: `gora 90
np 80
dol 90
np 100
dol 90
np 80`,
    tolerance: 3.0,
  },
  {
    id: 'ch-dwa-pietra-3d',
    title: 'Dwa piętra w przestrzeni',
    mode: '3d',
    difficulty: 'Przestrzenne',
    prompt:
      'Narysuj dolny kwadrat o boku 80 na płaszczyźnie XY, wznieś się pionowo o 60 jednostek w górę (+Z) i narysuj górny kwadrat o boku 80 dokładnie nad nim.',
    hint: 'Po dolnym kwadracie użyj `gora 90 np 60 dol 90`, a następnie powtórz kwadrat.',
    starterCode: `; Dwa kwadraty o boku 80 połączone pionową krawędzią o wysokości 60
powtorz 4 [np 80 pw 90]
`,
    referenceSolution: `powtorz 4 [np 80 pw 90]
gora 90 np 60 dol 90
powtorz 4 [np 80 pw 90]`,
    tolerance: 3.0,
  },
];

const targetCache = new Map<string, Segment[]>();

export function getChallengeTargetSegments(challenge: Challenge): Segment[] {
  const cached = targetCache.get(challenge.id);
  if (cached) return cached;
  const res = runProgram(challenge.referenceSolution, challenge.mode);
  targetCache.set(challenge.id, res.segments);
  return res.segments;
}
