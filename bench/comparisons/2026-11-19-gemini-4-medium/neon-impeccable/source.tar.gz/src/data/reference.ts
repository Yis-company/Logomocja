import { Mode } from '../interpreter';

export interface CommandDoc {
  polish: string;
  english: string;
  args: string;
  category: 'Ruch' | 'Pisak' | 'Sterowanie' | 'Przestrzeń 3D';
  mode: Mode;
  meaning: string;
  example: string;
}

export const COMMAND_DOCS: CommandDoc[] = [
  {
    polish: 'np, naprzod, naprzód',
    english: 'fd, forward',
    args: 'wyrażenie',
    category: 'Ruch',
    mode: '2d',
    meaning: 'Przesuwa żółwia naprzód o podaną odległość. Gdy pisak jest opuszczony, rysuje odcinek.',
    example: 'np 100',
  },
  {
    polish: 'ws, wstecz',
    english: 'bk, back',
    args: 'wyrażenie',
    category: 'Ruch',
    mode: '2d',
    meaning: 'Przesuwa żółwia wstecz bez zmiany kierunku, w którym jest zwrócony.',
    example: 'ws 60',
  },
  {
    polish: 'pw, prawo',
    english: 'rt, right',
    args: 'wyrażenie (stopnie)',
    category: 'Ruch',
    mode: '2d',
    meaning: 'Obraca żółwia w prawo (zgodnie z ruchem wskazówek zegara patrząc z góry) o zadaną liczbę stopni.',
    example: 'pw 90\nnp 80',
  },
  {
    polish: 'lw, lewo',
    english: 'lt, left',
    args: 'wyrażenie (stopnie)',
    category: 'Ruch',
    mode: '2d',
    meaning: 'Obraca żółwia w lewo o zadaną liczbę stopni.',
    example: 'lw 45\nnp 90',
  },
  {
    polish: 'dom',
    english: 'home',
    args: 'brak',
    category: 'Ruch',
    mode: '2d',
    meaning: 'Wraca żółwia do punktu (0, 0, 0) i przywraca początkową orientację (+Y, góra +Z). Rysuje linię, jeśli pisak jest opuszczony.',
    example: 'np 80 pw 90 np 60\ndom',
  },
  {
    polish: 'pod, podnies, podnieś',
    english: 'pu, penup',
    args: 'brak',
    category: 'Pisak',
    mode: '2d',
    meaning: 'Podnosi pisak — kolejne ruchy nie rysują odcinków.',
    example: 'np 50\npod np 30 opu\nnp 50',
  },
  {
    polish: 'opu, opusc, opuść',
    english: 'pd, pendown',
    args: 'brak',
    category: 'Pisak',
    mode: '2d',
    meaning: 'Opuszcza pisak — żółw znów zostawia ślad.',
    example: 'pod np 40\nopu np 80',
  },
  {
    polish: 'kolor',
    english: 'color',
    args: '"#rrggbb"',
    category: 'Pisak',
    mode: '2d',
    meaning: 'Ustawia kolor pisaka jako sześciocyfrowy kod szesnastkowy w cudzysłowie (wielkość liter bez znaczenia).',
    example: 'kolor "#c1763d"\nnp 100',
  },
  {
    polish: 'grubosc, grubość',
    english: 'width',
    args: 'wyrażenie (całkowite 1–12)',
    category: 'Pisak',
    mode: '2d',
    meaning: 'Ustawia grubość rysowanej linii (liczba całkowita od 1 do 12).',
    example: 'grubosc 6\nnp 120',
  },
  {
    polish: 'czyść, czysc',
    english: 'cs, clearscreen',
    args: 'brak',
    category: 'Pisak',
    mode: '2d',
    meaning: 'Usuwa wszystkie narysowane dotąd odcinki, zachowując pozycję żółwia, kolor i grubość pisaka.',
    example: 'np 80\nczyść\npw 90 np 80',
  },
  {
    polish: 'powtorz, powtórz',
    english: 'repeat',
    args: 'liczba (0–10000) [ blok ]',
    category: 'Sterowanie',
    mode: '2d',
    meaning: 'Wykonuje blok poleceń wskazaną liczbę razy. Wewnątrz bloku dostępna jest wartość `nrpowt` (`repcount`) liczona od 1.',
    example: 'powtorz 6 [\n  np nrpowt * 15\n  pw 60\n]',
  },
  {
    polish: 'niech',
    english: 'let',
    args: 'nazwa wyrażenie',
    category: 'Sterowanie',
    mode: '2d',
    meaning: 'Tworzy lub aktualizuje zmienną. Na poziomie głównym jest globalna, a w procedurze — lokalna (przesłania globalną na czas wywołania).',
    example: 'niech bok 90\npowtorz 4 [np bok pw 90]',
  },
  {
    polish: 'jeśli, jesli',
    english: 'if',
    args: 'warunek [ blok ]',
    category: 'Sterowanie',
    mode: '2d',
    meaning: 'Wykonuje blok tylko wtedy, gdy warunek (`<`, `>`, `=`, `<=`, `>=`, `<>`) jest prawdziwy.',
    example: 'powtorz 8 [\n  jeśli nrpowt > 4 [kolor "#c1763d"]\n  np 40 pw 45\n]',
  },
  {
    polish: 'jeżeli, jezeli',
    english: 'ifelse',
    args: 'warunek [ prawda ] [ fałsz ]',
    category: 'Sterowanie',
    mode: '2d',
    meaning: 'Wykonuje pierwszy blok, gdy warunek jest prawdziwy, a drugi w przeciwnym razie.',
    example: 'niech a 1\npowtorz 6 [\n  jeżeli a > 0 [kolor "#16866a"] [kolor "#c1763d"]\n  niech a -a\n  np 50 pw 60\n]',
  },
  {
    polish: 'stop',
    english: 'stop',
    args: 'brak',
    category: 'Sterowanie',
    mode: '2d',
    meaning: 'Natychmiast kończy bieżące wywołanie procedury (również z wnętrza pętli lub warunku). Na poziomie głównym zatrzymuje cały program.',
    example: 'oto linia ma: d\n  jeśli d < 10 [stop]\n  np d pw 90\n  linia d - 15\njuż\nlinia 80',
  },
  {
    polish: 'gora, góra',
    english: 'pitchup',
    args: 'wyrażenie (stopnie)',
    category: 'Przestrzeń 3D',
    mode: '3d',
    meaning: 'Podnosi nos żółwia ku górze (obrót wokół osi prawej). Działa wyłącznie w trybie 3D.',
    example: 'gora 45\nnp 100',
  },
  {
    polish: 'dol, dół',
    english: 'pitchdown',
    args: 'wyrażenie (stopnie)',
    category: 'Przestrzeń 3D',
    mode: '3d',
    meaning: 'Opuszcza nos żółwia w dół (odwrotność `gora`). Działa wyłącznie w trybie 3D.',
    example: 'gora 90 np 60\ndol 90 np 80',
  },
  {
    polish: 'pp, przechylprawo',
    english: 'rr, rollright',
    args: 'wyrażenie (stopnie)',
    category: 'Przestrzeń 3D',
    mode: '3d',
    meaning: 'Przechyla żółwia w prawo wokół jego kierunku lotu (wektor góry skręca ku prawemu bokowi). Tylko 3D.',
    example: 'powtorz 4 [\n  powtorz 36 [np 8 gora 10]\n  pp 45\n]',
  },
  {
    polish: 'pl, przechyllewo',
    english: 'rl, rollleft',
    args: 'wyrażenie (stopnie)',
    category: 'Przestrzeń 3D',
    mode: '3d',
    meaning: 'Przechyla żółwia w lewo wokół jego kierunku lotu. Tylko 3D.',
    example: 'pl 45\ngora 90 np 80',
  },
];

export const LANGUAGE_SECTIONS = [
  {
    id: 'wyrazenia',
    title: 'Wyrażenia i zasada spacji',
    body: [
      'Każdy argument liczbowy przyjmuje liczbę dziesiętną (`80`, `12.5`, `.5`), nazwę zmiennej lub parametru (także w zapisie `:nazwa`), `nrpowt` (`repcount`), nawiasy `( ... )`, znaki jednoargumentowe `+` / `-` oraz operatory `+`, `-`, `*`, `/`.',
      'Mnożenie i dzielenie wiążą silniej niż dodawanie i odejmowanie, a operatory równego priorytetu łączą od lewej (`20 - 5 - 3` daje `12`, a `2 + 3 * 4` daje `14`).',
      'Ważna zasada: operator binarny (`+`, `-`, `*`, `/`) musi mieć spacje po obu stronach albo po żadnej (`np 10 - 5` i `np 10-5` dają `5`, natomiast `np 10 -5` oznacza dwa osobne argumenty `10` i `-5`). Porównania (`<`, `>`, `=`, `<=`, `>=`, `<>`) działają dokładnie na liczbach zmiennoprzecinkowych.',
    ],
    code: `; Zasada spacji i priorytety
np 2 + 3 * 4       ; 14
pw 90
np -(3 - 5) * 20   ; 40`,
  },
  {
    id: 'zmienne',
    title: 'Zmienne i zasięg',
    body: [
      'Polecenie `niech x 5` przypisuje wartość zmiennej `x`. Kolejne `niech x ...` nadpisuje ją. Nazwa zmiennej nie może być słowem kluczowym ani nazwą procedury.',
      'Zmienna zdefiniowana na poziomie głównym jest globalna. Zmienna zdefiniowana przez `niech` w procedurze jest lokalna dla tego wywołania i przesłania zmienną globalną o tej samej nazwie.',
      'Nazwa może pojawić się w wyrażeniu tylko wtedy, gdy jest parametrem procedury albo jest przypisana przez `niech` w tej procedurze lub na poziomie głównym. Odczyt zadeklarowanej, ale jeszcze nieprzypisanej zmiennej zgłasza błąd w trakcie wykonania.',
    ],
    code: `niech krok 40
powtorz 5 [
  np krok
  pw 72
  niech krok krok + 10
]`,
  },
  {
    id: 'procedury',
    title: 'Procedury i rekurencja',
    body: [
      'Definicja procedury zaczyna się od `oto` (lub `to`) na początku wiersza, po czym następuje nazwa i opcjonalnie `ma:` z listą parametrów rozdzielonych przecinkami. Akceptowany jest też klasyczny nagłówek `oto kwadrat :bok :kąt`.',
      'Ciało procedury kończy się słowem `już` (`juz` lub `end`) stojącym samodzielnie w osobnym wierszu. Definicje mogą występować wyłącznie na poziomie głównym — przed lub po wywołaniach.',
      'Procedury mogą wywoływać same siebie rekurencyjnie. Polecenie `stop` przerywa bieżące wywołanie procedury.',
    ],
    code: `oto kwadrat ma: bok, kąt
  powtorz 4 [np bok pw kąt]
już

kwadrat 80 90`,
  },
  {
    id: 'limity',
    title: 'Ograniczenia i bezpieczeństwo wykonania',
    body: [
      'Program jest sprawdzany w całości przed uruchomieniem: błąd składniowy lub statyczny nie rysuje nic. Błąd czasu wykonania (np. dzielenie przez zero lub przekroczenie limitu) zatrzymuje żółwia, zachowując dotychczasowy rysunek.',
      'Limity: maksymalnie 50 000 znaków kodu, 10 000 tokenów, głębokość zagnieżdżenia nawiasów `[ ]` do 32, jednocześnie do 32 aktywnych ramek wywołań i pętli (bloki warunkowe nie zużywają ramek), 10 000 wykonanych operacji, 10 000 zachowanych odcinków (po ewentualnym `czyść`) oraz współrzędne w zakresie ±100 000.',
    ],
    code: `; Komentarze zaczynają się od średnika
; Grubość pisaka: 1–12, powtorz: 0–10000`,
  },
];
