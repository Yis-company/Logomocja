import React, { useState } from 'react';
import { CHALLENGES, Challenge, getChallengeTargetSegments } from '../data/challenges';
import { SegmentPreviewSvg } from './SegmentPreviewSvg';
import { IconCheck } from './Icons';

interface ChallengesViewProps {
  solvedIds: string[];
  activeChallengeId: string | null;
  onStartChallenge: (challenge: Challenge) => void;
}

export const ChallengesView: React.FC<ChallengesViewProps> = ({
  solvedIds,
  activeChallengeId,
  onStartChallenge,
}) => {
  const [selectedId, setSelectedId] = useState<string>(activeChallengeId ?? CHALLENGES[0].id);
  const [showHint, setShowHint] = useState(false);

  const selected = CHALLENGES.find((c) => c.id === selectedId) ?? CHALLENGES[0];
  const targetSegments = getChallengeTargetSegments(selected);
  const isSolved = solvedIds.includes(selected.id);

  return (
    <main className="page-scroll">
      <div className="page-container">
        <div className="page-header">
          <div>
            <h1>Wyzwania rysunkowe</h1>
            <p>
              Napisz program, który odtworzy wskazany kształt. Pracownia automatycznie sprawdzi geometrię
              Twojego rysunku i zapisze postęp w przeglądarce.
            </p>
          </div>
          <div className="tabular" style={{ fontSize: 13, color: 'var(--text-secondary)', fontWeight: 600 }}>
            Ukończono: {solvedIds.length} z {CHALLENGES.length}
          </div>
        </div>

        <div className="challenges-layout">
          <div className="challenge-list" role="list" aria-label="Lista wyzwań">
            {CHALLENGES.map((ch) => {
              const solved = solvedIds.includes(ch.id);
              return (
                <button
                  key={ch.id}
                  type="button"
                  className="challenge-item"
                  aria-current={ch.id === selected.id ? 'true' : undefined}
                  onClick={() => {
                    setSelectedId(ch.id);
                    setShowHint(false);
                  }}
                >
                  <div className="challenge-item-top">
                    <span className="challenge-item-title">{ch.title}</span>
                    <span className={`mode-tag${ch.mode === '3d' ? ' is-3d' : ''}`}>
                      {ch.mode.toUpperCase()}
                    </span>
                  </div>
                  <div className="challenge-item-top">
                    <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{ch.difficulty}</span>
                    <span className={`challenge-status${solved ? ' is-solved' : ''}`}>
                      {solved ? 'Zaliczone' : 'Do zrobienia'}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          <section className="challenge-detail" aria-label={`Szczegóły wyzwania: ${selected.title}`}>
            <div className="example-head">
              <h2 style={{ margin: 0, fontSize: 18 }}>{selected.title}</h2>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                {isSolved && (
                  <span
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: 4,
                      fontSize: 12.5,
                      fontWeight: 600,
                      color: 'var(--success)',
                    }}
                  >
                    <IconCheck size={14} /> Zaliczone
                  </span>
                )}
                <span className={`mode-tag${selected.mode === '3d' ? ' is-3d' : ''}`}>
                  {selected.mode.toUpperCase()}
                </span>
              </div>
            </div>

            <div className="challenge-detail-grid">
              <div className="challenge-target-box">
                <SegmentPreviewSvg
                  segments={targetSegments}
                  mode={selected.mode}
                  label={`Docelowy rysunek wyzwania ${selected.title}`}
                />
                <div className="challenge-target-caption">
                  Docelowy kształt (tolerancja ±{selected.tolerance} jedn.)
                </div>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                <p style={{ margin: 0, color: 'var(--text-primary)' }}>{selected.prompt}</p>

                <div>
                  <button
                    type="button"
                    className="btn btn-sm"
                    onClick={() => setShowHint((h) => !h)}
                    aria-expanded={showHint}
                  >
                    {showHint ? 'Ukryj podpowiedź' : 'Pokaż podpowiedź'}
                  </button>
                </div>

                {showHint && <div className="challenge-hint">{selected.hint}</div>}

                <div style={{ display: 'flex', gap: 8, marginTop: 4 }}>
                  <button
                    type="button"
                    className="btn btn-primary"
                    onClick={() => onStartChallenge(selected)}
                  >
                    Rozwiąż w pracowni
                  </button>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </main>
  );
};
