import React, { useState } from 'react';
import { Mode } from '../interpreter';
import { COMMAND_DOCS, CommandDoc, LANGUAGE_SECTIONS } from '../data/reference';

interface ReferenceViewProps {
  onTryCode: (source: string, mode: Mode) => void;
}

export const ReferenceView: React.FC<ReferenceViewProps> = ({ onTryCode }) => {
  const [cat, setCat] = useState<'Wszystkie' | CommandDoc['category']>('Wszystkie');

  const categories: Array<'Wszystkie' | CommandDoc['category']> = [
    'Wszystkie',
    'Ruch',
    'Pisak',
    'Sterowanie',
    'Przestrzeń 3D',
  ];

  const rows = COMMAND_DOCS.filter((c) => cat === 'Wszystkie' || c.category === cat);

  return (
    <main className="page-scroll">
      <div className="page-container">
        <div className="page-header">
          <div>
            <h1>Słownik języka Logomocja</h1>
            <p>
              Wszystkie polecenia (z polskimi i angielskimi aliasami bez rozróżniania wielkości liter),
              wyrażenia, zmienne, procedury oraz limity interpretera.
            </p>
          </div>
          <div className="filter-row" role="group" aria-label="Filtruj kategorię poleceń">
            {categories.map((c) => (
              <button
                key={c}
                type="button"
                className="filter-btn"
                aria-pressed={cat === c}
                onClick={() => setCat(c)}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        <div className="ref-table-wrap">
          <table className="ref-table">
            <thead>
              <tr>
                <th>Polski</th>
                <th>Angielski</th>
                <th>Argument</th>
                <th>Działanie</th>
                <th>Przykład</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((cmd) => (
                <tr key={cmd.polish}>
                  <td className="ref-code">{cmd.polish}</td>
                  <td className="ref-code">{cmd.english}</td>
                  <td>{cmd.args}</td>
                  <td>
                    {cmd.meaning}
                    {cmd.mode === '3d' && (
                      <>
                        {' '}
                        <span className="mode-tag is-3d">3D</span>
                      </>
                    )}
                  </td>
                  <td>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 6, alignItems: 'flex-start' }}>
                      <code className="ref-code" style={{ whiteSpace: 'pre-wrap' }}>
                        {cmd.example}
                      </code>
                      <button
                        type="button"
                        className="btn btn-sm"
                        onClick={() => onTryCode(cmd.example, cmd.mode)}
                      >
                        Wypróbuj
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="ref-sections">
          {LANGUAGE_SECTIONS.map((sec) => (
            <section key={sec.id} className="ref-section-card">
              <h2>{sec.title}</h2>
              {sec.body.map((p, idx) => (
                <p key={idx}>{p}</p>
              ))}
              <pre className="ref-pre">{sec.code}</pre>
            </section>
          ))}
        </div>
      </div>
    </main>
  );
};
