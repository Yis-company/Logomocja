import React from 'react';
import { Mode, TurtleState } from '../interpreter';

interface TelemetryStripProps {
  mode: Mode;
  turtle: TurtleState;
  operations: number;
  segmentCount: number;
  activeLine: number | null;
}

function fmt(n: number): string {
  const v = Math.abs(n) < 0.05 ? 0 : n;
  return v.toFixed(1);
}

function computeHeadingDeg(turtle: TurtleState): number {
  // Angle clockwise from +Y in XY plane
  const deg = (Math.atan2(turtle.heading[0], turtle.heading[1]) * 180) / Math.PI;
  return ((deg % 360) + 360) % 360;
}

function computePitchDeg(turtle: TurtleState): number {
  const clamped = Math.max(-1, Math.min(1, turtle.heading[2]));
  return (Math.asin(clamped) * 180) / Math.PI;
}

export const TelemetryStrip: React.FC<TelemetryStripProps> = ({
  mode,
  turtle,
  operations,
  segmentCount,
  activeLine,
}) => {
  const headingDeg = computeHeadingDeg(turtle);
  const pitchDeg = computePitchDeg(turtle);

  return (
    <div className="telemetry-strip tabular" aria-label="Telemetria żółwia">
      <div className="telemetry-group">
        <span className="telemetry-cell">
          <span className="telemetry-key">POZ</span>
          <span className="telemetry-val">
            {mode === '2d'
              ? `(${fmt(turtle.pos[0])}, ${fmt(turtle.pos[1])})`
              : `(${fmt(turtle.pos[0])}, ${fmt(turtle.pos[1])}, ${fmt(turtle.pos[2])})`}
          </span>
        </span>
        <span className="telemetry-cell">
          <span className="telemetry-key">KĄT</span>
          <span className="telemetry-val">{Math.round(headingDeg)}°</span>
        </span>
        {mode === '3d' && (
          <span className="telemetry-cell">
            <span className="telemetry-key">NACHYL</span>
            <span className="telemetry-val">{Math.round(pitchDeg)}°</span>
          </span>
        )}
        <span className="telemetry-cell">
          <span className="telemetry-key">PISAK</span>
          <span
            className="pen-swatch"
            style={{ backgroundColor: turtle.penDown ? turtle.color : 'transparent' }}
            title={turtle.penDown ? `Opuszczony (${turtle.color})` : 'Podniesiony'}
          />
          <span className="telemetry-val">
            {turtle.penDown ? `${turtle.width}px` : 'podniesiony'}
          </span>
        </span>
      </div>
      <div className="telemetry-group">
        {activeLine !== null && (
          <span className="telemetry-cell">
            <span className="telemetry-key">WIERSZ</span>
            <span className="telemetry-val">{activeLine}</span>
          </span>
        )}
        <span className="telemetry-cell">
          <span className="telemetry-key">KROKI</span>
          <span className="telemetry-val">{operations}</span>
        </span>
        <span className="telemetry-cell">
          <span className="telemetry-key">ODCINKI</span>
          <span className="telemetry-val">{segmentCount}</span>
        </span>
      </div>
    </div>
  );
};
