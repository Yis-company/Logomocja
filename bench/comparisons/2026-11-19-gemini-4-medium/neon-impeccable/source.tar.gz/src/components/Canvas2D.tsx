import React, {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react';
import { Segment, TurtleState } from '../interpreter';
import { IconFit, IconReset, IconZoomIn, IconZoomOut } from './Icons';

export interface ViewportHandle {
  fit: (overrideSegments?: Segment[]) => void;
  resetView: () => void;
  exportPng: () => string | null;
}

interface Canvas2DProps {
  segments: Segment[];
  turtle: TurtleState;
  theme: 'light' | 'dark';
  guideSegments?: Segment[];
}

interface Camera2D {
  x: number; // world x at center
  y: number; // world y at center
  scale: number; // pixels per world unit
}

export const Canvas2D = forwardRef<ViewportHandle, Canvas2DProps>(
  ({ segments, turtle, theme, guideSegments }, ref) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [cam, setCam] = useState<Camera2D>({ x: 0, y: 0, scale: 1.4 });
    const camRef = useRef(cam);
    camRef.current = cam;

    const dragRef = useRef<{ active: boolean; startX: number; startY: number; camX: number; camY: number }>({
      active: false,
      startX: 0,
      startY: 0,
      camX: 0,
      camY: 0,
    });

    const fit = useCallback(
      (overrideSegments?: Segment[]) => {
        const el = containerRef.current;
        if (!el) return;
        const rect = el.getBoundingClientRect();
        const w = Math.max(200, rect.width);
        const h = Math.max(200, rect.height);
        const segs = overrideSegments ?? segments;

        if (segs.length === 0 && (!guideSegments || guideSegments.length === 0)) {
          setCam({ x: 0, y: 0, scale: 1.4 });
          return;
        }

        let minX = Infinity;
        let maxX = -Infinity;
        let minY = Infinity;
        let maxY = -Infinity;

        const include = (list: Segment[]) => {
          for (const s of list) {
            minX = Math.min(minX, s.from[0], s.to[0]);
            maxX = Math.max(maxX, s.from[0], s.to[0]);
            minY = Math.min(minY, s.from[1], s.to[1]);
            maxY = Math.max(maxY, s.from[1], s.to[1]);
          }
        };

        include(segs);
        if (guideSegments) include(guideSegments);

        // Also include origin if no segments
        if (!Number.isFinite(minX)) {
          setCam({ x: 0, y: 0, scale: 1.4 });
          return;
        }

        const spanX = Math.max(20, maxX - minX);
        const spanY = Math.max(20, maxY - minY);
        const pad = 56;
        const scaleX = (w - pad * 2) / spanX;
        const scaleY = (h - pad * 2) / spanY;
        const scale = Math.max(0.05, Math.min(20, Math.min(scaleX, scaleY)));
        setCam({
          x: (minX + maxX) / 2,
          y: (minY + maxY) / 2,
          scale,
        });
      },
      [segments, guideSegments]
    );

    const resetView = useCallback(() => {
      setCam({ x: 0, y: 0, scale: 1.4 });
    }, []);

    const exportPng = useCallback(() => {
      const canvas = canvasRef.current;
      if (!canvas) return null;
      return canvas.toDataURL('image/png');
    }, []);

    useImperativeHandle(ref, () => ({ fit, resetView, exportPng }), [fit, resetView, exportPng]);

    const draw = useCallback(() => {
      const canvas = canvasRef.current;
      const container = containerRef.current;
      if (!canvas || !container) return;

      const rect = container.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const width = Math.max(1, Math.floor(rect.width));
      const height = Math.max(1, Math.floor(rect.height));

      if (canvas.width !== Math.floor(width * dpr) || canvas.height !== Math.floor(height * dpr)) {
        canvas.width = Math.floor(width * dpr);
        canvas.height = Math.floor(height * dpr);
      }

      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      ctx.save();
      ctx.scale(dpr, dpr);

      const cs = getComputedStyle(document.documentElement);
      const bg = cs.getPropertyValue('--bg-canvas').trim() || (theme === 'dark' ? '#0c1613' : '#ffffff');
      const gridMinor = cs.getPropertyValue('--grid-minor').trim() || (theme === 'dark' ? '#142520' : '#ecefe9');
      const gridMajor = cs.getPropertyValue('--grid-major').trim() || (theme === 'dark' ? '#1f3730' : '#d8dfd7');
      const axisX = cs.getPropertyValue('--axis-x').trim() || '#c24b3d';
      const axisY = cs.getPropertyValue('--axis-y').trim() || '#16866a';
      const textMuted = cs.getPropertyValue('--text-muted').trim() || '#5a6e66';

      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, width, height);

      const { x: cxWorld, y: cyWorld, scale } = cam;
      const toScreenX = (wx: number) => width / 2 + (wx - cxWorld) * scale;
      const toScreenY = (wy: number) => height / 2 - (wy - cyWorld) * scale;

      // Adaptive grid spacing
      const rawStep = 40 / scale;
      const pow10 = Math.pow(10, Math.floor(Math.log10(Math.max(rawStep, 1e-6))));
      const norm = rawStep / pow10;
      const gridStep = (norm < 1.5 ? 1 : norm < 3.5 ? 2 : norm < 7.5 ? 5 : 10) * pow10;
      const majorStep = gridStep * 5;

      const minWX = cxWorld - width / (2 * scale);
      const maxWX = cxWorld + width / (2 * scale);
      const minWY = cyWorld - height / (2 * scale);
      const maxWY = cyWorld + height / (2 * scale);

      const startX = Math.floor(minWX / gridStep) * gridStep;
      const startY = Math.floor(minWY / gridStep) * gridStep;

      ctx.lineWidth = 1;
      for (let gx = startX; gx <= maxWX; gx += gridStep) {
        const sx = Math.round(toScreenX(gx)) + 0.5;
        const isMajor = Math.abs(Math.round(gx / majorStep) * majorStep - gx) < gridStep * 0.01;
        ctx.strokeStyle = isMajor ? gridMajor : gridMinor;
        ctx.beginPath();
        ctx.moveTo(sx, 0);
        ctx.lineTo(sx, height);
        ctx.stroke();
      }
      for (let gy = startY; gy <= maxWY; gy += gridStep) {
        const sy = Math.round(toScreenY(gy)) + 0.5;
        const isMajor = Math.abs(Math.round(gy / majorStep) * majorStep - gy) < gridStep * 0.01;
        ctx.strokeStyle = isMajor ? gridMajor : gridMinor;
        ctx.beginPath();
        ctx.moveTo(0, sy);
        ctx.lineTo(width, sy);
        ctx.stroke();
      }

      // Origin axes & marker
      const ox = toScreenX(0);
      const oy = toScreenY(0);

      if (oy >= -2 && oy <= height + 2) {
        ctx.strokeStyle = axisX;
        ctx.globalAlpha = 0.35;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(0, oy);
        ctx.lineTo(width, oy);
        ctx.stroke();
      }
      if (ox >= -2 && ox <= width + 2) {
        ctx.strokeStyle = axisY;
        ctx.globalAlpha = 0.35;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(ox, 0);
        ctx.lineTo(ox, height);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;

      // Origin dot & label
      ctx.fillStyle = textMuted;
      ctx.beginPath();
      ctx.arc(ox, oy, 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.font = '11px ui-monospace, monospace';
      ctx.fillText('0,0', ox + 6, oy + 12);

      // Optional challenge guide segments
      if (guideSegments && guideSegments.length > 0) {
        ctx.save();
        ctx.setLineDash([5, 5]);
        ctx.strokeStyle = textMuted;
        ctx.globalAlpha = 0.4;
        ctx.lineWidth = 2;
        ctx.lineCap = 'round';
        for (const s of guideSegments) {
          ctx.beginPath();
          ctx.moveTo(toScreenX(s.from[0]), toScreenY(s.from[1]));
          ctx.lineTo(toScreenX(s.to[0]), toScreenY(s.to[1]));
          ctx.stroke();
        }
        ctx.restore();
      }

      // Drawn segments
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      for (const s of segments) {
        ctx.strokeStyle = s.color;
        ctx.lineWidth = Math.max(1, s.width * Math.min(1.6, Math.max(0.65, scale * 0.75)));
        ctx.beginPath();
        ctx.moveTo(toScreenX(s.from[0]), toScreenY(s.from[1]));
        ctx.lineTo(toScreenX(s.to[0]), toScreenY(s.to[1]));
        ctx.stroke();
      }

      // Turtle marker
      const tx = toScreenX(turtle.pos[0]);
      const ty = toScreenY(turtle.pos[1]);
      const angle = Math.atan2(turtle.heading[0], turtle.heading[1]); // clockwise from +Y

      ctx.save();
      ctx.translate(tx, ty);
      ctx.rotate(angle);

      ctx.beginPath();
      ctx.moveTo(0, -12);
      ctx.lineTo(8, 8);
      ctx.lineTo(0, 4);
      ctx.lineTo(-8, 8);
      ctx.closePath();

      ctx.fillStyle = turtle.penDown ? turtle.color : bg;
      ctx.fill();
      ctx.lineWidth = 1.75;
      ctx.strokeStyle = theme === 'dark' ? '#eef4f1' : '#14221d';
      ctx.stroke();
      ctx.restore();

      ctx.restore();
    }, [cam, segments, turtle, theme, guideSegments]);

    useEffect(() => {
      draw();
    }, [draw]);

    useEffect(() => {
      const container = containerRef.current;
      if (!container) return;
      const ro = new ResizeObserver(() => draw());
      ro.observe(container);
      return () => ro.disconnect();
    }, [draw]);

    const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
      e.currentTarget.setPointerCapture(e.pointerId);
      dragRef.current = {
        active: true,
        startX: e.clientX,
        startY: e.clientY,
        camX: camRef.current.x,
        camY: camRef.current.y,
      };
    };

    const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
      if (!dragRef.current.active) return;
      const dx = e.clientX - dragRef.current.startX;
      const dy = e.clientY - dragRef.current.startY;
      setCam((prev) => ({
        ...prev,
        x: dragRef.current.camX - dx / prev.scale,
        y: dragRef.current.camY + dy / prev.scale,
      }));
    };

    const handlePointerUp = () => {
      dragRef.current.active = false;
    };

    const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
      e.preventDefault();
      const canvas = canvasRef.current;
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      const mx = e.clientX - rect.left;
      const my = e.clientY - rect.top;
      const factor = e.deltaY < 0 ? 1.12 : 1 / 1.12;

      setCam((prev) => {
        const nextScale = Math.max(0.05, Math.min(40, prev.scale * factor));
        const wx = prev.x + (mx - rect.width / 2) / prev.scale;
        const wy = prev.y - (my - rect.height / 2) / prev.scale;
        return {
          scale: nextScale,
          x: wx - (mx - rect.width / 2) / nextScale,
          y: wy + (my - rect.height / 2) / nextScale,
        };
      });
    };

    const zoomBy = (factor: number) => {
      setCam((prev) => ({
        ...prev,
        scale: Math.max(0.05, Math.min(40, prev.scale * factor)),
      }));
    };

    return (
      <div
        ref={containerRef}
        style={{ position: 'relative', width: '100%', height: '100%', touchAction: 'none' }}
      >
        <canvas
          ref={canvasRef}
          style={{ width: '100%', height: '100%', display: 'block', cursor: 'grab' }}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          onWheel={handleWheel}
          aria-label="Płótno 2D — przeciągnij, aby przesunąć, użyj kółka myszy, aby przybliżyć"
        />
        <div className="viewport-overlay-controls" role="toolbar" aria-label="Widok 2D">
          <button
            type="button"
            className="btn btn-ghost btn-icon btn-sm"
            onClick={() => zoomBy(1.25)}
            title="Przybliż"
            aria-label="Przybliż widok"
          >
            <IconZoomIn size={15} />
          </button>
          <button
            type="button"
            className="btn btn-ghost btn-icon btn-sm"
            onClick={() => zoomBy(0.8)}
            title="Oddal"
            aria-label="Oddal widok"
          >
            <IconZoomOut size={15} />
          </button>
          <button
            type="button"
            className="btn btn-ghost btn-icon btn-sm"
            onClick={() => fit()}
            title="Dopasuj rysunek do ekranu"
            aria-label="Dopasuj rysunek do ekranu"
          >
            <IconFit size={15} />
          </button>
          <button
            type="button"
            className="btn btn-ghost btn-icon btn-sm"
            onClick={resetView}
            title="Wyśrodkuj (0, 0)"
            aria-label="Przywróć domyślny widok 2D"
          >
            <IconReset size={15} />
          </button>
        </div>
      </div>
    );
  }
);

Canvas2D.displayName = 'Canvas2D';
