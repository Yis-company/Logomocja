import React from 'react';
import { Mode } from '../interpreter';
import { AppRoute } from '../utils/urlState';
import {
  IconDownload,
  IconImage,
  IconMoon,
  IconShare,
  IconSun,
  IconUpload,
} from './Icons';

interface TopBarProps {
  route: AppRoute;
  onNavigate: (r: AppRoute) => void;
  mode: Mode;
  onModeChange: (m: Mode) => void;
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
  solvedCount: number;
  totalChallenges: number;
  onSharePermalink: () => void;
  onExportPng: () => void;
  onDownloadLogo: () => void;
  onOpenLogoFile: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  route,
  onNavigate,
  mode,
  onModeChange,
  theme,
  onToggleTheme,
  solvedCount,
  totalChallenges,
  onSharePermalink,
  onExportPng,
  onDownloadLogo,
  onOpenLogoFile,
}) => {
  return (
    <header className="topbar">
      <div className="topbar-left">
        <button
          type="button"
          className="brand-btn"
          onClick={() => onNavigate('pracownia')}
          aria-label="Logomocja — przejdź do pracowni"
        >
          <svg className="brand-mark" viewBox="0 0 24 24" aria-hidden="true">
            <rect width="24" height="24" rx="5" fill="#1d3c32" stroke="#2c594a" strokeWidth="1" />
            <path d="M12 4.5L18.5 18L12 14.8L5.5 18L12 4.5Z" fill="#28b08d" />
          </svg>
          <span>Logomocja</span>
        </button>

        <div className="mode-switch" role="group" aria-label="Tryb rysowania">
          <button
            type="button"
            className="mode-btn"
            aria-pressed={mode === '2d'}
            onClick={() => onModeChange('2d')}
          >
            2D
          </button>
          <button
            type="button"
            className="mode-btn"
            aria-pressed={mode === '3d'}
            onClick={() => onModeChange('3d')}
          >
            3D
          </button>
        </div>
      </div>

      <nav className="topbar-center nav-tabs" aria-label="Główna nawigacja">
        <button
          type="button"
          className="nav-tab"
          aria-current={route === 'pracownia' ? 'page' : undefined}
          onClick={() => onNavigate('pracownia')}
        >
          Pracownia
        </button>
        <button
          type="button"
          className="nav-tab"
          aria-current={route === 'przyklady' ? 'page' : undefined}
          onClick={() => onNavigate('przyklady')}
        >
          Przykłady
        </button>
        <button
          type="button"
          className="nav-tab"
          aria-current={route === 'wyzwania' ? 'page' : undefined}
          onClick={() => onNavigate('wyzwania')}
        >
          <span>Wyzwania</span>
          <span className="nav-badge tabular" aria-label={`Ukończono ${solvedCount} z ${totalChallenges}`}>
            {solvedCount}/{totalChallenges}
          </span>
        </button>
        <button
          type="button"
          className="nav-tab"
          aria-current={route === 'slownik' ? 'page' : undefined}
          onClick={() => onNavigate('slownik')}
        >
          Słownik
        </button>
      </nav>

      <div className="topbar-right">
        <button
          type="button"
          className="shell-btn"
          onClick={onSharePermalink}
          title="Kopiuj link do programu"
          aria-label="Kopiuj link do programu"
        >
          <IconShare size={15} />
          <span className="btn-label-desktop">Udostępnij</span>
        </button>
        <button
          type="button"
          className="shell-btn icon-only"
          onClick={onExportPng}
          title="Zapisz rysunek jako PNG"
          aria-label="Zapisz rysunek jako PNG"
        >
          <IconImage size={15} />
        </button>
        <button
          type="button"
          className="shell-btn icon-only"
          onClick={onDownloadLogo}
          title="Pobierz program (.logo)"
          aria-label="Pobierz program jako plik .logo"
        >
          <IconDownload size={15} />
        </button>
        <button
          type="button"
          className="shell-btn icon-only"
          onClick={onOpenLogoFile}
          title="Otwórz plik .logo"
          aria-label="Otwórz plik .logo z dysku"
        >
          <IconUpload size={15} />
        </button>
        <button
          type="button"
          className="shell-btn icon-only"
          onClick={onToggleTheme}
          title={theme === 'dark' ? 'Przełącz na motyw jasny' : 'Przełącz na motyw ciemny'}
          aria-label={theme === 'dark' ? 'Przełącz na motyw jasny' : 'Przełącz na motyw ciemny'}
        >
          {theme === 'dark' ? <IconSun size={15} /> : <IconMoon size={15} />}
        </button>
      </div>
    </header>
  );
};
