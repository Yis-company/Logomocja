import React, {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { Segment, TurtleState } from '../interpreter';
import { ViewportHandle } from './Canvas2D';
import { IconAlert, IconFit, IconReset } from './Icons';

interface Canvas3DProps {
  segments: Segment[];
  turtle: TurtleState;
  theme: 'light' | 'dark';
  guideSegments?: Segment[];
  onSwitchTo2D: () => void;
}

function detectWebGL(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
    return Boolean(gl);
  } catch {
    return false;
  }
}

export const Canvas3D = forwardRef<ViewportHandle, Canvas3DProps>(
  ({ segments, turtle, theme, guideSegments, onSwitchTo2D }, ref) => {
    const mountRef = useRef<HTMLDivElement>(null);
    const [webglError, setWebglError] = useState<string | null>(() =>
      detectWebGL()
        ? null
        : 'Twoja przeglądarka lub urządzenie nie obsługuje WebGL, który jest wymagany do wyświetlania sceny 3D.'
    );

    const sceneRef = useRef<THREE.Scene | null>(null);
    const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
    const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
    const controlsRef = useRef<OrbitControls | null>(null);
    const strokeMeshRef = useRef<THREE.InstancedMesh | null>(null);
    const guideGroupRef = useRef<THREE.Group | null>(null);
    const turtleGroupRef = useRef<THREE.Group | null>(null);
    const turtleBodyMatRef = useRef<THREE.MeshStandardMaterial | null>(null);
    const gridRef = useRef<THREE.GridHelper | null>(null);

    const resetView = useCallback(() => {
      const camera = cameraRef.current;
      const controls = controlsRef.current;
      if (!camera || !controls) return;
      camera.position.set(170, -190, 150);
      controls.target.set(0, 40, 20);
      controls.update();
    }, []);

    const fit = useCallback(
      (overrideSegments?: Segment[]) => {
        const camera = cameraRef.current;
        const controls = controlsRef.current;
        const renderer = rendererRef.current;
        const scene = sceneRef.current;
        if (!camera || !controls) return;

        const segs = overrideSegments ?? segments;
        const box = new THREE.Box3();
        let hasPoints = false;

        const addList = (list?: Segment[]) => {
          if (!list) return;
          for (const s of list) {
            box.expandByPoint(new THREE.Vector3(s.from[0], s.from[1], s.from[2]));
            box.expandByPoint(new THREE.Vector3(s.to[0], s.to[1], s.to[2]));
            hasPoints = true;
          }
        };

        addList(segs);
        addList(guideSegments);

        if (!hasPoints) {
          resetView();
          return;
        }

        const center = new THREE.Vector3();
        const sphere = new THREE.Sphere();
        box.getCenter(center);
        box.getBoundingSphere(sphere);

        const radius = Math.max(25, sphere.radius);
        const fovRad = (camera.fov * Math.PI) / 180;
        const dist = (radius / Math.sin(fovRad / 2)) * 1.18;

        // Place camera at a clear 3D vantage point (+X, -Y, +Z)
        const dir = new THREE.Vector3(0.68, -0.78, 0.56).normalize();
        camera.position.copy(center).addScaledVector(dir, dist);
        camera.near = Math.max(0.5, dist / 500);
        camera.far = Math.max(4000, dist * 12);
        camera.updateProjectionMatrix();

        controls.target.copy(center);
        controls.update();

        if (renderer && scene) {
          renderer.render(scene, camera);
        }
      },
      [segments, guideSegments, resetView]
    );

    const exportPng = useCallback(() => {
      const renderer = rendererRef.current;
      const scene = sceneRef.current;
      const camera = cameraRef.current;
      if (!renderer || !scene || !camera) return null;
      renderer.render(scene, camera);
      return renderer.domElement.toDataURL('image/png');
    }, []);

    useImperativeHandle(ref, () => ({ fit, resetView, exportPng }), [fit, resetView, exportPng]);

    // Initialize Three.js scene
    useEffect(() => {
      if (webglError) return;
      const mount = mountRef.current;
      if (!mount) return;

      let renderer: THREE.WebGLRenderer;
      try {
        renderer = new THREE.WebGLRenderer({
          antialias: true,
          preserveDrawingBuffer: true,
          alpha: false,
        });
      } catch {
        setWebglError('Nie udało się uruchomić kontekstu WebGL w tej przeglądarce.');
        return;
      }

      const width = Math.max(1, mount.clientWidth);
      const height = Math.max(1, mount.clientHeight);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      renderer.setSize(width, height);
      mount.innerHTML = '';
      mount.appendChild(renderer.domElement);

      const scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(45, width / height, 1, 8000);
      camera.up.set(0, 0, 1); // +Z is up!
      camera.position.set(170, -190, 150);

      const controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;
      controls.dampingFactor = 0.08;
      controls.target.set(0, 40, 20);
      controls.update();

      // Lighting
      const ambient = new THREE.AmbientLight(0xffffff, 0.78);
      scene.add(ambient);
      const dirLight = new THREE.DirectionalLight(0xffffff, 0.65);
      dirLight.position.set(220, -160, 320);
      scene.add(dirLight);
      const fillLight = new THREE.DirectionalLight(0xffffff, 0.25);
      fillLight.position.set(-180, 200, -100);
      scene.add(fillLight);

      // Ground grid on XY plane (z = 0)
      const grid = new THREE.GridHelper(400, 20, 0x8ea098, 0xd4dcd6);
      grid.rotation.x = Math.PI / 2;
      scene.add(grid);
      gridRef.current = grid;

      // Axes (X=red, Y=green, Z=blue)
      const axes = new THREE.AxesHelper(90);
      scene.add(axes);

      // Guide group for challenges
      const guideGroup = new THREE.Group();
      scene.add(guideGroup);
      guideGroupRef.current = guideGroup;

      // 3D Turtle marker (cone along +Y, dorsal fin along +Z, wing ticks along +X)
      const turtleGroup = new THREE.Group();
      const bodyGeo = new THREE.ConeGeometry(5.5, 16, 12);
      const bodyMat = new THREE.MeshStandardMaterial({
        color: 0x16866a,
        roughness: 0.35,
        metalness: 0.08,
      });
      const bodyMesh = new THREE.Mesh(bodyGeo, bodyMat);
      bodyMesh.position.y = 4; // ConeGeometry points along +Y by default!
      turtleGroup.add(bodyMesh);

      const finGeo = new THREE.BoxGeometry(1.4, 7, 5);
      const finMat = new THREE.MeshStandardMaterial({ color: 0xe5a93c, roughness: 0.4 });
      const finMesh = new THREE.Mesh(finGeo, finMat);
      finMesh.position.set(0, -1, 3.5);
      turtleGroup.add(finMesh);

      const wingGeo = new THREE.BoxGeometry(11, 1.8, 1.2);
      const wingMat = new THREE.MeshStandardMaterial({ color: 0x3b4d46, roughness: 0.5 });
      const wingMesh = new THREE.Mesh(wingGeo, wingMat);
      wingMesh.position.set(0, -2, 0);
      turtleGroup.add(wingMesh);

      scene.add(turtleGroup);
      turtleGroupRef.current = turtleGroup;
      turtleBodyMatRef.current = bodyMat;

      sceneRef.current = scene;
      cameraRef.current = camera;
      rendererRef.current = renderer;
      controlsRef.current = controls;

      let rafId = 0;
      const animate = () => {
        rafId = requestAnimationFrame(animate);
        controls.update();
        renderer.render(scene, camera);
      };
      animate();

      const ro = new ResizeObserver(() => {
        if (!mount) return;
        const w = Math.max(1, mount.clientWidth);
        const h = Math.max(1, mount.clientHeight);
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
      });
      ro.observe(mount);

      return () => {
        cancelAnimationFrame(rafId);
        ro.disconnect();
        controls.dispose();
        if (strokeMeshRef.current) {
          strokeMeshRef.current.geometry.dispose();
          (strokeMeshRef.current.material as THREE.Material).dispose();
          strokeMeshRef.current = null;
        }
        renderer.dispose();
        sceneRef.current = null;
        cameraRef.current = null;
        rendererRef.current = null;
        controlsRef.current = null;
      };
    }, [webglError]);

    // Update scene background & grid colors on theme change
    useEffect(() => {
      const scene = sceneRef.current;
      if (!scene) return;
      const isDark = theme === 'dark';
      scene.background = new THREE.Color(isDark ? 0x0c1613 : 0xfafaf6);

      if (gridRef.current) {
        scene.remove(gridRef.current);
        gridRef.current.dispose();
        const nextGrid = new THREE.GridHelper(
          400,
          20,
          isDark ? 0x2c4a40 : 0xb8c4bc,
          isDark ? 0x162923 : 0xe4e8e2
        );
        nextGrid.rotation.x = Math.PI / 2;
        scene.add(nextGrid);
        gridRef.current = nextGrid;
      }
    }, [theme, webglError]);

    // Update drawn segments (InstancedMesh cylinders for real stroke width)
    useEffect(() => {
      const scene = sceneRef.current;
      if (!scene) return;

      if (strokeMeshRef.current) {
        scene.remove(strokeMeshRef.current);
        strokeMeshRef.current.geometry.dispose();
        (strokeMeshRef.current.material as THREE.Material).dispose();
        strokeMeshRef.current = null;
      }

      if (segments.length === 0) return;

      const geo = new THREE.CylinderGeometry(1, 1, 1, 8, 1, false);
      const mat = new THREE.MeshStandardMaterial({
        color: 0xffffff,
        roughness: 0.45,
        metalness: 0.05,
      });
      const mesh = new THREE.InstancedMesh(geo, mat, segments.length);

      const upY = new THREE.Vector3(0, 1, 0);
      const p1 = new THREE.Vector3();
      const p2 = new THREE.Vector3();
      const dir = new THREE.Vector3();
      const mid = new THREE.Vector3();
      const quat = new THREE.Quaternion();
      const scale = new THREE.Vector3();
      const matrix = new THREE.Matrix4();
      const color = new THREE.Color();

      for (let i = 0; i < segments.length; i++) {
        const s = segments[i];
        p1.set(s.from[0], s.from[1], s.from[2]);
        p2.set(s.to[0], s.to[1], s.to[2]);
        dir.subVectors(p2, p1);
        const len = dir.length();
        if (len < 1e-6) {
          scale.set(0, 0, 0);
          matrix.compose(p1, quat.identity(), scale);
        } else {
          mid.addVectors(p1, p2).multiplyScalar(0.5);
          dir.divideScalar(len);
          quat.setFromUnitVectors(upY, dir);
          const radius = Math.max(0.45, s.width * 0.42);
          scale.set(radius, len, radius);
          matrix.compose(mid, quat, scale);
        }
        mesh.setMatrixAt(i, matrix);
        color.set(s.color);
        mesh.setColorAt(i, color);
      }

      mesh.instanceMatrix.needsUpdate = true;
      if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
      scene.add(mesh);
      strokeMeshRef.current = mesh;
    }, [segments, webglError]);

    // Update challenge guide segments in 3D
    useEffect(() => {
      const group = guideGroupRef.current;
      if (!group) return;
      while (group.children.length > 0) {
        const child = group.children[0] as THREE.Line;
        child.geometry.dispose();
        (child.material as THREE.Material).dispose();
        group.remove(child);
      }
      if (!guideSegments || guideSegments.length === 0) return;

      const positions: number[] = [];
      for (const s of guideSegments) {
        positions.push(s.from[0], s.from[1], s.from[2], s.to[0], s.to[1], s.to[2]);
      }
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
      const mat = new THREE.LineBasicMaterial({
        color: theme === 'dark' ? 0x829d93 : 0x5a6e66,
        transparent: true,
        opacity: 0.45,
      });
      const lines = new THREE.LineSegments(geo, mat);
      group.add(lines);
    }, [guideSegments, theme, webglError]);

    // Update 3D turtle position & orientation
    useEffect(() => {
      const group = turtleGroupRef.current;
      const mat = turtleBodyMatRef.current;
      if (!group || !mat) return;

      group.position.set(turtle.pos[0], turtle.pos[1], turtle.pos[2]);

      // Build basis matrix: X = right, Y = heading, Z = up
      const m = new THREE.Matrix4().makeBasis(
        new THREE.Vector3(turtle.right[0], turtle.right[1], turtle.right[2]),
        new THREE.Vector3(turtle.heading[0], turtle.heading[1], turtle.heading[2]),
        new THREE.Vector3(turtle.up[0], turtle.up[1], turtle.up[2])
      );
      group.quaternion.setFromRotationMatrix(m);

      mat.color.set(turtle.color);
      mat.opacity = turtle.penDown ? 1 : 0.45;
      mat.transparent = !turtle.penDown;
    }, [turtle, webglError]);

    if (webglError) {
      return (
        <div className="webgl-fallback" role="status">
          <IconAlert size={28} />
          <h2>Widok 3D jest niedostępny</h2>
          <p>{webglError}</p>
          <p>Tryb 2D działa bez WebGL — możesz przełączyć się na płaszczyznę i kontynuować pracę.</p>
          <button type="button" className="btn btn-primary" onClick={onSwitchTo2D}>
            Przejdź do trybu 2D
          </button>
        </div>
      );
    }

    return (
      <div style={{ position: 'relative', width: '100%', height: '100%' }}>
        <div
          ref={mountRef}
          style={{ width: '100%', height: '100%', cursor: 'grab' }}
          aria-label="Scena 3D — przeciągnij, aby obrócić kamerę, prawy przycisk przesuwa, kółko przybliża"
        />
        <div className="viewport-overlay-controls" role="toolbar" aria-label="Widok 3D">
          <button
            type="button"
            className="btn btn-ghost btn-icon btn-sm"
            onClick={() => fit()}
            title="Dopasuj rysunek do kadru"
            aria-label="Dopasuj rysunek 3D do kadru"
          >
            <IconFit size={15} />
          </button>
          <button
            type="button"
            className="btn btn-ghost btn-icon btn-sm"
            onClick={resetView}
            title="Resetuj kamerę 3D"
            aria-label="Przywróć domyślne ustawienie kamery 3D"
          >
            <IconReset size={15} />
          </button>
        </div>
      </div>
    );
  }
);

Canvas3D.displayName = 'Canvas3D';
