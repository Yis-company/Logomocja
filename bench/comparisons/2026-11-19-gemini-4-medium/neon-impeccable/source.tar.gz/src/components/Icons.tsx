import React from 'react';

interface IconProps {
  size?: number;
  className?: string;
}

const baseProps = (size: number, className?: string): React.SVGProps<SVGSVGElement> => ({
  width: size,
  height: size,
  viewBox: '0 0 20 20',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.75,
  strokeLinecap: 'round',
  strokeLinejoin: 'round',
  'aria-hidden': true,
  className,
});

export const IconPlay: React.FC<IconProps> = ({ size = 15, className }) => (
  <svg {...baseProps(size, className)}>
    <path d="M5.5 3.8L15.5 10L5.5 16.2V3.8Z" fill="currentColor" stroke="none" />
  </svg>
);

export const IconPause: React.FC<IconProps> = ({ size = 15, className }) => (
  <svg {...baseProps(size, className)}>
    <rect x="4.5" y="3.5" width="3.5" height="13" rx="0.8" fill="currentColor" stroke="none" />
    <rect x="12" y="3.5" width="3.5" height="13" rx="0.8" fill="currentColor" stroke="none" />
  </svg>
);

export const IconStep: React.FC<IconProps> = ({ size = 15, className }) => (
  <svg {...baseProps(size, className)}>
    <path d="M4.5 4.2L12 10L4.5 15.8V4.2Z" />
    <line x1="15" y1="4.2" x2="15" y2="15.8" />
  </svg>
);

export const IconReset: React.FC<IconProps> = ({ size = 15, className }) => (
  <svg {...baseProps(size, className)}>
    <path d="M4.5 9.5a5.5 5.5 0 1 1 1.4 3.7" />
    <path d="M4.5 4.5v5h5" />
  </svg>
);

export const IconZoomIn: React.FC<IconProps> = ({ size = 15, className }) => (
  <svg {...baseProps(size, className)}>
    <circle cx="9" cy="9" r="5.5" />
    <line x1="13" y1="13" x2="17" y2="17" />
    <line x1="9" y1="6.5" x2="9" y2="11.5" />
    <line x1="6.5" y1="9" x2="11.5" y2="9" />
  </svg>
);

export const IconZoomOut: React.FC<IconProps> = ({ size = 15, className }) => (
  <svg {...baseProps(size, className)}>
    <circle cx="9" cy="9" r="5.5" />
    <line x1="13" y1="13" x2="17" y2="17" />
    <line x1="6.5" y1="9" x2="11.5" y2="9" />
  </svg>
);

export const IconFit: React.FC<IconProps> = ({ size = 15, className }) => (
  <svg {...baseProps(size, className)}>
    <path d="M3.5 7.5V3.5h4" />
    <path d="M16.5 7.5V3.5h-4" />
    <path d="M3.5 12.5v4h4" />
    <path d="M16.5 12.5v4h-4" />
  </svg>
);

export const IconShare: React.FC<IconProps> = ({ size = 15, className }) => (
  <svg {...baseProps(size, className)}>
    <path d="M8.5 11.5L11.5 8.5" />
    <path d="M11 6.5l1.5-1.5a2.8 2.8 0 0 1 4 4L15 10.5" />
    <path d="M9 13.5l-1.5 1.5a2.8 2.8 0 0 1-4-4L5 9.5" />
  </svg>
);

export const IconDownload: React.FC<IconProps> = ({ size = 15, className }) => (
  <svg {...baseProps(size, className)}>
    <path d="M10 3.5v9" />
    <path d="M6.5 9.5L10 13l3.5-3.5" />
    <path d="M4 16h12" />
  </svg>
);

export const IconUpload: React.FC<IconProps> = ({ size = 15, className }) => (
  <svg {...baseProps(size, className)}>
    <path d="M10 12.5v-9" />
    <path d="M6.5 6.5L10 3l3.5 3.5" />
    <path d="M4 16h12" />
  </svg>
);

export const IconImage: React.FC<IconProps> = ({ size = 15, className }) => (
  <svg {...baseProps(size, className)}>
    <rect x="3" y="4" width="14" height="12" rx="1.8" />
    <circle cx="7.5" cy="8" r="1.2" />
    <path d="M4.5 14.5l4-4 3 3 2-2 2.5 3" />
  </svg>
);

export const IconSun: React.FC<IconProps> = ({ size = 15, className }) => (
  <svg {...baseProps(size, className)}>
    <circle cx="10" cy="10" r="3.5" />
    <line x1="10" y1="2.5" x2="10" y2="4.2" />
    <line x1="10" y1="15.8" x2="10" y2="17.5" />
    <line x1="2.5" y1="10" x2="4.2" y2="10" />
    <line x1="15.8" y1="10" x2="17.5" y2="10" />
    <line x1="4.7" y1="4.7" x2="5.9" y2="5.9" />
    <line x1="14.1" y1="14.1" x2="15.3" y2="15.3" />
    <line x1="15.3" y1="4.7" x2="14.1" y2="5.9" />
    <line x1="5.9" y1="14.1" x2="4.7" y2="15.3" />
  </svg>
);

export const IconMoon: React.FC<IconProps> = ({ size = 15, className }) => (
  <svg {...baseProps(size, className)}>
    <path d="M15.8 11.7A6.2 6.2 0 0 1 8.3 4.2a6.2 6.2 0 1 0 7.5 7.5Z" />
  </svg>
);

export const IconCheck: React.FC<IconProps> = ({ size = 15, className }) => (
  <svg {...baseProps(size, className)}>
    <path d="M4.2 10.5l3.6 3.6L16 5.8" />
  </svg>
);

export const IconAlert: React.FC<IconProps> = ({ size = 15, className }) => (
  <svg {...baseProps(size, className)}>
    <circle cx="10" cy="10" r="7" />
    <line x1="10" y1="6.5" x2="10" y2="10.8" />
    <circle cx="10" cy="13.8" r="0.6" fill="currentColor" />
  </svg>
);
