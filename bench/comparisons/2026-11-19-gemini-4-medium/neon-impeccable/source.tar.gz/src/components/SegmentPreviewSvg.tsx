import React, { useMemo } from 'react';
import { Mode, Segment, Vec3 } from '../interpreter';

interface SegmentPreviewSvgProps {
  segments: Segment[];
  mode: Mode;
  label: string;
}

function projectPoint(p: Vec3, mode: Mode): [number, number] {
  if (mode === '2d') {
    return [p[0], -p[1]];
  }
  // Isometric-like 3D projection where +Z is up, +X right-front, +Y left-back
  const yaw = -Math.PI / 4;
  const pitch = Math.PI / 6;
  const cosY = Math.cos(yaw);
  const sinY = Math.sin(yaw);
  const rx = p[0] * cosY - p[1] * sinY;
  const ry = p[0] * sinY + p[1] * cosY;
  const sx = rx;
  const sy = -(p[2] * Math.cos(pitch) + ry * Math.sin(pitch));
  return [sx, sy];
}

export const SegmentPreviewSvg: React.FC<SegmentPreviewSvgProps> = ({ segments, mode, label }) => {
  const projected = useMemo(() => {
    if (segments.length === 0) {
      return { lines: [], viewBox: '-50 -50 100 100', strokeScale: 1 };
    }
    let minX = Infinity;
    let maxX = -Infinity;
    let minY = Infinity;
    let maxY = -Infinity;

    const lines = segments.map((s) => {
      const [x1, y1] = projectPoint(s.from, mode);
      const [x2, y2] = projectPoint(s.to, mode);
      if (x1 < minX) minX = x1;
      if (x2 < minX) minX = x2;
      if (x1 > maxX) maxX = x1;
      if (x2 > maxX) maxX = x2;
      if (y1 < minY) minY = y1;
      if (y2 < minY) minY = y2;
      if (y1 > maxY) maxY = y1;
      if (y2 > maxY) maxY = y2;
      return { x1, y1, x2, y2, color: s.color, width: s.width };
    });

    const w = Math.max(10, maxX - minX);
    const h = Math.max(10, maxY - minY);
    const span = Math.max(w, h);
    const pad = span * 0.14;
    const cx = (minX + maxX) / 2;
    const cy = (minY + maxY) / 2;
    const size = span + pad * 2;
    const strokeScale = Math.max(0.6, size / 180);

    return {
      lines,
      viewBox: `${cx - size / 2} ${cy - size / 2} ${size} ${size}`,
      strokeScale,
    };
  }, [segments, mode]);

  return (
    <svg viewBox={projected.viewBox} role="img" aria-label={label} preserveAspectRatio="xMidYMid meet">
      {projected.lines.map((l, idx) => (
        <line
          key={idx}
          x1={l.x1}
          y1={l.y1}
          x2={l.x2}
          y2={l.y2}
          stroke={l.color}
          strokeWidth={Math.max(1.1, l.width * 0.55) * projected.strokeScale}
          strokeLinecap="round"
        />
      ))}
    </svg>
  );
};
