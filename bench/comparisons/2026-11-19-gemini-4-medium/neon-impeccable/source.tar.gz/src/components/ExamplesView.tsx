import React, { useMemo, useState } from 'react';
import { Mode, runProgram } from '../interpreter';
import { ExampleProgram, STANDARD_EXAMPLES } from '../data/examples';
import { SegmentPreviewSvg } from './SegmentPreviewSvg';

interface ExamplesViewProps {
  onSelectExample: (example: ExampleProgram) => void;
}

export const ExamplesView: React.FC<ExamplesViewProps> = ({ onSelectExample }) => {
  const [filter, setFilter] = useState<'all' | Mode>('all');

  const previews = useMemo(() => {
    const map = new Map<string, ReturnType<typeof runProgram>['segments']>();
    for (const ex of STANDARD_EXAMPLES) {
      map.set(ex.id, runProgram(ex.source, ex.mode).segments);
    }
    return map;
  }, []);

  const filtered = STANDARD_EXAMPLES.filter((e) => filter === 'all' || e.mode === filter);

  return (
    <main className="page-scroll">
      <div className="page-container">
        <div className="page-header">
          <div>
            <h1>Programy przykładowe</h1>
            <p>
              Trzynaście klasycznych rysunków 2D i 3D gotowych do uruchomienia. Wczytanie przykładu przełączy
              pracownię na właściwy tryb.
            </p>
          </div>
          <div className="filter-row" role="group" aria-label="Filtruj przykłady według trybu">
            <button
              type="button"
              className="filter-btn"
              aria-pressed={filter === 'all'}
              onClick={() => setFilter('all')}
            >
              Wszystkie (13)
            </button>
            <button
              type="button"
              className="filter-btn"
              aria-pressed={filter === '2d'}
              onClick={() => setFilter('2d')}
            >
              2D (7)
            </button>
            <button
              type="button"
              className="filter-btn"
              aria-pressed={filter === '3d'}
              onClick={() => setFilter('3d')}
            >
              3D (6)
            </button>
          </div>
        </div>

        <div className="examples-grid">
          {filtered.map((ex) => (
            <article key={ex.id} className="example-card">
              <div className="example-preview">
                <SegmentPreviewSvg
                  segments={previews.get(ex.id) ?? []}
                  mode={ex.mode}
                  label={`Podgląd przykładu ${ex.name}`}
                />
              </div>
              <div className="example-body">
                <div className="example-head">
                  <h2 className="example-title">{ex.name}</h2>
                  <span className={`mode-tag${ex.mode === '3d' ? ' is-3d' : ''}`}>
                    {ex.mode.toUpperCase()}
                  </span>
                </div>
                <p className="example-desc">{ex.description}</p>
                <div className="example-actions">
                  <button
                    type="button"
                    className="btn btn-primary btn-sm"
                    onClick={() => onSelectExample(ex)}
                  >
                    Otwórz w pracowni
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </main>
  );
};
