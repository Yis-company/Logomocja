import React, { useMemo, useRef } from 'react';
import { COMMAND_ALIASES, LogoError, normalizeName } from '../interpreter';
import { IconAlert } from './Icons';

interface CodeEditorProps {
  value: string;
  onChange: (next: string) => void;
  activeLine: number | null;
  error: LogoError | null;
  onRunShortcut?: () => void;
}

const KEYWORDS = new Set(['oto', 'to', 'już', 'juz', 'end', 'ma:', 'nrpowt', 'repcount']);

interface Span {
  text: string;
  cls?: string;
}

function tokenizeLineForHighlight(line: string): Span[] {
  const spans: Span[] = [];
  let i = 0;

  while (i < line.length) {
    const ch = line[i];

    // Comment
    if (ch === ';') {
      spans.push({ text: line.slice(i), cls: 'tok-comment' });
      break;
    }

    // Whitespace
    if (ch === ' ' || ch === '\t') {
      let j = i + 1;
      while (j < line.length && (line[j] === ' ' || line[j] === '\t')) j++;
      spans.push({ text: line.slice(i, j) });
      i = j;
      continue;
    }

    // String / color literal
    if (ch === '"') {
      let j = i + 1;
      while (j < line.length && line[j] !== '"') j++;
      if (j < line.length) j++;
      spans.push({ text: line.slice(i, j), cls: 'tok-string' });
      i = j;
      continue;
    }

    // Brackets & parens
    if (ch === '[' || ch === ']' || ch === '(' || ch === ')') {
      spans.push({ text: ch, cls: 'tok-bracket' });
      i++;
      continue;
    }

    // Operators & comparisons
    if ('+-*/<>=,'.includes(ch)) {
      let j = i + 1;
      if ((ch === '<' || ch === '>') && (line[j] === '=' || (ch === '<' && line[j] === '>'))) {
        j++;
      }
      spans.push({ text: line.slice(i, j), cls: 'tok-operator' });
      i = j;
      continue;
    }

    // Number
    if ((ch >= '0' && ch <= '9') || (ch === '.' && i + 1 < line.length && line[i + 1] >= '0' && line[i + 1] <= '9')) {
      let j = i + 1;
      while (j < line.length && ((line[j] >= '0' && line[j] <= '9') || line[j] === '.')) j++;
      spans.push({ text: line.slice(i, j), cls: 'tok-number' });
      i = j;
      continue;
    }

    // Legacy :name
    if (ch === ':') {
      let j = i + 1;
      while (j < line.length && /[\p{L}\p{N}_]/u.test(line[j])) j++;
      spans.push({ text: line.slice(i, j), cls: 'tok-name' });
      i = j;
      continue;
    }

    // Word / command / keyword / ma:
    if (/[\p{L}_]/u.test(ch)) {
      let j = i + 1;
      while (j < line.length && /[\p{L}\p{N}_]/u.test(line[j])) j++;
      if (line[j] === ':' && normalizeName(line.slice(i, j)) === 'ma') {
        j++;
      }
      const word = line.slice(i, j);
      const norm = normalizeName(word);
      let cls = 'tok-name';
      if (KEYWORDS.has(norm)) {
        cls = 'tok-keyword';
      } else if (COMMAND_ALIASES[norm]) {
        cls = 'tok-command';
      }
      spans.push({ text: word, cls });
      i = j;
      continue;
    }

    spans.push({ text: ch });
    i++;
  }

  return spans;
}

function renderLineWithErrorMarker(line: string, errorCol: number | null): React.ReactNode {
  if (line.length === 0) {
    return errorCol !== null ? <span className="err-caret"> </span> : '\n';
  }
  const spans = tokenizeLineForHighlight(line);
  if (errorCol === null) {
    return spans.map((s, i) =>
      s.cls ? (
        <span key={i} className={s.cls}>
          {s.text}
        </span>
      ) : (
        <React.Fragment key={i}>{s.text}</React.Fragment>
      )
    );
  }

  const targetIdx = Math.max(0, Math.min(line.length - 1, errorCol - 1));
  let offset = 0;
  const nodes: React.ReactNode[] = [];

  spans.forEach((s, idx) => {
    const start = offset;
    const end = offset + s.text.length;
    offset = end;

    if (targetIdx >= start && targetIdx < end) {
      const localIdx = targetIdx - start;
      // Underline the whole token containing targetIdx (or at least 1 char)
      const before = s.text.slice(0, localIdx);
      const marked = s.text.slice(localIdx) || ' ';
      nodes.push(
        <span key={idx} className={s.cls}>
          {before}
          <span className="err-caret">{marked}</span>
        </span>
      );
    } else if (s.cls) {
      nodes.push(
        <span key={idx} className={s.cls}>
          {s.text}
        </span>
      );
    } else {
      nodes.push(<React.Fragment key={idx}>{s.text}</React.Fragment>);
    }
  });

  return nodes;
}

export const CodeEditor: React.FC<CodeEditorProps> = ({
  value,
  onChange,
  activeLine,
  error,
  onRunShortcut,
}) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const highlightRef = useRef<HTMLDivElement>(null);
  const gutterRef = useRef<HTMLDivElement>(null);

  const lines = useMemo(() => value.split('\n'), [value]);

  const handleScroll = () => {
    const ta = textareaRef.current;
    if (!ta) return;
    if (highlightRef.current) {
      highlightRef.current.scrollTop = ta.scrollTop;
      highlightRef.current.scrollLeft = ta.scrollLeft;
    }
    if (gutterRef.current) {
      gutterRef.current.scrollTop = ta.scrollTop;
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
      e.preventDefault();
      onRunShortcut?.();
      return;
    }
    if (e.key === 'Tab' && !e.shiftKey && !e.ctrlKey && !e.metaKey && !e.altKey) {
      e.preventDefault();
      const ta = e.currentTarget;
      const start = ta.selectionStart;
      const end = ta.selectionEnd;
      const next = value.slice(0, start) + '  ' + value.slice(end);
      onChange(next);
      requestAnimationFrame(() => {
        ta.selectionStart = ta.selectionEnd = start + 2;
      });
    }
  };

  return (
    <>
      <div className="code-editor-wrap">
        <div className="code-gutter tabular" ref={gutterRef} aria-hidden="true">
          {lines.map((_, idx) => {
            const lineNum = idx + 1;
            const isErr = error?.line === lineNum;
            const isAct = activeLine === lineNum && !isErr;
            return (
              <div
                key={lineNum}
                className={`gutter-line${isErr ? ' is-error' : isAct ? ' is-active' : ''}`}
              >
                {lineNum}
              </div>
            );
          })}
        </div>

        <div className="code-stage">
          <div className="code-highlight" ref={highlightRef} aria-hidden="true">
            {lines.map((line, idx) => {
              const lineNum = idx + 1;
              const isErr = error?.line === lineNum;
              const isAct = activeLine === lineNum && !isErr;
              return (
                <div
                  key={lineNum}
                  className={`code-line${isErr ? ' is-error' : isAct ? ' is-active' : ''}`}
                >
                  {renderLineWithErrorMarker(line, isErr ? error!.column : null)}
                </div>
              );
            })}
          </div>

          <textarea
            ref={textareaRef}
            className="code-textarea"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            onScroll={handleScroll}
            onKeyDown={handleKeyDown}
            spellCheck={false}
            autoCapitalize="off"
            autoComplete="off"
            autoCorrect="off"
            aria-label="Edytor kodu Logo"
          />
        </div>
      </div>

      {error && (
        <div className="diagnostic-bar" role="alert">
          <IconAlert size={16} />
          <span className="diagnostic-loc tabular">
            W{error.line}:K{error.column}
          </span>
          <span>{error.message}</span>
        </div>
      )}
    </>
  );
};
