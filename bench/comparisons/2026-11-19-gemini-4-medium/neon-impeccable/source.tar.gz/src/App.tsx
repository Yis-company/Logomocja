import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  createInitialTurtle,
  createStepper,
  LogoError,
  LogoStepper,
  Mode,
  RunResult,
  runProgram,
  Segment,
  TurtleState,
} from './interpreter';
import { ExampleProgram, STANDARD_EXAMPLES } from './data/examples';
import { CHALLENGES, Challenge, getChallengeTargetSegments } from './data/challenges';
import { checkDrawingAgainstTarget, CheckResult } from './utils/challengeChecker';
import {
  loadDraft,
  loadLastMode,
  loadSolvedChallenges,
  loadThemePreference,
  saveDraft,
  saveLastMode,
  saveSolvedChallenges,
  saveThemePreference,
  ThemePreference,
} from './utils/storage';
import { AppRoute, buildPermalink, parseHashUrl } from './utils/urlState';
import { TopBar } from './components/TopBar';
import { CodeEditor } from './components/CodeEditor';
import { Canvas2D, ViewportHandle } from './components/Canvas2D';
import { Canvas3D } from './components/Canvas3D';
import { TelemetryStrip } from './components/TelemetryStrip';
import { ExamplesView } from './components/ExamplesView';
import { ChallengesView } from './components/ChallengesView';
import { ReferenceView } from './components/ReferenceView';
import { ConfirmDialog } from './components/ConfirmDialog';
import { IconCheck, IconPause, IconPlay, IconReset, IconStep } from './components/Icons';

declare global {
  interface Window {
    logomocja?: {
      version: string;
      run: (source: string, mode: Mode) => RunResult;
      open: (source: string, mode: Mode) => Promise<RunResult>;
    };
  }
}

type ExecStatus = 'idle' | 'running' | 'paused' | 'done' | 'error';

interface PendingLoad {
  title: string;
  mode: Mode;
  source: string;
  challengeId?: string | null;
  autoRun?: boolean;
}

const DEFAULT_2D = STANDARD_EXAMPLES.find((e) => e.id === 'kwadrat')!.source;
const DEFAULT_3D = STANDARD_EXAMPLES.find((e) => e.id === 'schody')!.source;

// Speed 1..5 -> label & ms/steps per tick
const SPEED_CONFIG: Record<number, { label: string; delayMs: number; stepsPerTick: number }> = {
  1: { label: 'Wolno', delayMs: 260, stepsPerTick: 1 },
  2: { label: 'Umiark.', delayMs: 90, stepsPerTick: 1 },
  3: { label: 'Normalnie', delayMs: 28, stepsPerTick: 2 },
  4: { label: 'Szybko', delayMs: 16, stepsPerTick: 18 },
  5: { label: 'Natychmiast', delayMs: 0, stepsPerTick: 10000 },
};

function getSystemTheme(): 'light' | 'dark' {
  if (typeof window === 'undefined' || !window.matchMedia) return 'light';
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

export const App: React.FC = () => {
  const initialHash = useMemo(() => parseHashUrl(window.location.hash), []);

  const [route, setRoute] = useState<AppRoute>(initialHash.route);
  const [mode, setMode] = useState<Mode>(() => initialHash.sharedMode ?? loadLastMode());

  const [drafts, setDrafts] = useState<Record<Mode, string>>(() => {
    const d2 = loadDraft('2d') ?? DEFAULT_2D;
    const d3 = loadDraft('3d') ?? DEFAULT_3D;
    if (initialHash.sharedMode && initialHash.sharedSource !== undefined) {
      return {
        '2d': initialHash.sharedMode === '2d' ? initialHash.sharedSource : d2,
        '3d': initialHash.sharedMode === '3d' ? initialHash.sharedSource : d3,
      };
    }
    return { '2d': d2, '3d': d3 };
  });

  const [dirty, setDirty] = useState<Record<Mode, boolean>>({ '2d': false, '3d': false });

  // Theme management
  const [themePref, setThemePref] = useState<ThemePreference>(() => loadThemePreference());
  const [systemTheme, setSystemTheme] = useState<'light' | 'dark'>(getSystemTheme);
  const effectiveTheme: 'light' | 'dark' = themePref === 'system' ? systemTheme : themePref;

  // Execution state
  const [status, setStatus] = useState<ExecStatus>('idle');
  const [segments, setSegments] = useState<Segment[]>([]);
  const [turtle, setTurtle] = useState<TurtleState>(createInitialTurtle);
  const [activeLine, setActiveLine] = useState<number | null>(null);
  const [operations, setOperations] = useState(0);
  const [error, setError] = useState<LogoError | null>(null);
  const [speed, setSpeed] = useState<number>(3);

  // Mobile studio pane switch
  const [mobilePane, setMobilePane] = useState<'code' | 'canvas'>('code');

  // Challenges state
  const [solvedIds, setSolvedIds] = useState<string[]>(() => loadSolvedChallenges());
  const [activeChallengeId, setActiveChallengeId] = useState<string | null>(null);
  const [challengeResult, setChallengeResult] = useState<CheckResult | null>(null);

  // Confirm overwrite dialog & toast
  const [pendingLoad, setPendingLoad] = useState<PendingLoad | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const stepperRef = useRef<LogoStepper | null>(null);
  const timerRef = useRef<number | null>(null);
  const viewportRef = useRef<ViewportHandle | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const toastTimerRef = useRef<number | null>(null);

  const currentSource = drafts[mode];
  const activeChallenge = useMemo(
    () => CHALLENGES.find((c) => c.id === activeChallengeId) ?? null,
    [activeChallengeId]
  );
  const guideSegments = useMemo(
    () => (activeChallenge && activeChallenge.mode === mode ? getChallengeTargetSegments(activeChallenge) : undefined),
    [activeChallenge, mode]
  );

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    if (toastTimerRef.current) window.clearTimeout(toastTimerRef.current);
    toastTimerRef.current = window.setTimeout(() => setToast(null), 2800);
  }, []);

  // Apply theme attribute
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', effectiveTheme);
  }, [effectiveTheme]);

  // Listen to OS color-scheme changes
  useEffect(() => {
    if (!window.matchMedia) return;
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const handler = (e: MediaQueryListEvent) => setSystemTheme(e.matches ? 'dark' : 'light');
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  // Sync hash navigation
  const navigate = useCallback((nextRoute: AppRoute) => {
    setRoute(nextRoute);
    const targetHash = `#${nextRoute}`;
    if (window.location.hash !== targetHash && !window.location.hash.startsWith(`${targetHash}?`)) {
      window.history.replaceState(null, '', targetHash);
    }
  }, []);

  useEffect(() => {
    const onHashChange = () => {
      const parsed = parseHashUrl(window.location.hash);
      setRoute(parsed.route);
      if (parsed.sharedMode && parsed.sharedSource !== undefined) {
        setMode(parsed.sharedMode);
        setDrafts((prev) => ({ ...prev, [parsed.sharedMode!]: parsed.sharedSource! }));
        setDirty((prev) => ({ ...prev, [parsed.sharedMode!]: false }));
      }
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  const stopTimer = useCallback(() => {
    if (timerRef.current !== null) {
      window.clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const resetExecution = useCallback(() => {
    stopTimer();
    stepperRef.current = null;
    setStatus('idle');
    setSegments([]);
    setTurtle(createInitialTurtle());
    setActiveLine(null);
    setOperations(0);
    setError(null);
    setChallengeResult(null);
  }, [stopTimer]);

  const syncFromStepper = useCallback((stepper: LogoStepper) => {
    const snap = stepper.getSnapshot();
    setSegments(snap.segments);
    setTurtle(snap.turtle);
    setActiveLine(snap.done && !snap.error ? null : snap.line);
    setOperations(snap.operations);
    setError(snap.error);
    if (snap.error) {
      setStatus('error');
    } else if (snap.done) {
      setStatus('done');
    }
  }, []);

  const runImmediate = useCallback(
    (source: string, runMode: Mode, shouldFit = true): RunResult => {
      stopTimer();
      const { stepper, error: parseErr } = createStepper(source, runMode);
      if (parseErr || !stepper) {
        stepperRef.current = null;
        setSegments([]);
        setTurtle(createInitialTurtle());
        setActiveLine(null);
        setOperations(0);
        setError(parseErr);
        setStatus('error');
        return { segments: [], error: parseErr };
      }
      const res = stepper.runToEnd();
      stepperRef.current = stepper;
      const snap = stepper.getSnapshot();
      setSegments(snap.segments);
      setTurtle(snap.turtle);
      setActiveLine(snap.error ? snap.line : null);
      setOperations(snap.operations);
      setError(snap.error);
      setStatus(snap.error ? 'error' : 'done');

      if (shouldFit) {
        requestAnimationFrame(() => {
          viewportRef.current?.fit(snap.segments);
        });
      }
      return res;
    },
    [stopTimer]
  );

  const scheduleTick = useCallback(
    (currentSpeed: number) => {
      stopTimer();
      const cfg = SPEED_CONFIG[currentSpeed] ?? SPEED_CONFIG[3];
      const tick = () => {
        const stepper = stepperRef.current;
        if (!stepper || stepper.isDone()) {
          setStatus(stepper?.getError() ? 'error' : 'done');
          return;
        }
        for (let i = 0; i < cfg.stepsPerTick && !stepper.isDone(); i++) {
          stepper.step();
        }
        syncFromStepper(stepper);
        if (!stepper.isDone()) {
          timerRef.current = window.setTimeout(tick, cfg.delayMs);
        }
      };
      timerRef.current = window.setTimeout(tick, cfg.delayMs);
    },
    [stopTimer, syncFromStepper]
  );

  const handleRun = useCallback(() => {
    setChallengeResult(null);
    if (speed === 5) {
      runImmediate(currentSource, mode, false);
      return;
    }
    stopTimer();
    const { stepper, error: parseErr } = createStepper(currentSource, mode);
    if (parseErr || !stepper) {
      stepperRef.current = null;
      setSegments([]);
      setTurtle(createInitialTurtle());
      setActiveLine(null);
      setOperations(0);
      setError(parseErr);
      setStatus('error');
      return;
    }
    stepperRef.current = stepper;
    setError(null);
    setSegments([]);
    setTurtle(createInitialTurtle());
    setOperations(0);
    setStatus('running');
    scheduleTick(speed);
  }, [currentSource, mode, speed, runImmediate, stopTimer, scheduleTick]);

  const handlePauseResume = useCallback(() => {
    if (status === 'running') {
      stopTimer();
      setStatus('paused');
    } else if (status === 'paused' && stepperRef.current && !stepperRef.current.isDone()) {
      setStatus('running');
      scheduleTick(speed);
    }
  }, [status, stopTimer, scheduleTick, speed]);

  const handleStep = useCallback(() => {
    setChallengeResult(null);
    stopTimer();
    let stepper = stepperRef.current;
    if (!stepper || status === 'idle' || status === 'done' || status === 'error') {
      const created = createStepper(currentSource, mode);
      if (created.error || !created.stepper) {
        stepperRef.current = null;
        setSegments([]);
        setTurtle(createInitialTurtle());
        setActiveLine(null);
        setOperations(0);
        setError(created.error);
        setStatus('error');
        return;
      }
      stepper = created.stepper;
      stepperRef.current = stepper;
    }
    stepper.step();
    syncFromStepper(stepper);
    if (!stepper.isDone()) {
      setStatus('paused');
    }
  }, [currentSource, mode, status, stopTimer, syncFromStepper]);

  // Speed change while running
  const handleSpeedChange = (nextSpeed: number) => {
    setSpeed(nextSpeed);
    if (status === 'running') {
      if (nextSpeed === 5 && stepperRef.current) {
        stopTimer();
        stepperRef.current.runToEnd();
        syncFromStepper(stepperRef.current);
      } else {
        scheduleTick(nextSpeed);
      }
    }
  };

  // Editing while running: stop animation cleanly and persist draft
  const handleSourceChange = useCallback(
    (next: string) => {
      if (status === 'running' || status === 'paused') {
        stopTimer();
        stepperRef.current = null;
        setStatus('idle');
        setActiveLine(null);
      }
      setDrafts((prev) => ({ ...prev, [mode]: next }));
      setDirty((prev) => ({ ...prev, [mode]: true }));
      saveDraft(mode, next);
      setError(null);
      setChallengeResult(null);
    },
    [mode, status, stopTimer]
  );

  // Switch 2D/3D mode
  const handleModeChange = useCallback(
    (nextMode: Mode) => {
      if (nextMode === mode) return;
      stopTimer();
      setMode(nextMode);
      saveLastMode(nextMode);
      if (activeChallenge && activeChallenge.mode !== nextMode) {
        setActiveChallengeId(null);
      }
      setChallengeResult(null);
      // Run the draft of the target mode immediately so canvas reflects it
      const nextSrc = drafts[nextMode];
      requestAnimationFrame(() => {
        runImmediate(nextSrc, nextMode, true);
      });
    },
    [mode, stopTimer, activeChallenge, drafts, runImmediate]
  );

  // Safe loading of examples / challenges / files without silently destroying unsaved draft
  const applyLoad = useCallback(
    (req: PendingLoad) => {
      stopTimer();
      setMode(req.mode);
      saveLastMode(req.mode);
      setDrafts((prev) => ({ ...prev, [req.mode]: req.source }));
      setDirty((prev) => ({ ...prev, [req.mode]: false }));
      saveDraft(req.mode, req.source);
      setActiveChallengeId(req.challengeId ?? null);
      setChallengeResult(null);
      navigate('pracownia');
      setPendingLoad(null);

      if (req.autoRun !== false) {
        requestAnimationFrame(() => {
          runImmediate(req.source, req.mode, true);
        });
      } else {
        resetExecution();
      }
    },
    [stopTimer, navigate, runImmediate, resetExecution]
  );

  const requestLoad = useCallback(
    (req: PendingLoad) => {
      if (dirty[req.mode] && drafts[req.mode].trim() !== req.source.trim()) {
        setPendingLoad(req);
      } else {
        applyLoad(req);
      }
    },
    [dirty, drafts, applyLoad]
  );

  const handleSelectExample = useCallback(
    (ex: ExampleProgram) => {
      requestLoad({
        title: `Przykład: ${ex.name}`,
        mode: ex.mode,
        source: ex.source,
        challengeId: null,
        autoRun: true,
      });
    },
    [requestLoad]
  );

  const handleStartChallenge = useCallback(
    (ch: Challenge) => {
      requestLoad({
        title: `Wyzwanie: ${ch.title}`,
        mode: ch.mode,
        source: ch.starterCode,
        challengeId: ch.id,
        autoRun: true,
      });
    },
    [requestLoad]
  );

  const handleCheckChallenge = useCallback(() => {
    if (!activeChallenge) return;
    const res = runImmediate(currentSource, activeChallenge.mode, true);
    if (res.error) {
      setChallengeResult({
        passed: false,
        reason: `Najpierw popraw błąd w programie (W${res.error.line}:K${res.error.column}): ${res.error.message}`,
        coveragePct: 0,
        maxDeviation: Infinity,
      });
      return;
    }
    const target = getChallengeTargetSegments(activeChallenge);
    const check = checkDrawingAgainstTarget(res.segments, target, activeChallenge.tolerance);
    setChallengeResult(check);
    if (check.passed && !solvedIds.includes(activeChallenge.id)) {
      const nextSolved = [...solvedIds, activeChallenge.id];
      setSolvedIds(nextSolved);
      saveSolvedChallenges(nextSolved);
      showToast(`Wyzwanie „${activeChallenge.title}” zaliczone!`);
    }
  }, [activeChallenge, currentSource, runImmediate, solvedIds, showToast]);

  // Share, Export PNG, Download .logo, Open .logo
  const handleSharePermalink = useCallback(async () => {
    const url = buildPermalink(currentSource, mode);
    window.history.replaceState(null, '', url);
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(url);
        showToast('Skopiowano link do programu do schowka.');
      } else {
        showToast('Zaktualizowano link w pasku adresu.');
      }
    } catch {
      showToast('Zaktualizowano link w pasku adresu.');
    }
  }, [currentSource, mode, showToast]);

  const handleExportPng = useCallback(() => {
    const dataUrl = viewportRef.current?.exportPng();
    if (!dataUrl) {
      showToast('Najpierw przejdź do pracowni, aby wyeksportować rysunek.');
      return;
    }
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `logomocja-${mode}.png`;
    a.click();
    showToast('Zapisano rysunek jako PNG.');
  }, [mode, showToast]);

  const handleDownloadLogo = useCallback(() => {
    const blob = new Blob([currentSource], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `program-${mode}.logo`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Pobrano plik .logo.');
  }, [currentSource, mode, showToast]);

  const handleOpenLogoFile = useCallback(() => {
    fileInputRef.current?.click();
  }, []);

  const handleFileSelected = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      e.target.value = '';
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        const text = typeof reader.result === 'string' ? reader.result : '';
        requestLoad({
          title: `Plik: ${file.name}`,
          mode,
          source: text,
          challengeId: null,
          autoRun: true,
        });
      };
      reader.readAsText(file, 'utf-8');
    },
    [mode, requestLoad]
  );

  // Global keyboard shortcuts (Run: Ctrl/Cmd+Enter, Step: F10 / Alt+S, Pause: Alt+P, Reset: Alt+R)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (route !== 'pracownia') return;
      if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
        e.preventDefault();
        handleRun();
      } else if (e.key === 'F10' || (e.altKey && e.key.toLowerCase() === 's')) {
        e.preventDefault();
        handleStep();
      } else if (e.altKey && e.key.toLowerCase() === 'p') {
        e.preventDefault();
        handlePauseResume();
      } else if (e.altKey && e.key.toLowerCase() === 'r') {
        e.preventDefault();
        resetExecution();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [route, handleRun, handleStep, handlePauseResume, resetExecution]);

  // Initial run on mount (for permalink or initial draft)
  const didInitRef = useRef(false);
  useEffect(() => {
    if (didInitRef.current) return;
    didInitRef.current = true;
    runImmediate(drafts[mode], mode, true);
  }, [drafts, mode, runImmediate]);

  // Expose window.logomocja testing hook
  useEffect(() => {
    window.logomocja = {
      version: '1.0.0',
      run: (source: string, runMode: Mode) => runProgram(source, runMode),
      open: async (source: string, openMode: Mode): Promise<RunResult> => {
        stopTimer();
        setRoute('pracownia');
        setActiveChallengeId(null);
        setChallengeResult(null);
        setMode(openMode);
        saveLastMode(openMode);
        setDrafts((prev) => ({ ...prev, [openMode]: source }));
        setDirty((prev) => ({ ...prev, [openMode]: false }));
        saveDraft(openMode, source);

        const res = runImmediate(source, openMode, false);

        // Wait for React commit & canvas mount/resize, then fit and paint
        await new Promise<void>((resolve) => {
          requestAnimationFrame(() => {
            requestAnimationFrame(() => {
              viewportRef.current?.fit(res.segments);
              requestAnimationFrame(() => resolve());
            });
          });
        });

        return res;
      },
    };
  }, [runImmediate, stopTimer]);

  const toggleTheme = () => {
    const next: ThemePreference = effectiveTheme === 'dark' ? 'light' : 'dark';
    setThemePref(next);
    saveThemePreference(next);
  };

  const statusLabel =
    status === 'running'
      ? 'Wykonywanie'
      : status === 'paused'
        ? 'Wstrzymano'
        : status === 'error'
          ? 'Błąd'
          : status === 'done'
            ? 'Gotowe'
            : 'Gotowy';

  return (
    <div className="app-shell">
      <TopBar
        route={route}
        onNavigate={navigate}
        mode={mode}
        onModeChange={handleModeChange}
        theme={effectiveTheme}
        onToggleTheme={toggleTheme}
        solvedCount={solvedIds.length}
        totalChallenges={CHALLENGES.length}
        onSharePermalink={handleSharePermalink}
        onExportPng={handleExportPng}
        onDownloadLogo={handleDownloadLogo}
        onOpenLogoFile={handleOpenLogoFile}
      />

      <input
        ref={fileInputRef}
        type="file"
        accept=".logo,.txt,text/plain"
        className="sr-only"
        onChange={handleFileSelected}
        aria-label="Wybierz plik .logo"
      />

      {route === 'pracownia' && (
        <main className="studio-main">
          <div className="mobile-pane-tabs" role="tablist" aria-label="Widok pracowni na małym ekranie">
            <button
              type="button"
              role="tab"
              className="mobile-pane-tab"
              aria-selected={mobilePane === 'code'}
              onClick={() => setMobilePane('code')}
            >
              Kod
            </button>
            <button
              type="button"
              role="tab"
              className="mobile-pane-tab"
              aria-selected={mobilePane === 'canvas'}
              onClick={() => setMobilePane('canvas')}
            >
              Rysunek ({mode.toUpperCase()})
            </button>
          </div>

          <section
            className={`editor-pane${mobilePane === 'canvas' ? ' mobile-hidden' : ''}`}
            aria-label="Edytor programu"
          >
            <div className="exec-toolbar" role="toolbar" aria-label="Sterowanie wykonywaniem">
              <div className="exec-actions">
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={handleRun}
                  title="Uruchom program (Ctrl+Enter)"
                >
                  <IconPlay size={14} />
                  <span>Uruchom</span>
                </button>
                <button
                  type="button"
                  className="btn"
                  onClick={handleStep}
                  title="Wykonaj jeden krok (F10 lub Alt+S)"
                >
                  <IconStep size={14} />
                  <span>Krok</span>
                </button>
                <button
                  type="button"
                  className="btn"
                  onClick={handlePauseResume}
                  disabled={status !== 'running' && status !== 'paused'}
                  title={status === 'paused' ? 'Wznów (Alt+P)' : 'Pauza (Alt+P)'}
                >
                  {status === 'paused' ? <IconPlay size={14} /> : <IconPause size={14} />}
                  <span>{status === 'paused' ? 'Wznów' : 'Pauza'}</span>
                </button>
                <button
                  type="button"
                  className="btn btn-icon"
                  onClick={resetExecution}
                  title="Resetuj rysunek i żółwia (Alt+R)"
                  aria-label="Resetuj rysunek i żółwia"
                >
                  <IconReset size={14} />
                </button>
              </div>

              <label className="speed-control">
                <span>Tempo</span>
                <input
                  type="range"
                  min={1}
                  max={5}
                  step={1}
                  value={speed}
                  onChange={(e) => handleSpeedChange(Number(e.target.value))}
                  aria-label="Prędkość animacji żółwia"
                />
                <span className="speed-label">{SPEED_CONFIG[speed].label}</span>
              </label>
            </div>

            {activeChallenge && (
              <div className="challenge-bar">
                <div className="challenge-bar-info">
                  <span className="mode-tag">{activeChallenge.mode.toUpperCase()}</span>
                  <span className="challenge-bar-title">Wyzwanie: {activeChallenge.title}</span>
                </div>
                <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
                  <button type="button" className="btn btn-primary btn-sm" onClick={handleCheckChallenge}>
                    <IconCheck size={14} />
                    <span>Sprawdź</span>
                  </button>
                  <button
                    type="button"
                    className="btn btn-sm"
                    onClick={() => {
                      setActiveChallengeId(null);
                      setChallengeResult(null);
                    }}
                  >
                    Zamknij
                  </button>
                </div>
              </div>
            )}

            <CodeEditor
              value={currentSource}
              onChange={handleSourceChange}
              activeLine={activeLine}
              error={error}
              onRunShortcut={handleRun}
            />

            {challengeResult && (
              <div
                className={`diagnostic-bar${challengeResult.passed ? ' is-success' : ''}`}
                role="status"
              >
                <span className="diagnostic-loc">{challengeResult.passed ? 'OK' : 'SPRAWDŹ'}</span>
                <span>{challengeResult.reason}</span>
              </div>
            )}

            <div className="editor-footer">
              <div className="shortcut-strip" aria-label="Skróty klawiszowe">
                <span className="shortcut-item">
                  <kbd>Ctrl+Enter</kbd> Uruchom
                </span>
                <span className="shortcut-item">
                  <kbd>F10</kbd> / <kbd>Alt+S</kbd> Krok
                </span>
                <span className="shortcut-item">
                  <kbd>Alt+P</kbd> Pauza
                </span>
                <span className="shortcut-item">
                  <kbd>Alt+R</kbd> Reset
                </span>
              </div>
              <span className="tabular">{currentSource.length.toLocaleString('pl-PL')} zn.</span>
            </div>
          </section>

          <section
            className={`viewport-pane${mobilePane === 'code' ? ' mobile-hidden' : ''}`}
            aria-label={`Płótno rysowania ${mode.toUpperCase()}`}
          >
            <div className="viewport-canvas-area">
              <div className="viewport-mode-pill" aria-live="polite">
                <span
                  className={`status-dot${
                    status === 'running'
                      ? ' is-running'
                      : status === 'paused'
                        ? ' is-paused'
                        : status === 'error'
                          ? ' is-error'
                          : ''
                  }`}
                />
                <span>
                  Tryb {mode.toUpperCase()} · {statusLabel}
                </span>
              </div>

              {mode === '2d' ? (
                <Canvas2D
                  ref={viewportRef}
                  segments={segments}
                  turtle={turtle}
                  theme={effectiveTheme}
                  guideSegments={guideSegments}
                />
              ) : (
                <Canvas3D
                  ref={viewportRef}
                  segments={segments}
                  turtle={turtle}
                  theme={effectiveTheme}
                  guideSegments={guideSegments}
                  onSwitchTo2D={() => handleModeChange('2d')}
                />
              )}
            </div>

            <TelemetryStrip
              mode={mode}
              turtle={turtle}
              operations={operations}
              segmentCount={segments.length}
              activeLine={activeLine}
            />
          </section>
        </main>
      )}

      {route === 'przyklady' && <ExamplesView onSelectExample={handleSelectExample} />}

      {route === 'wyzwania' && (
        <ChallengesView
          solvedIds={solvedIds}
          activeChallengeId={activeChallengeId}
          onStartChallenge={handleStartChallenge}
        />
      )}

      {route === 'slownik' && (
        <ReferenceView
          onTryCode={(src, targetMode) =>
            requestLoad({
              title: 'Przykład ze słownika',
              mode: targetMode,
              source: src,
              challengeId: null,
              autoRun: true,
            })
          }
        />
      )}

      <ConfirmDialog
        open={pendingLoad !== null}
        title="Zastąpić bieżący szkic?"
        message={
          pendingLoad
            ? `W trybie ${pendingLoad.mode.toUpperCase()} masz niezapisane zmiany. Wczytanie „${pendingLoad.title}” zastąpi obecny kod w edytorze.`
            : ''
        }
        confirmLabel="Zastąp szkic"
        onConfirm={() => pendingLoad && applyLoad(pendingLoad)}
        onCancel={() => setPendingLoad(null)}
      />

      {toast && (
        <div className="toast-banner" role="status" aria-live="polite">
          {toast}
        </div>
      )}
    </div>
  );
};
