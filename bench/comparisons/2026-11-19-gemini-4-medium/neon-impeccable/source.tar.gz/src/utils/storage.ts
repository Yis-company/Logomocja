import { Mode } from '../interpreter';

export type ThemePreference = 'system' | 'light' | 'dark';

const KEYS = {
  DRAFT_2D: 'logomocja:draft:2d',
  DRAFT_3D: 'logomocja:draft:3d',
  MODE: 'logomocja:mode',
  THEME: 'logomocja:theme',
  SOLVED: 'logomocja:challenges:solved',
} as const;

function safeGet(key: string): string | null {
  try {
    return window.localStorage.getItem(key);
  } catch {
    return null;
  }
}

function safeSet(key: string, value: string): void {
  try {
    window.localStorage.setItem(key, value);
  } catch {
    // Ignore storage quota / private mode errors
  }
}

export function loadDraft(mode: Mode): string | null {
  return safeGet(mode === '2d' ? KEYS.DRAFT_2D : KEYS.DRAFT_3D);
}

export function saveDraft(mode: Mode, source: string): void {
  safeSet(mode === '2d' ? KEYS.DRAFT_2D : KEYS.DRAFT_3D, source);
}

export function loadLastMode(): Mode {
  const v = safeGet(KEYS.MODE);
  return v === '3d' ? '3d' : '2d';
}

export function saveLastMode(mode: Mode): void {
  safeSet(KEYS.MODE, mode);
}

export function loadThemePreference(): ThemePreference {
  const v = safeGet(KEYS.THEME);
  if (v === 'light' || v === 'dark' || v === 'system') return v;
  return 'system';
}

export function saveThemePreference(pref: ThemePreference): void {
  safeSet(KEYS.THEME, pref);
}

export function loadSolvedChallenges(): string[] {
  const raw = safeGet(KEYS.SOLVED);
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter((x): x is string => typeof x === 'string') : [];
  } catch {
    return [];
  }
}

export function saveSolvedChallenges(ids: string[]): void {
  safeSet(KEYS.SOLVED, JSON.stringify(ids));
}
