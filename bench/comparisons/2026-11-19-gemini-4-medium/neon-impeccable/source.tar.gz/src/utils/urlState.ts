import { Mode } from '../interpreter';

export type AppRoute = 'pracownia' | 'przyklady' | 'wyzwania' | 'slownik';

export interface ParsedHash {
  route: AppRoute;
  sharedMode?: Mode;
  sharedSource?: string;
}

const VALID_ROUTES = new Set<AppRoute>(['pracownia', 'przyklady', 'wyzwania', 'slownik']);

export function encodeProgramBase64Url(source: string): string {
  const bytes = new TextEncoder().encode(source);
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

export function decodeProgramBase64Url(encoded: string): string | null {
  try {
    let base64 = encoded.replace(/-/g, '+').replace(/_/g, '/');
    while (base64.length % 4 !== 0) {
      base64 += '=';
    }
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return new TextDecoder().decode(bytes);
  } catch {
    return null;
  }
}

export function buildPermalink(source: string, mode: Mode): string {
  const base = window.location.href.split('#')[0];
  const encoded = encodeProgramBase64Url(source);
  return `${base}#pracownia?m=${mode}&p=${encoded}`;
}

export function parseHashUrl(hash: string): ParsedHash {
  const cleaned = hash.replace(/^#\/?/, '');
  if (!cleaned) {
    return { route: 'pracownia' };
  }
  const [rawRoute, rawQuery] = cleaned.split('?');
  const route: AppRoute = VALID_ROUTES.has(rawRoute as AppRoute)
    ? (rawRoute as AppRoute)
    : 'pracownia';

  if (!rawQuery) {
    return { route };
  }

  const params = new URLSearchParams(rawQuery);
  const m = params.get('m');
  const p = params.get('p');

  if ((m === '2d' || m === '3d') && p !== null) {
    const decoded = decodeProgramBase64Url(p);
    if (decoded !== null) {
      return {
        route: 'pracownia',
        sharedMode: m,
        sharedSource: decoded,
      };
    }
  }

  return { route };
}
