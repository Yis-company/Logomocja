import { Segment, Vec3 } from '../interpreter';

export interface CheckResult {
  passed: boolean;
  reason: string;
  coveragePct: number;
  maxDeviation: number;
}

function pointToSegmentDist(p: Vec3, a: Vec3, b: Vec3): number {
  const abx = b[0] - a[0];
  const aby = b[1] - a[1];
  const abz = b[2] - a[2];
  const apx = p[0] - a[0];
  const apy = p[1] - a[1];
  const apz = p[2] - a[2];
  const abLenSq = abx * abx + aby * aby + abz * abz;
  if (abLenSq === 0) {
    return Math.hypot(apx, apy, apz);
  }
  const t = Math.max(0, Math.min(1, (apx * abx + apy * aby + apz * abz) / abLenSq));
  const cx = a[0] + t * abx;
  const cy = a[1] + t * aby;
  const cz = a[2] + t * abz;
  return Math.hypot(p[0] - cx, p[1] - cy, p[2] - cz);
}

function sampleSegments(segments: Segment[], step = 4): Vec3[] {
  const pts: Vec3[] = [];
  for (const s of segments) {
    const len = Math.hypot(
      s.to[0] - s.from[0],
      s.to[1] - s.from[1],
      s.to[2] - s.from[2]
    );
    const count = Math.max(2, Math.min(60, Math.ceil(len / step) + 1));
    for (let i = 0; i < count; i++) {
      const t = i / (count - 1);
      pts.push([
        s.from[0] + (s.to[0] - s.from[0]) * t,
        s.from[1] + (s.to[1] - s.from[1]) * t,
        s.from[2] + (s.to[2] - s.from[2]) * t,
      ]);
    }
  }
  return pts;
}

function maxMinDist(points: Vec3[], targetSegments: Segment[]): { maxDist: number; withinPct: number; tol?: number } {
  let maxDist = 0;
  for (const p of points) {
    let best = Infinity;
    for (const s of targetSegments) {
      const d = pointToSegmentDist(p, s.from, s.to);
      if (d < best) best = d;
      if (best < 0.001) break;
    }
    if (best > maxDist) maxDist = best;
  }
  return { maxDist, withinPct: 100 };
}

function coverageWithin(points: Vec3[], targetSegments: Segment[], tolerance: number): { maxDist: number; withinPct: number } {
  if (points.length === 0) return { maxDist: 0, withinPct: 0 };
  let maxDist = 0;
  let inside = 0;
  for (const p of points) {
    let best = Infinity;
    for (const s of targetSegments) {
      const d = pointToSegmentDist(p, s.from, s.to);
      if (d < best) best = d;
      if (best < 0.01) break;
    }
    if (best > maxDist) maxDist = best;
    if (best <= tolerance) inside++;
  }
  return {
    maxDist,
    withinPct: Math.round((inside / points.length) * 100),
  };
}

export function checkDrawingAgainstTarget(
  actual: Segment[],
  expected: Segment[],
  tolerance = 2.5
): CheckResult {
  if (actual.length === 0) {
    return {
      passed: false,
      reason: 'Program nie narysował żadnych odcinków. Upewnij się, że pisak jest opuszczony („opu”) i używasz „np” lub „ws”.',
      coveragePct: 0,
      maxDeviation: Infinity,
    };
  }

  const expectedPts = sampleSegments(expected, 4);
  const actualPts = sampleSegments(actual, 4);

  const forward = coverageWithin(expectedPts, actual, tolerance);
  const backward = coverageWithin(actualPts, expected, tolerance);
  const maxDeviation = Math.max(forward.maxDist, backward.maxDist);
  const coveragePct = Math.min(forward.withinPct, backward.withinPct);

  if (forward.maxDist <= tolerance && backward.maxDist <= tolerance) {
    return {
      passed: true,
      reason: `Zaliczone! Rysunek pokrywa się ze wzorcem (maksymalne odchylenie ${maxDeviation.toFixed(1)} jedn., tolerancja ${tolerance} jedn.).`,
      coveragePct: 100,
      maxDeviation,
    };
  }

  if (forward.withinPct < 95 && backward.withinPct >= 95) {
    return {
      passed: false,
      reason: `Rysunek jest niepełny — pokrywa ${forward.withinPct}% wzorca. Brakuje części odcinków.`,
      coveragePct,
      maxDeviation,
    };
  }

  if (backward.withinPct < 95 && forward.withinPct >= 95) {
    return {
      passed: false,
      reason: `Rysunek zawiera nadmiarowe odcinki poza wzorcem (${100 - backward.withinPct}% linii wystaje poza kształt docelowy).`,
      coveragePct,
      maxDeviation,
    };
  }

  // Silence unused helper warning
  void maxMinDist;

  return {
    passed: false,
    reason: `Kształt lub położenie różni się od wzorca (pokrycie ${coveragePct}%, maks. odchylenie ${maxDeviation.toFixed(1)} jedn., wymagane ≤ ${tolerance} jedn.).`,
    coveragePct,
    maxDeviation,
  };
}
