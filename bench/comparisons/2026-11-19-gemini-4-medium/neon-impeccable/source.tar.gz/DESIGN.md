---
name: Logomocja
description: Polska pracownia żółwia 2D i 3D inspirowana szkolną pracownią kreślarską i tablicą.
colors:
  shell-pine: "#142b24"
  shell-text: "#eff5f2"
  shell-amber: "#e5a93c"
  primary-pine: "#16866a"
  primary-pine-hover: "#116d56"
  primary-emerald-dark: "#28b08d"
  secondary-ochre: "#b8682f"
  danger-crimson: "#b83232"
  success-forest: "#157a54"
  light-ground: "#f5f4ee"
  light-panel: "#eaece6"
  light-surface: "#ffffff"
  light-ink: "#14221d"
  light-ink-secondary: "#43564f"
  light-border: "#d3d9d2"
  dark-ground: "#101d19"
  dark-panel: "#162621"
  dark-canvas: "#0c1613"
  dark-ink: "#e9f0ec"
  dark-border: "#243b33"
typography:
  headline:
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Noto Sans', 'Liberation Sans', sans-serif"
    fontSize: "22px"
    fontWeight: 700
    lineHeight: 1.25
    letterSpacing: "-0.02em"
  title:
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Noto Sans', 'Liberation Sans', sans-serif"
    fontSize: "15px"
    fontWeight: 650
    lineHeight: 1.35
    letterSpacing: "-0.015em"
  body:
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Noto Sans', 'Liberation Sans', sans-serif"
    fontSize: "14px"
    fontWeight: 400
    lineHeight: 1.5
  label:
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Noto Sans', 'Liberation Sans', sans-serif"
    fontSize: "12.5px"
    fontWeight: 600
    lineHeight: 1.3
  code:
    fontFamily: "'JetBrains Mono', 'SFMono-Regular', ui-monospace, 'Cascadia Code', Menlo, Consolas, monospace"
    fontSize: "13.5px"
    fontWeight: 400
    lineHeight: 1.6
rounded:
  sm: "4px"
  md: "6px"
  lg: "10px"
spacing:
  xs: "4px"
  sm: "8px"
  md: "12px"
  lg: "18px"
  xl: "24px"
components:
  button-primary:
    backgroundColor: "{colors.primary-pine}"
    textColor: "{colors.light-surface}"
    rounded: "{rounded.md}"
    padding: "0 11px"
    height: "32px"
  button-primary-hover:
    backgroundColor: "{colors.primary-pine-hover}"
  button-secondary:
    backgroundColor: "{colors.light-surface}"
    textColor: "{colors.light-ink}"
    rounded: "{rounded.md}"
    padding: "0 11px"
    height: "32px"
  topbar:
    backgroundColor: "{colors.shell-pine}"
    textColor: "{colors.shell-text}"
    height: "50px"
    padding: "0 14px"
  telemetry-strip:
    backgroundColor: "{colors.light-panel}"
    textColor: "{colors.light-ink-secondary}"
    padding: "7px 14px"
---

# Design System: Logomocja

## Overview

**Creative North Star: "Szkolna Pracownia Kreślarska"**

Logomocja pairs the quiet authority of a Polish classroom chalkboard and drafting studio with modern web tooling. Rather than mimicking a neon dark IDE or a pastel children's toy, the interface anchors every view beneath a committed matte pine-slate top bar (`#142b24`) while switching the workspace below between daylight drafting paper (`#f5f4ee` ground, `#ffffff` canvas) and true slate-green chalkboard dark mode (`#101d19` ground, `#0c1613` canvas).

Because this is an Operate surface, standard web controls, crisp 1px structural dividers, and predictable navigation take priority over ornament. The visual world shows up through its committed pine-and-ochre palette, disciplined spacing, tabular numeric precision, and one signature move: the docked live Turtle Telemetry Strip at the base of the drawing viewport.

**Key Characteristics:**
- Committed pine-slate top shell (`#142b24`) with warm amber (`#e5a93c`) active navigation underline across both themes.
- Dual-theme workspace derived from one mineral-green hue family: daylight paper in light mode, matte chalkboard in dark mode.
- Pine-emerald primary accent (`#16866a` light / `#28b08d` dark) echoing the Logo dialect's default turtle pen color.
- Tabular monospace strictly reserved for Logo source code, line numbers, diagnostics, and live turtle telemetry.

## Colors

A restrained, mineral-green neutral system anchored by a committed dark pine-slate top shell, pine-emerald primary actions, warm ochre secondary indicators, and crimson diagnostics.

### Primary
- **Chalkboard Pine Shell** (`#142b24`): Committed 50px top navigation bar carrying brand, mode switch, primary tabs, and file/theme utilities.
- **Turtle Pine** (`#16866a` light / `#28b08d` dark): Primary CTA buttons (`Uruchom`, `Sprawdź`), active 2D/3D mode segment, active filter chips, and keyboard focus rings.
- **Deep Pine Hover** (`#116d56`): Hover state for primary buttons in light mode.

### Secondary
- **Drafting Ochre** (`#b8682f` light / `#e09854` dark): 3D mode tags, paused execution status dot, challenge banner tint, and syntax keywords.
- **Shell Amber** (`#e5a93c`): Active page indicator underline inside the dark top bar.

### Neutral
- **Drafting Paper Ground** (`#f5f4ee` light / `#101d19` dark): Application background and page scroll canvas.
- **Sage Panel** (`#eaece6` light / `#162621` dark): Toolbars, editor gutter, telemetry strip, and table headers.
- **Clean Sheet** (`#ffffff` light / `#0c1613` dark): Drawing canvas and editor writing surface.
- **Pine Ink** (`#14221d` light / `#e9f0ec` dark): Primary body copy and code identifiers.
- **Mineral Hairline** (`#d3d9d2` light / `#243b33` dark): 1px structural borders separating panes, cards, and table rows.

### Semantic
- **Diagnostic Crimson** (`#b83232` light / `#f07171` dark): Inline error squiggle, error line tint, and diagnostic bar.
- **Pass Forest** (`#157a54` light / `#3bc48d` dark): Challenge completion status and verified check banners.

### Named Rules
**The Committed Shell Rule.** The top bar stays matte pine-slate (`#142b24` light, `#0f211b` dark) in both themes so navigation and mode switching remain immediately anchored regardless of workspace theme.

**The Single-Hue Neutral Rule.** Every neutral surface, panel, and border is tinted subtly toward green-slate; pure neutral grays are avoided.

## Typography

**Body & UI Font:** System UI sans stack (`-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Noto Sans", "Liberation Sans", sans-serif`) for full Polish diacritic fidelity (`ą ć ę ł ń ó ś ź ż`) with zero runtime network requests.
**Code & Telemetry Font:** Monospace stack (`"JetBrains Mono", "SFMono-Regular", ui-monospace, "Cascadia Code", Menlo, Consolas, monospace`).

**Character:** Compact, legible workhorse UI typography on a fixed pixel/rem scale (1.15–1.2 ratio), keeping prose under 68ch in reference and challenge descriptions while preserving crisp density in toolbars and code.

### Hierarchy
- **Headline** (700, `22px`, line-height `1.25`, tracking `-0.02em`): Top-of-page titles (`Programy przykładowe`, `Wyzwania rysunkowe`, `Słownik języka Logomocja`).
- **Title** (650, `15px–18px`, line-height `1.35`): Example card titles, challenge headings, and reference section headers.
- **Body** (400, `14px`, line-height `1.5`): Descriptions, diagnostic messages, and reference prose (max-width `68ch`).
- **Label** (600, `12px–13px`, line-height `1.3`): Buttons, nav tabs, mode tags, and telemetry keys.
- **Code** (400, `13.5px`, line-height `21.6px` / `1.6`): Logo editor overlay, line numbers, and reference snippets.

### Named Rules
**The Earned Monospace Rule.** Monospace is used exclusively for Logo code, line/column positions, shortcut keys (`<kbd>`), and tabular numeric telemetry—never as decorative styling for headings or UI labels.

## Layout

- **Desktop Studio (`> 960px`)**: Full-viewport (`100dvh`) shell with a 50px top bar and a 2-column split workspace (`minmax(340px, 42%)` editor panel on the left, `1fr` interactive 2D/3D canvas + bottom telemetry strip on the right).
- **Tablet & Phone (`<= 960px`)**: Top bar wraps navigation cleanly to a scrollable second row; Studio switches to a tabbed `Kod` / `Rysunek` single-pane view so both editor and canvas keep full viewport height.
- **Secondary Views (`Przykłady`, `Wyzwania`, `Słownik`)**: Centered `1120px` max-width scrolling container with `24px 28px` desktop padding (`16px 14px` on mobile).

## Elevation & Depth

Surfaces are flat by default and rely on tonal layering (ground → panel → surface) and 1px hairline borders rather than drop shadows. Only modal dialogs and transient toast banners carry a soft offset shadow (`0 8px 24px rgba(14, 29, 24, 0.14)` in light mode, `0 10px 28px rgba(0, 0, 0, 0.45)` in dark mode).

### Named Rules
**The Hairline-First Rule.** Declare separation once with a 1px border or tonal surface shift; never combine a 1px card border with a wide ambient shadow.

## Shapes

Restrained technical geometry: `4px` (`--radius-sm`) for inline tags, segmented inner buttons, and `<kbd>` chips; `6px` (`--radius-md`) for buttons, inputs, and overlay toolbars; `10px` (`--radius-lg`) for example cards, challenge panels, reference tables, and native dialogs.

## Components

### Buttons
- **Shape:** Subtle rounded rectangle (`6px` radius), `32px` standard height (`28px` compact).
- **Primary:** Turtle Pine fill (`#16866a` / `#28b08d`), crisp white/dark-ink label, `0 11px` padding.
- **Secondary & Ghost:** Surface fill with 1px subtle border (`--border-subtle`), transitioning to tinted hover (`140ms ease`).
- **Focus:** High-visibility `2px solid var(--accent)` outline with `2px` offset (`--shell-accent` inside the dark top bar).

### Navigation & Mode Switch
- Committed pine-slate top bar with a dark recessed 2D/3D segmented toggle (`aria-pressed`), horizontal page tabs with a 2px amber bottom bar on `aria-current="page"`, and compact icon buttons for PNG/Logo/Theme actions.

### Code Editor
- Synchronized line-number gutter (`46px` wide, tabular numerals), syntax-highlighted overlay (commands, keywords, numbers, hex strings, comments, brackets), active-line execution tint, inline wavy crimson error underline at exact line/column, and a docked Polish diagnostic bar.

### Live Turtle Telemetry Strip (Signature Component)
- Docked to the bottom edge of the 2D/3D viewport in `--bg-panel` with a 1px top hairline. Displays tabular `(X, Y)` / `(X, Y, Z)` coordinates, heading angle `°`, 3D pitch angle `°`, live pen color swatch & stroke width, active line number, executed step count, and kept segment count.

## Do's and Don'ts

### Do:
- **Do** keep Polish diacritics, 1-based `W:K` error locations, and tabular numerals (`font-variant-numeric: tabular-nums`) consistent across editor, diagnostics, and telemetry.
- **Do** theme browser surfaces (`::selection`, `caret-color`, `:focus-visible`, scrollbars) from the active light/dark token set.
- **Do** use native `<dialog>` for destructive-action confirmations (such as overwriting an unsaved draft).

### Don't:
- **Don't** add eyebrows/kickers above headings, gradient text, hard offset shadows, or emoji/unicode glyphs in place of 1.75px stroke SVG icons.
- **Don't** introduce external runtime font or CDN requests; keep the entire bundle self-contained for offline static hosting.
- **Don't** use colored left-border stripes (>1px) on diagnostic bars, cards, or hints.
