# Product

<!-- impeccable:product-schema 1 -->

## Platform

web

## Stack

delegated: Vite + React 19 + TypeScript + Three.js (for 3D WebGL view) + bespoke semantic CSS with custom properties + Bun test runner. Chosen for fast, zero-backend static builds (`dist/`), clean `BASE_PATH` support via Vite `base`, hash-based routing that works without server rewrites, strong type safety for the Logo interpreter, and reliable WebGL 3D orbit/pan/zoom with graceful fallback when WebGL is unavailable.

## Users

- Primary users (inferred from brief): Polish learners, students, educators, and nostalgic former users of classic Polish Logo ("Logomocja") who want to write, step through, and explore turtle graphics in both 2D and 3D directly in a modern browser on desktop or mobile.
- Job: Open the studio, understand what the dialect can do, run built-in examples, write and debug their own 2D or 3D Logo programs, solve guided drawing challenges with automatic verification, and share or export their creations.

## Product Purpose

Logomocja is a Polish-language web studio for turtle drawing inspired by the classic Polish Logo environment, uniting flat 2D plane drawing and true 3D spatial drawing in a single offline-capable static web app. Success means a learner can immediately run an example, step through execution line-by-line, catch and fix syntax/runtime errors from clear Polish line/column diagnostics, solve challenges with automatic checking, and share programs via permalinks or `.logo` / PNG files without accounts or a backend.

## Positioning

A faithful, complete Polish-dialect Logo interpreter with unified 2D/3D right-handed turtle geometry—where flat programs produce identical coordinates in both modes—paired with step-by-step execution, interactive 3D spatial inspection, automatic geometric challenge verification, and zero-runtime-network portability.

## Operating Context

- Desktop and phone-sized viewports; light and dark themes following system preference with a manual toggle.
- Purely client-side execution: no accounts, no backend, no runtime network requests.
- Drafts per mode (2D / 3D) and challenge completion progress persist in `localStorage`.
- Programs can be shared via URL permalink (which loads and runs the program on open), exported as PNG, and saved/opened as `.logo` text files.
- Keyboard-driven execution workflow (shortcuts for run, step, pause, reset) alongside touch/pointer canvas manipulation (pan, zoom, fit in 2D; orbit, pan, zoom, reset in 3D).

## Capabilities and Constraints

- Interface language: Polish throughout, including all UI controls, command reference, challenges, and error messages with 1-based line and column positions.
- Fixed Logo dialect: case-insensitive keywords/identifiers with accented and unaccented Polish and English aliases, strict whitespace rule for binary arithmetic operators, exact floating-point comparisons, `powtorz`/`nrpowt`, `niech` scoping, `jeśli`/`jeżeli`, `oto ... ma: ... już` (and legacy `:param`) procedures with recursion and `stop`, and 3D orientation commands (`gora`, `dol`, `pp`, `pl`) restricted to 3D mode.
- Fixed interpreter limits: 50,000 chars, 10,000 tokens, 32 bracket depth, 32 active procedure/repeat frames, 10,000 executed operations, 10,000 kept segments, ±100,000 coordinate bounds.
- Parse-time errors draw nothing; run-time errors preserve segments drawn after the last `czyść`.
- 13 standard built-in programs shipped verbatim (7 in 2D, 6 in 3D); loading an example must not silently destroy an unsaved draft.
- At least 5 practice challenges with visual targets, automatic verification with tolerance, pass/fail reason in Polish, and persisted progress.
- Graceful WebGL fallback: if WebGL is unavailable, 2D mode continues working and the app clearly explains why 3D is off.
- Delivery contract: `bun install`, `bun run build` -> self-contained static `dist/` honoring `BASE_PATH` (default `/`), `bun run test` passing interpreter tests, and `window.logomocja` testing hook (`version`, `run(source, mode)`, `open(source, mode)`).

## Brand Commitments

- Name: **Logomocja**
- Polish-language studio inspired by the classic Polish Logo environment; nostalgic spirit that feels crisp and comfortable to use today.
- Default turtle pen color in the language specification: `#16866a`.

## Evidence on Hand

- Full language specification, 13 verbatim standard programs, and feature/delivery requirements provided in the product brief.
- No external backend, testimonials, or third-party runtime assets exist; all shipping assets (fonts, icons, examples, challenges, reference content) must be local.

## Product Principles

1. **Immediate legibility of code and geometry**: The editor and drawing canvas work as one coupled instrument—stepping highlights the active line, errors pinpoint exact line and column, and turtle orientation is always visible.
2. **Exact dialect fidelity**: Every command, precedence rule, whitespace rule, scoping rule, and limit matches the specification without silent approximations.
3. **Safe exploration**: Drafts persist per mode, loading examples protects unsaved work, and parse/runtime errors communicate clearly in Polish with recovery guidance.
4. **Equal dignity for 2D and 3D**: Flat commands produce identical geometry in both modes; switching modes is effortless and 3D degrades gracefully if WebGL is absent.
5. **Self-contained and portable**: Works offline from any static `BASE_PATH`, on desktop or phone, with keyboard accessibility throughout.

## Accessibility & Inclusion

- Responsive across phone-sized and desktop viewports.
- Light and dark themes following `prefers-color-scheme` with a manual toggle.
- Every control is keyboard-operable, properly labelled in Polish, and displays visible focus indicators.
