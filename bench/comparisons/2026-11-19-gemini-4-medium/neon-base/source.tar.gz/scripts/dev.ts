import { join } from 'node:path';
import { buildSite } from './build';

const port = Number(process.env.PORT || 4173);
await buildSite('/');

const distDir = join(process.cwd(), 'dist');

const server = Bun.serve({
  port,
  async fetch(req) {
    const url = new URL(req.url);
    let pathname = url.pathname;
    if (pathname === '/' || pathname === '') {
      pathname = '/index.html';
    }
    const file = Bun.file(join(distDir, pathname));
    if (await file.exists()) {
      return new Response(file);
    }
    return new Response(Bun.file(join(distDir, 'index.html')));
  },
});

console.log(`Logomocja dev server listening on http://localhost:${server.port}`);
