import { mkdir, rm, readFile, writeFile, copyFile } from 'node:fs/promises';
import { join } from 'node:path';

function normalizeBasePath(raw?: string): string {
  if (!raw || raw.trim() === '') return '/';
  let p = raw.trim();
  if (!p.startsWith('/')) p = '/' + p;
  if (!p.endsWith('/')) p = p + '/';
  return p;
}

export async function buildSite(basePathEnv = process.env.BASE_PATH): Promise<void> {
  const basePath = normalizeBasePath(basePathEnv);
  const rootDir = process.cwd();
  const distDir = join(rootDir, 'dist');
  const assetsDir = join(distDir, 'assets');

  await rm(distDir, { recursive: true, force: true });
  await mkdir(assetsDir, { recursive: true });

  const result = await Bun.build({
    entrypoints: [join(rootDir, 'src/main.ts')],
    outdir: assetsDir,
    naming: 'app.js',
    target: 'browser',
    format: 'esm',
    minify: true,
    sourcemap: 'none',
  });

  if (!result.success) {
    for (const log of result.logs) {
      console.error(log);
    }
    process.exit(1);
  }

  await copyFile(join(rootDir, 'src/styles.css'), join(assetsDir, 'styles.css'));

  const htmlTemplate = await readFile(join(rootDir, 'src/index.html'), 'utf8');
  const html = htmlTemplate.replaceAll('__BASE_PATH__', basePath);
  await writeFile(join(distDir, 'index.html'), html, 'utf8');

  console.log(`Built Logomocja into dist/ (BASE_PATH=${basePath})`);
}

if (import.meta.main) {
  await buildSite();
}
