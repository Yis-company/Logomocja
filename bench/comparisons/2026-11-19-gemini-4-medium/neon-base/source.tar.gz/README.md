# Logomocja

Polskojęzyczna pracownia rysowania żółwiem w przeglądarce — z trybem płaskim **2D** oraz przestrzennym **3D** (WebGL), inspirowana klasycznym środowiskiem Logomocja. Działa całkowicie lokalnie jako statyczna strona bez backendu i bez żądań sieciowych w czasie działania.

## Funkcje

- **Pracownia 2D i 3D** — edytor z numeracją wierszy, podświetlaniem składni dialektu, podświetlaniem aktualnie wykonywanego wiersza oraz znacznikiem błędu dokładnie w wierszu i kolumnie.
- **Wykonywanie i sterowanie** — uruchomienie całego programu, wykonywanie krok po kroku, pauza/wznowienie, reset oraz suwak prędkości animacji.
- **Widok 2D i 3D** — przesuwanie, przybliżanie, dopasowanie do rysunku, reset kamery, siatka i osie, a w razie braku WebGL czytelny komunikat w 3D przy pełnym działaniu 2D.
- **13 standardowych przykładów** — wbudowane wzory 2D i 3D z ochroną przed przypadkowym nadpisaniem niezapisanego szkicu.
- **6 zadań praktycznych** — automatyczne sprawdzanie geometrii rysunku z opisem powodu zaliczenia lub błędu oraz lokalnym zapisem postępów.
- **Podręcznik języka** — pełna dokumentacja poleceń po polsku z przykładami, wyrażeniami, zmiennymi, warunkami, procedurami i limitami.
- **Udostępnianie i pliki** — link stały (permalink) w adresie URL, eksport obrazu PNG, otwieranie i zapisywanie plików `.logo`.
- **Dostępność i motywy** — układ responsywny (desktop i telefon), jasny/ciemny motyw zgodny z systemem z ręcznym przełącznikiem oraz obsługa z klawiatury.

## Wymagania

- [Bun](https://bun.sh/) (v1.0+)

## Uruchomienie, budowanie i testy

```bash
# Instalacja (brak zewnętrznych zależności)
bun install

# Uruchomienie testów interpretera i sprawdzarki zadań
bun run test

# Zbudowanie statycznej strony do katalogu dist/
bun run build

# Budowanie pod podścieżką (BASE_PATH)
BASE_PATH=/Logomocja/builds/x/ bun run build

# Lokalny podgląd zbudowanej strony
bun run dev
```

## Interfejs testowy (`window.logomocja`)

Po załadowaniu strony obiekt `window.logomocja` udostępnia:
- `version` — wersja aplikacji,
- `run(source, mode)` — uruchamia kod w trybie `"2d"` lub `"3d"` bez ingerencji w interfejs i zwraca `{ segments, error }`,
- `open(source, mode)` — wczytuje kod do edytora, uruchamia bez animacji, dopasowuje widok i zwraca Promise z `{ segments, error }`.
