import { describe, expect, test } from 'bun:test';
import { runProgram, createVM, LIMITS } from '../src/engine';
import { STANDARD_EXAMPLES } from '../src/data/examples';

function approx(a: number, b: number, eps = 1e-6): boolean {
  return Math.abs(a - b) <= eps;
}

function expectVec3(actual: [number, number, number], expected: [number, number, number], eps = 1e-6) {
  expect(approx(actual[0], expected[0], eps)).toBe(true);
  expect(approx(actual[1], expected[1], eps)).toBe(true);
  expect(approx(actual[2], expected[2], eps)).toBe(true);
}

describe('Standard programs', () => {
  for (const ex of STANDARD_EXAMPLES) {
    test(`standard example "${ex.id}" (${ex.mode}) runs without errors`, () => {
      const res = runProgram(ex.source, ex.mode);
      expect(res.error).toBeNull();
      expect(res.segments.length).toBeGreaterThan(0);
      for (const seg of res.segments) {
        expect(seg.color).toMatch(/^#[0-9a-f]{6}$/);
        expect(seg.width).toBeGreaterThanOrEqual(1);
        expect(seg.width).toBeLessThanOrEqual(12);
      }
    });
  }

  test('flat 2D programs produce identical coordinates in 2D and 3D modes', () => {
    for (const ex of STANDARD_EXAMPLES.filter((e) => e.mode === '2d')) {
      const r2 = runProgram(ex.source, '2d');
      const r3 = runProgram(ex.source, '3d');
      expect(r2.error).toBeNull();
      expect(r3.error).toBeNull();
      expect(r2.segments).toEqual(r3.segments);
    }
  });
});

describe('Lexical rules & expressions', () => {
  test('case insensitivity and Polish/English aliases', () => {
    const r = runProgram(`
      NAPRZÓD 10
      fd 10
      PRAWO 90
      rt 90
      wstecz 5
      bk 5
      LEWO 90
      lt 90
      podnieś
      np 50
      opuść
      KOLOR "#AABBCC"
      GRUBOŚĆ 5
      np 20
    `, '2d');
    expect(r.error).toBeNull();
    expect(r.segments.length).toBe(5);
    expect(r.segments[4].color).toBe('#aabbcc');
    expect(r.segments[4].width).toBe(5);
  });

  test('decimal literals: 80, 12.5, .5 and invalid literals', () => {
    const ok = runProgram('np 80 np 12.5 np .5', '2d');
    expect(ok.error).toBeNull();
    expectVec3(ok.segments[2].to, [0, 93, 0]);

    expect(runProgram('np 1e3', '2d').error).not.toBeNull();
    expect(runProgram('np 0x10', '2d').error).not.toBeNull();
    expect(runProgram('np NaN', '2d').error).not.toBeNull();
    expect(runProgram('np Infinity', '2d').error).not.toBeNull();
    expect(runProgram('np 12.', '2d').error).not.toBeNull();
    expect(runProgram('np 1.2.3', '2d').error).not.toBeNull();
  });

  test('operator precedence and left associativity', () => {
    const r1 = runProgram('np 20 - 5 - 3', '2d');
    expect(r1.error).toBeNull();
    expectVec3(r1.segments[0].to, [0, 12, 0]);

    const r2 = runProgram('np 2 + 3 * 4', '2d');
    expect(r2.error).toBeNull();
    expectVec3(r2.segments[0].to, [0, 14, 0]);
  });

  test('binary operator whitespace rule', () => {
    const a = runProgram('np 10 - 5', '2d');
    expect(a.error).toBeNull();
    expectVec3(a.segments[0].to, [0, 5, 0]);

    const b = runProgram('np 10-5', '2d');
    expect(b.error).toBeNull();
    expectVec3(b.segments[0].to, [0, 5, 0]);

    const bad1 = runProgram('np 10 -5', '2d');
    expect(bad1.error).not.toBeNull();
    expect(bad1.error?.line).toBe(1);
    expect(bad1.error?.column).toBe(7);
    expect(bad1.segments).toEqual([]);

    const bad2 = runProgram('np 10- 5', '2d');
    expect(bad2.error).not.toBeNull();
    expect(bad2.error?.column).toBe(6);

    // Works for two procedure arguments: kwadrat 10 -5 passes 10 and -5
    const procArgs = runProgram(`
      oto f ma: a, b
        np a
        np b
      już
      f 10 -5
    `, '2d');
    expect(procArgs.error).toBeNull();
    expectVec3(procArgs.segments[0].to, [0, 10, 0]);
    expectVec3(procArgs.segments[1].to, [0, 5, 0]);
  });

  test('unary operators stacked and on expressions', () => {
    const r = runProgram('np -(3 - 5) np - -2 np +3', '2d');
    expect(r.error).toBeNull();
    expectVec3(r.segments[0].to, [0, 2, 0]);
    expectVec3(r.segments[1].to, [0, 4, 0]);
    expectVec3(r.segments[2].to, [0, 7, 0]);
  });

  test('exact floating-point comparisons', () => {
    const r = runProgram('jeśli 0.1 + 0.2 = 0.3 [np 50]', '2d');
    expect(r.error).toBeNull();
    expect(r.segments.length).toBe(0);

    const r2 = runProgram('jeśli 1 <> 2 [np 10] jeśli 2 >= 2 [np 10] jeśli 2 <= 2 [np 10]', '2d');
    expect(r2.error).toBeNull();
    expect(r2.segments.length).toBe(3);
  });
});

describe('Turtle & 3D geometry', () => {
  test('zero move draws nothing, dom draws back and resets orientation', () => {
    const r = runProgram('np 0 np 50 pw 90 np 50 dom np 10', '2d');
    expect(r.error).toBeNull();
    expect(r.segments.length).toBe(4);
    expectVec3(r.segments[2].to, [0, 0, 0]);
    expectVec3(r.segments[3].to, [0, 10, 0]);
  });

  test('czyść clears previous segments and resets segment count', () => {
    const r = runProgram('np 50 np 50 czyść np 10', '2d');
    expect(r.error).toBeNull();
    expect(r.segments.length).toBe(1);
    expectVec3(r.segments[0].from, [0, 100, 0]);
    expectVec3(r.segments[0].to, [0, 110, 0]);
  });

  test('3D pitch and roll exact right-handed basis', () => {
    // gora 90: heading becomes +Z (0, 0, 1)
    const r1 = runProgram('gora 90 np 25', '3d');
    expect(r1.error).toBeNull();
    expectVec3(r1.segments[0].to, [0, 0, 25]);

    // pp 90 then gora 90: up becomes +X, then pitching up points heading along +X
    const r2 = runProgram('pp 90 gora 90 np 30', '3d');
    expect(r2.error).toBeNull();
    expectVec3(r2.segments[0].to, [30, 0, 0]);

    // 3D commands in 2D mode are parse-time errors
    const r3 = runProgram('np 10 gora 90', '2d');
    expect(r3.error).not.toBeNull();
    expect(r3.segments).toEqual([]);
  });
});

describe('Repeat, variables & procedures', () => {
  test('nrpowt lexical scoping', () => {
    const ok = runProgram('powtorz 3 [np nrpowt * 10]', '2d');
    expect(ok.error).toBeNull();
    expectVec3(ok.segments[2].to, [0, 60, 0]);

    // Outside repeat at top level -> parse error
    const bad1 = runProgram('np nrpowt', '2d');
    expect(bad1.error).not.toBeNull();

    // Inside procedure called from repeat -> parse error (lexical!)
    const bad2 = runProgram(`
      oto krok
        np nrpowt
      już
      powtorz 3 [krok]
    `, '2d');
    expect(bad2.error).not.toBeNull();
  });

  test('variables: globals, locals, shadowing, forward declaration & unassigned runtime error', () => {
    // Local shadows global and discards on return
    const r1 = runProgram(`
      oto f
        niech x 20
        np x
      już
      niech x 10
      f
      np x
    `, '2d');
    expect(r1.error).toBeNull();
    expectVec3(r1.segments[0].to, [0, 20, 0]);
    expectVec3(r1.segments[1].to, [0, 30, 0]);

    // Declared later at top level, read before assigned -> runtime error at first token of arg
    const r2 = runProgram(`np 10\nnp x + 1\nniech x 5`, '2d');
    expect(r2.error).not.toBeNull();
    expect(r2.error?.line).toBe(2);
    expect(r2.error?.column).toBe(4);
    expect(r2.segments.length).toBe(1); // runtime error keeps what was drawn!
  });

  test('legacy procedure syntax, procedure defined after call, parameter sharing proc name', () => {
    const r = runProgram(`
      krok 25
      oto krok :krok
        np :krok
      end
    `, '2d');
    expect(r.error).toBeNull();
    expect(r.segments.length).toBe(1);
    expectVec3(r.segments[0].to, [0, 25, 0]);
  });

  test('stop inside repeat/if exits enclosing procedure, or program at top level', () => {
    const r1 = runProgram(`
      oto f
        powtorz 5 [
          np 10
          jeśli nrpowt = 2 [stop]
        ]
        np 100
      już
      f
      np 5
    `, '2d');
    expect(r1.error).toBeNull();
    expect(r1.segments.length).toBe(3); // 10, 10, then 5 after f returns

    const r2 = runProgram(`
      powtorz 5 [
        np 10
        jeśli nrpowt = 2 [stop]
      ]
      np 100
    `, '2d');
    expect(r2.error).toBeNull();
    expect(r2.segments.length).toBe(2);
  });
});

describe('Error locations & limits', () => {
  test('parse-time validation of literal width & repeat reports at first token of arg', () => {
    const r1 = runProgram('np 10\ngrubosc 13', '2d');
    expect(r1.error).not.toBeNull();
    expect(r1.error?.line).toBe(2);
    expect(r1.error?.column).toBe(9);
    expect(r1.segments).toEqual([]); // parse-time draws nothing

    const r2 = runProgram('np 10\npowtorz 1.5 [np 10]', '2d');
    expect(r2.error).not.toBeNull();
    expect(r2.error?.line).toBe(2);
    expect(r2.error?.column).toBe(9);
    expect(r2.segments).toEqual([]);
  });

  test('runtime error keeps drawn segments and reports at first token of arg', () => {
    const r = runProgram('np 10\nnp 5 + 1 / 0', '2d');
    expect(r.error).not.toBeNull();
    expect(r.error?.line).toBe(2);
    expect(r.error?.column).toBe(4);
    expect(r.segments.length).toBe(1);
  });

  test('missing argument reports at offending token or command on EOF', () => {
    const r1 = runProgram('powtorz 2 [np]', '2d');
    expect(r1.error).not.toBeNull();
    expect(r1.error?.column).toBe(14); // at ']'

    const r2 = runProgram('np', '2d');
    expect(r2.error).not.toBeNull();
    expect(r2.error?.column).toBe(1); // at 'np'
  });

  test('bracket nesting limit (32)', () => {
    const open = 'powtorz 1 ['.repeat(33);
    const close = ']'.repeat(33);
    const r = runProgram(open + 'np 1' + close, '2d');
    expect(r.error).not.toBeNull();
  });

  test('active frame limit (32) with recursion', () => {
    const r = runProgram(`
      oto rec ma: n
        jeśli n = 0 [stop]
        rec n - 1
      już
      rec 40
    `, '2d');
    expect(r.error).not.toBeNull();
  });

  test('operation limit (10,000)', () => {
    const r = runProgram('powtorz 10000 [np 1 pw 1]', '2d');
    expect(r.error).not.toBeNull();
    expect(r.segments.length).toBeGreaterThan(0);
  });

  test('coordinate limit (±100,000)', () => {
    const r = runProgram('np 100001', '2d');
    expect(r.error).not.toBeNull();
    expect(r.segments).toEqual([]);
  });

  test('source length limit (50,000 chars)', () => {
    const big = ';'.repeat(LIMITS.MAX_CHARS + 1);
    const r = runProgram(big, '2d');
    expect(r.error).not.toBeNull();
  });

  test('VM step-by-step produces identical result to runProgram', () => {
    const ex = STANDARD_EXAMPLES.find((e) => e.id === 'spirala')!;
    const direct = runProgram(ex.source, ex.mode);
    const { vm, error } = createVM(ex.source, ex.mode);
    expect(error).toBeNull();
    expect(vm).not.toBeNull();
    let steps = 0;
    while (!vm!.done) {
      vm!.step();
      steps += 1;
    }
    expect(steps).toBeGreaterThan(100);
    expect(vm!.error).toBeNull();
    expect(vm!.segments).toEqual(direct.segments);
  });

  test('token limit (10,000), dynamic width/repeat runtime errors, and deferred div-by-zero', () => {
    const tooManyTokens = 'np 1 '.repeat(5001); // 10,002 tokens
    expect(runProgram(tooManyTokens, '2d').error).not.toBeNull();

    // Dynamic width checked at runtime, keeping prior segments
    const dynW = runProgram('np 10\nniech w 15\ngrubosc w', '2d');
    expect(dynW.error).not.toBeNull();
    expect(dynW.error?.line).toBe(3);
    expect(dynW.error?.column).toBe(9);
    expect(dynW.segments.length).toBe(1);

    // Literal div-by-zero in width is a runtime error, keeping prior segments
    const divW = runProgram('np 10\ngrubosc 1 / 0', '2d');
    expect(divW.error).not.toBeNull();
    expect(divW.error?.line).toBe(2);
    expect(divW.error?.column).toBe(9);
    expect(divW.segments.length).toBe(1);

    // powtorz 0 still validates body at parse time
    expect(runProgram('powtorz 0 [nieznane]', '2d').error).not.toBeNull();
    expect(runProgram('powtorz 0 [gora 90]', '2d').error).not.toBeNull();

    // Procedure definition inside repeat body is a parse error
    expect(runProgram('powtorz 2 [\noto f\nnp 10\njuż\n]', '2d').error).not.toBeNull();

    // Exact op counting
    const { vm: vm1 } = createVM('powtorz 3 [np 10]', '2d');
    vm1!.runToEnd();
    expect(vm1!.ops).toBe(7); // 1 repeat + 3*(1 np + 1 end-iter)
  });
});
