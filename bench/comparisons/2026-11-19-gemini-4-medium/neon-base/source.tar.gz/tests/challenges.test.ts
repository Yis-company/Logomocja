import { describe, expect, test } from 'bun:test';
import { CHALLENGES, checkChallenge } from '../src/data/challenges';

describe('Challenges checker', () => {
  for (const ch of CHALLENGES) {
    test(`reference solution passes "${ch.id}"`, () => {
      const res = checkChallenge(ch, ch.referenceSolution);
      expect(res.passed).toBe(true);
      expect(res.error).toBeNull();
    });
  }

  test('left-turning square passes mirrored check', () => {
    const sq = CHALLENGES.find((c) => c.id === 'kwadrat-100')!;
    const res = checkChallenge(sq, 'powtorz 4 [np 100 lw 90]');
    expect(res.passed).toBe(true);
  });

  test('incomplete square fails with missing-part reason', () => {
    const sq = CHALLENGES.find((c) => c.id === 'kwadrat-100')!;
    const res = checkChallenge(sq, 'powtorz 3 [np 100 pw 90]');
    expect(res.passed).toBe(false);
    expect(res.reason).toContain('Brakuje');
  });

  test('connecting line in two-squares fails with extra-line reason', () => {
    const two = CHALLENGES.find((c) => c.id === 'dwa-kwadraty')!;
    const res = checkChallenge(
      two,
      'powtorz 4 [np 60 pw 90] pw 90 np 100 lw 90 powtorz 4 [np 60 pw 90]'
    );
    expect(res.passed).toBe(false);
    expect(res.reason).toContain('dodatkowe linie');
  });

  test('empty drawing fails', () => {
    const sq = CHALLENGES.find((c) => c.id === 'kwadrat-100')!;
    const res = checkChallenge(sq, '; pusto');
    expect(res.passed).toBe(false);
    expect(res.reason).toContain('pusty');
  });
});
