import { lex } from './lexer';
import {
  BinaryOp,
  COMMAND_ALIASES,
  CompOp,
  Condition,
  Expr,
  isReservedWord,
  LIMITS,
  LogoError,
  Mode,
  PROC_END_KEYWORDS,
  PROC_START_KEYWORDS,
  ProcedureDef,
  ProgramAST,
  REPCOUNT_KEYWORDS,
  Stmt,
  Token,
} from './types';

export interface ParseResult {
  ast: ProgramAST | null;
  error: LogoError | null;
}

class ParseException extends Error {
  constructor(public readonly logoError: LogoError) {
    super(logoError.message);
  }
}

function fail(message: string, line: number, column: number): never {
  throw new ParseException({ message, line, column });
}

interface RawProcedure {
  name: string;
  rawName: string;
  params: string[];
  bodyTokens: Token[];
  line: number;
  column: number;
  endLine: number;
  endColumn: number;
}

function splitTopLevelAndProcedures(tokens: Token[]): {
  topTokens: Token[];
  rawProcs: Map<string, RawProcedure>;
} {
  const topTokens: Token[] = [];
  const rawProcs = new Map<string, RawProcedure>();
  const len = tokens.length - 1; // exclude trailing eof
  const eofTok = tokens[len];
  let i = 0;
  let bracketDepth = 0;

  while (i < len) {
    const tok = tokens[i];

    if (tok.kind === 'lbracket') {
      bracketDepth += 1;
      topTokens.push(tok);
      i += 1;
      continue;
    }
    if (tok.kind === 'rbracket') {
      if (bracketDepth > 0) bracketDepth -= 1;
      topTokens.push(tok);
      i += 1;
      continue;
    }

    if (tok.kind === 'ident' && PROC_END_KEYWORDS.has(tok.lower)) {
      fail(`Nieoczekiwane „${tok.value}” poza definicją procedury.`, tok.line, tok.column);
    }

    if (tok.kind === 'ident' && PROC_START_KEYWORDS.has(tok.lower)) {
      if (bracketDepth > 0) {
        fail('Definicja procedury nie może znajdować się wewnątrz nawiasów [ ].', tok.line, tok.column);
      }
      if (!tok.atLineStart) {
        fail(`Definicja procedury „${tok.value}” musi zaczynać się na początku wiersza.`, tok.line, tok.column);
      }

      const headerLine = tok.line;
      i += 1;

      if (i >= len || tokens[i].line !== headerLine) {
        fail('Brak nazwy procedury po „oto”.', tok.line, tok.column);
      }

      const nameTok = tokens[i];
      if (nameTok.kind !== 'ident') {
        fail(`Nieprawidłowa nazwa procedury „${nameTok.value}”.`, nameTok.line, nameTok.column);
      }
      if (isReservedWord(nameTok.lower)) {
        fail(`Nazwa „${nameTok.value}” jest zarezerwowanym słowem kluczowym.`, nameTok.line, nameTok.column);
      }
      if (rawProcs.has(nameTok.lower)) {
        fail(`Procedura „${nameTok.value}” została już zdefiniowana.`, nameTok.line, nameTok.column);
      }
      i += 1;

      const params: string[] = [];
      const paramSet = new Set<string>();

      if (i < len && tokens[i].line === headerLine) {
        if (tokens[i].kind === 'ma_colon') {
          const maTok = tokens[i];
          i += 1;
          if (i >= len || tokens[i].line !== headerLine) {
            fail('Oczekiwano nazwy parametru po „ma:”.', maTok.line, maTok.column);
          }
          while (true) {
            const pTok = tokens[i];
            if (!pTok || pTok.line !== headerLine) {
              fail('Oczekiwano nazwy parametru po przecinku.', maTok.line, maTok.column);
            }
            if (pTok.kind !== 'ident') {
              fail(`Nieprawidłowa nazwa parametru „${pTok.value}”.`, pTok.line, pTok.column);
            }
            if (isReservedWord(pTok.lower)) {
              fail(`Parametr nie może mieć nazwy słowa kluczowego „${pTok.value}”.`, pTok.line, pTok.column);
            }
            if (paramSet.has(pTok.lower)) {
              fail(`Powtórzona nazwa parametru „${pTok.value}”.`, pTok.line, pTok.column);
            }
            paramSet.add(pTok.lower);
            params.push(pTok.lower);
            i += 1;

            if (i < len && tokens[i].line === headerLine) {
              if (tokens[i].kind === 'comma') {
                const commaTok = tokens[i];
                i += 1;
                if (i >= len || tokens[i].line !== headerLine) {
                  fail('Oczekiwano nazwy parametru po przecinku.', commaTok.line, commaTok.column);
                }
                continue;
              }
              fail(`Oczekiwano przecinka między parametrami, znaleziono „${tokens[i].value}”.`, tokens[i].line, tokens[i].column);
            }
            break;
          }
        } else if (tokens[i].kind === 'colon_ident') {
          while (i < len && tokens[i].line === headerLine) {
            const pTok = tokens[i];
            if (pTok.kind !== 'colon_ident') {
              fail(`Oczekiwano parametru w postaci „:nazwa”, znaleziono „${pTok.value}”.`, pTok.line, pTok.column);
            }
            if (isReservedWord(pTok.lower)) {
              fail(`Parametr nie może mieć nazwy słowa kluczowego „${pTok.value}”.`, pTok.line, pTok.column);
            }
            if (paramSet.has(pTok.lower)) {
              fail(`Powtórzona nazwa parametru „${pTok.value}”.`, pTok.line, pTok.column);
            }
            paramSet.add(pTok.lower);
            params.push(pTok.lower);
            i += 1;
          }
        } else {
          fail(`Nieoczekiwany token „${tokens[i].value}” w nagłówku procedury.`, tokens[i].line, tokens[i].column);
        }
      }

      // Collect body until `już` / `juz` / `end` alone on its own line
      const bodyTokens: Token[] = [];
      let foundEnd = false;
      let endLine = tok.line;
      let endColumn = tok.column;

      while (i < len) {
        const bTok = tokens[i];
        if (bTok.kind === 'ident' && PROC_START_KEYWORDS.has(bTok.lower)) {
          fail('Nie można definiować procedury wewnątrz innej procedury.', bTok.line, bTok.column);
        }
        if (bTok.kind === 'ident' && PROC_END_KEYWORDS.has(bTok.lower)) {
          if (!bTok.atLineStart) {
            fail(`Słowo „${bTok.value}” musi stać samo w osobnym wierszu.`, bTok.line, bTok.column);
          }
          if (i + 1 < len && tokens[i + 1].line === bTok.line) {
            fail(`Słowo „${bTok.value}” musi stać samo w osobnym wierszu.`, tokens[i + 1].line, tokens[i + 1].column);
          }
          endLine = bTok.line;
          endColumn = bTok.column;
          foundEnd = true;
          i += 1;
          break;
        }
        bodyTokens.push(bTok);
        i += 1;
      }

      if (!foundEnd) {
        fail(`Brak „już” kończącego definicję procedury „${nameTok.value}”.`, tok.line, tok.column);
      }

      bodyTokens.push({
        kind: 'eof',
        value: '',
        lower: '',
        line: endLine,
        column: endColumn,
        spaceBefore: true,
        spaceAfter: true,
        atLineStart: true,
      });

      rawProcs.set(nameTok.lower, {
        name: nameTok.lower,
        rawName: nameTok.value,
        params,
        bodyTokens,
        line: tok.line,
        column: tok.column,
        endLine,
        endColumn,
      });
      continue;
    }

    topTokens.push(tok);
    i += 1;
  }

  topTokens.push(eofTok);
  return { topTokens, rawProcs };
}

class TokenStreamParser {
  private pos = 0;

  constructor(
    private readonly tokens: Token[],
    private readonly procSignatures: Map<string, RawProcedure>,
    private readonly declaredVars: Set<string>,
    private readonly currentProcParams: Set<string> | null
  ) {}

  private peek(): Token {
    return this.tokens[this.pos];
  }

  private advance(): Token {
    const tok = this.tokens[this.pos];
    if (tok.kind !== 'eof') {
      this.pos += 1;
    }
    return tok;
  }

  public parseBlock(stopOnRBracket: boolean, bracketDepth: number): Stmt[] {
    const stmts: Stmt[] = [];
    while (true) {
      const tok = this.peek();
      if (tok.kind === 'eof') {
        if (stopOnRBracket) {
          fail('Brak zamykającego nawiasu „]”.', tok.line, tok.column);
        }
        break;
      }
      if (tok.kind === 'rbracket') {
        if (stopOnRBracket) {
          break;
        }
        fail('Nieoczekiwany zamykający nawias „]”.', tok.line, tok.column);
      }
      stmts.push(this.parseStmt(bracketDepth));
    }
    return stmts;
  }

  private parseStmt(bracketDepth: number): Stmt {
    const tok = this.peek();

    if (tok.kind !== 'ident') {
      fail(`Oczekiwano polecenia, znaleziono „${tok.value || 'koniec programu'}”.`, tok.line, tok.column);
    }

    const cmd = COMMAND_ALIASES[tok.lower];
    if (cmd) {
      this.advance();
      switch (cmd) {
        case 'fd':
          return { kind: 'move', dir: 1, expr: this.parseExpr(tok), line: tok.line, column: tok.column };
        case 'bk':
          return { kind: 'move', dir: -1, expr: this.parseExpr(tok), line: tok.line, column: tok.column };
        case 'rt':
          return { kind: 'turn', dir: 1, expr: this.parseExpr(tok), line: tok.line, column: tok.column };
        case 'lt':
          return { kind: 'turn', dir: -1, expr: this.parseExpr(tok), line: tok.line, column: tok.column };
        case 'pitchup':
          return { kind: 'pitch', dir: 1, expr: this.parseExpr(tok), line: tok.line, column: tok.column };
        case 'pitchdown':
          return { kind: 'pitch', dir: -1, expr: this.parseExpr(tok), line: tok.line, column: tok.column };
        case 'rollright':
          return { kind: 'roll', dir: 1, expr: this.parseExpr(tok), line: tok.line, column: tok.column };
        case 'rollleft':
          return { kind: 'roll', dir: -1, expr: this.parseExpr(tok), line: tok.line, column: tok.column };
        case 'pu':
          return { kind: 'pen', down: false, line: tok.line, column: tok.column };
        case 'pd':
          return { kind: 'pen', down: true, line: tok.line, column: tok.column };
        case 'home':
          return { kind: 'home', line: tok.line, column: tok.column };
        case 'cs':
          return { kind: 'cs', line: tok.line, column: tok.column };
        case 'stop':
          return { kind: 'stop', line: tok.line, column: tok.column };
        case 'color': {
          const next = this.peek();
          if (next.kind === 'eof') {
            fail('Brak koloru po poleceniu „kolor”.', tok.line, tok.column);
          }
          if (next.kind !== 'color') {
            fail(
              `Oczekiwano koloru w cudzysłowie (np. "#16866a"), znaleziono „${next.value}”.`,
              next.line,
              next.column
            );
          }
          this.advance();
          return { kind: 'color', value: next.lower, line: tok.line, column: tok.column };
        }
        case 'width':
          return { kind: 'width', expr: this.parseExpr(tok), line: tok.line, column: tok.column };
        case 'let': {
          const nameTok = this.peek();
          if (nameTok.kind === 'eof') {
            fail('Brak nazwy zmiennej po „niech”.', tok.line, tok.column);
          }
          if (nameTok.kind !== 'ident') {
            fail(`Oczekiwano nazwy zmiennej, znaleziono „${nameTok.value}”.`, nameTok.line, nameTok.column);
          }
          if (isReservedWord(nameTok.lower)) {
            fail(`Zmienna nie może mieć nazwy słowa kluczowego „${nameTok.value}”.`, nameTok.line, nameTok.column);
          }
          const isParamReassign = this.currentProcParams?.has(nameTok.lower) ?? false;
          if (this.procSignatures.has(nameTok.lower) && !isParamReassign) {
            fail(
              `Zmienna „${nameTok.value}” ma taką samą nazwę jak zdefiniowana procedura.`,
              nameTok.line,
              nameTok.column
            );
          }
          this.advance();
          const expr = this.parseExpr(nameTok);
          this.declaredVars.add(nameTok.lower);
          return {
            kind: 'let',
            name: nameTok.lower,
            rawName: nameTok.value,
            expr,
            line: tok.line,
            column: tok.column,
          };
        }
        case 'repeat': {
          const count = this.parseExpr(tok);
          const { body, endTok } = this.parseBracketedBody(tok, bracketDepth);
          return {
            kind: 'repeat',
            count,
            body,
            line: tok.line,
            column: tok.column,
            endLine: endTok.line,
            endColumn: endTok.column,
          };
        }
        case 'if': {
          const cond = this.parseCondition(tok);
          const { body, endTok } = this.parseBracketedBody(tok, bracketDepth);
          return {
            kind: 'if',
            cond,
            body,
            line: tok.line,
            column: tok.column,
            endLine: endTok.line,
            endColumn: endTok.column,
          };
        }
        case 'ifelse': {
          const cond = this.parseCondition(tok);
          const first = this.parseBracketedBody(tok, bracketDepth);
          const second = this.parseBracketedBody(tok, bracketDepth);
          return {
            kind: 'ifelse',
            cond,
            thenBody: first.body,
            elseBody: second.body,
            line: tok.line,
            column: tok.column,
            endLine: second.endTok.line,
            endColumn: second.endTok.column,
          };
        }
      }
    }

    // Procedure call?
    const procSig = this.procSignatures.get(tok.lower);
    if (procSig) {
      this.advance();
      const args: Expr[] = [];
      for (let k = 0; k < procSig.params.length; k += 1) {
        args.push(this.parseExpr(tok));
      }
      return {
        kind: 'call',
        name: procSig.name,
        rawName: tok.value,
        args,
        line: tok.line,
        column: tok.column,
      };
    }

    if (REPCOUNT_KEYWORDS.has(tok.lower)) {
      fail(`„${tok.value}” jest wartością, nie poleceniem.`, tok.line, tok.column);
    }

    fail(`Nieznane polecenie „${tok.value}”.`, tok.line, tok.column);
  }

  private parseBracketedBody(cmdTok: Token, bracketDepth: number): { body: Stmt[]; endTok: Token } {
    const open = this.peek();
    if (open.kind === 'eof') {
      fail(`Oczekiwano bloku „[ ... ]” dla polecenia „${cmdTok.value}”.`, cmdTok.line, cmdTok.column);
    }
    if (open.kind !== 'lbracket') {
      fail(`Oczekiwano nawiasu „[”, znaleziono „${open.value}”.`, open.line, open.column);
    }
    const nextDepth = bracketDepth + 1;
    if (nextDepth > LIMITS.MAX_BRACKET_DEPTH) {
      fail(`Przekroczono maksymalną głębokość zagnieżdżenia nawiasów (${LIMITS.MAX_BRACKET_DEPTH}).`, open.line, open.column);
    }
    this.advance();
    const body = this.parseBlock(true, nextDepth);
    const close = this.peek();
    if (close.kind !== 'rbracket') {
      fail('Brak zamykającego nawiasu „]”.', open.line, open.column);
    }
    this.advance();
    return { body, endTok: close };
  }

  private parseCondition(cmdTok: Token): Condition {
    const left = this.parseExpr(cmdTok);
    const comp = this.peek();
    if (comp.kind === 'eof') {
      fail('Brak operatora porównania w warunku (np. <, >, =, <=, >=, <>).', cmdTok.line, cmdTok.column);
    }
    if (comp.kind !== 'comp') {
      fail(`Oczekiwano operatora porównania, znaleziono „${comp.value}”.`, comp.line, comp.column);
    }
    this.advance();
    const right = this.parseExpr(comp);
    return {
      left,
      op: comp.value as CompOp,
      right,
      line: left.line,
      column: left.column,
    };
  }

  private parseExpr(fallbackTok: Token): Expr {
    return this.parseAddSub(fallbackTok);
  }

  private parseAddSub(fallbackTok: Token): Expr {
    let left = this.parseMulDiv(fallbackTok);
    while (true) {
      const next = this.peek();
      if (next.kind !== 'op' || (next.value !== '+' && next.value !== '-')) {
        break;
      }
      if (!next.spaceBefore && next.spaceAfter) {
        fail(
          `Operator binarny „${next.value}” musi mieć spacje po obu stronach albo po żadnej.`,
          next.line,
          next.column
        );
      }
      if (next.spaceBefore !== next.spaceAfter) {
        // Space before only: starts next argument or stray token
        break;
      }
      this.advance();
      const right = this.parseMulDiv(next);
      left = {
        kind: 'binary',
        op: next.value as BinaryOp,
        left,
        right,
        line: left.line,
        column: left.column,
      };
    }
    return left;
  }

  private parseMulDiv(fallbackTok: Token): Expr {
    let left = this.parseUnary(fallbackTok);
    while (true) {
      const next = this.peek();
      if (next.kind !== 'op' || (next.value !== '*' && next.value !== '/')) {
        break;
      }
      if (!next.spaceBefore && next.spaceAfter) {
        fail(
          `Operator binarny „${next.value}” musi mieć spacje po obu stronach albo po żadnej.`,
          next.line,
          next.column
        );
      }
      if (next.spaceBefore !== next.spaceAfter) {
        break;
      }
      this.advance();
      const right = this.parseUnary(next);
      left = {
        kind: 'binary',
        op: next.value as BinaryOp,
        left,
        right,
        line: left.line,
        column: left.column,
      };
    }
    return left;
  }

  private parseUnary(fallbackTok: Token): Expr {
    const next = this.peek();
    if (next.kind === 'op' && (next.value === '+' || next.value === '-')) {
      this.advance();
      const operand = this.parseUnary(next);
      return {
        kind: 'unary',
        op: next.value,
        operand,
        line: next.line,
        column: next.column,
      };
    }
    return this.parsePrimary(fallbackTok);
  }

  private parsePrimary(fallbackTok: Token): Expr {
    const tok = this.peek();
    if (tok.kind === 'eof') {
      fail('Brak oczekiwanego argumentu lub wyrażenia.', fallbackTok.line, fallbackTok.column);
    }

    if (tok.kind === 'number') {
      this.advance();
      const val = Number(tok.value);
      if (!Number.isFinite(val)) {
        fail(`Nieprawidłowa liczba „${tok.value}”.`, tok.line, tok.column);
      }
      return { kind: 'number', value: val, line: tok.line, column: tok.column };
    }

    if (tok.kind === 'lparen') {
      this.advance();
      const inner = this.parseExpr(tok);
      const close = this.peek();
      if (close.kind !== 'rparen') {
        if (close.kind === 'eof') {
          fail('Brak zamykającego nawiasu „)”.', tok.line, tok.column);
        }
        fail(`Oczekiwano „)”, znaleziono „${close.value}”.`, close.line, close.column);
      }
      this.advance();
      return { ...inner, line: tok.line, column: tok.column };
    }

    if (tok.kind === 'ident') {
      if (REPCOUNT_KEYWORDS.has(tok.lower)) {
        this.advance();
        return { kind: 'repcount', line: tok.line, column: tok.column };
      }
      if (isReservedWord(tok.lower)) {
        fail(`Nieoczekiwane słowo kluczowe „${tok.value}” zamiast wartości.`, tok.line, tok.column);
      }
      this.advance();
      return { kind: 'var', name: tok.lower, rawName: tok.value, line: tok.line, column: tok.column };
    }

    if (tok.kind === 'colon_ident') {
      if (isReservedWord(tok.lower)) {
        fail(`Nieoczekiwane słowo kluczowe „:${tok.value}” zamiast wartości.`, tok.line, tok.column);
      }
      this.advance();
      return { kind: 'var', name: tok.lower, rawName: tok.value, line: tok.line, column: tok.column };
    }

    fail(`Oczekiwano wartości lub wyrażenia, znaleziono „${tok.value}”.`, tok.line, tok.column);
  }
}

function exprHasNames(expr: Expr): boolean {
  switch (expr.kind) {
    case 'number':
      return false;
    case 'var':
    case 'repcount':
      return true;
    case 'unary':
      return exprHasNames(expr.operand);
    case 'binary':
      return exprHasNames(expr.left) || exprHasNames(expr.right);
  }
}

function evalConstExpr(expr: Expr): { ok: true; value: number } | { ok: false } {
  switch (expr.kind) {
    case 'number':
      return { ok: true, value: expr.value };
    case 'var':
    case 'repcount':
      return { ok: false };
    case 'unary': {
      const r = evalConstExpr(expr.operand);
      if (!r.ok) return { ok: false };
      return { ok: true, value: expr.op === '-' ? -r.value : r.value };
    }
    case 'binary': {
      const l = evalConstExpr(expr.left);
      const r = evalConstExpr(expr.right);
      if (!l.ok || !r.ok) return { ok: false };
      let val: number;
      switch (expr.op) {
        case '+':
          val = l.value + r.value;
          break;
        case '-':
          val = l.value - r.value;
          break;
        case '*':
          val = l.value * r.value;
          break;
        case '/':
          if (r.value === 0) return { ok: false }; // deferred to runtime division-by-zero
          val = l.value / r.value;
          break;
      }
      if (!Number.isFinite(val)) return { ok: false }; // deferred to runtime non-finite error
      return { ok: true, value: val };
    }
  }
}

function validateExpr(
  expr: Expr,
  inRepeat: boolean,
  allowedVars: Set<string>
): void {
  switch (expr.kind) {
    case 'number':
      return;
    case 'repcount':
      if (!inRepeat) {
        fail('„nrpowt” może być używane wyłącznie wewnątrz bloku „powtórz”.', expr.line, expr.column);
      }
      return;
    case 'var':
      if (!allowedVars.has(expr.name)) {
        fail(`Nieznana zmienna lub parametr „${expr.rawName}”.`, expr.line, expr.column);
      }
      return;
    case 'unary':
      validateExpr(expr.operand, inRepeat, allowedVars);
      return;
    case 'binary':
      validateExpr(expr.left, inRepeat, allowedVars);
      validateExpr(expr.right, inRepeat, allowedVars);
      return;
  }
}

function validateStmts(
  stmts: Stmt[],
  mode: Mode,
  inRepeat: boolean,
  allowedVars: Set<string>
): void {
  for (const stmt of stmts) {
    switch (stmt.kind) {
      case 'move':
      case 'turn':
        validateExpr(stmt.expr, inRepeat, allowedVars);
        break;
      case 'pitch':
      case 'roll':
        if (mode === '2d') {
          fail('Polecenia przechyłu i pochylenia działają wyłącznie w trybie 3D.', stmt.line, stmt.column);
        }
        validateExpr(stmt.expr, inRepeat, allowedVars);
        break;
      case 'width':
        validateExpr(stmt.expr, inRepeat, allowedVars);
        if (!exprHasNames(stmt.expr)) {
          const res = evalConstExpr(stmt.expr);
          if (res.ok) {
            if (!Number.isInteger(res.value) || res.value < LIMITS.MIN_WIDTH || res.value > LIMITS.MAX_WIDTH) {
              fail(
                `Grubość linii musi być liczbą całkowitą od ${LIMITS.MIN_WIDTH} do ${LIMITS.MAX_WIDTH}.`,
                stmt.expr.line,
                stmt.expr.column
              );
            }
          }
        }
        break;
      case 'let':
        validateExpr(stmt.expr, inRepeat, allowedVars);
        break;
      case 'repeat':
        validateExpr(stmt.count, inRepeat, allowedVars);
        if (!exprHasNames(stmt.count)) {
          const res = evalConstExpr(stmt.count);
          if (res.ok) {
            if (!Number.isInteger(res.value) || res.value < LIMITS.MIN_REPEAT || res.value > LIMITS.MAX_REPEAT) {
              fail(
                `Liczba powtórzeń musi być liczbą całkowitą od ${LIMITS.MIN_REPEAT} do ${LIMITS.MAX_REPEAT}.`,
                stmt.count.line,
                stmt.count.column
              );
            }
          }
        }
        validateStmts(stmt.body, mode, true, allowedVars);
        break;
      case 'if':
        validateExpr(stmt.cond.left, inRepeat, allowedVars);
        validateExpr(stmt.cond.right, inRepeat, allowedVars);
        validateStmts(stmt.body, mode, inRepeat, allowedVars);
        break;
      case 'ifelse':
        validateExpr(stmt.cond.left, inRepeat, allowedVars);
        validateExpr(stmt.cond.right, inRepeat, allowedVars);
        validateStmts(stmt.thenBody, mode, inRepeat, allowedVars);
        validateStmts(stmt.elseBody, mode, inRepeat, allowedVars);
        break;
      case 'call':
        for (const arg of stmt.args) {
          validateExpr(arg, inRepeat, allowedVars);
        }
        break;
      case 'pen':
      case 'color':
      case 'home':
      case 'cs':
      case 'stop':
        break;
    }
  }
}

export function parse(source: string, mode: Mode): ParseResult {
  const lexRes = lex(source);
  if (lexRes.error) {
    return { ast: null, error: lexRes.error };
  }

  try {
    const { topTokens, rawProcs } = splitTopLevelAndProcedures(lexRes.tokens);
    const globalVars = new Set<string>();
    const topParser = new TokenStreamParser(topTokens, rawProcs, globalVars, null);
    const body = topParser.parseBlock(false, 0);

    const procedures = new Map<string, ProcedureDef>();
    for (const [name, raw] of rawProcs.entries()) {
      const localVars = new Set<string>();
      const paramSet = new Set<string>(raw.params);
      const procParser = new TokenStreamParser(raw.bodyTokens, rawProcs, localVars, paramSet);
      const procBody = procParser.parseBlock(false, 0);
      procedures.set(name, {
        name,
        rawName: raw.rawName,
        params: raw.params,
        body: procBody,
        localVars,
        line: raw.line,
        column: raw.column,
      });
    }

    // Pass 3: Static validation
    validateStmts(body, mode, false, globalVars);
    for (const proc of procedures.values()) {
      const allowed = new Set<string>(globalVars);
      for (const p of proc.params) allowed.add(p);
      for (const v of proc.localVars) allowed.add(v);
      validateStmts(proc.body, mode, false, allowed);
    }

    return {
      ast: { procedures, body, globalVars },
      error: null,
    };
  } catch (err) {
    if (err instanceof ParseException) {
      return { ast: null, error: err.logoError };
    }
    throw err;
  }
}
