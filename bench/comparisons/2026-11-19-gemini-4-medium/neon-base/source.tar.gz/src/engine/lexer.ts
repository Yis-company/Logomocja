import { LIMITS, LogoError, Token } from './types';

export interface LexResult {
  tokens: Token[];
  error: LogoError | null;
}

const IDENT_START = /[\p{L}_]/u;
const IDENT_CONT = /[\p{L}\p{N}_]/u;
const HEX_COLOR = /^#[0-9a-fA-F]{6}$/;

function isDigit(ch: string): boolean {
  return ch >= '0' && ch <= '9';
}

function isHorizSpace(ch: string): boolean {
  return ch === ' ' || ch === '\t' || ch === '\f' || ch === '\v' || ch === '\u00a0';
}

function isAnySpaceOrCommentOrEof(source: string, index: number): boolean {
  if (index >= source.length) return true;
  const ch = source[index];
  return isHorizSpace(ch) || ch === '\n' || ch === '\r' || ch === ';';
}

export function lex(source: string): LexResult {
  if (source.length > LIMITS.MAX_CHARS) {
    return {
      tokens: [],
      error: {
        message: `Kod przekracza limit ${LIMITS.MAX_CHARS.toLocaleString('pl-PL')} znaków.`,
        line: 1,
        column: 1,
      },
    };
  }

  const tokens: Token[] = [];
  const len = source.length;
  let i = 0;
  let line = 1;
  let col = 1;
  let lineHasToken = false;
  let prevWasSpace = true;

  const pushToken = (tok: Token): LogoError | null => {
    tokens.push(tok);
    lineHasToken = true;
    prevWasSpace = false;
    if (tokens.length > LIMITS.MAX_TOKENS) {
      return {
        message: `Przekroczono limit ${LIMITS.MAX_TOKENS.toLocaleString('pl-PL')} tokenów.`,
        line: tok.line,
        column: tok.column,
      };
    }
    return null;
  };

  while (i < len) {
    const ch = source[i];

    // Newlines
    if (ch === '\r' || ch === '\n') {
      if (ch === '\r' && i + 1 < len && source[i + 1] === '\n') {
        i += 2;
      } else {
        i += 1;
      }
      line += 1;
      col = 1;
      lineHasToken = false;
      prevWasSpace = true;
      continue;
    }

    // Horizontal whitespace
    if (isHorizSpace(ch)) {
      i += 1;
      col += 1;
      prevWasSpace = true;
      continue;
    }

    // Comments
    if (ch === ';') {
      while (i < len && source[i] !== '\n' && source[i] !== '\r') {
        i += 1;
        col += 1;
      }
      prevWasSpace = true;
      continue;
    }

    const startLine = line;
    const startCol = col;
    const atLineStart = !lineHasToken;
    const spaceBefore = prevWasSpace;

    // Colour literal "..."
    if (ch === '"') {
      i += 1;
      col += 1;
      const contentStart = i;
      while (i < len && source[i] !== '"' && source[i] !== '\n' && source[i] !== '\r') {
        i += 1;
        col += 1;
      }
      if (i >= len || source[i] !== '"') {
        return {
          tokens: [],
          error: {
            message: 'Niedomknięty napis z kolorem. Dodaj zamykający cudzysłów.',
            line: startLine,
            column: startCol,
          },
        };
      }
      const rawContent = source.slice(contentStart, i);
      i += 1; // closing quote
      col += 1;
      if (!HEX_COLOR.test(rawContent)) {
        return {
          tokens: [],
          error: {
            message: `Nieprawidłowy kolor "${rawContent}". Użyj sześciocyfrowego kodu hex, np. "#16866a".`,
            line: startLine,
            column: startCol,
          },
        };
      }
      const err = pushToken({
        kind: 'color',
        value: rawContent,
        lower: rawContent.toLowerCase(),
        line: startLine,
        column: startCol,
        spaceBefore,
        spaceAfter: isAnySpaceOrCommentOrEof(source, i),
        atLineStart,
      });
      if (err) return { tokens: [], error: err };
      continue;
    }

    // Numbers: 80, 12.5, .5
    if (isDigit(ch) || (ch === '.' && i + 1 < len && isDigit(source[i + 1]))) {
      const numStart = i;
      let hasDot = false;
      if (ch === '.') {
        hasDot = true;
        i += 1;
        col += 1;
      }
      while (i < len && isDigit(source[i])) {
        i += 1;
        col += 1;
      }
      if (!hasDot && i < len && source[i] === '.') {
        if (i + 1 < len && isDigit(source[i + 1])) {
          hasDot = true;
          i += 1;
          col += 1;
          while (i < len && isDigit(source[i])) {
            i += 1;
            col += 1;
          }
        } else {
          return {
            tokens: [],
            error: {
              message: `Nieprawidłowa liczba „${source.slice(numStart, i + 1)}”. Po kropce dziesiętnej muszą wystąpić cyfry.`,
              line: startLine,
              column: startCol,
            },
          };
        }
      }
      // Reject trailing dot (e.g. 1.2.3) or letters (e.g. 1e3, 0x10)
      if (i < len && (source[i] === '.' || IDENT_START.test(source[i]))) {
        let badEnd = i;
        while (badEnd < len && (source[badEnd] === '.' || IDENT_CONT.test(source[badEnd]))) {
          badEnd += 1;
        }
        return {
          tokens: [],
          error: {
            message: `Nieprawidłowa liczba „${source.slice(numStart, badEnd)}”. Dozwolone są wyłącznie zwykłe liczby dziesiętne.`,
            line: startLine,
            column: startCol,
          },
        };
      }
      const rawNum = source.slice(numStart, i);
      const err = pushToken({
        kind: 'number',
        value: rawNum,
        lower: rawNum,
        line: startLine,
        column: startCol,
        spaceBefore,
        spaceAfter: isAnySpaceOrCommentOrEof(source, i),
        atLineStart,
      });
      if (err) return { tokens: [], error: err };
      continue;
    }

    // Legacy parameter/variable reference :name
    if (ch === ':') {
      i += 1;
      col += 1;
      if (i >= len || !IDENT_START.test(source[i])) {
        return {
          tokens: [],
          error: {
            message: 'Po dwukropku „:” oczekiwano nazwy parametru lub zmiennej.',
            line: startLine,
            column: startCol,
          },
        };
      }
      const nameStart = i;
      while (i < len && IDENT_CONT.test(source[i])) {
        i += 1;
        col += 1;
      }
      const name = source.slice(nameStart, i);
      const err = pushToken({
        kind: 'colon_ident',
        value: name,
        lower: name.toLowerCase(),
        line: startLine,
        column: startCol,
        spaceBefore,
        spaceAfter: isAnySpaceOrCommentOrEof(source, i),
        atLineStart,
      });
      if (err) return { tokens: [], error: err };
      continue;
    }

    // Identifiers and ma:
    if (IDENT_START.test(ch)) {
      const idStart = i;
      while (i < len && IDENT_CONT.test(source[i])) {
        i += 1;
        col += 1;
      }
      const rawId = source.slice(idStart, i);
      const lowerId = rawId.toLowerCase();
      if (lowerId === 'ma' && i < len && source[i] === ':') {
        i += 1;
        col += 1;
        const err = pushToken({
          kind: 'ma_colon',
          value: rawId + ':',
          lower: 'ma:',
          line: startLine,
          column: startCol,
          spaceBefore,
          spaceAfter: isAnySpaceOrCommentOrEof(source, i),
          atLineStart,
        });
        if (err) return { tokens: [], error: err };
        continue;
      }
      const err = pushToken({
        kind: 'ident',
        value: rawId,
        lower: lowerId,
        line: startLine,
        column: startCol,
        spaceBefore,
        spaceAfter: isAnySpaceOrCommentOrEof(source, i),
        atLineStart,
      });
      if (err) return { tokens: [], error: err };
      continue;
    }

    // Comparisons: <=, >=, <>, <, >, =
    if (ch === '<' || ch === '>' || ch === '=') {
      let val = ch;
      if (ch === '<' && i + 1 < len && (source[i + 1] === '=' || source[i + 1] === '>')) {
        val = source.slice(i, i + 2);
        i += 2;
        col += 2;
      } else if (ch === '>' && i + 1 < len && source[i + 1] === '=') {
        val = '>=';
        i += 2;
        col += 2;
      } else {
        i += 1;
        col += 1;
      }
      const err = pushToken({
        kind: 'comp',
        value: val,
        lower: val,
        line: startLine,
        column: startCol,
        spaceBefore,
        spaceAfter: isAnySpaceOrCommentOrEof(source, i),
        atLineStart,
      });
      if (err) return { tokens: [], error: err };
      continue;
    }

    // Arithmetic operators: + - * /
    if (ch === '+' || ch === '-' || ch === '*' || ch === '/') {
      i += 1;
      col += 1;
      const err = pushToken({
        kind: 'op',
        value: ch,
        lower: ch,
        line: startLine,
        column: startCol,
        spaceBefore,
        spaceAfter: isAnySpaceOrCommentOrEof(source, i),
        atLineStart,
      });
      if (err) return { tokens: [], error: err };
      continue;
    }

    // Single-character delimiters
    if (ch === '[' || ch === ']' || ch === '(' || ch === ')' || ch === ',') {
      const kind =
        ch === '['
          ? 'lbracket'
          : ch === ']'
            ? 'rbracket'
            : ch === '('
              ? 'lparen'
              : ch === ')'
                ? 'rparen'
                : 'comma';
      i += 1;
      col += 1;
      const err = pushToken({
        kind,
        value: ch,
        lower: ch,
        line: startLine,
        column: startCol,
        spaceBefore,
        spaceAfter: isAnySpaceOrCommentOrEof(source, i),
        atLineStart,
      });
      if (err) return { tokens: [], error: err };
      continue;
    }

    return {
      tokens: [],
      error: {
        message: `Nieoczekiwany znak „${ch}”.`,
        line: startLine,
        column: startCol,
      },
    };
  }

  tokens.push({
    kind: 'eof',
    value: '',
    lower: '',
    line,
    column: col,
    spaceBefore: true,
    spaceAfter: true,
    atLineStart: !lineHasToken,
  });

  return { tokens, error: null };
}
