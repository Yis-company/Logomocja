export type Mode = '2d' | '3d';

export type Vec3 = [number, number, number];

export interface Segment {
  from: Vec3;
  to: Vec3;
  color: string;
  width: number;
}

export interface LogoError {
  message: string;
  line: number;
  column: number;
}

export interface RunResult {
  segments: Segment[];
  error: LogoError | null;
}

export interface TurtleState {
  pos: Vec3;
  heading: Vec3;
  right: Vec3;
  up: Vec3;
  penDown: boolean;
  color: string;
  width: number;
}

export const LIMITS = {
  MAX_CHARS: 50_000,
  MAX_TOKENS: 10_000,
  MAX_BRACKET_DEPTH: 32,
  MAX_FRAMES: 32,
  MAX_OPS: 10_000,
  MAX_SEGMENTS: 10_000,
  MAX_COORD: 100_000,
  MIN_WIDTH: 1,
  MAX_WIDTH: 12,
  MIN_REPEAT: 0,
  MAX_REPEAT: 10_000,
} as const;

export const DEFAULT_COLOR = '#16866a';
export const DEFAULT_WIDTH = 3;

export type TokenKind =
  | 'number'
  | 'ident'
  | 'colon_ident'
  | 'ma_colon'
  | 'color'
  | 'op'
  | 'comp'
  | 'lbracket'
  | 'rbracket'
  | 'lparen'
  | 'rparen'
  | 'comma'
  | 'eof';

export interface Token {
  kind: TokenKind;
  value: string;
  lower: string;
  line: number;
  column: number;
  spaceBefore: boolean;
  spaceAfter: boolean;
  atLineStart: boolean;
}

export type BinaryOp = '+' | '-' | '*' | '/';
export type CompOp = '<' | '>' | '=' | '<=' | '>=' | '<>';

export type Expr =
  | { kind: 'number'; value: number; line: number; column: number }
  | { kind: 'var'; name: string; rawName: string; line: number; column: number }
  | { kind: 'repcount'; line: number; column: number }
  | { kind: 'unary'; op: '+' | '-'; operand: Expr; line: number; column: number }
  | { kind: 'binary'; op: BinaryOp; left: Expr; right: Expr; line: number; column: number };

export interface Condition {
  left: Expr;
  op: CompOp;
  right: Expr;
  line: number;
  column: number;
}

export type CommandKind =
  | 'fd'
  | 'bk'
  | 'rt'
  | 'lt'
  | 'pu'
  | 'pd'
  | 'color'
  | 'width'
  | 'repeat'
  | 'let'
  | 'if'
  | 'ifelse'
  | 'stop'
  | 'home'
  | 'cs'
  | 'pitchup'
  | 'pitchdown'
  | 'rollright'
  | 'rollleft';

export type Stmt =
  | { kind: 'move'; dir: 1 | -1; expr: Expr; line: number; column: number }
  | { kind: 'turn'; dir: 1 | -1; expr: Expr; line: number; column: number }
  | { kind: 'pitch'; dir: 1 | -1; expr: Expr; line: number; column: number }
  | { kind: 'roll'; dir: 1 | -1; expr: Expr; line: number; column: number }
  | { kind: 'pen'; down: boolean; line: number; column: number }
  | { kind: 'color'; value: string; line: number; column: number }
  | { kind: 'width'; expr: Expr; line: number; column: number }
  | { kind: 'home'; line: number; column: number }
  | { kind: 'cs'; line: number; column: number }
  | { kind: 'stop'; line: number; column: number }
  | { kind: 'let'; name: string; rawName: string; expr: Expr; line: number; column: number }
  | { kind: 'repeat'; count: Expr; body: Stmt[]; line: number; column: number; endLine: number; endColumn: number }
  | { kind: 'if'; cond: Condition; body: Stmt[]; line: number; column: number; endLine: number; endColumn: number }
  | {
      kind: 'ifelse';
      cond: Condition;
      thenBody: Stmt[];
      elseBody: Stmt[];
      line: number;
      column: number;
      endLine: number;
      endColumn: number;
    }
  | { kind: 'call'; name: string; rawName: string; args: Expr[]; line: number; column: number };

export interface ProcedureDef {
  name: string;
  rawName: string;
  params: string[];
  body: Stmt[];
  localVars: Set<string>;
  line: number;
  column: number;
}

export interface ProgramAST {
  procedures: Map<string, ProcedureDef>;
  body: Stmt[];
  globalVars: Set<string>;
}

export const COMMAND_ALIASES: Record<string, CommandKind> = {
  // Forward
  np: 'fd',
  naprzod: 'fd',
  'naprzód': 'fd',
  fd: 'fd',
  forward: 'fd',
  // Back
  ws: 'bk',
  wstecz: 'bk',
  bk: 'bk',
  back: 'bk',
  // Right
  pw: 'rt',
  prawo: 'rt',
  rt: 'rt',
  right: 'rt',
  // Left
  lw: 'lt',
  lewo: 'lt',
  lt: 'lt',
  left: 'lt',
  // Pen up
  pod: 'pu',
  podnies: 'pu',
  'podnieś': 'pu',
  pu: 'pu',
  penup: 'pu',
  // Pen down
  opu: 'pd',
  opusc: 'pd',
  'opuść': 'pd',
  pd: 'pd',
  pendown: 'pd',
  // Color
  kolor: 'color',
  color: 'color',
  // Width
  grubosc: 'width',
  'grubość': 'width',
  width: 'width',
  // Repeat
  powtorz: 'repeat',
  'powtórz': 'repeat',
  repeat: 'repeat',
  // Let
  niech: 'let',
  let: 'let',
  // If
  'jeśli': 'if',
  jesli: 'if',
  if: 'if',
  // Ifelse
  'jeżeli': 'ifelse',
  jezeli: 'ifelse',
  ifelse: 'ifelse',
  // Stop
  stop: 'stop',
  // Home
  dom: 'home',
  home: 'home',
  // Clear screen
  'czyść': 'cs',
  czysc: 'cs',
  cs: 'cs',
  clearscreen: 'cs',
  // 3D pitch up
  gora: 'pitchup',
  'góra': 'pitchup',
  pitchup: 'pitchup',
  // 3D pitch down
  dol: 'pitchdown',
  'dół': 'pitchdown',
  pitchdown: 'pitchdown',
  // 3D roll right
  pp: 'rollright',
  przechylprawo: 'rollright',
  rr: 'rollright',
  rollright: 'rollright',
  // 3D roll left
  pl: 'rollleft',
  przechyllewo: 'rollleft',
  rl: 'rollleft',
  rollleft: 'rollleft',
};

export const PROC_START_KEYWORDS = new Set(['oto', 'to']);
export const PROC_END_KEYWORDS = new Set(['już', 'juz', 'end']);
export const REPCOUNT_KEYWORDS = new Set(['nrpowt', 'repcount']);

export function isReservedWord(lower: string): boolean {
  return (
    Object.prototype.hasOwnProperty.call(COMMAND_ALIASES, lower) ||
    PROC_START_KEYWORDS.has(lower) ||
    PROC_END_KEYWORDS.has(lower) ||
    REPCOUNT_KEYWORDS.has(lower) ||
    lower === 'ma:'
  );
}
