import { parse } from './parser';
import {
  Condition,
  DEFAULT_COLOR,
  DEFAULT_WIDTH,
  Expr,
  LIMITS,
  LogoError,
  Mode,
  ProgramAST,
  RunResult,
  Segment,
  Stmt,
  TurtleState,
  Vec3,
} from './types';

class RuntimeException extends Error {
  constructor(public readonly logoError: LogoError) {
    super(logoError.message);
  }
}

function rfail(message: string, line: number, column: number): never {
  throw new RuntimeException({ message, line, column });
}

type Frame =
  | { kind: 'program'; stmts: Stmt[]; pc: number }
  | { kind: 'proc'; name: string; stmts: Stmt[]; pc: number; locals: Map<string, number>; endLine: number; endColumn: number }
  | { kind: 'repeat'; stmts: Stmt[]; pc: number; iter: number; count: number; endLine: number; endColumn: number }
  | { kind: 'block'; stmts: Stmt[]; pc: number; endLine: number; endColumn: number };

function cleanZero(n: number): number {
  return n === 0 ? 0 : n;
}

function normalize(v: Vec3): Vec3 {
  const len = Math.hypot(v[0], v[1], v[2]);
  if (len === 0) return [0, 0, 0];
  return [cleanZero(v[0] / len), cleanZero(v[1] / len), cleanZero(v[2] / len)];
}

function cross(a: Vec3, b: Vec3): Vec3 {
  return [
    cleanZero(a[1] * b[2] - a[2] * b[1]),
    cleanZero(a[2] * b[0] - a[0] * b[2]),
    cleanZero(a[0] * b[1] - a[1] * b[0]),
  ];
}

function dot(a: Vec3, b: Vec3): number {
  return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}

function reorthogonalize(t: TurtleState): void {
  const h = normalize(t.heading);
  const d = dot(t.up, h);
  const u = normalize([t.up[0] - d * h[0], t.up[1] - d * h[1], t.up[2] - d * h[2]]);
  const r = normalize(cross(h, u));
  t.heading = h;
  t.up = u;
  t.right = r;
}

export function createInitialTurtle(): TurtleState {
  return {
    pos: [0, 0, 0],
    heading: [0, 1, 0],
    right: [1, 0, 0],
    up: [0, 0, 1],
    penDown: true,
    color: DEFAULT_COLOR,
    width: DEFAULT_WIDTH,
  };
}

export interface StepInfo {
  done: boolean;
  line: number | null;
  column: number | null;
  error: LogoError | null;
  drewSegment: boolean;
  cleared: boolean;
}

export class LogoVM {
  public readonly turtle: TurtleState = createInitialTurtle();
  public readonly segments: Segment[] = [];
  public error: LogoError | null = null;
  public done = false;
  public ops = 0;
  public currentLine: number | null = null;

  private readonly globals = new Map<string, number>();
  private readonly stack: Frame[] = [];
  private activeFrames = 0;

  constructor(private readonly ast: ProgramAST) {
    this.stack.push({ kind: 'program', stmts: ast.body, pc: 0 });
    if (ast.body.length === 0) {
      this.done = true;
    }
  }

  private countOp(line: number, column: number): void {
    this.ops += 1;
    if (this.ops > LIMITS.MAX_OPS) {
      rfail(
        `Przekroczono limit ${LIMITS.MAX_OPS.toLocaleString('pl-PL')} wykonanych operacji.`,
        line,
        column
      );
    }
  }

  private getCurrentProc(): Extract<Frame, { kind: 'proc' }> | null {
    for (let i = this.stack.length - 1; i >= 0; i -= 1) {
      const f = this.stack[i];
      if (f.kind === 'proc') return f;
    }
    return null;
  }

  private getCurrentRepcount(): number | null {
    for (let i = this.stack.length - 1; i >= 0; i -= 1) {
      const f = this.stack[i];
      if (f.kind === 'repeat') return f.iter;
      if (f.kind === 'proc') return null; // lexical scoping
    }
    return null;
  }

  private evalExpr(expr: Expr, argLine: number, argCol: number): number {
    switch (expr.kind) {
      case 'number':
        return expr.value;
      case 'repcount': {
        const rc = this.getCurrentRepcount();
        if (rc === null) {
          rfail('„nrpowt” poza pętlą „powtórz”.', argLine, argCol);
        }
        return rc;
      }
      case 'var': {
        const proc = this.getCurrentProc();
        if (proc && proc.locals.has(expr.name)) {
          return proc.locals.get(expr.name)!;
        }
        if (this.globals.has(expr.name)) {
          return this.globals.get(expr.name)!;
        }
        rfail(
          `Zmienna „${expr.rawName}” nie ma jeszcze przypisanej wartości.`,
          argLine,
          argCol
        );
      }
      case 'unary': {
        const v = this.evalExpr(expr.operand, argLine, argCol);
        const res = expr.op === '-' ? -v : v;
        if (!Number.isFinite(res)) {
          rfail('Wynik obliczenia nie jest skończoną liczbą.', argLine, argCol);
        }
        return res;
      }
      case 'binary': {
        const l = this.evalExpr(expr.left, argLine, argCol);
        const r = this.evalExpr(expr.right, argLine, argCol);
        let res: number;
        switch (expr.op) {
          case '+':
            res = l + r;
            break;
          case '-':
            res = l - r;
            break;
          case '*':
            res = l * r;
            break;
          case '/':
            if (r === 0) {
              rfail('Dzielenie przez zero.', argLine, argCol);
            }
            res = l / r;
            break;
        }
        if (!Number.isFinite(res)) {
          rfail('Wynik obliczenia nie jest skończoną liczbą.', argLine, argCol);
        }
        return res;
      }
    }
  }

  private evalArg(expr: Expr): number {
    return this.evalExpr(expr, expr.line, expr.column);
  }

  private evalCondition(cond: Condition): boolean {
    const l = this.evalArg(cond.left);
    const r = this.evalArg(cond.right);
    switch (cond.op) {
      case '<':
        return l < r;
      case '>':
        return l > r;
      case '=':
        return l === r;
      case '<=':
        return l <= r;
      case '>=':
        return l >= r;
      case '<>':
        return l !== r;
    }
  }

  private addSegment(from: Vec3, to: Vec3, line: number, column: number): void {
    if (this.segments.length >= LIMITS.MAX_SEGMENTS) {
      rfail(
        `Przekroczono limit ${LIMITS.MAX_SEGMENTS.toLocaleString('pl-PL')} odcinków na rysunku.`,
        line,
        column
      );
    }
    this.segments.push({
      from: [cleanZero(from[0]), cleanZero(from[1]), cleanZero(from[2])],
      to: [cleanZero(to[0]), cleanZero(to[1]), cleanZero(to[2])],
      color: this.turtle.color,
      width: this.turtle.width,
    });
  }

  public step(): StepInfo {
    if (this.done || this.error) {
      return { done: true, line: this.currentLine, column: null, error: this.error, drewSegment: false, cleared: false };
    }

    try {
      while (this.stack.length > 0) {
        const top = this.stack[this.stack.length - 1];

        if (top.pc >= top.stmts.length) {
          if (top.kind === 'program') {
            this.stack.pop();
            this.done = true;
            this.currentLine = null;
            return { done: true, line: null, column: null, error: null, drewSegment: false, cleared: false };
          }
          if (top.kind === 'repeat') {
            this.countOp(top.endLine, top.endColumn);
            if (top.iter < top.count) {
              top.iter += 1;
              top.pc = 0;
            } else {
              this.stack.pop();
              this.activeFrames -= 1;
            }
            return { done: false, line: top.endLine, column: top.endColumn, error: null, drewSegment: false, cleared: false };
          }
          if (top.kind === 'block') {
            this.countOp(top.endLine, top.endColumn);
            this.stack.pop();
            return { done: false, line: top.endLine, column: top.endColumn, error: null, drewSegment: false, cleared: false };
          }
          if (top.kind === 'proc') {
            this.countOp(top.endLine, top.endColumn);
            this.stack.pop();
            this.activeFrames -= 1;
            return { done: false, line: top.endLine, column: top.endColumn, error: null, drewSegment: false, cleared: false };
          }
        }

        const stmt = top.stmts[top.pc];
        top.pc += 1;
        this.currentLine = stmt.line;
        this.countOp(stmt.line, stmt.column);

        let drewSegment = false;
        let cleared = false;

        switch (stmt.kind) {
          case 'move': {
            const val = this.evalArg(stmt.expr);
            const dist = stmt.dir * val;
            const [x, y, z] = this.turtle.pos;
            const [hx, hy, hz] = this.turtle.heading;
            const nx = cleanZero(x + hx * dist);
            const ny = cleanZero(y + hy * dist);
            const nz = cleanZero(z + hz * dist);
            if (
              !Number.isFinite(nx) ||
              !Number.isFinite(ny) ||
              !Number.isFinite(nz) ||
              Math.abs(nx) > LIMITS.MAX_COORD ||
              Math.abs(ny) > LIMITS.MAX_COORD ||
              Math.abs(nz) > LIMITS.MAX_COORD
            ) {
              rfail(
                `Żółw wyszedł poza dozwolony zakres współrzędnych (±${LIMITS.MAX_COORD.toLocaleString('pl-PL')}).`,
                stmt.expr.line,
                stmt.expr.column
              );
            }
            if (nx !== x || ny !== y || nz !== z) {
              if (this.turtle.penDown) {
                this.addSegment([x, y, z], [nx, ny, nz], stmt.line, stmt.column);
                drewSegment = true;
              }
              this.turtle.pos = [nx, ny, nz];
            }
            break;
          }
          case 'turn': {
            const deg = stmt.dir * this.evalArg(stmt.expr);
            const rad = (deg * Math.PI) / 180;
            const c = Math.cos(rad);
            const s = Math.sin(rad);
            const h = this.turtle.heading;
            const r = this.turtle.right;
            this.turtle.heading = [h[0] * c + r[0] * s, h[1] * c + r[1] * s, h[2] * c + r[2] * s];
            this.turtle.right = [r[0] * c - h[0] * s, r[1] * c - h[1] * s, r[2] * c - h[2] * s];
            reorthogonalize(this.turtle);
            break;
          }
          case 'pitch': {
            const deg = stmt.dir * this.evalArg(stmt.expr);
            const rad = (deg * Math.PI) / 180;
            const c = Math.cos(rad);
            const s = Math.sin(rad);
            const h = this.turtle.heading;
            const u = this.turtle.up;
            this.turtle.heading = [h[0] * c + u[0] * s, h[1] * c + u[1] * s, h[2] * c + u[2] * s];
            this.turtle.up = [u[0] * c - h[0] * s, u[1] * c - h[1] * s, u[2] * c - h[2] * s];
            reorthogonalize(this.turtle);
            break;
          }
          case 'roll': {
            const deg = stmt.dir * this.evalArg(stmt.expr);
            const rad = (deg * Math.PI) / 180;
            const c = Math.cos(rad);
            const s = Math.sin(rad);
            const u = this.turtle.up;
            const r = this.turtle.right;
            this.turtle.up = [u[0] * c + r[0] * s, u[1] * c + r[1] * s, u[2] * c + r[2] * s];
            this.turtle.right = [r[0] * c - u[0] * s, r[1] * c - u[1] * s, r[2] * c - u[2] * s];
            reorthogonalize(this.turtle);
            break;
          }
          case 'pen':
            this.turtle.penDown = stmt.down;
            break;
          case 'color':
            this.turtle.color = stmt.value;
            break;
          case 'width': {
            const w = this.evalArg(stmt.expr);
            if (!Number.isInteger(w) || w < LIMITS.MIN_WIDTH || w > LIMITS.MAX_WIDTH) {
              rfail(
                `Grubość linii musi być liczbą całkowitą od ${LIMITS.MIN_WIDTH} do ${LIMITS.MAX_WIDTH}.`,
                stmt.expr.line,
                stmt.expr.column
              );
            }
            this.turtle.width = w;
            break;
          }
          case 'home': {
            const [x, y, z] = this.turtle.pos;
            if (this.turtle.penDown && (x !== 0 || y !== 0 || z !== 0)) {
              this.addSegment([x, y, z], [0, 0, 0], stmt.line, stmt.column);
              drewSegment = true;
            }
            this.turtle.pos = [0, 0, 0];
            this.turtle.heading = [0, 1, 0];
            this.turtle.right = [1, 0, 0];
            this.turtle.up = [0, 0, 1];
            break;
          }
          case 'cs':
            this.segments.length = 0;
            cleared = true;
            break;
          case 'stop': {
            let unwoundProc = false;
            while (this.stack.length > 0) {
              const popped = this.stack.pop()!;
              if (popped.kind === 'repeat') {
                this.activeFrames -= 1;
              } else if (popped.kind === 'proc') {
                this.activeFrames -= 1;
                unwoundProc = true;
                break;
              }
            }
            if (!unwoundProc) {
              this.done = true;
            }
            break;
          }
          case 'let': {
            const val = this.evalArg(stmt.expr);
            const proc = this.getCurrentProc();
            if (proc) {
              proc.locals.set(stmt.name, val);
            } else {
              this.globals.set(stmt.name, val);
            }
            break;
          }
          case 'repeat': {
            const count = this.evalArg(stmt.count);
            if (!Number.isInteger(count) || count < LIMITS.MIN_REPEAT || count > LIMITS.MAX_REPEAT) {
              rfail(
                `Liczba powtórzeń musi być liczbą całkowitą od ${LIMITS.MIN_REPEAT} do ${LIMITS.MAX_REPEAT}.`,
                stmt.count.line,
                stmt.count.column
              );
            }
            if (count > 0) {
              if (this.activeFrames + 1 > LIMITS.MAX_FRAMES) {
                rfail(
                  `Przekroczono limit ${LIMITS.MAX_FRAMES} zagnieżdżonych wywołań i pętli.`,
                  stmt.line,
                  stmt.column
                );
              }
              this.activeFrames += 1;
              this.stack.push({
                kind: 'repeat',
                stmts: stmt.body,
                pc: 0,
                iter: 1,
                count,
                endLine: stmt.endLine,
                endColumn: stmt.endColumn,
              });
            }
            break;
          }
          case 'if': {
            if (this.evalCondition(stmt.cond)) {
              this.stack.push({
                kind: 'block',
                stmts: stmt.body,
                pc: 0,
                endLine: stmt.endLine,
                endColumn: stmt.endColumn,
              });
            }
            break;
          }
          case 'ifelse': {
            const branch = this.evalCondition(stmt.cond) ? stmt.thenBody : stmt.elseBody;
            this.stack.push({
              kind: 'block',
              stmts: branch,
              pc: 0,
              endLine: stmt.endLine,
              endColumn: stmt.endColumn,
            });
            break;
          }
          case 'call': {
            const proc = this.ast.procedures.get(stmt.name);
            if (!proc) {
              rfail(`Nieznana procedura „${stmt.rawName}”.`, stmt.line, stmt.column);
            }
            const evalArgs: number[] = [];
            for (const arg of stmt.args) {
              evalArgs.push(this.evalArg(arg));
            }
            if (this.activeFrames + 1 > LIMITS.MAX_FRAMES) {
              rfail(
                `Przekroczono limit ${LIMITS.MAX_FRAMES} zagnieżdżonych wywołań i pętli.`,
                stmt.line,
                stmt.column
              );
            }
            const locals = new Map<string, number>();
            for (let k = 0; k < proc.params.length; k += 1) {
              locals.set(proc.params[k], evalArgs[k]);
            }
            this.activeFrames += 1;
            this.stack.push({
              kind: 'proc',
              name: proc.name,
              stmts: proc.body,
              pc: 0,
              locals,
              endLine: proc.line,
              endColumn: proc.column,
            });
            break;
          }
        }

        if (this.stack.length === 0) {
          this.done = true;
        }
        return {
          done: this.done,
          line: stmt.line,
          column: stmt.column,
          error: null,
          drewSegment,
          cleared,
        };
      }

      this.done = true;
      return { done: true, line: null, column: null, error: null, drewSegment: false, cleared: false };
    } catch (err) {
      if (err instanceof RuntimeException) {
        this.error = err.logoError;
        this.done = true;
        return {
          done: true,
          line: err.logoError.line,
          column: err.logoError.column,
          error: err.logoError,
          drewSegment: false,
          cleared: false,
        };
      }
      throw err;
    }
  }

  public runToEnd(): RunResult {
    while (!this.done && !this.error) {
      this.step();
    }
    return {
      segments: this.segments,
      error: this.error,
    };
  }
}

export function createVM(source: string, mode: Mode): { vm: LogoVM | null; error: LogoError | null } {
  const parsed = parse(source, mode);
  if (parsed.error || !parsed.ast) {
    return { vm: null, error: parsed.error };
  }
  return { vm: new LogoVM(parsed.ast), error: null };
}

export function runProgram(source: string, mode: Mode): RunResult {
  const { vm, error } = createVM(source, mode);
  if (error || !vm) {
    return { segments: [], error };
  }
  return vm.runToEnd();
}
