import {
  createInitialTurtle,
  createVM,
  LogoError,
  LogoVM,
  Mode,
  runProgram,
  RunResult,
  Segment,
  TurtleState,
} from './engine';
import { getExampleById, STANDARD_EXAMPLES } from './data/examples';
import { CHALLENGES, checkChallenge } from './data/challenges';
import { COMMAND_DOCS, DIALECT_SECTIONS } from './data/reference';
import { Renderer2D } from './render/renderer2d';
import { Renderer3D } from './render/renderer3d';
import { CodeEditor } from './ui/editor';
import {
  isDraftDirty,
  loadChallengeCode,
  loadCompletedChallenges,
  loadDraft,
  loadSavedMode,
  loadThemePref,
  markChallengeCompleted,
  saveChallengeCode,
  saveDraft,
  saveMode,
  saveThemePref,
  ThemePref,
} from './ui/storage';
import { buildPermalink, parsePermalinkFromLocation } from './ui/permalink';
import { showConfirmDialog, showShortcutsDialog } from './ui/modal';
import { renderSegmentsSVG, renderSourcePreviewSVG } from './ui/preview';

const APP_VERSION = '1.0.0';

type Route = 'workspace' | 'examples' | 'challenges' | 'reference';
type ExecState = 'idle' | 'running' | 'paused' | 'done' | 'error';

interface LogomocjaAPI {
  version: string;
  run: (source: string, mode: Mode) => RunResult;
  open: (source: string, mode: Mode) => Promise<RunResult>;
}

declare global {
  interface Window {
    logomocja: LogomocjaAPI;
  }
}

class LogomocjaApp {
  private route: Route = 'workspace';
  private mode: Mode = '2d';
  private themePref: ThemePref = loadThemePref();
  private dark = false;

  private drafts: Record<Mode, string>;
  private dirty: Record<Mode, boolean>;
  private activeExampleName: Record<Mode, string | null> = { '2d': 'kwadrat', '3d': 'schody' };

  private vm: LogoVM | null = null;
  private execState: ExecState = 'idle';
  private speed = 65; // 1..100 (100 = instant)
  private rafId: number | null = null;
  private lastTickTime = 0;
  private stepAccumulator = 0;

  private currentSegments: Segment[] = [];
  private currentTurtle: TurtleState = createInitialTurtle();
  private currentError: LogoError | null = null;

  private editor!: CodeEditor;
  private renderer2d!: Renderer2D;
  private renderer3d!: Renderer3D;

  private completedChallenges = loadCompletedChallenges();
  private selectedChallengeId = CHALLENGES[0].id;
  private challengeEditor: CodeEditor | null = null;

  private toastTimer: number | null = null;

  // DOM references
  private root!: HTMLElement;
  private viewWorkspace!: HTMLElement;
  private viewExamples!: HTMLElement;
  private viewChallenges!: HTMLElement;
  private viewReference!: HTMLElement;
  private canvas2d!: HTMLCanvasElement;
  private canvas3d!: HTMLCanvasElement;
  private webglFallback!: HTMLElement;
  private statusText!: HTMLElement;
  private turtleReadout!: HTMLElement;
  private toastEl!: HTMLElement;
  private fileInput!: HTMLInputElement;

  private btnRun!: HTMLButtonElement;
  private btnStep!: HTMLButtonElement;
  private btnPause!: HTMLButtonElement;
  private btnReset!: HTMLButtonElement;
  private speedInput!: HTMLInputElement;
  private speedValue!: HTMLElement;
  private exampleSelect!: HTMLSelectElement;
  private mobileView: 'both' | 'editor' | 'canvas' = 'both';

  constructor() {
    const default2d = getExampleById('kwadrat')!.source;
    const default3d = getExampleById('schody')!.source;
    const saved2d = loadDraft('2d');
    const saved3d = loadDraft('3d');
    this.drafts = {
      '2d': saved2d !== null ? saved2d : default2d,
      '3d': saved3d !== null ? saved3d : default3d,
    };
    this.dirty = {
      '2d': saved2d !== null ? isDraftDirty('2d') : false,
      '3d': saved3d !== null ? isDraftDirty('3d') : false,
    };
    this.mode = loadSavedMode();
  }

  public mount(root: HTMLElement): void {
    this.root = root;
    this.renderShell();
    this.applyTheme();
    this.bindGlobalEvents();

    // Expose testing hook
    window.logomocja = {
      version: APP_VERSION,
      run: (source: string, mode: Mode) => runProgram(source, mode),
      open: (source: string, mode: Mode) => this.apiOpen(source, mode),
    };

    // Check permalink on initial load
    const permalink = parsePermalinkFromLocation();
    if (permalink) {
      this.mode = permalink.mode;
      this.drafts[this.mode] = permalink.source;
      this.dirty[this.mode] = false;
      saveMode(this.mode);
      this.editor.setValue(permalink.source);
      this.syncModeUI();
      this.setRoute('workspace', false);
      this.runImmediate(true);
    } else {
      this.editor.setValue(this.drafts[this.mode]);
      this.syncModeUI();
      this.handleHashChange();
      this.runImmediate(true);
    }
  }

  private renderShell(): void {
    this.root.innerHTML = `
      <div class="app-shell">
        <header class="topbar" role="banner">
          <div class="topbar-left">
            <a href="#/" class="brand" aria-label="Logomocja — strona główna">
              <svg class="brand-icon" viewBox="0 0 32 32" width="26" height="26" aria-hidden="true">
                <polygon points="16,3 27,26 16,20 5,26" fill="currentColor"/>
              </svg>
              <span class="brand-name">Logomocja</span>
            </a>

            <div class="mode-switch" role="group" aria-label="Tryb rysowania">
              <button type="button" class="mode-btn" data-mode="2d" aria-pressed="true">2D</button>
              <button type="button" class="mode-btn" data-mode="3d" aria-pressed="false">3D</button>
            </div>
          </div>

          <nav class="main-nav" aria-label="Nawigacja główna">
            <a href="#/" class="nav-link" data-route="workspace">Pracownia</a>
            <a href="#/przyklady" class="nav-link" data-route="examples">Przykłady</a>
            <a href="#/zadania" class="nav-link" data-route="challenges">
              Zadania <span class="badge" id="nav-challenge-badge"></span>
            </a>
            <a href="#/podrecznik" class="nav-link" data-route="reference">Podręcznik</a>
          </nav>

          <div class="topbar-right">
            <button type="button" class="icon-btn" id="btn-share" title="Kopiuj link do programu" aria-label="Udostępnij link do programu">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
                <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
              </svg>
              <span class="btn-label">Udostępnij</span>
            </button>
            <button type="button" class="icon-btn" id="btn-shortcuts" title="Skróty klawiszowe" aria-label="Pokaż skróty klawiszowe">
              <span aria-hidden="true">?</span>
            </button>
            <button type="button" class="icon-btn" id="btn-theme" title="Zmień motyw (jasny/ciemny)" aria-label="Przełącz motyw jasny lub ciemny">
              <span id="theme-icon" aria-hidden="true">◐</span>
            </button>
          </div>
        </header>

        <main class="main-content" id="main-content">
          <!-- WORKSPACE -->
          <section class="view view-workspace" id="view-workspace" aria-label="Pracownia">
            <div class="mobile-tabs" role="tablist" aria-label="Widok mobilny">
              <button type="button" role="tab" class="mobile-tab is-active" data-mtab="canvas" aria-selected="true">Rysunek</button>
              <button type="button" role="tab" class="mobile-tab" data-mtab="editor" aria-selected="false">Kod</button>
            </div>

            <div class="workspace-grid">
              <div class="pane pane-editor" id="pane-editor">
                <div class="pane-toolbar">
                  <div class="toolbar-group">
                    <button type="button" class="btn btn-primary" id="btn-run" title="Uruchom program (Ctrl/Cmd+Enter)">
                      ▶ Uruchom
                    </button>
                    <button type="button" class="btn btn-secondary" id="btn-step" title="Jeden krok (Alt+S lub F10)">
                      ⏭ Krok
                    </button>
                    <button type="button" class="btn btn-secondary" id="btn-pause" title="Wstrzymaj / Wznów (Alt+P)" disabled>
                      ⏸ Wstrzymaj
                    </button>
                    <button type="button" class="btn btn-ghost" id="btn-reset" title="Resetuj (Alt+R)">
                      ↺ Reset
                    </button>
                  </div>

                  <div class="toolbar-group speed-group">
                    <label for="speed-slider" class="speed-label">Prędkość</label>
                    <input type="range" id="speed-slider" min="1" max="100" value="65" aria-label="Prędkość animacji żółwia" />
                    <span class="speed-val" id="speed-val">Szybko</span>
                  </div>
                </div>

                <div class="editor-subbar">
                  <div class="subbar-left">
                    <label for="quick-example" class="sr-only">Wczytaj przykład</label>
                    <select id="quick-example" class="select-input" aria-label="Wybierz wbudowany przykład"></select>
                  </div>
                  <div class="subbar-right">
                    <button type="button" class="btn btn-sm btn-ghost" id="btn-open-file" title="Otwórz plik .logo">Otwórz .logo</button>
                    <button type="button" class="btn btn-sm btn-ghost" id="btn-save-file" title="Zapisz program jako plik .logo">Zapisz .logo</button>
                    <input type="file" id="file-input" accept=".logo,.txt,text/plain" class="sr-only" aria-hidden="true" />
                  </div>
                </div>

                <div class="editor-host" id="editor-host"></div>

                <div class="editor-footer">
                  <span class="status-text" id="status-text" role="status" aria-live="polite">Gotowy</span>
                  <span class="shortcuts-hint">Ctrl+Enter: uruchom · Alt+S: krok · Alt+P: pauza · Alt+R: reset</span>
                </div>
              </div>

              <div class="pane pane-canvas" id="pane-canvas">
                <div class="canvas-stage">
                  <canvas id="canvas-2d" class="stage-canvas" aria-label="Płótno rysowania 2D"></canvas>
                  <canvas id="canvas-3d" class="stage-canvas hidden" aria-label="Scena rysowania 3D"></canvas>
                  <div id="webgl-fallback" class="webgl-fallback hidden" role="status">
                    <h3>Tryb 3D niedostępny</h3>
                    <p id="webgl-fallback-reason"></p>
                    <button type="button" class="btn btn-primary" id="btn-switch-2d">Przejdź do trybu 2D</button>
                  </div>

                  <div class="canvas-hud-top">
                    <div class="hud-pill" id="turtle-readout" aria-label="Położenie żółwia">X: 0 · Y: 0</div>
                  </div>

                  <div class="canvas-hud-bottom" role="group" aria-label="Sterowanie widokiem">
                    <button type="button" class="hud-btn" id="btn-zoom-in" title="Przybliż" aria-label="Przybliż widok">+</button>
                    <button type="button" class="hud-btn" id="btn-zoom-out" title="Oddal" aria-label="Oddal widok">−</button>
                    <button type="button" class="hud-btn" id="btn-fit" title="Dopasuj rysunek (Alt+F)" aria-label="Dopasuj widok do rysunku">Dopasuj</button>
                    <button type="button" class="hud-btn" id="btn-reset-cam" title="Resetuj kamerę" aria-label="Resetuj kamerę">Początek</button>
                    <button type="button" class="hud-btn" id="btn-export-png" title="Zapisz rysunek jako PNG" aria-label="Eksportuj rysunek jako PNG">PNG</button>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <!-- EXAMPLES -->
          <section class="view view-page hidden" id="view-examples" aria-label="Przykładowe programy"></section>

          <!-- CHALLENGES -->
          <section class="view view-page hidden" id="view-challenges" aria-label="Zadania"></section>

          <!-- REFERENCE -->
          <section class="view view-page hidden" id="view-reference" aria-label="Podręcznik poleceń"></section>
        </main>

        <div class="toast hidden" id="toast" role="status" aria-live="polite"></div>
      </div>
    `;

    this.viewWorkspace = this.root.querySelector('#view-workspace')!;
    this.viewExamples = this.root.querySelector('#view-examples')!;
    this.viewChallenges = this.root.querySelector('#view-challenges')!;
    this.viewReference = this.root.querySelector('#view-reference')!;
    this.canvas2d = this.root.querySelector('#canvas-2d')!;
    this.canvas3d = this.root.querySelector('#canvas-3d')!;
    this.webglFallback = this.root.querySelector('#webgl-fallback')!;
    this.statusText = this.root.querySelector('#status-text')!;
    this.turtleReadout = this.root.querySelector('#turtle-readout')!;
    this.toastEl = this.root.querySelector('#toast')!;
    this.fileInput = this.root.querySelector('#file-input')!;

    this.btnRun = this.root.querySelector('#btn-run')!;
    this.btnStep = this.root.querySelector('#btn-step')!;
    this.btnPause = this.root.querySelector('#btn-pause')!;
    this.btnReset = this.root.querySelector('#btn-reset')!;
    this.speedInput = this.root.querySelector('#speed-slider')!;
    this.speedValue = this.root.querySelector('#speed-val')!;
    this.exampleSelect = this.root.querySelector('#quick-example')!;

    // Mount code editor
    this.editor = new CodeEditor({
      ariaLabel: 'Edytor kodu Logo',
      onChange: (val) => this.handleEditorChange(val),
    });
    this.root.querySelector('#editor-host')!.appendChild(this.editor.element);

    // Mount renderers
    this.renderer2d = new Renderer2D(this.canvas2d);
    this.renderer3d = new Renderer3D(this.canvas3d);
    if (!this.renderer3d.supported && this.renderer3d.unavailableReason) {
      this.root.querySelector('#webgl-fallback-reason')!.textContent =
        this.renderer3d.unavailableReason;
    }

    this.populateQuickExamples();
    this.updateChallengeBadge();
    this.updateSpeedLabel();
    this.renderExamplesView();
    this.renderReferenceView();
  }

  private bindGlobalEvents(): void {
    window.addEventListener('hashchange', () => this.handleHashChange());

    // System theme change
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    mq.addEventListener('change', () => {
      if (this.themePref === 'system') this.applyTheme();
    });

    // Mode switch
    this.root.querySelectorAll<HTMLButtonElement>('.mode-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const nextMode = btn.dataset.mode as Mode;
        if (nextMode !== this.mode) {
          this.switchMode(nextMode);
        }
      });
    });

    this.root.querySelector('#btn-switch-2d')?.addEventListener('click', () => {
      this.switchMode('2d');
    });

    // Mobile tabs
    this.root.querySelectorAll<HTMLButtonElement>('.mobile-tab').forEach((btn) => {
      btn.addEventListener('click', () => {
        const tab = btn.dataset.mtab as 'canvas' | 'editor';
        this.mobileView = tab;
        this.root.querySelectorAll<HTMLButtonElement>('.mobile-tab').forEach((b) => {
          const active = b.dataset.mtab === tab;
          b.classList.toggle('is-active', active);
          b.setAttribute('aria-selected', String(active));
        });
        this.viewWorkspace.dataset.mobileTab = tab;
        requestAnimationFrame(() => {
          this.renderer2d.resize();
          this.renderer3d.resize();
        });
      });
    });
    this.viewWorkspace.dataset.mobileTab = 'canvas';

    // Topbar actions
    this.root.querySelector('#btn-share')!.addEventListener('click', () => this.copyPermalink());
    this.root.querySelector('#btn-shortcuts')!.addEventListener('click', () => showShortcutsDialog());
    this.root.querySelector('#btn-theme')!.addEventListener('click', () => this.toggleTheme());

    // Execution controls
    this.btnRun.addEventListener('click', () => this.handleRunClick());
    this.btnStep.addEventListener('click', () => this.handleStepClick());
    this.btnPause.addEventListener('click', () => this.handlePauseToggle());
    this.btnReset.addEventListener('click', () => this.handleReset());

    this.speedInput.addEventListener('input', () => {
      this.speed = Number(this.speedInput.value);
      this.updateSpeedLabel();
    });

    // Quick example select
    this.exampleSelect.addEventListener('change', async () => {
      const id = this.exampleSelect.value;
      if (!id) return;
      const ex = getExampleById(id);
      this.exampleSelect.value = '';
      if (ex) {
        await this.loadExampleWithConfirm(ex.id);
      }
    });

    // File open / save
    this.root.querySelector('#btn-open-file')!.addEventListener('click', () => {
      this.fileInput.value = '';
      this.fileInput.click();
    });
    this.fileInput.addEventListener('change', () => this.handleFileOpen());
    this.root.querySelector('#btn-save-file')!.addEventListener('click', () => this.downloadLogoFile());

    // Viewport HUD
    this.root.querySelector('#btn-zoom-in')!.addEventListener('click', () => {
      if (this.mode === '2d') this.renderer2d.zoomBy(1.25);
      else this.renderer3d.zoomBy(1.25);
    });
    this.root.querySelector('#btn-zoom-out')!.addEventListener('click', () => {
      if (this.mode === '2d') this.renderer2d.zoomBy(1 / 1.25);
      else this.renderer3d.zoomBy(1 / 1.25);
    });
    this.root.querySelector('#btn-fit')!.addEventListener('click', () => {
      if (this.mode === '2d') this.renderer2d.fit();
      else this.renderer3d.fit();
    });
    this.root.querySelector('#btn-reset-cam')!.addEventListener('click', () => {
      if (this.mode === '2d') this.renderer2d.resetView();
      else this.renderer3d.resetView();
    });
    this.root.querySelector('#btn-export-png')!.addEventListener('click', () => this.exportPNG());

    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
      if (this.route !== 'workspace') return;
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        this.handleRunClick();
      } else if (e.key === 'F10' || (e.altKey && e.key.toLowerCase() === 's')) {
        e.preventDefault();
        this.handleStepClick();
      } else if (e.altKey && e.key.toLowerCase() === 'p') {
        e.preventDefault();
        this.handlePauseToggle();
      } else if (e.altKey && e.key.toLowerCase() === 'r') {
        e.preventDefault();
        this.handleReset();
      } else if (e.altKey && e.key.toLowerCase() === 'f') {
        e.preventDefault();
        if (this.mode === '2d') this.renderer2d.fit();
        else this.renderer3d.fit();
      }
    });
  }

  private handleHashChange(): void {
    const hash = window.location.hash || '#/';
    const path = hash.split('?')[0];
    if (path === '#/przyklady') {
      this.setRoute('examples', false);
    } else if (path === '#/zadania') {
      this.setRoute('challenges', false);
    } else if (path === '#/podrecznik') {
      this.setRoute('reference', false);
    } else {
      this.setRoute('workspace', false);
    }
  }

  private setRoute(route: Route, updateHash = true): void {
    this.route = route;
    if (updateHash) {
      const targetHash =
        route === 'workspace'
          ? '#/'
          : route === 'examples'
            ? '#/przyklady'
            : route === 'challenges'
              ? '#/zadania'
              : '#/podrecznik';
      if (window.location.hash !== targetHash) {
        window.location.hash = targetHash;
      }
    }

    this.viewWorkspace.classList.toggle('hidden', route !== 'workspace');
    this.viewExamples.classList.toggle('hidden', route !== 'examples');
    this.viewChallenges.classList.toggle('hidden', route !== 'challenges');
    this.viewReference.classList.toggle('hidden', route !== 'reference');

    this.root.querySelectorAll<HTMLAnchorElement>('.nav-link').forEach((link) => {
      const active = link.dataset.route === route;
      link.classList.toggle('is-active', active);
      if (active) link.setAttribute('aria-current', 'page');
      else link.removeAttribute('aria-current');
    });

    if (route === 'workspace') {
      requestAnimationFrame(() => {
        this.renderer2d.resize();
        this.renderer3d.resize();
      });
    } else if (route === 'challenges') {
      this.renderChallengesView();
    }
  }

  private applyTheme(): void {
    const systemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    this.dark = this.themePref === 'system' ? systemDark : this.themePref === 'dark';
    document.documentElement.dataset.theme = this.dark ? 'dark' : 'light';
    const icon = this.root.querySelector('#theme-icon');
    if (icon) {
      icon.textContent = this.dark ? '☀' : '☾';
    }
    this.renderer2d?.setTheme(this.dark);
    this.renderer3d?.setTheme(this.dark);
  }

  private toggleTheme(): void {
    this.themePref = this.dark ? 'light' : 'dark';
    saveThemePref(this.themePref);
    this.applyTheme();
  }

  private populateQuickExamples(): void {
    const sel = this.exampleSelect;
    sel.innerHTML = `<option value="">Przykłady (${STANDARD_EXAMPLES.length})…</option>`;
    const g2 = document.createElement('optgroup');
    g2.label = 'Tryb 2D (płaszczyzna)';
    const g3 = document.createElement('optgroup');
    g3.label = 'Tryb 3D (przestrzeń)';
    for (const ex of STANDARD_EXAMPLES) {
      const opt = document.createElement('option');
      opt.value = ex.id;
      opt.textContent = ex.title;
      (ex.mode === '2d' ? g2 : g3).appendChild(opt);
    }
    sel.appendChild(g2);
    sel.appendChild(g3);
  }

  private switchMode(nextMode: Mode): void {
    this.stopAnimation();
    this.drafts[this.mode] = this.editor.getValue();
    saveDraft(this.mode, this.drafts[this.mode], this.dirty[this.mode]);

    this.mode = nextMode;
    saveMode(nextMode);
    this.editor.setValue(this.drafts[nextMode]);
    this.editor.setActiveLine(null);
    this.editor.setError(null);
    this.syncModeUI();
    this.runImmediate(true);
  }

  private syncModeUI(): void {
    this.root.querySelectorAll<HTMLButtonElement>('.mode-btn').forEach((btn) => {
      const active = btn.dataset.mode === this.mode;
      btn.classList.toggle('is-active', active);
      btn.setAttribute('aria-pressed', String(active));
    });

    if (this.mode === '2d') {
      this.canvas2d.classList.remove('hidden');
      this.canvas3d.classList.add('hidden');
      this.webglFallback.classList.add('hidden');
      this.renderer2d.resize();
    } else {
      this.canvas2d.classList.add('hidden');
      if (this.renderer3d.supported) {
        this.canvas3d.classList.remove('hidden');
        this.webglFallback.classList.add('hidden');
        this.renderer3d.resize();
      } else {
        this.canvas3d.classList.add('hidden');
        this.webglFallback.classList.remove('hidden');
      }
    }
  }

  private handleEditorChange(val: string): void {
    this.drafts[this.mode] = val;
    this.dirty[this.mode] = true;
    saveDraft(this.mode, val, true);

    if (this.execState === 'running' || this.execState === 'paused') {
      this.stopAnimation();
      this.vm = null;
      this.execState = 'idle';
      this.editor.setActiveLine(null);
      this.updateExecButtons();
      this.setStatus('Kod zmieniony — uruchom ponownie');
    }
  }

  private stopAnimation(): void {
    if (this.rafId !== null) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
  }

  private updateSpeedLabel(): void {
    const label =
      this.speed >= 98
        ? 'Natychmiast'
        : this.speed >= 70
          ? 'Szybko'
          : this.speed >= 35
            ? 'Średnio'
            : 'Wolno';
    this.speedValue.textContent = label;
  }

  private updateExecButtons(): void {
    const running = this.execState === 'running';
    const paused = this.execState === 'paused';
    this.btnPause.disabled = !running && !paused;
    this.btnPause.textContent = paused ? '▶ Wznów' : '⏸ Wstrzymaj';
  }

  private setStatus(text: string): void {
    this.statusText.textContent = text;
  }

  private updateViewport(): void {
    if (this.mode === '2d') {
      this.renderer2d.setData(this.currentSegments, this.currentTurtle);
    } else if (this.renderer3d.supported) {
      this.renderer3d.setData(this.currentSegments, this.currentTurtle);
    }
    const [x, y, z] = this.currentTurtle.pos;
    const fmt = (n: number) => (Math.abs(n) < 0.05 ? '0' : n.toFixed(1));
    this.turtleReadout.textContent =
      this.mode === '2d'
        ? `X: ${fmt(x)} · Y: ${fmt(y)} · Odcinki: ${this.currentSegments.length}`
        : `X: ${fmt(x)} · Y: ${fmt(y)} · Z: ${fmt(z)} · Odcinki: ${this.currentSegments.length}`;
  }

  private handleRunClick(): void {
    if (this.execState === 'paused' && this.vm) {
      this.execState = 'running';
      this.updateExecButtons();
      this.setStatus('Wykonywanie…');
      this.startAnimationLoop();
      return;
    }

    this.stopAnimation();
    const source = this.editor.getValue();
    if (this.speed >= 98) {
      this.runImmediate(false);
      return;
    }

    const { vm, error } = createVM(source, this.mode);
    if (error || !vm) {
      this.vm = null;
      this.currentSegments = [];
      this.currentTurtle = createInitialTurtle();
      this.currentError = error;
      this.execState = 'error';
      this.editor.setActiveLine(null);
      this.editor.setError(error);
      this.updateViewport();
      this.updateExecButtons();
      this.setStatus('Błąd składni');
      return;
    }

    this.vm = vm;
    this.currentSegments = vm.segments;
    this.currentTurtle = vm.turtle;
    this.currentError = null;
    this.editor.setError(null);
    this.execState = 'running';
    this.updateExecButtons();
    this.setStatus('Wykonywanie…');
    this.updateViewport();
    this.startAnimationLoop();
  }

  private startAnimationLoop(): void {
    this.lastTickTime = performance.now();
    this.stepAccumulator = 0;

    const tick = (now: number) => {
      if (this.execState !== 'running' || !this.vm) return;

      const dt = Math.min(0.1, (now - this.lastTickTime) / 1000);
      this.lastTickTime = now;

      // Exponential speed curve: speed 1 -> ~2 ops/sec, speed 50 -> ~45 ops/sec, speed 97 -> ~1500 ops/sec
      const opsPerSec =
        this.speed >= 98 ? 100_000 : Math.pow(1.072, this.speed) * 1.6;
      this.stepAccumulator += dt * opsPerSec;
      const budget = Math.min(250, Math.floor(this.stepAccumulator));
      this.stepAccumulator -= budget;

      let lastLine: number | null = this.vm.currentLine;
      for (let i = 0; i < budget; i += 1) {
        if (this.vm.done) break;
        const info = this.vm.step();
        if (info.line !== null) lastLine = info.line;
        if (info.error) break;
      }

      this.currentSegments = this.vm.segments;
      this.currentTurtle = this.vm.turtle;
      this.editor.setActiveLine(this.vm.done ? null : lastLine);
      this.updateViewport();

      if (this.vm.error) {
        this.currentError = this.vm.error;
        this.execState = 'error';
        this.editor.setError(this.vm.error);
        this.editor.setActiveLine(null);
        this.updateExecButtons();
        this.setStatus('Błąd wykonania');
        return;
      }

      if (this.vm.done) {
        this.execState = 'done';
        this.editor.setActiveLine(null);
        this.updateExecButtons();
        this.setStatus(`Gotowe (${this.currentSegments.length} odc.)`);
        return;
      }

      this.rafId = requestAnimationFrame(tick);
    };

    this.rafId = requestAnimationFrame(tick);
  }

  private handleStepClick(): void {
    this.stopAnimation();
    if (!this.vm || this.execState === 'done' || this.execState === 'error' || this.execState === 'idle') {
      const source = this.editor.getValue();
      const { vm, error } = createVM(source, this.mode);
      if (error || !vm) {
        this.vm = null;
        this.currentSegments = [];
        this.currentTurtle = createInitialTurtle();
        this.currentError = error;
        this.execState = 'error';
        this.editor.setActiveLine(null);
        this.editor.setError(error);
        this.updateViewport();
        this.updateExecButtons();
        this.setStatus('Błąd składni');
        return;
      }
      this.vm = vm;
      this.currentError = null;
      this.editor.setError(null);
    }

    const info = this.vm.step();
    this.currentSegments = this.vm.segments;
    this.currentTurtle = this.vm.turtle;

    if (info.error) {
      this.currentError = info.error;
      this.execState = 'error';
      this.editor.setError(info.error);
      this.editor.setActiveLine(null);
      this.setStatus('Błąd wykonania');
    } else if (info.done) {
      this.execState = 'done';
      this.editor.setActiveLine(null);
      this.setStatus(`Gotowe (${this.currentSegments.length} odc.)`);
    } else {
      this.execState = 'paused';
      this.editor.setActiveLine(info.line);
      this.setStatus(`Krok — wiersz ${info.line ?? '—'}`);
    }

    this.updateViewport();
    this.updateExecButtons();
  }

  private handlePauseToggle(): void {
    if (this.execState === 'running') {
      this.stopAnimation();
      this.execState = 'paused';
      this.updateExecButtons();
      this.setStatus('Wstrzymano');
    } else if (this.execState === 'paused' && this.vm) {
      this.execState = 'running';
      this.updateExecButtons();
      this.setStatus('Wykonywanie…');
      this.startAnimationLoop();
    }
  }

  private handleReset(): void {
    this.stopAnimation();
    this.vm = null;
    this.execState = 'idle';
    this.currentSegments = [];
    this.currentTurtle = createInitialTurtle();
    this.currentError = null;
    this.editor.setActiveLine(null);
    this.editor.setError(null);
    this.updateViewport();
    this.updateExecButtons();
    this.setStatus('Zresetowano');
  }

  private runImmediate(fitAfter: boolean): RunResult {
    this.stopAnimation();
    const source = this.editor.getValue();
    const { vm, error } = createVM(source, this.mode);
    if (error || !vm) {
      this.vm = null;
      this.currentSegments = [];
      this.currentTurtle = createInitialTurtle();
      this.currentError = error;
      this.execState = 'error';
      this.editor.setActiveLine(null);
      this.editor.setError(error);
      this.updateViewport();
      this.updateExecButtons();
      this.setStatus('Błąd składni');
      return { segments: [], error };
    }

    const res = vm.runToEnd();
    this.vm = vm;
    this.currentSegments = res.segments;
    this.currentTurtle = vm.turtle;
    this.currentError = res.error;
    this.execState = res.error ? 'error' : 'done';
    this.editor.setActiveLine(null);
    this.editor.setError(res.error);
    this.updateViewport();
    if (fitAfter && !res.error) {
      if (this.mode === '2d') this.renderer2d.fit();
      else if (this.renderer3d.supported) this.renderer3d.fit();
    }
    this.updateExecButtons();
    this.setStatus(
      res.error ? 'Błąd wykonania' : `Gotowe (${this.currentSegments.length} odc.)`
    );
    return res;
  }

  private async apiOpen(source: string, mode: Mode): Promise<RunResult> {
    this.setRoute('workspace', false);
    this.stopAnimation();
    this.mode = mode;
    this.drafts[mode] = source;
    this.dirty[mode] = false;
    saveMode(mode);
    saveDraft(mode, source, false);
    this.editor.setValue(source);
    this.syncModeUI();

    const res = this.runImmediate(true);

    // Wait for layout & paint so the drawing is visible on screen
    await new Promise<void>((resolve) => {
      requestAnimationFrame(() => {
        if (this.mode === '2d') {
          this.renderer2d.resize();
          this.renderer2d.fit();
        } else if (this.renderer3d.supported) {
          this.renderer3d.resize();
          this.renderer3d.fit();
        }
        requestAnimationFrame(() => resolve());
      });
    });

    return res;
  }

  private async confirmOverwriteIfDirty(targetMode: Mode): Promise<boolean> {
    const currentText =
      targetMode === this.mode ? this.editor.getValue() : this.drafts[targetMode];
    if (!this.dirty[targetMode] || currentText.trim() === '') {
      return true;
    }
    return showConfirmDialog({
      title: 'Niezapisane zmiany w szkicu',
      body: `W trybie ${targetMode.toUpperCase()} masz niezapisane zmiany. Czy chcesz je zastąpić nowym programem?`,
      confirmLabel: 'Zastąp szkic',
      cancelLabel: 'Anuluj',
      secondaryLabel: 'Pobierz .logo',
      onSecondary: () => this.downloadLogoFile(targetMode),
    });
  }

  private async loadExampleWithConfirm(id: string): Promise<void> {
    const ex = getExampleById(id);
    if (!ex) return;
    const ok = await this.confirmOverwriteIfDirty(ex.mode);
    if (!ok) return;

    this.mode = ex.mode;
    this.drafts[ex.mode] = ex.source;
    this.dirty[ex.mode] = false;
    this.activeExampleName[ex.mode] = ex.id;
    saveMode(ex.mode);
    saveDraft(ex.mode, ex.source, false);
    this.editor.setValue(ex.source);
    this.syncModeUI();
    this.setRoute('workspace', true);
    this.runImmediate(true);
    this.showToast(`Wczytano przykład: ${ex.title}`);
  }

  private async loadCustomSnippetWithConfirm(source: string, mode: Mode, label: string): Promise<void> {
    const ok = await this.confirmOverwriteIfDirty(mode);
    if (!ok) return;

    this.mode = mode;
    this.drafts[mode] = source;
    this.dirty[mode] = false;
    this.activeExampleName[mode] = null;
    saveMode(mode);
    saveDraft(mode, source, false);
    this.editor.setValue(source);
    this.syncModeUI();
    this.setRoute('workspace', true);
    this.runImmediate(true);
    this.showToast(`Wczytano: ${label}`);
  }

  private async handleFileOpen(): Promise<void> {
    const file = this.fileInput.files?.[0];
    if (!file) return;
    const text = await file.text();
    const ok = await this.confirmOverwriteIfDirty(this.mode);
    if (!ok) return;

    this.drafts[this.mode] = text;
    this.dirty[this.mode] = false;
    this.activeExampleName[this.mode] = file.name.replace(/\.[^.]+$/, '');
    saveDraft(this.mode, text, false);
    this.editor.setValue(text);
    this.runImmediate(true);
    this.showToast(`Otwarto plik: ${file.name}`);
  }

  private downloadLogoFile(modeOverride?: Mode): void {
    const m = modeOverride ?? this.mode;
    const content = m === this.mode ? this.editor.getValue() : this.drafts[m];
    const name = this.activeExampleName[m] || `logomocja-${m}`;
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${name}.logo`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    this.dirty[m] = false;
    saveDraft(m, content, false);
    this.showToast(`Zapisano ${name}.logo`);
  }

  private exportPNG(): void {
    const dataUrl =
      this.mode === '2d' ? this.renderer2d.exportPNG() : this.renderer3d.exportPNG();
    if (!dataUrl) {
      this.showToast('Eksport PNG niedostępny bez WebGL w trybie 3D.');
      return;
    }
    const name = this.activeExampleName[this.mode] || `logomocja-${this.mode}`;
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `${name}.png`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    this.showToast(`Zapisano obraz ${name}.png`);
  }

  private async copyPermalink(): Promise<void> {
    const url = buildPermalink(this.editor.getValue(), this.mode);
    try {
      await navigator.clipboard.writeText(url);
      this.showToast('Skopiowano link do schowka!');
    } catch {
      window.prompt('Skopiuj link do programu:', url);
    }
  }

  private showToast(msg: string): void {
    this.toastEl.textContent = msg;
    this.toastEl.classList.remove('hidden');
    if (this.toastTimer !== null) window.clearTimeout(this.toastTimer);
    this.toastTimer = window.setTimeout(() => {
      this.toastEl.classList.add('hidden');
    }, 2600);
  }

  private updateChallengeBadge(): void {
    const badge = this.root.querySelector('#nav-challenge-badge');
    if (badge) {
      badge.textContent = `${this.completedChallenges.size}/${CHALLENGES.length}`;
    }
  }

  // ---- EXAMPLES PAGE ----
  private renderExamplesView(): void {
    const cardsHtml = STANDARD_EXAMPLES.map(
      (ex) => `
      <article class="card example-card" data-mode="${ex.mode}">
        <div class="card-thumb">
          ${renderSourcePreviewSVG(ex.source, ex.mode, 260, 160)}
          <span class="mode-pill mode-pill-${ex.mode}">${ex.mode.toUpperCase()}</span>
        </div>
        <div class="card-body">
          <h3>${ex.title}</h3>
          <p>${ex.description}</p>
          <div class="card-actions">
            <button type="button" class="btn btn-primary btn-sm" data-load-example="${ex.id}">
              Otwórz w pracowni
            </button>
          </div>
        </div>
      </article>
    `
    ).join('');

    this.viewExamples.innerHTML = `
      <div class="page-container">
        <div class="page-header">
          <div>
            <h1>Przykładowe programy</h1>
            <p class="page-lead">Trzynaście gotowych wzorów 2D i 3D — od prostego kwadratu po rekurencyjne drzewa w przestrzeni.</p>
          </div>
          <div class="filter-group" role="group" aria-label="Filtruj przykłady">
            <button type="button" class="filter-btn is-active" data-filter="all">Wszystkie (13)</button>
            <button type="button" class="filter-btn" data-filter="2d">2D (7)</button>
            <button type="button" class="filter-btn" data-filter="3d">3D (6)</button>
          </div>
        </div>
        <div class="card-grid" id="examples-grid">${cardsHtml}</div>
      </div>
    `;

    this.viewExamples.querySelectorAll<HTMLButtonElement>('[data-load-example]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const id = btn.dataset.loadExample!;
        this.loadExampleWithConfirm(id);
      });
    });

    this.viewExamples.querySelectorAll<HTMLButtonElement>('[data-filter]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const f = btn.dataset.filter!;
        this.viewExamples.querySelectorAll<HTMLButtonElement>('[data-filter]').forEach((b) =>
          b.classList.toggle('is-active', b === btn)
        );
        this.viewExamples.querySelectorAll<HTMLElement>('.example-card').forEach((card) => {
          card.classList.toggle('hidden', f !== 'all' && card.dataset.mode !== f);
        });
      });
    });
  }

  // ---- CHALLENGES PAGE ----
  private renderChallengesView(): void {
    const ch = CHALLENGES.find((c) => c.id === this.selectedChallengeId) || CHALLENGES[0];
    const savedCode = loadChallengeCode(ch.id) ?? ch.starterCode;
    const refSvg = renderSourcePreviewSVG(ch.referenceSolution, ch.mode, 280, 190);

    const listHtml = CHALLENGES.map((item) => {
      const done = this.completedChallenges.has(item.id);
      const selected = item.id === ch.id;
      return `
        <button type="button" class="challenge-item${selected ? ' is-selected' : ''}${done ? ' is-done' : ''}" data-ch-id="${item.id}">
          <span class="ch-status" aria-hidden="true">${done ? '✓' : '○'}</span>
          <span class="ch-meta">
            <strong>${item.title}</strong>
            <small>${item.mode.toUpperCase()} · ${item.difficulty}</small>
          </span>
        </button>
      `;
    }).join('');

    this.viewChallenges.innerHTML = `
      <div class="page-container">
        <div class="page-header">
          <div>
            <h1>Zadania praktyczne</h1>
            <p class="page-lead">Ukończono ${this.completedChallenges.size} z ${CHALLENGES.length} zadań. Postęp zapisuje się lokalnie w przeglądarce.</p>
          </div>
        </div>

        <div class="challenges-layout">
          <aside class="challenge-sidebar" aria-label="Lista zadań">
            ${listHtml}
          </aside>

          <div class="challenge-detail">
            <div class="challenge-card">
              <div class="challenge-head">
                <div>
                  <span class="mode-pill mode-pill-${ch.mode}">${ch.mode.toUpperCase()}</span>
                  <span class="diff-pill">${ch.difficulty}</span>
                  ${this.completedChallenges.has(ch.id) ? '<span class="done-pill">✓ Zaliczono</span>' : ''}
                  <h2>${ch.title}</h2>
                </div>
                <button type="button" class="btn btn-ghost btn-sm" id="ch-open-workspace">Otwórz w pracowni</button>
              </div>
              <p class="ch-instructions">${ch.instructions}</p>

              <details class="ch-hint">
                <summary>Podpowiedź</summary>
                <p>${ch.hint}</p>
              </details>

              <div class="ch-previews">
                <div class="ch-preview-box">
                  <div class="ch-preview-label">Wzór do narysowania</div>
                  <div class="ch-svg-wrap">${refSvg}</div>
                </div>
                <div class="ch-preview-box">
                  <div class="ch-preview-label">Twój rysunek</div>
                  <div class="ch-svg-wrap" id="ch-user-preview"></div>
                </div>
              </div>

              <div class="ch-editor-wrap" id="ch-editor-host"></div>

              <div class="ch-actions">
                <button type="button" class="btn btn-primary" id="ch-check-btn">Sprawdź rozwiązanie</button>
                <button type="button" class="btn btn-secondary" id="ch-preview-btn">Podgląd</button>
                <button type="button" class="btn btn-ghost" id="ch-reset-btn">Wyczyść szkic</button>
              </div>

              <div class="ch-result hidden" id="ch-result" role="status" aria-live="polite"></div>
            </div>
          </div>
        </div>
      </div>
    `;

    const userPreview = this.viewChallenges.querySelector('#ch-user-preview')!;
    const resultEl = this.viewChallenges.querySelector('#ch-result')!;

    this.challengeEditor = new CodeEditor({
      ariaLabel: `Edytor rozwiązania zadania ${ch.title}`,
      onChange: (val) => {
        saveChallengeCode(ch.id, val);
      },
    });
    this.challengeEditor.setValue(savedCode);
    this.viewChallenges.querySelector('#ch-editor-host')!.appendChild(this.challengeEditor.element);

    const updateUserPreview = () => {
      const code = this.challengeEditor!.getValue();
      const run = runProgram(code, ch.mode);
      this.challengeEditor!.setError(run.error);
      userPreview.innerHTML =
        run.segments.length > 0
          ? renderSegmentsSVG(run.segments, ch.mode, 280, 190)
          : '<span class="ch-empty">Kliknij „Podgląd” lub „Sprawdź rozwiązanie”</span>';
    };
    updateUserPreview();

    this.viewChallenges.querySelector('#ch-preview-btn')!.addEventListener('click', updateUserPreview);

    this.viewChallenges.querySelector('#ch-check-btn')!.addEventListener('click', () => {
      const code = this.challengeEditor!.getValue();
      const res = checkChallenge(ch, code);
      this.challengeEditor!.setError(res.error);
      userPreview.innerHTML =
        res.segments.length > 0
          ? renderSegmentsSVG(res.segments, ch.mode, 280, 190)
          : '<span class="ch-empty">Pusty rysunek</span>';

      resultEl.classList.remove('hidden', 'is-pass', 'is-fail');
      resultEl.classList.add(res.passed ? 'is-pass' : 'is-fail');
      resultEl.innerHTML = `<strong>${res.passed ? '✓ Zaliczono!' : '✗ Jeszcze nie tym razem'}</strong> ${res.reason}`;

      if (res.passed) {
        this.completedChallenges = markChallengeCompleted(ch.id);
        this.updateChallengeBadge();
        // Update sidebar tick without losing editor focus
        const btn = this.viewChallenges.querySelector(`[data-ch-id="${ch.id}"]`);
        btn?.classList.add('is-done');
        const st = btn?.querySelector('.ch-status');
        if (st) st.textContent = '✓';
      }
    });

    this.viewChallenges.querySelector('#ch-reset-btn')!.addEventListener('click', () => {
      this.challengeEditor!.setValue(ch.starterCode);
      saveChallengeCode(ch.id, ch.starterCode);
      resultEl.classList.add('hidden');
      updateUserPreview();
    });

    this.viewChallenges.querySelector('#ch-open-workspace')!.addEventListener('click', () => {
      this.loadCustomSnippetWithConfirm(this.challengeEditor!.getValue(), ch.mode, ch.title);
    });

    this.viewChallenges.querySelectorAll<HTMLButtonElement>('[data-ch-id]').forEach((btn) => {
      btn.addEventListener('click', () => {
        this.selectedChallengeId = btn.dataset.chId!;
        this.renderChallengesView();
      });
    });
  }

  // ---- REFERENCE PAGE ----
  private renderReferenceView(): void {
    const cmdRows = COMMAND_DOCS.map(
      (doc, idx) => `
      <tr data-cat="${doc.category}" data-search="${[...doc.polish, ...doc.english, doc.description].join(' ').toLowerCase()}">
        <td>
          <div class="cmd-names">${doc.polish.map((p) => `<code>${p}</code>`).join(' ')}</div>
          <div class="cmd-aliases">${doc.english.map((e) => `<code>${e}</code>`).join(' ')}</div>
        </td>
        <td><span class="arg-pill">${doc.args}</span></td>
        <td>
          ${doc.mode === '3d' ? '<span class="mode-pill mode-pill-3d">3D</span> ' : ''}
          ${doc.description}
        </td>
        <td>
          <pre class="ref-code"><code>${doc.example}</code></pre>
          <button type="button" class="btn btn-ghost btn-xs" data-try-cmd="${idx}">Wypróbuj</button>
        </td>
      </tr>
    `
    ).join('');

    const sectionsHtml = DIALECT_SECTIONS.map(
      (sec) => `
      <section class="ref-section" id="ref-${sec.id}">
        <h2>${sec.title}</h2>
        ${sec.body.map((p) => `<p>${p}</p>`).join('')}
        ${
          sec.code
            ? `<pre class="ref-code-block"><code>${sec.code}</code></pre>`
            : ''
        }
      </section>
    `
    ).join('');

    this.viewReference.innerHTML = `
      <div class="page-container">
        <div class="page-header">
          <div>
            <h1>Podręcznik języka Logomocja</h1>
            <p class="page-lead">Pełny opis dialektu Logo: polecenia 2D i 3D, wyrażenia, zmienne, warunki, procedury i limity.</p>
          </div>
          <div class="ref-search-wrap">
            <label for="ref-search" class="sr-only">Szukaj polecenia</label>
            <input type="search" id="ref-search" class="text-input" placeholder="Szukaj polecenia (np. powtorz, gora)…" />
          </div>
        </div>

        <div class="ref-table-wrap">
          <table class="ref-table">
            <thead>
              <tr>
                <th>Polecenie (PL / EN)</th>
                <th>Argumenty</th>
                <th>Działanie</th>
                <th>Przykład</th>
              </tr>
            </thead>
            <tbody id="ref-tbody">${cmdRows}</tbody>
          </table>
        </div>

        <div class="ref-sections">${sectionsHtml}</div>
      </div>
    `;

    const searchInput = this.viewReference.querySelector<HTMLInputElement>('#ref-search')!;
    searchInput.addEventListener('input', () => {
      const q = searchInput.value.trim().toLowerCase();
      this.viewReference.querySelectorAll<HTMLTableRowElement>('#ref-tbody tr').forEach((tr) => {
        const hay = tr.dataset.search || '';
        tr.classList.toggle('hidden', q !== '' && !hay.includes(q));
      });
    });

    this.viewReference.querySelectorAll<HTMLButtonElement>('[data-try-cmd]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const doc = COMMAND_DOCS[Number(btn.dataset.tryCmd)];
        if (doc) {
          this.loadCustomSnippetWithConfirm(doc.example, doc.mode, doc.polish[0]);
        }
      });
    });
  }
}

const appRoot = document.getElementById('app');
if (appRoot) {
  const app = new LogomocjaApp();
  app.mount(appRoot);
}
