import { Mode } from '../engine';

export interface CommandDoc {
  polish: string[];
  english: string[];
  args: string;
  description: string;
  example: string;
  mode: Mode;
  category: 'ruch' | 'pisak' | 'sterowanie' | 'przestrzen';
}

export const COMMAND_DOCS: CommandDoc[] = [
  {
    polish: ['np', 'naprzod', 'naprzód'],
    english: ['fd', 'forward'],
    args: 'wyrażenie',
    description: 'Przesuwa żółwia naprzód o podaną liczbę jednostek. Jeśli pisak jest opuszczony, rysuje odcinek.',
    example: 'np 100',
    mode: '2d',
    category: 'ruch',
  },
  {
    polish: ['ws', 'wstecz'],
    english: ['bk', 'back'],
    args: 'wyrażenie',
    description: 'Cofa żółwia o podaną liczbę jednostek bez zmiany jego kierunku.',
    example: 'ws 60',
    mode: '2d',
    category: 'ruch',
  },
  {
    polish: ['pw', 'prawo'],
    english: ['rt', 'right'],
    args: 'wyrażenie (stopnie)',
    description: 'Obraca żółwia w prawo (zgodnie ze wskazówkami zegara) o podaną liczbę stopni.',
    example: 'pw 90\nnp 80',
    mode: '2d',
    category: 'ruch',
  },
  {
    polish: ['lw', 'lewo'],
    english: ['lt', 'left'],
    args: 'wyrażenie (stopnie)',
    description: 'Obraca żółwia w lewo (przeciwnie do wskazówek zegara) o podaną liczbę stopni.',
    example: 'lw 45\nnp 80',
    mode: '2d',
    category: 'ruch',
  },
  {
    polish: ['dom'],
    english: ['home'],
    args: 'brak',
    description: 'Wraca żółwiem do początku układu (0, 0, 0) i ustawia początkową orientację. Jeśli pisak jest opuszczony, rysuje linię powrotu.',
    example: 'np 80 pw 90 np 80\ndom',
    mode: '2d',
    category: 'ruch',
  },
  {
    polish: ['pod', 'podnies', 'podnieś'],
    english: ['pu', 'penup'],
    args: 'brak',
    description: 'Podnosi pisak — kolejne ruchy żółwia nie pozostawiają śladu.',
    example: 'np 40\npod np 30 opu\nnp 40',
    mode: '2d',
    category: 'pisak',
  },
  {
    polish: ['opu', 'opusc', 'opuść'],
    english: ['pd', 'pendown'],
    args: 'brak',
    description: 'Opuszcza pisak — żółw znowu rysuje podczas ruchu.',
    example: 'pod np 50\nopu np 60',
    mode: '2d',
    category: 'pisak',
  },
  {
    polish: ['kolor'],
    english: ['color'],
    args: '"#rrggbb"',
    description: 'Zmienia kolor rysowanej linii na podany sześciocyfrowy kod szesnastkowy w cudzysłowie.',
    example: 'kolor "#c1763d"\nnp 100',
    mode: '2d',
    category: 'pisak',
  },
  {
    polish: ['grubosc', 'grubość'],
    english: ['width'],
    args: 'liczba całkowita 1–12',
    description: 'Ustawia grubość linii (liczba całkowita od 1 do 12). Domyślna grubość to 3.',
    example: 'grubosc 8\nnp 100',
    mode: '2d',
    category: 'pisak',
  },
  {
    polish: ['czyść', 'czysc'],
    english: ['cs', 'clearscreen'],
    args: 'brak',
    description: 'Usuwa wszystkie narysowane dotąd odcinki. Nie zmienia położenia żółwia, koloru ani grubości.',
    example: 'np 100\nczyść\npw 90 np 100',
    mode: '2d',
    category: 'pisak',
  },
  {
    polish: ['powtorz', 'powtórz'],
    english: ['repeat'],
    args: 'liczba 0–10000 [ blok ]',
    description: 'Wykonuje polecenia w nawiasach [ ] określoną liczbę razy. Wewnątrz bloku dostępna jest wartość nrpowt (repcount) od 1 do N.',
    example: 'powtorz 4 [\n  np 90\n  pw 90\n]',
    mode: '2d',
    category: 'sterowanie',
  },
  {
    polish: ['niech'],
    english: ['let'],
    args: 'nazwa wyrażenie',
    description: 'Tworzy lub zmienia wartość zmiennej. Na poziomie głównym zmienna jest globalna, wewnątrz procedury — lokalna dla tego wywołania.',
    example: 'niech bok 70\npowtorz 4 [np bok pw 90]',
    mode: '2d',
    category: 'sterowanie',
  },
  {
    polish: ['jeśli', 'jesli'],
    english: ['if'],
    args: 'warunek [ blok ]',
    description: 'Wykonuje blok w nawiasach tylko wtedy, gdy warunek jest prawdziwy.',
    example: 'niech x 5\njeśli x > 3 [np 100]',
    mode: '2d',
    category: 'sterowanie',
  },
  {
    polish: ['jeżeli', 'jezeli'],
    english: ['ifelse'],
    args: 'warunek [ blok1 ] [ blok2 ]',
    description: 'Wykonuje pierwszy blok, gdy warunek jest prawdziwy, a drugi — gdy jest fałszywy.',
    example: 'powtorz 6 [\n  jeżeli nrpowt > 3 [kolor "#c1763d"] [kolor "#16866a"]\n  np 50 pw 60\n]',
    mode: '2d',
    category: 'sterowanie',
  },
  {
    polish: ['stop'],
    english: ['stop'],
    args: 'brak',
    description: 'Natychmiast kończy bieżącą procedurę (nawet z wnętrza pętli lub warunku). Na poziomie głównym kończy cały program.',
    example: 'powtorz 10 [\n  np 30 pw 36\n  jeśli nrpowt = 5 [stop]\n]',
    mode: '2d',
    category: 'sterowanie',
  },
  {
    polish: ['gora', 'góra'],
    english: ['pitchup'],
    args: 'wyrażenie (stopnie)',
    description: 'Tylko 3D: zadziera dziób żółwia w górę o podaną liczbę stopni wokół jego osi poprzecznej.',
    example: 'np 40\ngora 90\nnp 40',
    mode: '3d',
    category: 'przestrzen',
  },
  {
    polish: ['dol', 'dół'],
    english: ['pitchdown'],
    args: 'wyrażenie (stopnie)',
    description: 'Tylko 3D: pochyla dziób żółwia w dół o podaną liczbę stopni.',
    example: 'gora 90 np 50\ndol 90 np 50',
    mode: '3d',
    category: 'przestrzen',
  },
  {
    polish: ['pp', 'przechylprawo'],
    english: ['rr', 'rollright'],
    args: 'wyrażenie (stopnie)',
    description: 'Tylko 3D: przechyla żółwia w prawo (obraca wektor „góra” w stronę prawego boku wokół kierunku ruchu).',
    example: 'pp 45\npowtorz 36 [np 10 gora 10]',
    mode: '3d',
    category: 'przestrzen',
  },
  {
    polish: ['pl', 'przechyllewo'],
    english: ['rl', 'rollleft'],
    args: 'wyrażenie (stopnie)',
    description: 'Tylko 3D: przechyla żółwia w lewo wokół kierunku ruchu.',
    example: 'pl 45\npowtorz 36 [np 10 gora 10]',
    mode: '3d',
    category: 'przestrzen',
  },
];

export const DIALECT_SECTIONS = [
  {
    id: 'wyrazenia',
    title: 'Wyrażenia i liczby',
    body: [
      'Liczby zapisujemy w postaci dziesiętnej: 80, 12.5, .5. Notacja naukowa (1e3), szesnastkowa (0x10) oraz NaN/Infinity są błędami.',
      'Operatory arytmetyczne to +, -, *, / z klasycznym pierwszeństwem (* i / przed + i -) i łącznością lewostronną. Nawiasy ( ) pozwalają grupować działania.',
      'Ważna zasada spacji: operator binarny (+, -, *, /) musi mieć spacje po obu stronach (np 10 - 5) albo po żadnej (np 10-5). Zapis np 10 -5 jest traktowany jako dwa osobne elementy (10 i -5). Zasada nie dotyczy porównań.',
      'Znaki jednoargumentowe + i - można łączyć i stosować przed dowolnym wyrażeniem: np -(3 - 5), np - -2, np -bok.',
      'Komentarze zaczynają się od średnika ; i biegną do końca wiersza.',
    ],
  },
  {
    id: 'zmienne',
    title: 'Zmienne i nrpowt',
    body: [
      'Polecenie niech nazwa wartość przypisuje wartość zmiennej (np. niech bok 60). Kolejne niech zmienia jej wartość.',
      'Zmienne na poziomie głównym są globalne. Zmienne przypisane wewnątrz procedury są lokalne dla tego wywołania i mogą przesłaniać zmienną globalną o tej samej nazwie.',
      'W wyrażeniach można używać nazw bezpośrednio (bok) albo w tradycyjnej postaci z dwukropkiem (:bok).',
      'Wewnątrz bloku powtorz dostępna jest specjalna wartość nrpowt (alias repcount) — numer bieżącego powtórzenia od 1 do N. Działa leksykalnie: musi występować bezpośrednio w ciele pętli powtorz.',
    ],
  },
  {
    id: 'warunki',
    title: 'Warunki',
    body: [
      'Warunek ma postać: wyrażenie operator wyrażenie. Dostępne porównania to <, >, =, <=, >= oraz <> (różne).',
      'Porównania są dokładne (bez zaokrąglania liczb zmiennoprzecinkowych — np. 0.1 + 0.2 = 0.3 jest fałszem).',
      'jeśli warunek [ ... ] wykonuje blok, gdy warunek jest prawdziwy. jeżeli warunek [ ... ] [ ... ] wybiera pierwszy blok dla prawdy, a drugi dla fałszu.',
    ],
  },
  {
    id: 'procedury',
    title: 'Procedury i rekurencja',
    body: [
      'Procedurę definiujemy na poziomie głównym słowem oto (lub to) na początku wiersza i kończymy słowem już (juz, end) stojącym samodzielnie w osobnym wierszu.',
      'Parametry podajemy po ma: oddzielone przecinkami (oto kwadrat ma: bok, kąt) lub w tradycyjnym zapisie z dwukropkami (oto kwadrat :bok :kąt).',
      'Procedury mogą być zdefiniowane przed lub po miejscu wywołania oraz mogą wywoływać się rekurencyjnie. Polecenie stop natychmiast kończy bieżące wywołanie.',
    ],
    code: `oto wielokąt ma: boki, bok
  powtorz boki [np bok pw 360 / boki]
już

wielokąt 5 80`,
  },
  {
    id: 'limity',
    title: 'Ograniczenia i układ współrzędnych',
    body: [
      'Układ współrzędnych jest prawoskrętny: +X w prawo, +Y do przodu (w górę kartki w 2D), +Z w górę nad płaszczyznę.',
      'Żółw startuje w (0, 0, 0), zwrócony w stronę +Y, z prawym bokiem w +X i górą w +Z, z opuszczonym pisakiem, kolorem "#16866a" i grubością 3.',
      'Limity bezpieczeństwa: 50 000 znaków kodu, 10 000 tokenów, głębokość zagnieżdżenia nawiasów [ ] do 32, maksymalnie 32 aktywne ramki wywołań i pętli powtorz, 10 000 wykonanych operacji, 10 000 zachowanych odcinków oraz współrzędne w zakresie ±100 000.',
    ],
  },
];
