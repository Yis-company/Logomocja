import { Mode, runProgram, Segment, Vec3 } from '../engine';

export interface Challenge {
  id: string;
  title: string;
  difficulty: 'Łatwe' | 'Średnie' | 'Trudne';
  mode: Mode;
  summary: string;
  instructions: string;
  hint: string;
  starterCode: string;
  referenceSolution: string;
  allowMirrorX?: boolean;
  tolerance?: number;
}

export interface ChallengeCheckResult {
  passed: boolean;
  reason: string;
  segments: Segment[];
  error: { message: string; line: number; column: number } | null;
}

export const CHALLENGES: Challenge[] = [
  {
    id: 'kwadrat-100',
    title: 'Kwadrat o boku 100',
    difficulty: 'Łatwe',
    mode: '2d',
    summary: 'Narysuj zamknięty kwadrat o boku 100 jednostek.',
    instructions:
      'Zacznij w punkcie (0, 0) i narysuj kwadrat o boku dokładnie 100 jednostek. Możesz skręcać w prawo lub w lewo.',
    hint: 'Użyj powtorz 4 [ np 100 pw 90 ].',
    starterCode: '; Narysuj kwadrat o boku 100\n',
    referenceSolution: 'powtorz 4 [np 100 pw 90]',
    allowMirrorX: true,
    tolerance: 2.0,
  },
  {
    id: 'trojkat-120',
    title: 'Trójkąt równoboczny',
    difficulty: 'Łatwe',
    mode: '2d',
    summary: 'Narysuj trójkąt równoboczny o boku 120 jednostek.',
    instructions:
      'Narysuj trójkąt o trzech równych bokach długości 120 jednostek. Pamiętaj, że żółw skręca o kąt zewnętrzny (120 stopni).',
    hint: 'Powtórz 3 razy: idź naprzód o 120 i skręć o 120 stopni.',
    starterCode: '; Narysuj trójkąt równoboczny o boku 120\n',
    referenceSolution: 'powtorz 3 [np 120 pw 120]',
    allowMirrorX: true,
    tolerance: 2.0,
  },
  {
    id: 'szesciokat-80',
    title: 'Sześciokąt foremny',
    difficulty: 'Średnie',
    mode: '2d',
    summary: 'Narysuj sześciokąt foremny o boku 80 jednostek.',
    instructions:
      'Wykorzystaj pętlę powtorz, aby narysować sześciokąt o boku 80 jednostek. Suma kątów skrętu pełnego obrotu to 360 stopni.',
    hint: 'Kąt skrętu dla sześciokąta to 360 / 6 = 60 stopni.',
    starterCode: '; Narysuj sześciokąt foremny o boku 80\n',
    referenceSolution: 'powtorz 6 [np 80 pw 60]',
    allowMirrorX: true,
    tolerance: 2.0,
  },
  {
    id: 'dwa-kwadraty',
    title: 'Dwa oddzielne kwadraty',
    difficulty: 'Średnie',
    mode: '2d',
    summary: 'Narysuj dwa kwadraty o boku 60 oddzielone przerwą.',
    instructions:
      'Narysuj pierwszy kwadrat o boku 60 (skręcając w prawo). Następnie podnieś pisak (pod), przesuń się o 100 jednostek w prawo (+X), opuść pisak (opu) i narysuj drugi taki sam kwadrat — bez łączenia ich linią.',
    hint: 'Po pierwszym kwadracie obróć się w prawo o 90°, podnieś pisak, idź np 100, obróć się w lewo o 90°, opuść pisak i narysuj drugi kwadrat.',
    starterCode: '; Dwa oddzielne kwadraty o boku 60 (drugi przesunięty o 100 w prawo)\n',
    referenceSolution: `oto kwadrat
  powtorz 4 [np 60 pw 90]
już

kwadrat
pod pw 90 np 100 lw 90 opu
kwadrat`,
    allowMirrorX: false,
    tolerance: 2.0,
  },
  {
    id: 'schodki-3d',
    title: 'Trzy stopnie w 3D',
    difficulty: 'Średnie',
    mode: '3d',
    summary: 'Zbuduj w przestrzeni 3 stopnie schodów.',
    instructions:
      'W trybie 3D narysuj 3 stopnie schodów. Każdy stopień składa się z odcinka 40 jednostek do przodu (+Y), a potem 25 jednostek pionowo w górę (+Z).',
    hint: 'Użyj poleceń gora 90 przed ruchem w górę oraz dol 90 po nim, aby wrócić do poziomu.',
    starterCode: '; Narysuj 3 stopnie: 40 naprzód, 25 w górę\n',
    referenceSolution: `powtorz 3 [
  np 40
  gora 90
  np 25
  dol 90
]`,
    allowMirrorX: false,
    tolerance: 2.0,
  },
  {
    id: 'szescian-80',
    title: 'Sześcian 3D',
    difficulty: 'Trudne',
    mode: '3d',
    summary: 'Narysuj szkielet sześcianu o krawędzi 80 jednostek.',
    instructions:
      'Narysuj wszystkie 12 krawędzi sześcianu o boku 80: dolną podstawę (kwadrat w prawo od (0,0,0)), górną podstawę na wysokości Z = 80 oraz cztery pionowe krawędzie łączące narożniki.',
    hint: 'Narysuj dolny kwadrat, wejdź w górę (gora 90 np 80 dol 90), narysuj górny kwadrat, a następnie w pętli 4 razy zjedź w dół w każdym narożniku.',
    starterCode: '; Narysuj szkielet sześcianu o boku 80\n',
    referenceSolution: `powtorz 4 [np 80 pw 90]
gora 90 np 80 dol 90
powtorz 4 [np 80 pw 90]
powtorz 4 [
  np 80
  dol 90 np 80
  pod ws 80 opu
  gora 90 pw 90
]`,
    allowMirrorX: false,
    tolerance: 2.5,
  },
];

function pointToSegmentDistance(p: Vec3, a: Vec3, b: Vec3): number {
  const abx = b[0] - a[0];
  const aby = b[1] - a[1];
  const abz = b[2] - a[2];
  const apx = p[0] - a[0];
  const apy = p[1] - a[1];
  const apz = p[2] - a[2];
  const lenSq = abx * abx + aby * aby + abz * abz;
  if (lenSq === 0) {
    return Math.hypot(apx, apy, apz);
  }
  const t = Math.max(0, Math.min(1, (apx * abx + apy * aby + apz * abz) / lenSq));
  const cx = a[0] + t * abx;
  const cy = a[1] + t * aby;
  const cz = a[2] + t * abz;
  return Math.hypot(p[0] - cx, p[1] - cy, p[2] - cz);
}

function sampleSegments(segments: Segment[], step = 2.0): Vec3[] {
  const pts: Vec3[] = [];
  for (const s of segments) {
    const len = Math.hypot(
      s.to[0] - s.from[0],
      s.to[1] - s.from[1],
      s.to[2] - s.from[2]
    );
    const n = Math.max(1, Math.ceil(len / step));
    for (let i = 0; i <= n; i += 1) {
      const t = i / n;
      pts.push([
        s.from[0] + (s.to[0] - s.from[0]) * t,
        s.from[1] + (s.to[1] - s.from[1]) * t,
        s.from[2] + (s.to[2] - s.from[2]) * t,
      ]);
    }
  }
  return pts;
}

function directedMaxDistance(samples: Vec3[], targetSegments: Segment[]): number {
  let maxDist = 0;
  for (const p of samples) {
    let minD = Infinity;
    for (const seg of targetSegments) {
      const d = pointToSegmentDistance(p, seg.from, seg.to);
      if (d < minD) minD = d;
      if (minD === 0) break;
    }
    if (minD > maxDist) maxDist = minD;
  }
  return maxDist;
}

function mirrorSegmentsX(segments: Segment[]): Segment[] {
  return segments.map((s) => ({
    ...s,
    from: [-s.from[0], s.from[1], s.from[2]],
    to: [-s.to[0], s.to[1], s.to[2]],
  }));
}

function compareGeometry(
  userSegments: Segment[],
  expectedSegments: Segment[]
): { missingDist: number; extraDist: number } {
  const expectedSamples = sampleSegments(expectedSegments, 2.0);
  const userSamples = sampleSegments(userSegments, 2.0);
  const missingDist = directedMaxDistance(expectedSamples, userSegments);
  const extraDist = directedMaxDistance(userSamples, expectedSegments);
  return { missingDist, extraDist };
}

export function checkChallenge(challenge: Challenge, userSource: string): ChallengeCheckResult {
  const userRun = runProgram(userSource, challenge.mode);
  if (userRun.error) {
    return {
      passed: false,
      reason: `Błąd programu (wiersz ${userRun.error.line}, kolumna ${userRun.error.column}): ${userRun.error.message}`,
      segments: userRun.segments,
      error: userRun.error,
    };
  }

  if (userRun.segments.length === 0) {
    return {
      passed: false,
      reason: 'Rysunek jest pusty. Napisz polecenia, które narysują wymaganą figurę.',
      segments: [],
      error: null,
    };
  }

  const refRun = runProgram(challenge.referenceSolution, challenge.mode);
  const tol = challenge.tolerance ?? 2.0;

  let best = compareGeometry(userRun.segments, refRun.segments);
  if (challenge.allowMirrorX) {
    const mirrored = compareGeometry(userRun.segments, mirrorSegmentsX(refRun.segments));
    if (
      Math.max(mirrored.missingDist, mirrored.extraDist) <
      Math.max(best.missingDist, best.extraDist)
    ) {
      best = mirrored;
    }
  }

  if (best.missingDist <= tol && best.extraDist <= tol) {
    return {
      passed: true,
      reason: 'Świetna robota! Twój rysunek idealnie pasuje do wzoru.',
      segments: userRun.segments,
      error: null,
    };
  }

  const fmt = (n: number) => n.toFixed(1).replace('.', ',');
  if (best.missingDist > tol && best.extraDist <= tol) {
    return {
      passed: false,
      reason: `Brakuje części wzoru (największa luka: ${fmt(best.missingDist)} j.). Sprawdź liczbę powtórzeń i długości boków.`,
      segments: userRun.segments,
      error: null,
    };
  }
  if (best.extraDist > tol && best.missingDist <= tol) {
    return {
      passed: false,
      reason: `Narysowano dodatkowe linie poza wzorem (odchylenie: ${fmt(best.extraDist)} j.). Pamiętaj o poleceniu „pod” przy przenoszeniu żółwia.`,
      segments: userRun.segments,
      error: null,
    };
  }
  return {
    passed: false,
    reason: `Kształt różni się od wzoru (brakująca część: ${fmt(best.missingDist)} j., nadmiarowe linie: ${fmt(best.extraDist)} j.).`,
    segments: userRun.segments,
    error: null,
  };
}
