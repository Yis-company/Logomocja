import { Segment, TurtleState, Vec3 } from '../engine';

const VERT_SRC = `
attribute vec3 aPos;
attribute vec3 aNormal;
attribute vec3 aColor;
uniform mat4 uMvp;
varying vec3 vNormal;
varying vec3 vColor;
void main() {
  gl_Position = uMvp * vec4(aPos, 1.0);
  vNormal = aNormal;
  vColor = aColor;
}
`;

const FRAG_SRC = `
precision mediump float;
varying vec3 vNormal;
varying vec3 vColor;
uniform float uUseLighting;
void main() {
  if (uUseLighting > 0.5) {
    vec3 n = normalize(vNormal);
    vec3 lightDir1 = normalize(vec3(0.45, 0.35, 0.82));
    vec3 lightDir2 = normalize(vec3(-0.6, -0.5, 0.35));
    float d1 = max(dot(n, lightDir1), 0.0);
    float d2 = max(dot(n, lightDir2), 0.0);
    float shade = 0.52 + 0.38 * d1 + 0.16 * d2;
    gl_FragColor = vec4(vColor * min(shade, 1.15), 1.0);
  } else {
    gl_FragColor = vec4(vColor, 1.0);
  }
}
`;

function hexToRgb(hex: string): [number, number, number] {
  const h = hex.startsWith('#') ? hex.slice(1) : hex;
  const n = parseInt(h, 16);
  if (Number.isNaN(n)) return [0.09, 0.53, 0.42];
  return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
}

function mat4Perspective(fovRad: number, aspect: number, near: number, far: number): Float32Array {
  const f = 1.0 / Math.tan(fovRad / 2);
  const nf = 1 / (near - far);
  const out = new Float32Array(16);
  out[0] = f / aspect;
  out[5] = f;
  out[10] = (far + near) * nf;
  out[11] = -1;
  out[14] = 2 * far * near * nf;
  return out;
}

function mat4LookAt(eye: Vec3, target: Vec3, up: Vec3): Float32Array {
  let zx = eye[0] - target[0];
  let zy = eye[1] - target[1];
  let zz = eye[2] - target[2];
  let len = Math.hypot(zx, zy, zz) || 1;
  zx /= len;
  zy /= len;
  zz /= len;

  let xx = up[1] * zz - up[2] * zy;
  let xy = up[2] * zx - up[0] * zz;
  let xz = up[0] * zy - up[1] * zx;
  len = Math.hypot(xx, xy, xz) || 1;
  xx /= len;
  xy /= len;
  xz /= len;

  const yx = zy * xz - zz * xy;
  const yy = zz * xx - zx * xz;
  const yz = zx * xy - zy * xx;

  const out = new Float32Array(16);
  out[0] = xx;
  out[1] = yx;
  out[2] = zx;
  out[3] = 0;
  out[4] = xy;
  out[5] = yy;
  out[6] = zy;
  out[7] = 0;
  out[8] = xz;
  out[9] = yz;
  out[10] = zz;
  out[11] = 0;
  out[12] = -(xx * eye[0] + xy * eye[1] + xz * eye[2]);
  out[13] = -(yx * eye[0] + yy * eye[1] + yz * eye[2]);
  out[14] = -(zx * eye[0] + zy * eye[1] + zz * eye[2]);
  out[15] = 1;
  return out;
}

function mat4Multiply(a: Float32Array, b: Float32Array): Float32Array {
  const out = new Float32Array(16);
  for (let col = 0; col < 4; col += 1) {
    for (let row = 0; row < 4; row += 1) {
      out[col * 4 + row] =
        a[0 * 4 + row] * b[col * 4 + 0] +
        a[1 * 4 + row] * b[col * 4 + 1] +
        a[2 * 4 + row] * b[col * 4 + 2] +
        a[3 * 4 + row] * b[col * 4 + 3];
    }
  }
  return out;
}

function compileShader(gl: WebGLRenderingContext, type: number, src: string): WebGLShader | null {
  const sh = gl.createShader(type);
  if (!sh) return null;
  gl.shaderSource(sh, src);
  gl.compileShader(sh);
  if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
    gl.deleteShader(sh);
    return null;
  }
  return sh;
}

export class Renderer3D {
  public readonly supported: boolean;
  public readonly unavailableReason: string | null = null;

  private canvas: HTMLCanvasElement;
  private gl: WebGLRenderingContext | null = null;
  private program: WebGLProgram | null = null;
  private uMvp: WebGLUniformLocation | null = null;
  private uUseLighting: WebGLUniformLocation | null = null;
  private aPos = -1;
  private aNormal = -1;
  private aColor = -1;

  private gridBuf: WebGLBuffer | null = null;
  private gridVertexCount = 0;
  private segBuf: WebGLBuffer | null = null;
  private segVertexCount = 0;
  private turtleBuf: WebGLBuffer | null = null;

  private segments: Segment[] = [];
  private turtle: TurtleState | null = null;
  private dark = false;
  private segmentsDirty = true;

  // Spherical orbit camera around target (Z-up)
  private yaw = -Math.PI * 0.28;
  private pitch = 0.52;
  private distance = 320;
  private target: Vec3 = [0, 35, 25];

  private dragMode: 'none' | 'orbit' | 'pan' = 'none';
  private lastX = 0;
  private lastY = 0;
  private pinchDist = 0;
  private resizeObserver: ResizeObserver | null = null;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    let gl: WebGLRenderingContext | null = null;
    try {
      gl =
        (canvas.getContext('webgl', {
          antialias: true,
          preserveDrawingBuffer: true,
          alpha: false,
        }) as WebGLRenderingContext | null) ||
        (canvas.getContext('experimental-webgl', {
          antialias: true,
          preserveDrawingBuffer: true,
          alpha: false,
        }) as WebGLRenderingContext | null);
    } catch {
      gl = null;
    }

    if (!gl) {
      this.supported = false;
      this.unavailableReason =
        'Twoja przeglądarka lub urządzenie nie obsługuje WebGL, który jest wymagany do wyświetlania sceny 3D. Tryb 2D działa bez ograniczeń.';
      return;
    }

    const vs = compileShader(gl, gl.VERTEX_SHADER, VERT_SRC);
    const fs = compileShader(gl, gl.FRAGMENT_SHADER, FRAG_SRC);
    if (!vs || !fs) {
      this.supported = false;
      this.unavailableReason =
        'Nie udało się zainicjować shaderów WebGL. Tryb 2D działa bez ograniczeń.';
      return;
    }

    const prog = gl.createProgram();
    if (!prog) {
      this.supported = false;
      this.unavailableReason = 'Nie udało się utworzyć programu WebGL.';
      return;
    }
    gl.attachShader(prog, vs);
    gl.attachShader(prog, fs);
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
      this.supported = false;
      this.unavailableReason = 'Błąd konsolidacji programu WebGL.';
      return;
    }

    this.supported = true;
    this.gl = gl;
    this.program = prog;
    this.uMvp = gl.getUniformLocation(prog, 'uMvp');
    this.uUseLighting = gl.getUniformLocation(prog, 'uUseLighting');
    this.aPos = gl.getAttribLocation(prog, 'aPos');
    this.aNormal = gl.getAttribLocation(prog, 'aNormal');
    this.aColor = gl.getAttribLocation(prog, 'aColor');

    this.gridBuf = gl.createBuffer();
    this.segBuf = gl.createBuffer();
    this.turtleBuf = gl.createBuffer();

    this.rebuildGrid();
    this.bindEvents();
    this.resize();
  }

  public setTheme(dark: boolean): void {
    this.dark = dark;
    if (!this.supported) return;
    this.rebuildGrid();
    this.render();
  }

  public setData(segments: Segment[], turtle: TurtleState | null): void {
    this.segments = segments;
    this.turtle = turtle;
    this.segmentsDirty = true;
    if (!this.supported) return;
    this.render();
  }

  public resize(): void {
    if (!this.supported || !this.gl) return;
    const rect = this.canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = Math.max(1, Math.floor(rect.width * dpr));
    const h = Math.max(1, Math.floor(rect.height * dpr));
    if (this.canvas.width !== w || this.canvas.height !== h) {
      this.canvas.width = w;
      this.canvas.height = h;
    }
    this.gl.viewport(0, 0, w, h);
    this.render();
  }

  public resetView(): void {
    this.yaw = -Math.PI * 0.28;
    this.pitch = 0.52;
    this.distance = 320;
    this.target = [0, 35, 25];
    this.render();
  }

  public zoomBy(factor: number): void {
    this.distance = Math.max(12, Math.min(250000, this.distance / factor));
    this.render();
  }

  public fit(): void {
    if (!this.supported) return;
    if (this.segments.length === 0) {
      this.resetView();
      return;
    }

    let minX = Infinity;
    let maxX = -Infinity;
    let minY = Infinity;
    let maxY = -Infinity;
    let minZ = Infinity;
    let maxZ = -Infinity;

    for (const s of this.segments) {
      minX = Math.min(minX, s.from[0], s.to[0]);
      maxX = Math.max(maxX, s.from[0], s.to[0]);
      minY = Math.min(minY, s.from[1], s.to[1]);
      maxY = Math.max(maxY, s.from[1], s.to[1]);
      minZ = Math.min(minZ, s.from[2], s.to[2]);
      maxZ = Math.max(maxZ, s.from[2], s.to[2]);
    }
    if (this.turtle) {
      minX = Math.min(minX, this.turtle.pos[0]);
      maxX = Math.max(maxX, this.turtle.pos[0]);
      minY = Math.min(minY, this.turtle.pos[1]);
      maxY = Math.max(maxY, this.turtle.pos[1]);
      minZ = Math.min(minZ, this.turtle.pos[2]);
      maxZ = Math.max(maxZ, this.turtle.pos[2]);
    }

    const cx = (minX + maxX) / 2;
    const cy = (minY + maxY) / 2;
    const cz = (minZ + maxZ) / 2;
    const radius = Math.max(
      20,
      Math.hypot(maxX - minX, maxY - minY, maxZ - minZ) * 0.5
    );

    this.target = [cx, cy, cz];
    const fov = (45 * Math.PI) / 180;
    this.distance = Math.max(30, (radius / Math.sin(fov / 2)) * 1.12);
    this.yaw = -Math.PI * 0.28;
    this.pitch = 0.48;
    this.segmentsDirty = true;
    this.render();
  }

  public exportPNG(): string | null {
    if (!this.supported) return null;
    this.render();
    return this.canvas.toDataURL('image/png');
  }

  public destroy(): void {
    this.resizeObserver?.disconnect();
  }

  private getEye(): Vec3 {
    const cp = Math.cos(this.pitch);
    const sp = Math.sin(this.pitch);
    const cy = Math.cos(this.yaw);
    const sy = Math.sin(this.yaw);
    // Offset from target
    return [
      this.target[0] + this.distance * cp * sy * -1,
      this.target[1] - this.distance * cp * cy,
      this.target[2] + this.distance * sp,
    ];
  }

  private panScreen(dx: number, dy: number): void {
    const eye = this.getEye();
    let fx = this.target[0] - eye[0];
    let fy = this.target[1] - eye[1];
    let fz = this.target[2] - eye[2];
    const fl = Math.hypot(fx, fy, fz) || 1;
    fx /= fl;
    fy /= fl;
    fz /= fl;

    // right = normalize(forward x worldUp(0,0,1))
    let rx = fy;
    let ry = -fx;
    let rz = 0;
    const rl = Math.hypot(rx, ry, rz) || 1;
    rx /= rl;
    ry /= rl;

    // camUp = right x forward
    const ux = ry * fz - rz * fy;
    const uy = rz * fx - rx * fz;
    const uz = rx * fy - ry * fx;

    const factor = this.distance * 0.0018;
    this.target = [
      this.target[0] - rx * dx * factor + ux * dy * factor,
      this.target[1] - ry * dx * factor + uy * dy * factor,
      this.target[2] - rz * dx * factor + uz * dy * factor,
    ];
  }

  private bindEvents(): void {
    if (typeof ResizeObserver !== 'undefined') {
      this.resizeObserver = new ResizeObserver(() => this.resize());
      this.resizeObserver.observe(this.canvas);
    }

    this.canvas.addEventListener('contextmenu', (e) => e.preventDefault());

    this.canvas.addEventListener('pointerdown', (e) => {
      if (e.button === 2 || e.button === 1 || e.shiftKey) {
        this.dragMode = 'pan';
      } else if (e.button === 0) {
        this.dragMode = 'orbit';
      } else {
        return;
      }
      this.lastX = e.clientX;
      this.lastY = e.clientY;
      this.canvas.setPointerCapture(e.pointerId);
      this.canvas.style.cursor = 'grabbing';
    });

    this.canvas.addEventListener('pointermove', (e) => {
      if (this.dragMode === 'none') return;
      const dx = e.clientX - this.lastX;
      const dy = e.clientY - this.lastY;
      this.lastX = e.clientX;
      this.lastY = e.clientY;
      if (this.dragMode === 'orbit') {
        this.yaw -= dx * 0.0075;
        this.pitch = Math.max(-1.5, Math.min(1.5, this.pitch + dy * 0.0075));
      } else {
        this.panScreen(dx, dy);
      }
      this.render();
    });

    const endDrag = () => {
      this.dragMode = 'none';
      this.canvas.style.cursor = 'grab';
    };
    this.canvas.addEventListener('pointerup', endDrag);
    this.canvas.addEventListener('pointercancel', endDrag);

    this.canvas.addEventListener(
      'wheel',
      (e) => {
        e.preventDefault();
        const factor = e.deltaY < 0 ? 1.14 : 1 / 1.14;
        this.zoomBy(factor);
      },
      { passive: false }
    );

    this.canvas.addEventListener(
      'touchstart',
      (e) => {
        if (e.touches.length === 2) {
          this.dragMode = 'none';
          this.pinchDist = Math.hypot(
            e.touches[0].clientX - e.touches[1].clientX,
            e.touches[0].clientY - e.touches[1].clientY
          );
          this.lastX = (e.touches[0].clientX + e.touches[1].clientX) / 2;
          this.lastY = (e.touches[0].clientY + e.touches[1].clientY) / 2;
        }
      },
      { passive: true }
    );

    this.canvas.addEventListener(
      'touchmove',
      (e) => {
        if (e.touches.length === 2) {
          e.preventDefault();
          const dist = Math.hypot(
            e.touches[0].clientX - e.touches[1].clientX,
            e.touches[0].clientY - e.touches[1].clientY
          );
          const cx = (e.touches[0].clientX + e.touches[1].clientX) / 2;
          const cy = (e.touches[0].clientY + e.touches[1].clientY) / 2;
          if (this.pinchDist > 0) {
            this.zoomBy(dist / this.pinchDist);
          }
          this.panScreen(cx - this.lastX, cy - this.lastY);
          this.pinchDist = dist;
          this.lastX = cx;
          this.lastY = cy;
          this.render();
        }
      },
      { passive: false }
    );
  }

  private rebuildGrid(): void {
    const gl = this.gl;
    if (!gl || !this.gridBuf) return;

    const verts: number[] = [];
    const pushLine = (a: Vec3, b: Vec3, c: [number, number, number]) => {
      verts.push(a[0], a[1], a[2], 0, 0, 1, c[0], c[1], c[2]);
      verts.push(b[0], b[1], b[2], 0, 0, 1, c[0], c[1], c[2]);
    };

    const gridColor: [number, number, number] = this.dark ? [0.22, 0.28, 0.26] : [0.84, 0.82, 0.78];
    const majorColor: [number, number, number] = this.dark ? [0.30, 0.38, 0.35] : [0.74, 0.71, 0.66];
    const extent = 200;
    const step = 20;

    for (let k = -extent; k <= extent; k += step) {
      if (k === 0) continue;
      const col = k % 100 === 0 ? majorColor : gridColor;
      pushLine([k, -extent, 0], [k, extent, 0], col);
      pushLine([-extent, k, 0], [extent, k, 0], col);
    }

    // Axes: X (terracotta/red), Y (emerald/green), Z (blue)
    const xCol: [number, number, number] = this.dark ? [0.90, 0.48, 0.38] : [0.78, 0.32, 0.24];
    const yCol: [number, number, number] = this.dark ? [0.24, 0.78, 0.62] : [0.09, 0.53, 0.42];
    const zCol: [number, number, number] = this.dark ? [0.40, 0.66, 0.96] : [0.17, 0.44, 0.70];

    pushLine([-extent, 0, 0], [extent, 0, 0], xCol);
    pushLine([0, -extent, 0], [0, extent, 0], yCol);
    pushLine([0, 0, 0], [0, 0, 160], zCol);

    const data = new Float32Array(verts);
    this.gridVertexCount = verts.length / 9;
    gl.bindBuffer(gl.ARRAY_BUFFER, this.gridBuf);
    gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
  }

  private rebuildSegments(): void {
    const gl = this.gl;
    if (!gl || !this.segBuf) return;

    const sides = 6;
    const floatsPerSeg = sides * 6 * 9;
    const data = new Float32Array(this.segments.length * floatsPerSeg);
    let offset = 0;

    const baseRadius = Math.max(0.22, Math.min(2.2, this.distance * 0.0014));

    const cosTable: number[] = [];
    const sinTable: number[] = [];
    for (let s = 0; s < sides; s += 1) {
      const a = (s / sides) * Math.PI * 2;
      cosTable.push(Math.cos(a));
      sinTable.push(Math.sin(a));
    }

    for (const seg of this.segments) {
      const dx = seg.to[0] - seg.from[0];
      const dy = seg.to[1] - seg.from[1];
      const dz = seg.to[2] - seg.from[2];
      const len = Math.hypot(dx, dy, dz);
      if (len < 1e-6) continue;

      const ax = dx / len;
      const ay = dy / len;
      const az = dz / len;

      // Choose a perpendicular vector u
      let ux: number;
      let uy: number;
      let uz: number;
      if (Math.abs(az) < 0.9) {
        // cross(a, (0,0,1)) = (ay, -ax, 0)
        const l = Math.hypot(ay, -ax) || 1;
        ux = ay / l;
        uy = -ax / l;
        uz = 0;
      } else {
        // cross(a, (1,0,0)) = (0, az, -ay)
        const l = Math.hypot(az, -ay) || 1;
        ux = 0;
        uy = az / l;
        uz = -ay / l;
      }

      // v = cross(a, u)
      const vx = ay * uz - az * uy;
      const vy = az * ux - ax * uz;
      const vz = ax * uy - ay * ux;

      const r = baseRadius * (0.35 + seg.width * 0.25);
      const [cr, cg, cb] = hexToRgb(seg.color);

      for (let s = 0; s < sides; s += 1) {
        const s2 = (s + 1) % sides;
        const n1x = ux * cosTable[s] + vx * sinTable[s];
        const n1y = uy * cosTable[s] + vy * sinTable[s];
        const n1z = uz * cosTable[s] + vz * sinTable[s];

        const n2x = ux * cosTable[s2] + vx * sinTable[s2];
        const n2y = uy * cosTable[s2] + vy * sinTable[s2];
        const n2z = uz * cosTable[s2] + vz * sinTable[s2];

        const p1x = seg.from[0] + n1x * r;
        const p1y = seg.from[1] + n1y * r;
        const p1z = seg.from[2] + n1z * r;

        const p2x = seg.from[0] + n2x * r;
        const p2y = seg.from[1] + n2y * r;
        const p2z = seg.from[2] + n2z * r;

        const q1x = seg.to[0] + n1x * r;
        const q1y = seg.to[1] + n1y * r;
        const q1z = seg.to[2] + n1z * r;

        const q2x = seg.to[0] + n2x * r;
        const q2y = seg.to[1] + n2y * r;
        const q2z = seg.to[2] + n2z * r;

        // Triangle 1: p1, p2, q2
        data[offset++] = p1x; data[offset++] = p1y; data[offset++] = p1z;
        data[offset++] = n1x; data[offset++] = n1y; data[offset++] = n1z;
        data[offset++] = cr;  data[offset++] = cg;  data[offset++] = cb;

        data[offset++] = p2x; data[offset++] = p2y; data[offset++] = p2z;
        data[offset++] = n2x; data[offset++] = n2y; data[offset++] = n2z;
        data[offset++] = cr;  data[offset++] = cg;  data[offset++] = cb;

        data[offset++] = q2x; data[offset++] = q2y; data[offset++] = q2z;
        data[offset++] = n2x; data[offset++] = n2y; data[offset++] = n2z;
        data[offset++] = cr;  data[offset++] = cg;  data[offset++] = cb;

        // Triangle 2: p1, q2, q1
        data[offset++] = p1x; data[offset++] = p1y; data[offset++] = p1z;
        data[offset++] = n1x; data[offset++] = n1y; data[offset++] = n1z;
        data[offset++] = cr;  data[offset++] = cg;  data[offset++] = cb;

        data[offset++] = q2x; data[offset++] = q2y; data[offset++] = q2z;
        data[offset++] = n2x; data[offset++] = n2y; data[offset++] = n2z;
        data[offset++] = cr;  data[offset++] = cg;  data[offset++] = cb;

        data[offset++] = q1x; data[offset++] = q1y; data[offset++] = q1z;
        data[offset++] = n1x; data[offset++] = n1y; data[offset++] = n1z;
        data[offset++] = cr;  data[offset++] = cg;  data[offset++] = cb;
      }
    }

    this.segVertexCount = offset / 9;
    gl.bindBuffer(gl.ARRAY_BUFFER, this.segBuf);
    gl.bufferData(gl.ARRAY_BUFFER, data.subarray(0, offset), gl.DYNAMIC_DRAW);
    this.segmentsDirty = false;
  }

  private buildTurtleGeometry(t: TurtleState): Float32Array {
    const size = Math.max(4, this.distance * 0.032);
    const [px, py, pz] = t.pos;
    const [hx, hy, hz] = t.heading;
    const [rx, ry, rz] = t.right;
    const [ux, uy, uz] = t.up;

    const pt = (f: number, r: number, u: number): Vec3 => [
      px + hx * f * size + rx * r * size + ux * u * size,
      py + hy * f * size + ry * r * size + uy * u * size,
      pz + hz * f * size + rz * r * size + uz * u * size,
    ];

    const nose = pt(1.15, 0, 0);
    const leftWing = pt(-0.65, -0.7, 0);
    const rightWing = pt(-0.65, 0.7, 0);
    const tail = pt(-0.3, 0, 0);
    const crest = pt(-0.45, 0, 0.55);
    const belly = pt(-0.35, 0, -0.2);

    const bodyCol: [number, number, number] = t.penDown
      ? hexToRgb(t.color)
      : [0.55, 0.62, 0.60];
    const finCol: [number, number, number] = this.dark ? [0.95, 0.65, 0.36] : [0.76, 0.46, 0.24];

    const verts: number[] = [];
    const tri = (a: Vec3, b: Vec3, c: Vec3, col: [number, number, number]) => {
      const abx = b[0] - a[0], aby = b[1] - a[1], abz = b[2] - a[2];
      const acx = c[0] - a[0], acy = c[1] - a[1], acz = c[2] - a[2];
      let nx = aby * acz - abz * acy;
      let ny = abz * acx - abx * acz;
      let nz = abx * acy - aby * acx;
      const nl = Math.hypot(nx, ny, nz) || 1;
      nx /= nl; ny /= nl; nz /= nl;
      verts.push(a[0], a[1], a[2], nx, ny, nz, col[0], col[1], col[2]);
      verts.push(b[0], b[1], b[2], nx, ny, nz, col[0], col[1], col[2]);
      verts.push(c[0], c[1], c[2], nx, ny, nz, col[0], col[1], col[2]);
    };

    // Upper shell
    tri(nose, leftWing, crest, bodyCol);
    tri(nose, crest, rightWing, bodyCol);
    tri(leftWing, tail, crest, bodyCol);
    tri(tail, rightWing, crest, bodyCol);
    // Lower shell
    tri(nose, belly, leftWing, bodyCol);
    tri(nose, rightWing, belly, bodyCol);
    tri(leftWing, belly, tail, bodyCol);
    tri(tail, belly, rightWing, bodyCol);
    // Dorsal fin (shows +Up clearly)
    const finTip = pt(-0.35, 0, 0.92);
    const finFront = pt(0.35, 0, 0.12);
    tri(finFront, crest, finTip, finCol);
    tri(finFront, finTip, crest, finCol);

    return new Float32Array(verts);
  }

  private bindAttributes(): void {
    const gl = this.gl!;
    const stride = 9 * 4;
    gl.enableVertexAttribArray(this.aPos);
    gl.vertexAttribPointer(this.aPos, 3, gl.FLOAT, false, stride, 0);
    gl.enableVertexAttribArray(this.aNormal);
    gl.vertexAttribPointer(this.aNormal, 3, gl.FLOAT, false, stride, 3 * 4);
    gl.enableVertexAttribArray(this.aColor);
    gl.vertexAttribPointer(this.aColor, 3, gl.FLOAT, false, stride, 6 * 4);
  }

  public render(): void {
    const gl = this.gl;
    if (!this.supported || !gl || !this.program) return;

    if (this.segmentsDirty) {
      this.rebuildSegments();
    }

    if (this.dark) {
      gl.clearColor(0.075, 0.098, 0.094, 1);
    } else {
      gl.clearColor(0.98, 0.972, 0.953, 1);
    }
    gl.enable(gl.DEPTH_TEST);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    gl.useProgram(this.program);

    const aspect = this.canvas.width / Math.max(1, this.canvas.height);
    const near = Math.max(0.5, this.distance * 0.004);
    const far = Math.max(4000, this.distance * 15);
    const proj = mat4Perspective((45 * Math.PI) / 180, aspect, near, far);
    const view = mat4LookAt(this.getEye(), this.target, [0, 0, 1]);
    const mvp = mat4Multiply(proj, view);
    gl.uniformMatrix4fv(this.uMvp, false, mvp);

    // 1. Grid & axes (unlit)
    gl.uniform1f(this.uUseLighting, 0.0);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.gridBuf);
    this.bindAttributes();
    gl.drawArrays(gl.LINES, 0, this.gridVertexCount);

    // 2. 3D stroke tubes (lit)
    if (this.segVertexCount > 0) {
      gl.uniform1f(this.uUseLighting, 1.0);
      gl.bindBuffer(gl.ARRAY_BUFFER, this.segBuf);
      this.bindAttributes();
      gl.drawArrays(gl.TRIANGLES, 0, this.segVertexCount);
    }

    // 3. 3D turtle marker (lit)
    if (this.turtle && this.turtleBuf) {
      const tData = this.buildTurtleGeometry(this.turtle);
      gl.uniform1f(this.uUseLighting, 1.0);
      gl.bindBuffer(gl.ARRAY_BUFFER, this.turtleBuf);
      gl.bufferData(gl.ARRAY_BUFFER, tData, gl.DYNAMIC_DRAW);
      this.bindAttributes();
      gl.drawArrays(gl.TRIANGLES, 0, tData.length / 9);
    }
  }
}
