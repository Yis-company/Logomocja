import { Segment, TurtleState } from '../engine';

export interface View2DTheme {
  bg: string;
  gridMinor: string;
  gridMajor: string;
  axis: string;
  origin: string;
  label: string;
  turtleStroke: string;
  turtleFill: string;
  turtlePenUp: string;
}

const LIGHT_THEME: View2DTheme = {
  bg: '#faf8f3',
  gridMinor: 'rgba(30, 36, 33, 0.055)',
  gridMajor: 'rgba(30, 36, 33, 0.11)',
  axis: 'rgba(22, 134, 106, 0.38)',
  origin: '#16866a',
  label: 'rgba(30, 36, 33, 0.45)',
  turtleStroke: '#122620',
  turtleFill: '#16866a',
  turtlePenUp: 'rgba(22, 134, 106, 0.25)',
};

const DARK_THEME: View2DTheme = {
  bg: '#131918',
  gridMinor: 'rgba(232, 238, 233, 0.045)',
  gridMajor: 'rgba(232, 238, 233, 0.10)',
  axis: 'rgba(42, 181, 146, 0.40)',
  origin: '#2ab592',
  label: 'rgba(232, 238, 233, 0.42)',
  turtleStroke: '#e8eee9',
  turtleFill: '#2ab592',
  turtlePenUp: 'rgba(42, 181, 146, 0.22)',
};

export class Renderer2D {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private segments: Segment[] = [];
  private turtle: TurtleState | null = null;
  private dark = false;

  // Camera: world (0, 0) maps to screen (width/2 + panX, height/2 + panY)
  // World +Y goes UP on screen (screenY = height/2 + panY - worldY * scale)
  private scale = 1.4;
  private panX = 0;
  private panY = 0;

  private dragging = false;
  private lastX = 0;
  private lastY = 0;
  private pinchDist = 0;
  private resizeObserver: ResizeObserver | null = null;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      throw new Error('Nie można utworzyć kontekstu 2D.');
    }
    this.ctx = ctx;
    this.bindEvents();
    this.resize();
  }

  public setTheme(dark: boolean): void {
    this.dark = dark;
    this.render();
  }

  public setData(segments: Segment[], turtle: TurtleState | null): void {
    this.segments = segments;
    this.turtle = turtle;
    this.render();
  }

  public resize(): void {
    const rect = this.canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = Math.max(1, Math.floor(rect.width * dpr));
    const h = Math.max(1, Math.floor(rect.height * dpr));
    if (this.canvas.width !== w || this.canvas.height !== h) {
      this.canvas.width = w;
      this.canvas.height = h;
    }
    this.render();
  }

  public resetView(): void {
    this.scale = 1.4;
    this.panX = 0;
    this.panY = 0;
    this.render();
  }

  public zoomBy(factor: number, cx?: number, cy?: number): void {
    const rect = this.canvas.getBoundingClientRect();
    const w = rect.width || 1;
    const h = rect.height || 1;
    const px = cx ?? w / 2;
    const py = cy ?? h / 2;

    const worldX = (px - w / 2 - this.panX) / this.scale;
    const worldY = -(py - h / 2 - this.panY) / this.scale;

    const nextScale = Math.max(0.02, Math.min(80, this.scale * factor));
    this.scale = nextScale;
    this.panX = px - w / 2 - worldX * this.scale;
    this.panY = py - h / 2 + worldY * this.scale;
    this.render();
  }

  public fit(): void {
    const rect = this.canvas.getBoundingClientRect();
    const w = rect.width || 400;
    const h = rect.height || 400;

    if (this.segments.length === 0) {
      this.resetView();
      return;
    }

    let minX = Infinity;
    let maxX = -Infinity;
    let minY = Infinity;
    let maxY = -Infinity;

    for (const s of this.segments) {
      minX = Math.min(minX, s.from[0], s.to[0]);
      maxX = Math.max(maxX, s.from[0], s.to[0]);
      minY = Math.min(minY, s.from[1], s.to[1]);
      maxY = Math.max(maxY, s.from[1], s.to[1]);
    }
    if (this.turtle) {
      minX = Math.min(minX, this.turtle.pos[0]);
      maxX = Math.max(maxX, this.turtle.pos[0]);
      minY = Math.min(minY, this.turtle.pos[1]);
      maxY = Math.max(maxY, this.turtle.pos[1]);
    }

    const spanX = Math.max(20, maxX - minX);
    const spanY = Math.max(20, maxY - minY);
    const pad = 48;
    const availW = Math.max(80, w - pad * 2);
    const availH = Math.max(80, h - pad * 2);

    this.scale = Math.max(0.02, Math.min(12, Math.min(availW / spanX, availH / spanY)));
    const midX = (minX + maxX) / 2;
    const midY = (minY + maxY) / 2;
    this.panX = -midX * this.scale;
    this.panY = midY * this.scale;
    this.render();
  }

  public exportPNG(): string {
    this.render();
    return this.canvas.toDataURL('image/png');
  }

  public destroy(): void {
    this.resizeObserver?.disconnect();
  }

  private bindEvents(): void {
    if (typeof ResizeObserver !== 'undefined') {
      this.resizeObserver = new ResizeObserver(() => this.resize());
      this.resizeObserver.observe(this.canvas);
    }

    this.canvas.addEventListener('pointerdown', (e) => {
      if (e.button !== 0 && e.button !== 1) return;
      this.dragging = true;
      this.lastX = e.clientX;
      this.lastY = e.clientY;
      this.canvas.setPointerCapture(e.pointerId);
      this.canvas.style.cursor = 'grabbing';
    });

    this.canvas.addEventListener('pointermove', (e) => {
      if (!this.dragging) return;
      const dx = e.clientX - this.lastX;
      const dy = e.clientY - this.lastY;
      this.lastX = e.clientX;
      this.lastY = e.clientY;
      this.panX += dx;
      this.panY += dy;
      this.render();
    });

    const endDrag = () => {
      this.dragging = false;
      this.canvas.style.cursor = 'grab';
    };
    this.canvas.addEventListener('pointerup', endDrag);
    this.canvas.addEventListener('pointercancel', endDrag);

    this.canvas.addEventListener(
      'wheel',
      (e) => {
        e.preventDefault();
        const rect = this.canvas.getBoundingClientRect();
        const factor = e.deltaY < 0 ? 1.14 : 1 / 1.14;
        this.zoomBy(factor, e.clientX - rect.left, e.clientY - rect.top);
      },
      { passive: false }
    );

    // Touch pinch zoom
    this.canvas.addEventListener(
      'touchstart',
      (e) => {
        if (e.touches.length === 2) {
          this.dragging = false;
          this.pinchDist = Math.hypot(
            e.touches[0].clientX - e.touches[1].clientX,
            e.touches[0].clientY - e.touches[1].clientY
          );
        }
      },
      { passive: true }
    );

    this.canvas.addEventListener(
      'touchmove',
      (e) => {
        if (e.touches.length === 2) {
          e.preventDefault();
          const dist = Math.hypot(
            e.touches[0].clientX - e.touches[1].clientX,
            e.touches[0].clientY - e.touches[1].clientY
          );
          if (this.pinchDist > 0) {
            const rect = this.canvas.getBoundingClientRect();
            const cx = (e.touches[0].clientX + e.touches[1].clientX) / 2 - rect.left;
            const cy = (e.touches[0].clientY + e.touches[1].clientY) / 2 - rect.top;
            this.zoomBy(dist / this.pinchDist, cx, cy);
          }
          this.pinchDist = dist;
        }
      },
      { passive: false }
    );
  }

  private pickGridStep(): number {
    const targetPx = 44;
    const raw = targetPx / this.scale;
    const pow = Math.pow(10, Math.floor(Math.log10(raw)));
    const norm = raw / pow;
    if (norm < 2) return pow;
    if (norm < 5) return 2 * pow;
    return 5 * pow;
  }

  public render(): void {
    const ctx = this.ctx;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = this.canvas.width / dpr;
    const h = this.canvas.height / dpr;
    const theme = this.dark ? DARK_THEME : LIGHT_THEME;

    ctx.save();
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    // Background
    ctx.fillStyle = theme.bg;
    ctx.fillRect(0, 0, w, h);

    const originX = w / 2 + this.panX;
    const originY = h / 2 + this.panY;

    // Grid
    const step = this.pickGridStep();
    const minWorldX = -originX / this.scale;
    const maxWorldX = (w - originX) / this.scale;
    const minWorldY = -(h - originY) / this.scale;
    const maxWorldY = originY / this.scale;

    const startX = Math.floor(minWorldX / step) * step;
    const startY = Math.floor(minWorldY / step) * step;

    ctx.lineWidth = 1;
    for (let gx = startX; gx <= maxWorldX; gx += step) {
      const sx = Math.round(originX + gx * this.scale) + 0.5;
      const isMajor = Math.abs(Math.round(gx / step)) % 5 === 0;
      ctx.strokeStyle = isMajor ? theme.gridMajor : theme.gridMinor;
      ctx.beginPath();
      ctx.moveTo(sx, 0);
      ctx.lineTo(sx, h);
      ctx.stroke();
    }
    for (let gy = startY; gy <= maxWorldY; gy += step) {
      const sy = Math.round(originY - gy * this.scale) + 0.5;
      const isMajor = Math.abs(Math.round(gy / step)) % 5 === 0;
      ctx.strokeStyle = isMajor ? theme.gridMajor : theme.gridMinor;
      ctx.beginPath();
      ctx.moveTo(0, sy);
      ctx.lineTo(w, sy);
      ctx.stroke();
    }

    // Axes through origin
    ctx.strokeStyle = theme.axis;
    ctx.lineWidth = 1.25;
    ctx.beginPath();
    ctx.moveTo(0, originY);
    ctx.lineTo(w, originY);
    ctx.moveTo(originX, 0);
    ctx.lineTo(originX, h);
    ctx.stroke();

    // Visible origin marker (0, 0)
    ctx.fillStyle = theme.origin;
    ctx.beginPath();
    ctx.arc(originX, originY, 3.5, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = theme.label;
    ctx.font = '11px ui-monospace, SFMono-Regular, Menlo, monospace';
    ctx.fillText('(0, 0)', originX + 7, originY + 14);
    ctx.fillText('+X', w - 24, Math.max(14, Math.min(h - 8, originY - 6)));
    ctx.fillText('+Y', Math.max(6, Math.min(w - 24, originX + 6)), 14);

    // Drawn segments
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    for (const seg of this.segments) {
      const x1 = originX + seg.from[0] * this.scale;
      const y1 = originY - seg.from[1] * this.scale;
      const x2 = originX + seg.to[0] * this.scale;
      const y2 = originY - seg.to[1] * this.scale;
      ctx.strokeStyle = seg.color;
      ctx.lineWidth = Math.max(1, seg.width * Math.min(1.8, Math.max(0.55, Math.sqrt(this.scale))));
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
    }

    // Turtle marker
    if (this.turtle) {
      const tx = originX + this.turtle.pos[0] * this.scale;
      const ty = originY - this.turtle.pos[1] * this.scale;
      const angle = Math.atan2(this.turtle.heading[0], this.turtle.heading[1]);

      ctx.save();
      ctx.translate(tx, ty);
      ctx.rotate(angle);

      // Stylized turtle chevron/shell
      ctx.beginPath();
      ctx.moveTo(0, -13);
      ctx.lineTo(9, 9);
      ctx.lineTo(0, 5);
      ctx.lineTo(-9, 9);
      ctx.closePath();

      ctx.fillStyle = this.turtle.penDown ? this.turtle.color : theme.turtlePenUp;
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.strokeStyle = theme.turtleStroke;
      ctx.stroke();

      // Small nose dot
      ctx.fillStyle = theme.turtleStroke;
      ctx.beginPath();
      ctx.arc(0, -13, 2, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();
    }

    ctx.restore();
  }
}
