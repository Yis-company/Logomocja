import { Mode } from '../engine';

function toBase64Url(str: string): string {
  const bytes = new TextEncoder().encode(str);
  let bin = '';
  for (let i = 0; i < bytes.length; i += 1) {
    bin += String.fromCharCode(bytes[i]);
  }
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

function fromBase64Url(encoded: string): string | null {
  try {
    const padded = encoded.replace(/-/g, '+').replace(/_/g, '/');
    const padLen = (4 - (padded.length % 4)) % 4;
    const bin = atob(padded + '='.repeat(padLen));
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i += 1) {
      bytes[i] = bin.charCodeAt(i);
    }
    return new TextDecoder().decode(bytes);
  } catch {
    return null;
  }
}

export function buildPermalink(source: string, mode: Mode): string {
  const encoded = toBase64Url(source);
  const base = window.location.href.split('#')[0].split('?')[0];
  return `${base}#/?mode=${mode}&code=${encoded}`;
}

export function parsePermalinkFromLocation(): { source: string; mode: Mode } | null {
  const hash = window.location.hash || '';
  const qIdx = hash.indexOf('?');
  const params =
    qIdx >= 0
      ? new URLSearchParams(hash.slice(qIdx + 1))
      : new URLSearchParams(window.location.search);

  const code = params.get('code');
  if (!code) return null;
  const decoded = fromBase64Url(code);
  if (decoded === null) return null;
  const modeParam = params.get('mode');
  const mode: Mode = modeParam === '3d' ? '3d' : '2d';
  return { source: decoded, mode };
}
