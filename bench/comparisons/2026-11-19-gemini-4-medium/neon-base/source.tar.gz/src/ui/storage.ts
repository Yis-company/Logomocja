import { Mode } from '../engine';

const KEYS = {
  DRAFT_2D: 'logomocja.draft.2d',
  DRAFT_3D: 'logomocja.draft.3d',
  DIRTY_2D: 'logomocja.dirty.2d',
  DIRTY_3D: 'logomocja.dirty.3d',
  MODE: 'logomocja.mode',
  THEME: 'logomocja.theme',
  CHALLENGES_DONE: 'logomocja.challenges.done',
  CHALLENGE_CODE_PREFIX: 'logomocja.challenge.code.',
};

export type ThemePref = 'system' | 'light' | 'dark';

function safeGet(key: string): string | null {
  try {
    return window.localStorage.getItem(key);
  } catch {
    return null;
  }
}

function safeSet(key: string, value: string): void {
  try {
    window.localStorage.setItem(key, value);
  } catch {
    // Ignore storage quota or private mode errors
  }
}

export function loadDraft(mode: Mode): string | null {
  return safeGet(mode === '2d' ? KEYS.DRAFT_2D : KEYS.DRAFT_3D);
}

export function saveDraft(mode: Mode, source: string, dirty: boolean): void {
  safeSet(mode === '2d' ? KEYS.DRAFT_2D : KEYS.DRAFT_3D, source);
  safeSet(mode === '2d' ? KEYS.DIRTY_2D : KEYS.DIRTY_3D, dirty ? '1' : '0');
}

export function isDraftDirty(mode: Mode): boolean {
  return safeGet(mode === '2d' ? KEYS.DIRTY_2D : KEYS.DIRTY_3D) === '1';
}

export function loadSavedMode(): Mode {
  const m = safeGet(KEYS.MODE);
  return m === '3d' ? '3d' : '2d';
}

export function saveMode(mode: Mode): void {
  safeSet(KEYS.MODE, mode);
}

export function loadThemePref(): ThemePref {
  const t = safeGet(KEYS.THEME);
  if (t === 'light' || t === 'dark') return t;
  return 'system';
}

export function saveThemePref(pref: ThemePref): void {
  safeSet(KEYS.THEME, pref);
}

export function loadCompletedChallenges(): Set<string> {
  const raw = safeGet(KEYS.CHALLENGES_DONE);
  if (!raw) return new Set();
  try {
    const arr = JSON.parse(raw);
    if (Array.isArray(arr)) {
      return new Set(arr.filter((x): x is string => typeof x === 'string'));
    }
  } catch {
    // ignore
  }
  return new Set();
}

export function markChallengeCompleted(id: string): Set<string> {
  const set = loadCompletedChallenges();
  set.add(id);
  safeSet(KEYS.CHALLENGES_DONE, JSON.stringify([...set]));
  return set;
}

export function loadChallengeCode(id: string): string | null {
  return safeGet(KEYS.CHALLENGE_CODE_PREFIX + id);
}

export function saveChallengeCode(id: string, code: string): void {
  safeSet(KEYS.CHALLENGE_CODE_PREFIX + id, code);
}
