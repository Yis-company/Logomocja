import { Mode, runProgram, Segment } from '../engine';

function projectPoint(p: [number, number, number], mode: Mode): [number, number] {
  if (mode === '2d') {
    return [p[0], -p[1]];
  }
  // Clean isometric projection for 3D thumbnails (+Z up)
  const yaw = -Math.PI * 0.25;
  const pitch = 0.52;
  const cy = Math.cos(yaw);
  const sy = Math.sin(yaw);
  const rx = p[0] * cy - p[1] * sy;
  const ry = p[0] * sy + p[1] * cy;
  const sx = rx;
  const syProj = -(ry * Math.sin(pitch) + p[2] * Math.cos(pitch));
  return [sx, syProj];
}

export function renderSegmentsSVG(
  segments: Segment[],
  mode: Mode,
  width = 240,
  height = 150
): string {
  if (segments.length === 0) {
    return `<svg viewBox="0 0 ${width} ${height}" width="${width}" height="${height}" aria-hidden="true"></svg>`;
  }

  let minX = Infinity;
  let maxX = -Infinity;
  let minY = Infinity;
  let maxY = -Infinity;

  const projected: Array<{ x1: number; y1: number; x2: number; y2: number; color: string; width: number }> = [];

  for (const s of segments) {
    const [x1, y1] = projectPoint(s.from, mode);
    const [x2, y2] = projectPoint(s.to, mode);
    minX = Math.min(minX, x1, x2);
    maxX = Math.max(maxX, x1, x2);
    minY = Math.min(minY, y1, y2);
    maxY = Math.max(maxY, y1, y2);
    projected.push({ x1, y1, x2, y2, color: s.color, width: s.width });
  }

  const pad = 16;
  const spanX = Math.max(10, maxX - minX);
  const spanY = Math.max(10, maxY - minY);
  const scale = Math.min((width - pad * 2) / spanX, (height - pad * 2) / spanY);
  const ox = width / 2 - ((minX + maxX) / 2) * scale;
  const oy = height / 2 - ((minY + maxY) / 2) * scale;

  let lines = '';
  for (const p of projected) {
    const sw = Math.max(1, Math.min(3.5, p.width * 0.65));
    lines += `<line x1="${(ox + p.x1 * scale).toFixed(1)}" y1="${(oy + p.y1 * scale).toFixed(1)}" x2="${(ox + p.x2 * scale).toFixed(1)}" y2="${(oy + p.y2 * scale).toFixed(1)}" stroke="${p.color}" stroke-width="${sw.toFixed(1)}" stroke-linecap="round"/>`;
  }

  return `<svg viewBox="0 0 ${width} ${height}" class="thumb-svg" aria-hidden="true">${lines}</svg>`;
}

export function renderSourcePreviewSVG(source: string, mode: Mode, width = 240, height = 150): string {
  const res = runProgram(source, mode);
  return renderSegmentsSVG(res.segments, mode, width, height);
}
