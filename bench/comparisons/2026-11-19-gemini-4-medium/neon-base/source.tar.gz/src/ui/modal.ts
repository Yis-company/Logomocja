export interface ConfirmOptions {
  title: string;
  body: string;
  confirmLabel: string;
  cancelLabel?: string;
  secondaryLabel?: string;
  onSecondary?: () => void;
}

export function showConfirmDialog(opts: ConfirmOptions): Promise<boolean> {
  return new Promise((resolve) => {
    const prevFocus = document.activeElement as HTMLElement | null;
    const backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop';
    backdrop.setAttribute('role', 'dialog');
    backdrop.setAttribute('aria-modal', 'true');
    backdrop.setAttribute('aria-labelledby', 'modal-title');

    const box = document.createElement('div');
    box.className = 'modal-box';
    box.innerHTML = `
      <h2 id="modal-title" class="modal-title"></h2>
      <p class="modal-body"></p>
      <div class="modal-actions">
        <button type="button" class="btn btn-ghost" data-act="cancel"></button>
        ${opts.secondaryLabel ? `<button type="button" class="btn btn-secondary" data-act="secondary"></button>` : ''}
        <button type="button" class="btn btn-primary" data-act="confirm"></button>
      </div>
    `;
    box.querySelector('.modal-title')!.textContent = opts.title;
    box.querySelector('.modal-body')!.textContent = opts.body;
    box.querySelector('[data-act="cancel"]')!.textContent = opts.cancelLabel ?? 'Anuluj';
    box.querySelector('[data-act="confirm"]')!.textContent = opts.confirmLabel;
    if (opts.secondaryLabel) {
      box.querySelector('[data-act="secondary"]')!.textContent = opts.secondaryLabel;
    }

    backdrop.appendChild(box);
    document.body.appendChild(backdrop);

    const close = (result: boolean) => {
      document.removeEventListener('keydown', onKey);
      backdrop.remove();
      prevFocus?.focus();
      resolve(result);
    };

    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        close(false);
      }
    };
    document.addEventListener('keydown', onKey);

    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) close(false);
    });
    box.querySelector('[data-act="cancel"]')!.addEventListener('click', () => close(false));
    box.querySelector('[data-act="confirm"]')!.addEventListener('click', () => close(true));
    box.querySelector('[data-act="secondary"]')?.addEventListener('click', () => {
      opts.onSecondary?.();
    });

    (box.querySelector('[data-act="confirm"]') as HTMLButtonElement).focus();
  });
}

export function showShortcutsDialog(): void {
  const prevFocus = document.activeElement as HTMLElement | null;
  const backdrop = document.createElement('div');
  backdrop.className = 'modal-backdrop';
  backdrop.setAttribute('role', 'dialog');
  backdrop.setAttribute('aria-modal', 'true');
  backdrop.setAttribute('aria-labelledby', 'shortcuts-title');

  const box = document.createElement('div');
  box.className = 'modal-box';
  box.innerHTML = `
    <h2 id="shortcuts-title" class="modal-title">Skróty klawiszowe</h2>
    <dl class="shortcuts-list">
      <div><dt><kbd>Ctrl</kbd> / <kbd>⌘</kbd> + <kbd>Enter</kbd></dt><dd>Uruchom program</dd></div>
      <div><dt><kbd>Alt</kbd> + <kbd>S</kbd> lub <kbd>F10</kbd></dt><dd>Wykonaj jeden krok</dd></div>
      <div><dt><kbd>Alt</kbd> + <kbd>P</kbd></dt><dd>Wstrzymaj lub wznów wykonywanie</dd></div>
      <div><dt><kbd>Alt</kbd> + <kbd>R</kbd></dt><dd>Resetuj rysunek i żółwia</dd></div>
      <div><dt><kbd>Alt</kbd> + <kbd>F</kbd></dt><dd>Dopasuj widok do rysunku</dd></div>
      <div><dt><kbd>Tab</kbd> (w edytorze)</dt><dd>Wstaw dwie spacje wcięcia</dd></div>
    </dl>
    <div class="modal-actions">
      <button type="button" class="btn btn-primary" data-act="close">Zamknij</button>
    </div>
  `;

  backdrop.appendChild(box);
  document.body.appendChild(backdrop);

  const close = () => {
    document.removeEventListener('keydown', onKey);
    backdrop.remove();
    prevFocus?.focus();
  };
  const onKey = (e: KeyboardEvent) => {
    if (e.key === 'Escape') {
      e.preventDefault();
      close();
    }
  };
  document.addEventListener('keydown', onKey);
  backdrop.addEventListener('click', (e) => {
    if (e.target === backdrop) close();
  });
  box.querySelector('[data-act="close"]')!.addEventListener('click', close);
  (box.querySelector('[data-act="close"]') as HTMLButtonElement).focus();
}
