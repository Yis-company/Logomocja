import {
  COMMAND_ALIASES,
  LogoError,
  PROC_END_KEYWORDS,
  PROC_START_KEYWORDS,
  REPCOUNT_KEYWORDS,
} from '../engine';

const THREE_D_CMDS = new Set([
  'gora',
  'góra',
  'pitchup',
  'dol',
  'dół',
  'pitchdown',
  'pp',
  'przechylprawo',
  'rr',
  'rollright',
  'pl',
  'przechyllewo',
  'rl',
  'rollleft',
]);

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function highlightLineTokens(line: string): string {
  let out = '';
  let i = 0;
  const len = line.length;

  while (i < len) {
    const ch = line[i];

    // Comment
    if (ch === ';') {
      out += `<span class="tok-comment">${escapeHtml(line.slice(i))}</span>`;
      break;
    }

    // String / colour literal
    if (ch === '"') {
      let j = i + 1;
      while (j < len && line[j] !== '"') j += 1;
      if (j < len) j += 1;
      const raw = line.slice(i, j);
      const inner = raw.slice(1, raw.endsWith('"') ? -1 : raw.length);
      const isHex = /^#[0-9a-fA-F]{6}$/.test(inner);
      if (isHex) {
        out += `<span class="tok-string tok-color" style="--swatch:${inner}">${escapeHtml(raw)}</span>`;
      } else {
        out += `<span class="tok-string">${escapeHtml(raw)}</span>`;
      }
      i = j;
      continue;
    }

    // Brackets & parens
    if (ch === '[' || ch === ']' || ch === '(' || ch === ')') {
      out += `<span class="tok-bracket">${escapeHtml(ch)}</span>`;
      i += 1;
      continue;
    }

    // Operators & comparisons
    if ('+-*/<>=,'.includes(ch)) {
      out += `<span class="tok-op">${escapeHtml(ch)}</span>`;
      i += 1;
      continue;
    }

    // Numbers
    if (
      (ch >= '0' && ch <= '9') ||
      (ch === '.' && i + 1 < len && line[i + 1] >= '0' && line[i + 1] <= '9')
    ) {
      let j = i;
      while (j < len && ((line[j] >= '0' && line[j] <= '9') || line[j] === '.')) {
        j += 1;
      }
      out += `<span class="tok-number">${escapeHtml(line.slice(i, j))}</span>`;
      i = j;
      continue;
    }

    // :name
    if (ch === ':' && i + 1 < len && /[\p{L}_]/u.test(line[i + 1])) {
      let j = i + 1;
      while (j < len && /[\p{L}\p{N}_]/u.test(line[j])) j += 1;
      out += `<span class="tok-name">${escapeHtml(line.slice(i, j))}</span>`;
      i = j;
      continue;
    }

    // Identifiers & keywords
    if (/[\p{L}_]/u.test(ch)) {
      let j = i + 1;
      while (j < len && /[\p{L}\p{N}_]/u.test(line[j])) j += 1;
      let word = line.slice(i, j);
      const lower = word.toLowerCase();
      if (lower === 'ma' && j < len && line[j] === ':') {
        word += ':';
        j += 1;
        out += `<span class="tok-keyword">${escapeHtml(word)}</span>`;
        i = j;
        continue;
      }
      if (PROC_START_KEYWORDS.has(lower) || PROC_END_KEYWORDS.has(lower)) {
        out += `<span class="tok-keyword">${escapeHtml(word)}</span>`;
      } else if (THREE_D_CMDS.has(lower)) {
        out += `<span class="tok-cmd3d">${escapeHtml(word)}</span>`;
      } else if (Object.prototype.hasOwnProperty.call(COMMAND_ALIASES, lower)) {
        out += `<span class="tok-cmd">${escapeHtml(word)}</span>`;
      } else if (REPCOUNT_KEYWORDS.has(lower)) {
        out += `<span class="tok-special">${escapeHtml(word)}</span>`;
      } else {
        out += `<span class="tok-name">${escapeHtml(word)}</span>`;
      }
      i = j;
      continue;
    }

    out += escapeHtml(ch);
    i += 1;
  }

  return out;
}

export class CodeEditor {
  public readonly element: HTMLElement;
  private gutter: HTMLElement;
  private highlight: HTMLElement;
  private textarea: HTMLTextAreaElement;
  private errorBanner: HTMLElement;
  private activeLine: number | null = null;
  private error: LogoError | null = null;
  private onChangeCb: (value: string) => void;

  constructor(options: {
    ariaLabel: string;
    onChange: (value: string) => void;
  }) {
    this.onChangeCb = options.onChange;

    this.element = document.createElement('div');
    this.element.className = 'editor-root';

    const surface = document.createElement('div');
    surface.className = 'editor-surface';

    this.gutter = document.createElement('div');
    this.gutter.className = 'editor-gutter';
    this.gutter.setAttribute('aria-hidden', 'true');

    const codeWrap = document.createElement('div');
    codeWrap.className = 'editor-code-wrap';

    this.highlight = document.createElement('div');
    this.highlight.className = 'editor-highlight';
    this.highlight.setAttribute('aria-hidden', 'true');

    this.textarea = document.createElement('textarea');
    this.textarea.className = 'editor-textarea';
    this.textarea.spellcheck = false;
    this.textarea.autocapitalize = 'off';
    this.textarea.autocomplete = 'off';
    this.textarea.setAttribute('aria-label', options.ariaLabel);
    this.textarea.setAttribute('wrap', 'off');

    codeWrap.appendChild(this.highlight);
    codeWrap.appendChild(this.textarea);
    surface.appendChild(this.gutter);
    surface.appendChild(codeWrap);

    this.errorBanner = document.createElement('div');
    this.errorBanner.className = 'editor-error-banner hidden';
    this.errorBanner.setAttribute('role', 'alert');

    this.element.appendChild(surface);
    this.element.appendChild(this.errorBanner);

    this.bindEvents();
    this.renderOverlay();
  }

  public getValue(): string {
    return this.textarea.value;
  }

  public setValue(value: string): void {
    this.textarea.value = value;
    this.renderOverlay();
  }

  public setActiveLine(line: number | null): void {
    if (this.activeLine === line) return;
    this.activeLine = line;
    this.renderOverlay();
  }

  public setError(error: LogoError | null): void {
    this.error = error;
    this.renderOverlay();
    if (!error) {
      this.errorBanner.classList.add('hidden');
      this.errorBanner.innerHTML = '';
    } else {
      this.errorBanner.classList.remove('hidden');
      this.errorBanner.innerHTML = `
        <button type="button" class="error-jump-btn" title="Przejdź do miejsca błędu">
          <span class="error-loc">Wiersz ${error.line}, kol. ${error.column}</span>
          <span class="error-msg">${escapeHtml(error.message)}</span>
        </button>
      `;
      const btn = this.errorBanner.querySelector('.error-jump-btn');
      btn?.addEventListener('click', () => this.jumpTo(error.line, error.column));
    }
  }

  public focus(): void {
    this.textarea.focus();
  }

  public jumpTo(line: number, column: number): void {
    const lines = this.textarea.value.split('\n');
    let offset = 0;
    for (let i = 0; i < Math.min(line - 1, lines.length); i += 1) {
      offset += lines[i].length + 1;
    }
    const targetLine = lines[Math.min(line - 1, lines.length - 1)] || '';
    offset += Math.min(Math.max(0, column - 1), targetLine.length);
    this.textarea.focus();
    this.textarea.setSelectionRange(offset, offset);
  }

  private bindEvents(): void {
    this.textarea.addEventListener('input', () => {
      this.renderOverlay();
      this.onChangeCb(this.textarea.value);
    });

    this.textarea.addEventListener('scroll', () => {
      this.highlight.scrollTop = this.textarea.scrollTop;
      this.highlight.scrollLeft = this.textarea.scrollLeft;
      this.gutter.scrollTop = this.textarea.scrollTop;
    });

    this.textarea.addEventListener('keydown', (e) => {
      if (e.key === 'Tab') {
        e.preventDefault();
        const start = this.textarea.selectionStart;
        const end = this.textarea.selectionEnd;
        const val = this.textarea.value;
        this.textarea.value = val.slice(0, start) + '  ' + val.slice(end);
        this.textarea.selectionStart = this.textarea.selectionEnd = start + 2;
        this.renderOverlay();
        this.onChangeCb(this.textarea.value);
      }
    });
  }

  private renderOverlay(): void {
    const text = this.textarea.value;
    const lines = text.split('\n');

    let gutterHtml = '';
    let codeHtml = '';

    for (let idx = 0; idx < lines.length; idx += 1) {
      const lineNum = idx + 1;
      const isActive = this.activeLine === lineNum;
      const isErr = this.error?.line === lineNum;
      const cls = `editor-line${isActive ? ' is-active' : ''}${isErr ? ' is-error' : ''}`;

      gutterHtml += `<div class="gutter-num${isActive ? ' is-active' : ''}${isErr ? ' is-error' : ''}">${lineNum}</div>`;

      const lineStr = lines[idx];
      let renderedLine = highlightLineTokens(lineStr);

      if (isErr && this.error) {
        const colIdx = Math.max(0, this.error.column - 1);
        const pad = ' '.repeat(colIdx);
        renderedLine += `<span class="inline-error-row" aria-hidden="true">${escapeHtml(pad)}<span class="inline-error-caret">^</span> <span class="inline-error-tip">${escapeHtml(this.error.message)}</span></span>`;
      }

      // Ensure empty line keeps height
      codeHtml += `<div class="${cls}">${renderedLine || '&nbsp;'}</div>`;
    }

    this.gutter.innerHTML = gutterHtml;
    this.highlight.innerHTML = codeHtml;
    this.highlight.scrollTop = this.textarea.scrollTop;
    this.highlight.scrollLeft = this.textarea.scrollLeft;
    this.gutter.scrollTop = this.textarea.scrollTop;
  }
}
