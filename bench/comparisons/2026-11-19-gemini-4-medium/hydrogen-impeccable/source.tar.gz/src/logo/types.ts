export type Mode = '2d' | '3d';

export type Vec3 = [number, number, number];

export interface Segment {
  from: Vec3;
  to: Vec3;
  color: string;
  width: number;
}

export interface LogoError {
  message: string;
  line: number;
  column: number;
}

export interface TurtleState {
  pos: Vec3;
  heading: Vec3;
  right: Vec3;
  up: Vec3;
  penDown: boolean;
  color: string;
  width: number;
}

export interface RunResult {
  segments: Segment[];
  error: LogoError | null;
}

export const LIMITS = {
  MAX_SOURCE_CHARS: 50_000,
  MAX_TOKENS: 10_000,
  MAX_BRACKET_DEPTH: 32,
  MAX_ACTIVE_FRAMES: 32,
  MAX_OPERATIONS: 10_000,
  MAX_SEGMENTS: 10_000,
  MAX_COORD: 100_000,
} as const;

export type TokenType =
  | 'ident'
  | 'legacyVar'
  | 'number'
  | 'color'
  | 'op'
  | 'cmp'
  | 'lbracket'
  | 'rbracket'
  | 'lparen'
  | 'rparen'
  | 'comma'
  | 'eof';

export interface Token {
  type: TokenType;
  value: string;
  lower: string;
  line: number;
  column: number;
  spaceBefore: boolean;
  spaceAfter: boolean;
}

export type Expr =
  | { kind: 'number'; value: number; line: number; column: number }
  | { kind: 'var'; name: string; line: number; column: number }
  | { kind: 'repcount'; line: number; column: number }
  | { kind: 'unary'; op: '+' | '-'; expr: Expr; line: number; column: number }
  | {
      kind: 'binary';
      op: '+' | '-' | '*' | '/';
      left: Expr;
      right: Expr;
      line: number;
      column: number;
    };

export interface Condition {
  left: Expr;
  op: '<' | '>' | '=' | '<=' | '>=' | '<>';
  right: Expr;
  line: number;
  column: number;
}

export type Stmt =
  | { kind: 'move'; dir: 1 | -1; dist: Expr; line: number; column: number }
  | { kind: 'turn'; dir: 1 | -1; angle: Expr; line: number; column: number }
  | { kind: 'pitch'; dir: 1 | -1; angle: Expr; line: number; column: number }
  | { kind: 'roll'; dir: 1 | -1; angle: Expr; line: number; column: number }
  | { kind: 'pen'; down: boolean; line: number; column: number }
  | { kind: 'color'; value: string; line: number; column: number }
  | { kind: 'width'; value: Expr; line: number; column: number }
  | { kind: 'home'; line: number; column: number }
  | { kind: 'clear'; line: number; column: number }
  | { kind: 'stop'; line: number; column: number }
  | { kind: 'let'; name: string; expr: Expr; line: number; column: number }
  | { kind: 'repeat'; count: Expr; body: Stmt[]; line: number; column: number }
  | {
      kind: 'if';
      cond: Condition;
      thenBody: Stmt[];
      elseBody: Stmt[] | null;
      line: number;
      column: number;
    }
  | { kind: 'call'; name: string; args: Expr[]; line: number; column: number };

export interface ProcedureDef {
  name: string;
  params: string[];
  body: Stmt[];
  declaredLocals: Set<string>;
  line: number;
  column: number;
}

export interface Program {
  procedures: Map<string, ProcedureDef>;
  statements: Stmt[];
  topLevelVars: Set<string>;
}
