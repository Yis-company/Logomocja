export type CommandKind =
  | 'fd'
  | 'bk'
  | 'rt'
  | 'lt'
  | 'pu'
  | 'pd'
  | 'color'
  | 'width'
  | 'repeat'
  | 'let'
  | 'if'
  | 'ifelse'
  | 'stop'
  | 'home'
  | 'cs'
  | 'pitchup'
  | 'pitchdown'
  | 'rollright'
  | 'rollleft';

const COMMAND_ALIASES: Record<string, CommandKind> = {
  np: 'fd',
  naprzod: 'fd',
  naprzód: 'fd',
  fd: 'fd',
  forward: 'fd',

  ws: 'bk',
  wstecz: 'bk',
  bk: 'bk',
  back: 'bk',

  pw: 'rt',
  prawo: 'rt',
  rt: 'rt',
  right: 'rt',

  lw: 'lt',
  lewo: 'lt',
  lt: 'lt',
  left: 'lt',

  pod: 'pu',
  podnies: 'pu',
  podnieś: 'pu',
  pu: 'pu',
  penup: 'pu',

  opu: 'pd',
  opusc: 'pd',
  opuść: 'pd',
  pd: 'pd',
  pendown: 'pd',

  kolor: 'color',
  color: 'color',

  grubosc: 'width',
  grubość: 'width',
  width: 'width',

  powtorz: 'repeat',
  powtórz: 'repeat',
  repeat: 'repeat',

  niech: 'let',
  let: 'let',

  jeśli: 'if',
  jesli: 'if',
  if: 'if',

  jeżeli: 'ifelse',
  jezeli: 'ifelse',
  ifelse: 'ifelse',

  stop: 'stop',

  dom: 'home',
  home: 'home',

  czyść: 'cs',
  czysc: 'cs',
  cs: 'cs',
  clearscreen: 'cs',

  gora: 'pitchup',
  góra: 'pitchup',
  pitchup: 'pitchup',

  dol: 'pitchdown',
  dół: 'pitchdown',
  pitchdown: 'pitchdown',

  pp: 'rollright',
  przechylprawo: 'rollright',
  rr: 'rollright',
  rollright: 'rollright',

  pl: 'rollleft',
  przechyllewo: 'rollleft',
  rl: 'rollleft',
  rollleft: 'rollleft',
};

export const PROC_START_KEYWORDS = new Set(['oto', 'to']);
export const PROC_END_KEYWORDS = new Set(['już', 'juz', 'end']);
export const REPCOUNT_KEYWORDS = new Set(['nrpowt', 'repcount']);

export function lookupCommand(lowerWord: string): CommandKind | null {
  return COMMAND_ALIASES[lowerWord] ?? null;
}

export function isReservedWord(lowerWord: string): boolean {
  return (
    lowerWord in COMMAND_ALIASES ||
    PROC_START_KEYWORDS.has(lowerWord) ||
    PROC_END_KEYWORDS.has(lowerWord) ||
    REPCOUNT_KEYWORDS.has(lowerWord) ||
    lowerWord === 'ma:'
  );
}

export function is3DOnlyCommand(cmd: CommandKind): boolean {
  return cmd === 'pitchup' || cmd === 'pitchdown' || cmd === 'rollright' || cmd === 'rollleft';
}
