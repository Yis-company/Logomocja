import {
  is3DOnlyCommand,
  isReservedWord,
  lookupCommand,
  PROC_END_KEYWORDS,
  PROC_START_KEYWORDS,
} from './keywords';
import { lex } from './lexer';
import {
  Condition,
  Expr,
  LIMITS,
  LogoError,
  Mode,
  ProcedureDef,
  Program,
  Stmt,
  Token,
} from './types';

class ParseError extends Error {
  logoError: LogoError;
  constructor(message: string, line: number, column: number) {
    super(message);
    this.logoError = { message, line, column };
  }
}

interface RawProcedure {
  name: string;
  params: string[];
  tokens: Token[];
  line: number;
  column: number;
}

function splitTopLevelAndProcedures(tokens: Token[]): {
  topTokens: Token[];
  rawProcs: RawProcedure[];
} {
  const topTokens: Token[] = [];
  const rawProcs: RawProcedure[] = [];
  const procNames = new Set<string>();

  let i = 0;
  let bracketDepth = 0;
  const n = tokens.length - 1; // exclude eof

  const isStartOfLine = (idx: number): boolean => {
    if (idx === 0) return true;
    return tokens[idx].line > tokens[idx - 1].line;
  };

  while (i < n) {
    const tok = tokens[i];

    if (tok.type === 'lbracket') {
      bracketDepth++;
      topTokens.push(tok);
      i++;
      continue;
    }
    if (tok.type === 'rbracket') {
      if (bracketDepth > 0) bracketDepth--;
      topTokens.push(tok);
      i++;
      continue;
    }

    if (tok.type === 'ident' && PROC_END_KEYWORDS.has(tok.lower)) {
      throw new ParseError(
        `Nieoczekiwane „${tok.value}” poza definicją procedury.`,
        tok.line,
        tok.column
      );
    }

    if (tok.type === 'ident' && PROC_START_KEYWORDS.has(tok.lower)) {
      if (bracketDepth > 0) {
        throw new ParseError(
          'Definicja procedury nie może znajdować się wewnątrz nawiasów „[ ... ]”.',
          tok.line,
          tok.column
        );
      }
      if (!isStartOfLine(i)) {
        throw new ParseError(
          'Definicja procedury „oto” musi zaczynać się w nowym wierszu.',
          tok.line,
          tok.column
        );
      }

      const headerLine = tok.line;
      i++;
      if (i >= n || tokens[i].line !== headerLine) {
        throw new ParseError(
          'Po „oto” oczekiwano nazwy procedury.',
          tok.line,
          tok.column
        );
      }

      const nameTok = tokens[i];
      if (nameTok.type !== 'ident') {
        throw new ParseError(
          'Oczekiwano nazwy procedury.',
          nameTok.line,
          nameTok.column
        );
      }
      if (isReservedWord(nameTok.lower)) {
        throw new ParseError(
          `Nazwa „${nameTok.value}” jest słowem kluczowym i nie może być nazwą procedury.`,
          nameTok.line,
          nameTok.column
        );
      }
      if (procNames.has(nameTok.lower)) {
        throw new ParseError(
          `Procedura „${nameTok.value}” została już zdefiniowana.`,
          nameTok.line,
          nameTok.column
        );
      }
      procNames.add(nameTok.lower);
      i++;

      const params: string[] = [];
      const paramSet = new Set<string>();

      // Parse optional parameter list on the same line
      if (i < n && tokens[i].line === headerLine) {
        const firstParamTok = tokens[i];
        if (firstParamTok.type === 'ident' && firstParamTok.lower === 'ma:') {
          i++;
          if (i >= n || tokens[i].line !== headerLine) {
            throw new ParseError(
              'Po „ma:” oczekiwano listy parametrów.',
              firstParamTok.line,
              firstParamTok.column
            );
          }
          while (true) {
            const pTok = tokens[i];
            if (pTok.line !== headerLine) {
              throw new ParseError(
                'Po przecinku oczekiwano nazwy parametru.',
                tokens[i - 1].line,
                tokens[i - 1].column
              );
            }
            if (pTok.type !== 'ident' || isReservedWord(pTok.lower)) {
              throw new ParseError(
                `Nieprawidłowa nazwa parametru „${pTok.value}”.`,
                pTok.line,
                pTok.column
              );
            }
            if (paramSet.has(pTok.lower)) {
              throw new ParseError(
                `Parametr „${pTok.value}” powtarza się w nagłówku procedury.`,
                pTok.line,
                pTok.column
              );
            }
            paramSet.add(pTok.lower);
            params.push(pTok.lower);
            i++;

            if (i >= n || tokens[i].line !== headerLine) break;
            if (tokens[i].type === 'comma') {
              i++;
              if (i >= n || tokens[i].line !== headerLine) {
                throw new ParseError(
                  'Po przecinku oczekiwano kolejnego parametru.',
                  tokens[i - 1].line,
                  tokens[i - 1].column
                );
              }
              continue;
            }
            throw new ParseError(
              `Nieoczekiwany token „${tokens[i].value}” w nagłówku procedury (oczekiwano przecinka).`,
              tokens[i].line,
              tokens[i].column
            );
          }
        } else if (firstParamTok.type === 'legacyVar') {
          while (i < n && tokens[i].line === headerLine) {
            const pTok = tokens[i];
            if (pTok.type !== 'legacyVar') {
              throw new ParseError(
                `Nieoczekiwany token „${pTok.value}” w nagłówku procedury.`,
                pTok.line,
                pTok.column
              );
            }
            if (isReservedWord(pTok.lower)) {
              throw new ParseError(
                `Nieprawidłowa nazwa parametru „${pTok.value}”.`,
                pTok.line,
                pTok.column
              );
            }
            if (paramSet.has(pTok.lower)) {
              throw new ParseError(
                `Parametr „${pTok.value}” powtarza się w nagłówku procedury.`,
                pTok.line,
                pTok.column
              );
            }
            paramSet.add(pTok.lower);
            params.push(pTok.lower);
            i++;
          }
        } else {
          throw new ParseError(
            `Nieoczekiwany token „${firstParamTok.value}” w nagłówku procedury (użyj „ma:” lub „:parametr”).`,
            firstParamTok.line,
            firstParamTok.column
          );
        }
      }

      // Collect body tokens until `już` / `juz` / `end` alone on its own line
      const bodyTokens: Token[] = [];
      let foundEnd = false;
      while (i < n) {
        const bTok = tokens[i];
        if (bTok.type === 'ident' && PROC_START_KEYWORDS.has(bTok.lower) && isStartOfLine(i)) {
          throw new ParseError(
            'Nie można definiować procedury wewnątrz innej procedury.',
            bTok.line,
            bTok.column
          );
        }
        if (bTok.type === 'ident' && PROC_END_KEYWORDS.has(bTok.lower)) {
          const aloneOnLine =
            isStartOfLine(i) && (i + 1 >= n || tokens[i + 1].line > bTok.line);
          if (!aloneOnLine) {
            throw new ParseError(
              `Słowo „${bTok.value}” musi stać samo w osobnym wierszu.`,
              bTok.line,
              bTok.column
            );
          }
          foundEnd = true;
          i++;
          break;
        }
        bodyTokens.push(bTok);
        i++;
      }

      if (!foundEnd) {
        throw new ParseError(
          `Brak „już” zamykającego definicję procedury „${nameTok.value}”.`,
          tok.line,
          tok.column
        );
      }

      const lastLine =
        bodyTokens.length > 0 ? bodyTokens[bodyTokens.length - 1].line : tok.line;
      bodyTokens.push({
        type: 'eof',
        value: '',
        lower: '',
        line: lastLine + 1,
        column: 1,
        spaceBefore: true,
        spaceAfter: true,
      });

      rawProcs.push({
        name: nameTok.lower,
        params,
        tokens: bodyTokens,
        line: tok.line,
        column: tok.column,
      });
      continue;
    }

    topTokens.push(tok);
    i++;
  }

  topTokens.push(tokens[tokens.length - 1]); // eof
  return { topTokens, rawProcs };
}

class TokenParser {
  private pos = 0;
  private bracketDepth = 0;

  constructor(
    private tokens: Token[],
    private procMap: Map<string, { params: string[] }>,
    private mode: Mode
  ) {}

  private peek(): Token {
    return this.tokens[this.pos];
  }

  private advance(): Token {
    const t = this.tokens[this.pos];
    if (this.pos < this.tokens.length - 1) this.pos++;
    return t;
  }

  parseBlockBody(stopOnRBracket: boolean): Stmt[] {
    const stmts: Stmt[] = [];
    while (true) {
      const tok = this.peek();
      if (tok.type === 'eof') {
        if (stopOnRBracket) {
          throw new ParseError(
            'Niezamknięty nawias kwadratowy „[”.',
            tok.line,
            tok.column
          );
        }
        break;
      }
      if (tok.type === 'rbracket') {
        if (!stopOnRBracket) {
          throw new ParseError('Nieoczekiwany nawias „]”.', tok.line, tok.column);
        }
        break;
      }
      stmts.push(this.parseStatement());
    }
    return stmts;
  }

  private parseBracketedBody(anchorTok: Token): Stmt[] {
    const open = this.peek();
    if (open.type === 'eof') {
      throw new ParseError(
        'Oczekiwano nawiasu „[” otwierającego blok poleceń.',
        anchorTok.line,
        anchorTok.column
      );
    }
    if (open.type !== 'lbracket') {
      throw new ParseError(
        'Oczekiwano nawiasu „[” otwierającego blok poleceń.',
        open.line,
        open.column
      );
    }
    this.advance();
    this.bracketDepth++;
    if (this.bracketDepth > LIMITS.MAX_BRACKET_DEPTH) {
      throw new ParseError(
        `Przekroczono maksymalną głębokość zagnieżdżenia nawiasów (${LIMITS.MAX_BRACKET_DEPTH}).`,
        open.line,
        open.column
      );
    }
    let body: Stmt[];
    try {
      body = this.parseBlockBody(true);
    } catch (e) {
      if (e instanceof ParseError && this.peek().type === 'eof') {
        throw new ParseError(
          'Niezamknięty nawias kwadratowy „[”.',
          open.line,
          open.column
        );
      }
      throw e;
    }
    const close = this.peek();
    if (close.type !== 'rbracket') {
      throw new ParseError(
        'Niezamknięty nawias kwadratowy „[”.',
        open.line,
        open.column
      );
    }
    this.advance();
    this.bracketDepth--;
    return body;
  }

  private parseStatement(): Stmt {
    const tok = this.peek();
    if (tok.type !== 'ident') {
      throw new ParseError(
        `Nieoczekiwany token „${tok.value}” — oczekiwano polecenia.`,
        tok.line,
        tok.column
      );
    }

    const cmd = lookupCommand(tok.lower);
    if (cmd !== null) {
      this.advance();
      if (this.mode === '2d' && is3DOnlyCommand(cmd)) {
        throw new ParseError(
          `Polecenie „${tok.value}” działa tylko w trybie 3D.`,
          tok.line,
          tok.column
        );
      }

      switch (cmd) {
        case 'fd':
          return {
            kind: 'move',
            dir: 1,
            dist: this.parseExpr(tok),
            line: tok.line,
            column: tok.column,
          };
        case 'bk':
          return {
            kind: 'move',
            dir: -1,
            dist: this.parseExpr(tok),
            line: tok.line,
            column: tok.column,
          };
        case 'rt':
          return {
            kind: 'turn',
            dir: 1,
            angle: this.parseExpr(tok),
            line: tok.line,
            column: tok.column,
          };
        case 'lt':
          return {
            kind: 'turn',
            dir: -1,
            angle: this.parseExpr(tok),
            line: tok.line,
            column: tok.column,
          };
        case 'pitchup':
          return {
            kind: 'pitch',
            dir: 1,
            angle: this.parseExpr(tok),
            line: tok.line,
            column: tok.column,
          };
        case 'pitchdown':
          return {
            kind: 'pitch',
            dir: -1,
            angle: this.parseExpr(tok),
            line: tok.line,
            column: tok.column,
          };
        case 'rollright':
          return {
            kind: 'roll',
            dir: 1,
            angle: this.parseExpr(tok),
            line: tok.line,
            column: tok.column,
          };
        case 'rollleft':
          return {
            kind: 'roll',
            dir: -1,
            angle: this.parseExpr(tok),
            line: tok.line,
            column: tok.column,
          };
        case 'pu':
          return { kind: 'pen', down: false, line: tok.line, column: tok.column };
        case 'pd':
          return { kind: 'pen', down: true, line: tok.line, column: tok.column };
        case 'home':
          return { kind: 'home', line: tok.line, column: tok.column };
        case 'cs':
          return { kind: 'clear', line: tok.line, column: tok.column };
        case 'stop':
          return { kind: 'stop', line: tok.line, column: tok.column };
        case 'color': {
          const arg = this.peek();
          if (arg.type === 'eof') {
            throw new ParseError(
              'Brak literału koloru po poleceniu „kolor”.',
              tok.line,
              tok.column
            );
          }
          if (arg.type !== 'color') {
            throw new ParseError(
              'Oczekiwano literału koloru w formacie „#rrggbb”.',
              arg.line,
              arg.column
            );
          }
          this.advance();
          return {
            kind: 'color',
            value: arg.value,
            line: tok.line,
            column: tok.column,
          };
        }
        case 'width': {
          const expr = this.parseExpr(tok);
          return { kind: 'width', value: expr, line: tok.line, column: tok.column };
        }
        case 'let': {
          const nameTok = this.peek();
          if (nameTok.type === 'eof') {
            throw new ParseError(
              'Brak nazwy zmiennej po „niech”.',
              tok.line,
              tok.column
            );
          }
          if (
            nameTok.type !== 'ident' ||
            isReservedWord(nameTok.lower) ||
            this.procMap.has(nameTok.lower)
          ) {
            throw new ParseError(
              `Nieprawidłowa nazwa zmiennej „${nameTok.value}”.`,
              nameTok.line,
              nameTok.column
            );
          }
          this.advance();
          const expr = this.parseExpr(nameTok);
          return {
            kind: 'let',
            name: nameTok.lower,
            expr,
            line: tok.line,
            column: tok.column,
          };
        }
        case 'repeat': {
          const count = this.parseExpr(tok);
          const body = this.parseBracketedBody(tok);
          return {
            kind: 'repeat',
            count,
            body,
            line: tok.line,
            column: tok.column,
          };
        }
        case 'if': {
          const cond = this.parseCondition(tok);
          const thenBody = this.parseBracketedBody(tok);
          return {
            kind: 'if',
            cond,
            thenBody,
            elseBody: null,
            line: tok.line,
            column: tok.column,
          };
        }
        case 'ifelse': {
          const cond = this.parseCondition(tok);
          const thenBody = this.parseBracketedBody(tok);
          const elseBody = this.parseBracketedBody(tok);
          return {
            kind: 'if',
            cond,
            thenBody,
            elseBody,
            line: tok.line,
            column: tok.column,
          };
        }
      }
    }

    // Procedure call?
    const proc = this.procMap.get(tok.lower);
    if (proc) {
      this.advance();
      const args: Expr[] = [];
      let anchor = tok;
      for (let k = 0; k < proc.params.length; k++) {
        const argExpr = this.parseExpr(anchor);
        args.push(argExpr);
        anchor = tok;
      }
      return {
        kind: 'call',
        name: tok.lower,
        args,
        line: tok.line,
        column: tok.column,
      };
    }

    throw new ParseError(
      `Nieznane polecenie „${tok.value}”.`,
      tok.line,
      tok.column
    );
  }

  private parseCondition(anchorTok: Token): Condition {
    const left = this.parseExpr(anchorTok);
    const cmpTok = this.peek();
    if (cmpTok.type === 'eof') {
      throw new ParseError(
        'Oczekiwano operatora porównania (<, >, =, <=, >=, <>).',
        anchorTok.line,
        anchorTok.column
      );
    }
    if (cmpTok.type !== 'cmp') {
      throw new ParseError(
        'Oczekiwano operatora porównania (<, >, =, <=, >=, <>).',
        cmpTok.line,
        cmpTok.column
      );
    }
    this.advance();
    const right = this.parseExpr(cmpTok);
    return {
      left,
      op: cmpTok.value as Condition['op'],
      right,
      line: left.line,
      column: left.column,
    };
  }

  private canBeBinaryOp(tok: Token): boolean {
    return tok.type === 'op' && tok.spaceBefore === tok.spaceAfter;
  }

  private parseExpr(anchorTok: Token): Expr {
    return this.parseAddSub(anchorTok);
  }

  private parseAddSub(anchorTok: Token): Expr {
    let left = this.parseMulDiv(anchorTok);
    while (
      this.canBeBinaryOp(this.peek()) &&
      (this.peek().value === '+' || this.peek().value === '-')
    ) {
      const opTok = this.advance();
      const right = this.parseMulDiv(opTok);
      left = {
        kind: 'binary',
        op: opTok.value as '+' | '-',
        left,
        right,
        line: left.line,
        column: left.column,
      };
    }
    return left;
  }

  private parseMulDiv(anchorTok: Token): Expr {
    let left = this.parseUnary(anchorTok);
    while (
      this.canBeBinaryOp(this.peek()) &&
      (this.peek().value === '*' || this.peek().value === '/')
    ) {
      const opTok = this.advance();
      const right = this.parseUnary(opTok);
      left = {
        kind: 'binary',
        op: opTok.value as '*' | '/',
        left,
        right,
        line: left.line,
        column: left.column,
      };
    }
    return left;
  }

  private parseUnary(anchorTok: Token): Expr {
    const tok = this.peek();
    if (tok.type === 'op' && (tok.value === '+' || tok.value === '-')) {
      this.advance();
      const inner = this.parseUnary(tok);
      return {
        kind: 'unary',
        op: tok.value,
        expr: inner,
        line: tok.line,
        column: tok.column,
      };
    }
    return this.parsePrimary(anchorTok);
  }

  private parsePrimary(anchorTok: Token): Expr {
    const tok = this.peek();
    if (tok.type === 'eof') {
      throw new ParseError(
        'Brak oczekiwanego wyrażenia.',
        anchorTok.line,
        anchorTok.column
      );
    }

    if (tok.type === 'number') {
      this.advance();
      const num = Number(tok.value);
      if (!Number.isFinite(num)) {
        throw new ParseError(
          'Liczba wykracza poza dopuszczalny zakres.',
          tok.line,
          tok.column
        );
      }
      return { kind: 'number', value: num, line: tok.line, column: tok.column };
    }

    if (tok.type === 'lparen') {
      const lparen = this.advance();
      const inner = this.parseExpr(lparen);
      const close = this.peek();
      if (close.type === 'eof') {
        throw new ParseError(
          'Brak nawiasu zamykającego „)”.',
          lparen.line,
          lparen.column
        );
      }
      if (close.type !== 'rparen') {
        throw new ParseError(
          'Oczekiwano nawiasu zamykającego „)”.',
          close.line,
          close.column
        );
      }
      this.advance();
      return { ...inner, line: lparen.line, column: lparen.column };
    }

    if (tok.type === 'legacyVar') {
      this.advance();
      return { kind: 'var', name: tok.lower, line: tok.line, column: tok.column };
    }

    if (tok.type === 'ident') {
      if (tok.lower === 'nrpowt' || tok.lower === 'repcount') {
        this.advance();
        return { kind: 'repcount', line: tok.line, column: tok.column };
      }
      if (isReservedWord(tok.lower)) {
        throw new ParseError(
          `Nieoczekiwane słowo kluczowe „${tok.value}” w wyrażeniu.`,
          tok.line,
          tok.column
        );
      }
      this.advance();
      return { kind: 'var', name: tok.lower, line: tok.line, column: tok.column };
    }

    throw new ParseError(
      `Oczekiwano wyrażenia zamiast „${tok.value}”.`,
      tok.line,
      tok.column
    );
  }
}

function collectLets(stmts: Stmt[], out: Set<string>): void {
  for (const s of stmts) {
    if (s.kind === 'let') {
      out.add(s.name);
    } else if (s.kind === 'repeat') {
      collectLets(s.body, out);
    } else if (s.kind === 'if') {
      collectLets(s.thenBody, out);
      if (s.elseBody) collectLets(s.elseBody, out);
    }
  }
}

function isStaticExpr(expr: Expr): boolean {
  switch (expr.kind) {
    case 'number':
      return true;
    case 'var':
    case 'repcount':
      return false;
    case 'unary':
      return isStaticExpr(expr.expr);
    case 'binary':
      return isStaticExpr(expr.left) && isStaticExpr(expr.right);
  }
}

function evalStaticExpr(expr: Expr): number {
  switch (expr.kind) {
    case 'number':
      return expr.value;
    case 'unary': {
      const v = evalStaticExpr(expr.expr);
      return expr.op === '-' ? -v : v;
    }
    case 'binary': {
      const l = evalStaticExpr(expr.left);
      const r = evalStaticExpr(expr.right);
      let res = 0;
      if (expr.op === '+') res = l + r;
      else if (expr.op === '-') res = l - r;
      else if (expr.op === '*') res = l * r;
      else {
        if (r === 0) {
          throw new ParseError(
            'Dzielenie przez zero.',
            expr.line,
            expr.column
          );
        }
        res = l / r;
      }
      if (!Number.isFinite(res)) {
        throw new ParseError(
          'Wynik działania wykracza poza dopuszczalny zakres liczbowy.',
          expr.line,
          expr.column
        );
      }
      return res;
    }
    default:
      return 0;
  }
}

function validateExpr(
  expr: Expr,
  insideRepeat: boolean,
  allowedVars: Set<string>
): void {
  switch (expr.kind) {
    case 'number':
      return;
    case 'repcount':
      if (!insideRepeat) {
        throw new ParseError(
          'Wartość „nrpowt” może być użyta wyłącznie wewnątrz pętli „powtorz”.',
          expr.line,
          expr.column
        );
      }
      return;
    case 'var':
      if (!allowedVars.has(expr.name)) {
        throw new ParseError(
          `Nieznana zmienna lub parametr „${expr.name}”.`,
          expr.line,
          expr.column
        );
      }
      return;
    case 'unary':
      validateExpr(expr.expr, insideRepeat, allowedVars);
      return;
    case 'binary':
      validateExpr(expr.left, insideRepeat, allowedVars);
      validateExpr(expr.right, insideRepeat, allowedVars);
      return;
  }
}

function validateStmts(
  stmts: Stmt[],
  insideRepeat: boolean,
  allowedVars: Set<string>
): void {
  for (const s of stmts) {
    switch (s.kind) {
      case 'move':
        validateExpr(s.dist, insideRepeat, allowedVars);
        break;
      case 'turn':
      case 'pitch':
      case 'roll':
        validateExpr(s.angle, insideRepeat, allowedVars);
        break;
      case 'width':
        validateExpr(s.value, insideRepeat, allowedVars);
        if (isStaticExpr(s.value)) {
          const w = evalStaticExpr(s.value);
          if (!Number.isInteger(w) || w < 1 || w > 12) {
            throw new ParseError(
              'Grubość pisaka musi być liczbą całkowitą od 1 do 12.',
              s.value.line,
              s.value.column
            );
          }
        }
        break;
      case 'let':
        validateExpr(s.expr, insideRepeat, allowedVars);
        break;
      case 'repeat':
        validateExpr(s.count, insideRepeat, allowedVars);
        if (isStaticExpr(s.count)) {
          const c = evalStaticExpr(s.count);
          if (!Number.isInteger(c) || c < 0 || c > 10_000) {
            throw new ParseError(
              'Liczba powtórzeń musi być liczbą całkowitą od 0 do 10 000.',
              s.count.line,
              s.count.column
            );
          }
        }
        validateStmts(s.body, true, allowedVars);
        break;
      case 'if':
        validateExpr(s.cond.left, insideRepeat, allowedVars);
        validateExpr(s.cond.right, insideRepeat, allowedVars);
        validateStmts(s.thenBody, insideRepeat, allowedVars);
        if (s.elseBody) validateStmts(s.elseBody, insideRepeat, allowedVars);
        break;
      case 'call':
        for (const a of s.args) {
          validateExpr(a, insideRepeat, allowedVars);
        }
        break;
      case 'pen':
      case 'color':
      case 'home':
      case 'clear':
      case 'stop':
        break;
    }
  }
}

export interface ParseResult {
  program: Program | null;
  error: LogoError | null;
}

export function parseProgram(source: string, mode: Mode): ParseResult {
  const lexRes = lex(source);
  if (lexRes.error) {
    return { program: null, error: lexRes.error };
  }

  try {
    const { topTokens, rawProcs } = splitTopLevelAndProcedures(lexRes.tokens);

    const procMeta = new Map<string, { params: string[] }>();
    for (const rp of rawProcs) {
      procMeta.set(rp.name, { params: rp.params });
    }

    const procedures = new Map<string, ProcedureDef>();
    for (const rp of rawProcs) {
      const parser = new TokenParser(rp.tokens, procMeta, mode);
      const body = parser.parseBlockBody(false);
      const declaredLocals = new Set<string>();
      collectLets(body, declaredLocals);
      procedures.set(rp.name, {
        name: rp.name,
        params: rp.params,
        body,
        declaredLocals,
        line: rp.line,
        column: rp.column,
      });
    }

    const topParser = new TokenParser(topTokens, procMeta, mode);
    const statements = topParser.parseBlockBody(false);
    const topLevelVars = new Set<string>();
    collectLets(statements, topLevelVars);

    for (const proc of procedures.values()) {
      const allowed = new Set<string>(topLevelVars);
      for (const p of proc.params) allowed.add(p);
      for (const l of proc.declaredLocals) allowed.add(l);
      validateStmts(proc.body, false, allowed);
    }

    validateStmts(statements, false, topLevelVars);

    return {
      program: { procedures, statements, topLevelVars },
      error: null,
    };
  } catch (e) {
    if (e instanceof ParseError) {
      return { program: null, error: e.logoError };
    }
    throw e;
  }
}
