import { parseProgram } from './parser';
import {
  Condition,
  Expr,
  LIMITS,
  LogoError,
  Mode,
  Program,
  RunResult,
  Segment,
  Stmt,
  TurtleState,
  Vec3,
} from './types';

class RuntimeLogoError extends Error {
  logoError: LogoError;
  constructor(message: string, line: number, column: number) {
    super(message);
    this.logoError = { message, line, column };
  }
}

type Frame =
  | { kind: 'program'; stmts: Stmt[]; ip: number }
  | {
      kind: 'procedure';
      name: string;
      stmts: Stmt[];
      ip: number;
      locals: Map<string, number>;
      declaredLocals: Set<string>;
      line: number;
      column: number;
    }
  | {
      kind: 'repeat';
      stmts: Stmt[];
      ip: number;
      iteration: number;
      total: number;
      line: number;
      column: number;
    }
  | { kind: 'conditional'; stmts: Stmt[]; ip: number; line: number; column: number };

function normalize(v: Vec3): Vec3 {
  const len = Math.hypot(v[0], v[1], v[2]);
  if (len === 0) return [0, 0, 0];
  return [v[0] / len, v[1] / len, v[2] / len];
}

function rotatePair(a: Vec3, b: Vec3, deg: number): [Vec3, Vec3] {
  const rad = (deg * Math.PI) / 180;
  const c = Math.cos(rad);
  const s = Math.sin(rad);
  const na: Vec3 = [
    a[0] * c + b[0] * s,
    a[1] * c + b[1] * s,
    a[2] * c + b[2] * s,
  ];
  const nb: Vec3 = [
    -a[0] * s + b[0] * c,
    -a[1] * s + b[1] * c,
    -a[2] * s + b[2] * c,
  ];
  // Re-orthonormalize to prevent drift
  const naNorm = normalize(na);
  const dot = naNorm[0] * nb[0] + naNorm[1] * nb[1] + naNorm[2] * nb[2];
  const nbOrtho: Vec3 = [
    nb[0] - dot * naNorm[0],
    nb[1] - dot * naNorm[1],
    nb[2] - dot * naNorm[2],
  ];
  return [naNorm, normalize(nbOrtho)];
}

export interface StepOutcome {
  done: boolean;
  line: number | null;
  error: LogoError | null;
}

export class LogoVM {
  private program: Program;
  private frames: Frame[];
  private globals = new Map<string, number>();
  private turtle: TurtleState;
  private segments: Segment[] = [];
  private ops = 0;
  private activeFrames = 0;
  public finished = false;
  public error: LogoError | null = null;

  constructor(program: Program) {
    this.program = program;
    this.frames = [{ kind: 'program', stmts: program.statements, ip: 0 }];
    this.turtle = {
      pos: [0, 0, 0],
      heading: [0, 1, 0],
      right: [1, 0, 0],
      up: [0, 0, 1],
      penDown: true,
      color: '#16866a',
      width: 3,
    };
  }

  getTurtle(): TurtleState {
    return {
      ...this.turtle,
      pos: [...this.turtle.pos] as Vec3,
      heading: [...this.turtle.heading] as Vec3,
      right: [...this.turtle.right] as Vec3,
      up: [...this.turtle.up] as Vec3,
    };
  }

  getSegments(): Segment[] {
    return this.segments;
  }

  getOps(): number {
    return this.ops;
  }

  getNextLine(): number | null {
    for (let i = this.frames.length - 1; i >= 0; i--) {
      const f = this.frames[i];
      if (f.ip < f.stmts.length) {
        return f.stmts[f.ip].line;
      }
    }
    return null;
  }

  private bumpOp(line: number, column: number): void {
    this.ops++;
    if (this.ops > LIMITS.MAX_OPERATIONS) {
      throw new RuntimeLogoError(
        `Przekroczono limit ${LIMITS.MAX_OPERATIONS} wykonanych operacji.`,
        line,
        column
      );
    }
  }

  private currentProcFrame(): Extract<Frame, { kind: 'procedure' }> | null {
    for (let i = this.frames.length - 1; i >= 0; i--) {
      const f = this.frames[i];
      if (f.kind === 'procedure') return f;
    }
    return null;
  }

  private currentRepcount(): number {
    for (let i = this.frames.length - 1; i >= 0; i--) {
      const f = this.frames[i];
      if (f.kind === 'repeat') return f.iteration;
      if (f.kind === 'procedure') break;
    }
    return 1;
  }

  private evalExpr(expr: Expr): number {
    switch (expr.kind) {
      case 'number':
        return expr.value;
      case 'repcount':
        return this.currentRepcount();
      case 'var': {
        const proc = this.currentProcFrame();
        if (proc) {
          if (proc.locals.has(expr.name)) {
            return proc.locals.get(expr.name)!;
          }
          if (proc.declaredLocals.has(expr.name)) {
            throw new RuntimeLogoError(
              `Zmienna lokalna „${expr.name}” nie ma jeszcze przypisanej wartości.`,
              expr.line,
              expr.column
            );
          }
        }
        if (this.globals.has(expr.name)) {
          return this.globals.get(expr.name)!;
        }
        throw new RuntimeLogoError(
          `Zmienna „${expr.name}” nie ma jeszcze przypisanej wartości.`,
          expr.line,
          expr.column
        );
      }
      case 'unary': {
        const v = this.evalExpr(expr.expr);
        return expr.op === '-' ? -v : v;
      }
      case 'binary': {
        const l = this.evalExpr(expr.left);
        const r = this.evalExpr(expr.right);
        let res = 0;
        if (expr.op === '+') res = l + r;
        else if (expr.op === '-') res = l - r;
        else if (expr.op === '*') res = l * r;
        else {
          if (r === 0) {
            throw new RuntimeLogoError('Dzielenie przez zero.', expr.line, expr.column);
          }
          res = l / r;
        }
        if (!Number.isFinite(res)) {
          throw new RuntimeLogoError(
            'Wynik działania wykracza poza dopuszczalny zakres liczbowy.',
            expr.line,
            expr.column
          );
        }
        return res;
      }
    }
  }

  private evalCondition(cond: Condition): boolean {
    const l = this.evalExpr(cond.left);
    const r = this.evalExpr(cond.right);
    switch (cond.op) {
      case '<':
        return l < r;
      case '>':
        return l > r;
      case '=':
        return l === r;
      case '<=':
        return l <= r;
      case '>=':
        return l >= r;
      case '<>':
        return l !== r;
    }
  }

  private pushSegment(from: Vec3, to: Vec3, line: number, column: number): void {
    if (this.segments.length >= LIMITS.MAX_SEGMENTS) {
      throw new RuntimeLogoError(
        `Przekroczono limit ${LIMITS.MAX_SEGMENTS} odcinków na rysunku.`,
        line,
        column
      );
    }
    this.segments.push({
      from: [from[0], from[1], from[2]],
      to: [to[0], to[1], to[2]],
      color: this.turtle.color,
      width: this.turtle.width,
    });
  }

  private unwindCompletedFrames(): boolean {
    while (this.frames.length > 0) {
      const top = this.frames[this.frames.length - 1];
      if (top.ip < top.stmts.length) {
        return false;
      }
      if (top.kind === 'program') {
        this.frames.pop();
        this.finished = true;
        return true;
      }
      if (top.kind === 'conditional') {
        this.frames.pop();
        this.bumpOp(top.line, top.column);
        continue;
      }
      if (top.kind === 'procedure') {
        this.frames.pop();
        this.activeFrames--;
        this.bumpOp(top.line, top.column);
        continue;
      }
      if (top.kind === 'repeat') {
        this.bumpOp(top.line, top.column);
        if (top.iteration < top.total) {
          top.iteration++;
          top.ip = 0;
          return false;
        }
        this.frames.pop();
        this.activeFrames--;
        continue;
      }
    }
    this.finished = true;
    return true;
  }

  step(): StepOutcome {
    if (this.finished || this.error) {
      return { done: true, line: null, error: this.error };
    }

    try {
      if (this.unwindCompletedFrames()) {
        return { done: true, line: null, error: null };
      }

      const top = this.frames[this.frames.length - 1];
      const stmt = top.stmts[top.ip];
      top.ip++;

      this.bumpOp(stmt.line, stmt.column);

      switch (stmt.kind) {
        case 'move': {
          const d = this.evalExpr(stmt.dist) * stmt.dir;
          const [x, y, z] = this.turtle.pos;
          const nx = x + this.turtle.heading[0] * d;
          const ny = y + this.turtle.heading[1] * d;
          const nz = z + this.turtle.heading[2] * d;
          if (
            !Number.isFinite(nx) ||
            !Number.isFinite(ny) ||
            !Number.isFinite(nz) ||
            Math.abs(nx) > LIMITS.MAX_COORD ||
            Math.abs(ny) > LIMITS.MAX_COORD ||
            Math.abs(nz) > LIMITS.MAX_COORD
          ) {
            throw new RuntimeLogoError(
              'Żółw przekroczył dopuszczalny zakres współrzędnych (±100 000).',
              stmt.dist.line,
              stmt.dist.column
            );
          }
          const nextPos: Vec3 = [nx, ny, nz];
          if (
            d !== 0 &&
            this.turtle.penDown &&
            (nx !== x || ny !== y || nz !== z)
          ) {
            this.pushSegment(this.turtle.pos, nextPos, stmt.line, stmt.column);
          }
          this.turtle.pos = nextPos;
          break;
        }
        case 'turn': {
          const a = this.evalExpr(stmt.angle) * stmt.dir;
          const [nh, nr] = rotatePair(this.turtle.heading, this.turtle.right, a);
          this.turtle.heading = nh;
          this.turtle.right = nr;
          break;
        }
        case 'pitch': {
          const a = this.evalExpr(stmt.angle) * stmt.dir;
          const [nh, nu] = rotatePair(this.turtle.heading, this.turtle.up, a);
          this.turtle.heading = nh;
          this.turtle.up = nu;
          break;
        }
        case 'roll': {
          const a = this.evalExpr(stmt.angle) * stmt.dir;
          const [nu, nr] = rotatePair(this.turtle.up, this.turtle.right, a);
          this.turtle.up = nu;
          this.turtle.right = nr;
          break;
        }
        case 'pen': {
          this.turtle.penDown = stmt.down;
          break;
        }
        case 'color': {
          this.turtle.color = stmt.value;
          break;
        }
        case 'width': {
          const w = this.evalExpr(stmt.value);
          if (!Number.isInteger(w) || w < 1 || w > 12) {
            throw new RuntimeLogoError(
              'Grubość pisaka musi być liczbą całkowitą od 1 do 12.',
              stmt.value.line,
              stmt.value.column
            );
          }
          this.turtle.width = w;
          break;
        }
        case 'home': {
          const [x, y, z] = this.turtle.pos;
          if (this.turtle.penDown && (x !== 0 || y !== 0 || z !== 0)) {
            this.pushSegment(this.turtle.pos, [0, 0, 0], stmt.line, stmt.column);
          }
          this.turtle.pos = [0, 0, 0];
          this.turtle.heading = [0, 1, 0];
          this.turtle.right = [1, 0, 0];
          this.turtle.up = [0, 0, 1];
          break;
        }
        case 'clear': {
          this.segments = [];
          break;
        }
        case 'let': {
          const val = this.evalExpr(stmt.expr);
          const proc = this.currentProcFrame();
          if (proc) {
            proc.locals.set(stmt.name, val);
          } else {
            this.globals.set(stmt.name, val);
          }
          break;
        }
        case 'stop': {
          // Unwind until we exit the enclosing procedure or the top-level program
          while (this.frames.length > 0) {
            const popped = this.frames.pop()!;
            if (popped.kind === 'repeat') {
              this.activeFrames--;
            } else if (popped.kind === 'procedure') {
              this.activeFrames--;
              this.bumpOp(stmt.line, stmt.column);
              break;
            } else if (popped.kind === 'program') {
              this.finished = true;
              return { done: true, line: null, error: null };
            }
          }
          break;
        }
        case 'repeat': {
          const count = this.evalExpr(stmt.count);
          if (!Number.isInteger(count) || count < 0 || count > 10_000) {
            throw new RuntimeLogoError(
              'Liczba powtórzeń musi być liczbą całkowitą od 0 do 10 000.',
              stmt.count.line,
              stmt.count.column
            );
          }
          if (count > 0) {
            if (this.activeFrames >= LIMITS.MAX_ACTIVE_FRAMES) {
              throw new RuntimeLogoError(
                `Przekroczono limit ${LIMITS.MAX_ACTIVE_FRAMES} zagnieżdżonych wywołań i pętli.`,
                stmt.line,
                stmt.column
              );
            }
            this.activeFrames++;
            this.frames.push({
              kind: 'repeat',
              stmts: stmt.body,
              ip: 0,
              iteration: 1,
              total: count,
              line: stmt.line,
              column: stmt.column,
            });
          }
          break;
        }
        case 'if': {
          const condResult = this.evalCondition(stmt.cond);
          const branch = condResult ? stmt.thenBody : stmt.elseBody;
          if (branch) {
            this.frames.push({
              kind: 'conditional',
              stmts: branch,
              ip: 0,
              line: stmt.line,
              column: stmt.column,
            });
          }
          break;
        }
        case 'call': {
          const procDef = this.program.procedures.get(stmt.name)!;
          if (this.activeFrames >= LIMITS.MAX_ACTIVE_FRAMES) {
            throw new RuntimeLogoError(
              `Przekroczono limit ${LIMITS.MAX_ACTIVE_FRAMES} zagnieżdżonych wywołań i pętli.`,
              stmt.line,
              stmt.column
            );
          }
          const locals = new Map<string, number>();
          for (let i = 0; i < procDef.params.length; i++) {
            locals.set(procDef.params[i], this.evalExpr(stmt.args[i]));
          }
          this.activeFrames++;
          this.frames.push({
            kind: 'procedure',
            name: procDef.name,
            stmts: procDef.body,
            ip: 0,
            locals,
            declaredLocals: procDef.declaredLocals,
            line: stmt.line,
            column: stmt.column,
          });
          break;
        }
      }

      if (this.unwindCompletedFrames()) {
        return { done: true, line: null, error: null };
      }

      return { done: false, line: stmt.line, error: null };
    } catch (e) {
      if (e instanceof RuntimeLogoError) {
        this.error = e.logoError;
        this.finished = true;
        return { done: true, line: null, error: this.error };
      }
      throw e;
    }
  }

  runToEnd(): RunResult {
    while (!this.finished && !this.error) {
      this.step();
    }
    return {
      segments: this.segments,
      error: this.error,
    };
  }
}

export function createExecution(
  source: string,
  mode: Mode
): { vm: LogoVM | null; error: LogoError | null } {
  const parsed = parseProgram(source, mode);
  if (parsed.error || !parsed.program) {
    return { vm: null, error: parsed.error };
  }
  return { vm: new LogoVM(parsed.program), error: null };
}

export function runProgram(source: string, mode: Mode): RunResult {
  const { vm, error } = createExecution(source, mode);
  if (error || !vm) {
    return { segments: [], error };
  }
  return vm.runToEnd();
}
