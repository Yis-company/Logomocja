import { LIMITS, LogoError, Token } from './types';

function isWhitespace(ch: string): boolean {
  return ch === ' ' || ch === '\t' || ch === '\r' || ch === '\n';
}

function isDigit(ch: string): boolean {
  return ch >= '0' && ch <= '9';
}

function isIdentStart(ch: string): boolean {
  return /[\p{L}_]/u.test(ch);
}

function isIdentPart(ch: string): boolean {
  return /[\p{L}\p{N}_]/u.test(ch);
}

export interface LexResult {
  tokens: Token[];
  error: LogoError | null;
}

export function lex(source: string): LexResult {
  if (source.length > LIMITS.MAX_SOURCE_CHARS) {
    return {
      tokens: [],
      error: {
        message: 'Program przekracza limit 50 000 znaków.',
        line: 1,
        column: 1,
      },
    };
  }

  const tokens: Token[] = [];
  let i = 0;
  let line = 1;
  let col = 1;
  const len = source.length;

  const pushToken = (token: Token): LogoError | null => {
    if (tokens.length >= LIMITS.MAX_TOKENS) {
      return {
        message: 'Program przekracza limit 10 000 tokenów.',
        line: token.line,
        column: token.column,
      };
    }
    tokens.push(token);
    return null;
  };

  while (i < len) {
    const ch = source[i];

    if (ch === '\n') {
      i++;
      line++;
      col = 1;
      continue;
    }

    if (ch === ' ' || ch === '\t' || ch === '\r') {
      i++;
      col++;
      continue;
    }

    if (ch === ';') {
      while (i < len && source[i] !== '\n') {
        i++;
        col++;
      }
      continue;
    }

    const startLine = line;
    const startCol = col;

    // Colour literal "..."
    if (ch === '"') {
      i++;
      col++;
      let raw = '';
      let closed = false;
      while (i < len && source[i] !== '\n') {
        if (source[i] === '"') {
          closed = true;
          i++;
          col++;
          break;
        }
        raw += source[i];
        i++;
        col++;
      }
      if (!closed) {
        return {
          tokens,
          error: {
            message: 'Niezamknięty literał koloru.',
            line: startLine,
            column: startCol,
          },
        };
      }
      if (!/^#[0-9a-fA-F]{6}$/.test(raw)) {
        return {
          tokens,
          error: {
            message: 'Nieprawidłowy literał koloru (oczekiwano formatu „#rrggbb”).',
            line: startLine,
            column: startCol,
          },
        };
      }
      const err = pushToken({
        type: 'color',
        value: raw.toLowerCase(),
        lower: raw.toLowerCase(),
        line: startLine,
        column: startCol,
        spaceBefore: false,
        spaceAfter: false,
      });
      if (err) return { tokens, error: err };
      continue;
    }

    // Legacy variable :name
    if (ch === ':') {
      i++;
      col++;
      if (i >= len || !isIdentStart(source[i])) {
        return {
          tokens,
          error: {
            message: 'Po dwukropku oczekiwano nazwy zmiennej lub parametru.',
            line: startLine,
            column: startCol,
          },
        };
      }
      let name = '';
      while (i < len && isIdentPart(source[i])) {
        name += source[i];
        i++;
        col++;
      }
      const err = pushToken({
        type: 'legacyVar',
        value: name,
        lower: name.toLowerCase(),
        line: startLine,
        column: startCol,
        spaceBefore: false,
        spaceAfter: false,
      });
      if (err) return { tokens, error: err };
      continue;
    }

    // Numbers: 80, 12.5, .5
    if (isDigit(ch) || ch === '.') {
      let numStr = '';
      if (ch === '.') {
        if (i + 1 >= len || !isDigit(source[i + 1])) {
          return {
            tokens,
            error: {
              message: 'Nieoczekiwana kropka (oczekiwano cyfry po kropce).',
              line: startLine,
              column: startCol,
            },
          };
        }
        numStr += '.';
        i++;
        col++;
        while (i < len && isDigit(source[i])) {
          numStr += source[i];
          i++;
          col++;
        }
      } else {
        while (i < len && isDigit(source[i])) {
          numStr += source[i];
          i++;
          col++;
        }
        if (i < len && source[i] === '.') {
          if (i + 1 >= len || !isDigit(source[i + 1])) {
            return {
              tokens,
              error: {
                message: 'Nieprawidłowy literał liczbowy.',
                line: startLine,
                column: startCol,
              },
            };
          }
          numStr += '.';
          i++;
          col++;
          while (i < len && isDigit(source[i])) {
            numStr += source[i];
            i++;
            col++;
          }
        }
      }

      // Reject trailing letters/underscore/dot (e.g. 1e3, 0x10, 1.2.3)
      if (i < len && (isIdentStart(source[i]) || source[i] === '.')) {
        return {
          tokens,
          error: {
            message: 'Nieprawidłowy literał liczbowy.',
            line: startLine,
            column: startCol,
          },
        };
      }

      const err = pushToken({
        type: 'number',
        value: numStr,
        lower: numStr,
        line: startLine,
        column: startCol,
        spaceBefore: false,
        spaceAfter: false,
      });
      if (err) return { tokens, error: err };
      continue;
    }

    // Arithmetic operators + - * /
    if (ch === '+' || ch === '-' || ch === '*' || ch === '/') {
      const spaceBefore = i === 0 || isWhitespace(source[i - 1]);
      i++;
      col++;
      const spaceAfter = i >= len || isWhitespace(source[i]) || source[i] === ';';
      const err = pushToken({
        type: 'op',
        value: ch,
        lower: ch,
        line: startLine,
        column: startCol,
        spaceBefore,
        spaceAfter,
      });
      if (err) return { tokens, error: err };
      continue;
    }

    // Comparisons: <= >= <> < > =
    if (ch === '<' || ch === '>' || ch === '=') {
      let val = ch;
      i++;
      col++;
      if (ch === '<' && i < len && (source[i] === '=' || source[i] === '>')) {
        val += source[i];
        i++;
        col++;
      } else if (ch === '>' && i < len && source[i] === '=') {
        val += source[i];
        i++;
        col++;
      }
      const err = pushToken({
        type: 'cmp',
        value: val,
        lower: val,
        line: startLine,
        column: startCol,
        spaceBefore: false,
        spaceAfter: false,
      });
      if (err) return { tokens, error: err };
      continue;
    }

    // Brackets, parens, comma
    if (ch === '[' || ch === ']' || ch === '(' || ch === ')' || ch === ',') {
      i++;
      col++;
      const typeMap = {
        '[': 'lbracket',
        ']': 'rbracket',
        '(': 'lparen',
        ')': 'rparen',
        ',': 'comma',
      } as const;
      const err = pushToken({
        type: typeMap[ch],
        value: ch,
        lower: ch,
        line: startLine,
        column: startCol,
        spaceBefore: false,
        spaceAfter: false,
      });
      if (err) return { tokens, error: err };
      continue;
    }

    // Identifiers (and `ma:`)
    if (isIdentStart(ch)) {
      let word = '';
      while (i < len && isIdentPart(source[i])) {
        word += source[i];
        i++;
        col++;
      }
      if (word.toLowerCase() === 'ma' && i < len && source[i] === ':') {
        word += ':';
        i++;
        col++;
      }
      const err = pushToken({
        type: 'ident',
        value: word,
        lower: word.toLowerCase(),
        line: startLine,
        column: startCol,
        spaceBefore: false,
        spaceAfter: false,
      });
      if (err) return { tokens, error: err };
      continue;
    }

    return {
      tokens,
      error: {
        message: `Nieoczekiwany znak „${ch}”.`,
        line: startLine,
        column: startCol,
      },
    };
  }

  tokens.push({
    type: 'eof',
    value: '',
    lower: '',
    line,
    column: col,
    spaceBefore: true,
    spaceAfter: true,
  });

  return { tokens, error: null };
}
