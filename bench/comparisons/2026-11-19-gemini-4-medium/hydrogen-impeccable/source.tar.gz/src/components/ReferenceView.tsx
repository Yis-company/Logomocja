import React, { useMemo, useState } from 'react';
import { COMMAND_DOCS, DIALECT_LIMITS } from '../data/reference';

export const ReferenceView: React.FC = () => {
  const [query, setQuery] = useState('');

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return COMMAND_DOCS;
    return COMMAND_DOCS.filter(
      (c) =>
        c.polish.some((a) => a.toLowerCase().includes(q)) ||
        c.english.some((a) => a.toLowerCase().includes(q)) ||
        c.meaning.toLowerCase().includes(q)
    );
  }, [query]);

  return (
    <div className="page-scroll">
      <div className="page-container ref-container">
        <header className="page-header">
          <h1>Słownik języka Logomocja</h1>
          <p className="page-lead">
            Pełna dokumentacja dialektu: polecenia polskie i angielskie, wyrażenia, zmienne, procedury, warunki, limity oraz skróty klawiszowe.
          </p>
        </header>

        <section className="ref-section">
          <div className="ref-search-row">
            <h2>Polecenia</h2>
            <input
              type="search"
              className="ref-search-input"
              placeholder="Szukaj polecenia (np. np, powtorz, pitchup)..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              aria-label="Szukaj polecenia w słowniku"
            />
          </div>

          <div className="ref-table-wrap">
            <table className="ref-table">
              <thead>
                <tr>
                  <th>Polskie</th>
                  <th>Angielskie</th>
                  <th>Argument</th>
                  <th>Działanie</th>
                  <th>Przykład</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((cmd) => (
                  <tr key={cmd.polish[0]}>
                    <td className="mono">
                      {cmd.polish.join(', ')}
                      {cmd.only3d && <span className="mode-tag inline-tag">3D</span>}
                    </td>
                    <td className="mono">{cmd.english.join(', ')}</td>
                    <td>{cmd.argument}</td>
                    <td>{cmd.meaning}</td>
                    <td className="mono">{cmd.example}</td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={5} className="ref-empty">
                      Brak poleceń pasujących do zapytania „{query}”.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </section>

        <div className="ref-prose-grid">
          <section className="ref-section">
            <h2>Wyrażenia i operatory</h2>
            <p>
              W miejscu argumentu liczbowego można podać liczbę dziesiętną (np. <code>80</code>, <code>12.5</code>, <code>.5</code>),
              nazwę zmiennej lub parametru (także w starszej postaci <code>:bok</code>), wartość <code>nrpowt</code> (<code>repcount</code>)
              wewnątrz pętli, wyrażenie w nawiasach <code>(...)</code>, znak jednoargumentowy <code>+</code> lub <code>-</code> oraz działania <code>+</code>, <code>-</code>, <code>*</code>, <code>/</code>.
            </p>
            <p>
              Mnożenie i dzielenie wiążą silniej niż dodawanie i odejmowanie. Operator dwuargumentowy musi mieć odstęp po obu stronach albo po żadnej:
              <code>np 10 - 5</code> i <code>np 10-5</code> są poprawne, natomiast <code>np 10 -5</code> powoduje błąd.
              Porównania w warunkach to <code>&lt;</code>, <code>&gt;</code>, <code>=</code>, <code>&lt;=</code>, <code>&gt;=</code>, <code>&lt;&gt;</code>.
            </p>
          </section>

          <section className="ref-section">
            <h2>Zmienne i zasięg</h2>
            <p>
              Polecenie <code>niech x 5</code> przypisuje wartość zmiennej <code>x</code>. Poza procedurą tworzy lub zmienia zmienną globalną;
              wewnątrz procedury tworzy zmienną lokalną dla danego wywołania, przesłaniającą zmienną globalną o tej samej nazwie.
              Odczyt zadeklarowanej zmiennej przed jej przypisaniem na bieżącej ścieżce wykonania zgłasza błąd czasu wykonania.
            </p>
          </section>

          <section className="ref-section">
            <h2>Warunki i pętle</h2>
            <p>
              <code>jeśli warunek [ ... ]</code> wykonuje blok, gdy warunek jest prawdziwy.
              <code>jeżeli warunek [ ... ] [ ... ]</code> wybiera pierwszy lub drugi blok.
              W pętli <code>powtorz n [ ... ]</code> licznik <code>nrpowt</code> zaczyna się od 1 i dotyczy najbliższej otaczającej pętli w kodzie.
            </p>
          </section>

          <section className="ref-section">
            <h2>Procedury</h2>
            <pre className="ref-code">{`oto kwadrat ma: bok, kąt
  powtorz 4 [np bok pw kąt]
już

kwadrat 80 90`}</pre>
            <p>
              Definicja zaczyna się od <code>oto</code> (<code>to</code>) na początku wiersza i kończy słowem <code>już</code> (<code>juz</code>, <code>end</code>) w osobnym wierszu.
              Obsługiwany jest również starszy nagłówek <code>oto kwadrat :bok :kąt</code>. Procedury mogą wywoływać się rekurencyjnie, a <code>stop</code> kończy bieżące wywołanie.
            </p>
          </section>

          <section className="ref-section">
            <h2>Limity środowiska</h2>
            <dl className="limits-list">
              {DIALECT_LIMITS.map((item) => (
                <div key={item.label} className="limits-row">
                  <dt>{item.label}</dt>
                  <dd className="tabular">{item.value}</dd>
                </div>
              ))}
            </dl>
          </section>

          <section className="ref-section">
            <h2>Skróty klawiszowe w pracowni</h2>
            <dl className="limits-list">
              <div className="limits-row">
                <dt>Uruchom program</dt>
                <dd className="mono">Ctrl/Cmd + Enter</dd>
              </div>
              <div className="limits-row">
                <dt>Wykonaj jeden krok</dt>
                <dd className="mono">F10 lub Alt + K</dd>
              </div>
              <div className="limits-row">
                <dt>Pauza / Wznów</dt>
                <dd className="mono">F8 lub Alt + P</dd>
              </div>
              <div className="limits-row">
                <dt>Resetuj wykonanie</dt>
                <dd className="mono">Alt + R</dd>
              </div>
            </dl>
          </section>
        </div>
      </div>
    </div>
  );
};
