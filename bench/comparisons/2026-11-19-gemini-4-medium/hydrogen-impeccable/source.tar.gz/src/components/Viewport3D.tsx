import React, {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react';
import * as THREE from 'three';
import { Line2 } from 'three/examples/jsm/lines/Line2.js';
import { LineGeometry } from 'three/examples/jsm/lines/LineGeometry.js';
import { LineMaterial } from 'three/examples/jsm/lines/LineMaterial.js';
import { Segment, TurtleState } from '../logo/types';
import { FitIcon, ResetIcon } from './Icons';
import { ViewportHandle } from './Viewport2D';

interface Viewport3DProps {
  segments: Segment[];
  turtle: TurtleState;
  isDark: boolean;
}

interface OrbitState {
  target: THREE.Vector3;
  radius: number;
  theta: number; // azimuth around Z
  phi: number; // polar angle from +Z
}

const DEFAULT_ORBIT = (): OrbitState => ({
  target: new THREE.Vector3(0, 0, 20),
  radius: 320,
  theta: -Math.PI / 4,
  phi: Math.PI / 3,
});

export const Viewport3D = forwardRef<ViewportHandle, Viewport3DProps>(
  ({ segments, turtle, isDark }, ref) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const [webglError, setWebglError] = useState<string | null>(null);
    const [showGrid, setShowGrid] = useState(true);

    const orbitRef = useRef<OrbitState>(DEFAULT_ORBIT());
    const sceneRef = useRef<THREE.Scene | null>(null);
    const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
    const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
    const linesGroupRef = useRef<THREE.Group | null>(null);
    const gridGroupRef = useRef<THREE.Group | null>(null);
    const turtleGroupRef = useRef<THREE.Group | null>(null);
    const materialsRef = useRef<LineMaterial[]>([]);

    const dragRef = useRef<{
      active: boolean;
      mode: 'orbit' | 'pan';
      lastX: number;
      lastY: number;
    }>({ active: false, mode: 'orbit', lastX: 0, lastY: 0 });

    const updateCamera = useCallback(() => {
      const cam = cameraRef.current;
      const renderer = rendererRef.current;
      const scene = sceneRef.current;
      if (!cam || !renderer || !scene) return;

      const { target, radius, theta, phi } = orbitRef.current;
      const clampedPhi = Math.max(0.05, Math.min(Math.PI - 0.05, phi));
      const sinPhi = Math.sin(clampedPhi);
      const x = target.x + radius * sinPhi * Math.cos(theta);
      const y = target.y + radius * sinPhi * Math.sin(theta);
      const z = target.z + radius * Math.cos(clampedPhi);

      cam.position.set(x, y, z);
      cam.up.set(0, 0, 1);
      cam.lookAt(target);
      cam.updateMatrixWorld();

      renderer.render(scene, cam);
    }, []);

    const fitToDrawing = useCallback(() => {
      let minX = turtle.pos[0];
      let maxX = turtle.pos[0];
      let minY = turtle.pos[1];
      let maxY = turtle.pos[1];
      let minZ = turtle.pos[2];
      let maxZ = turtle.pos[2];

      if (segments.length === 0) {
        minX = -100;
        maxX = 100;
        minY = -100;
        maxY = 100;
        minZ = -20;
        maxZ = 100;
      } else {
        for (const s of segments) {
          minX = Math.min(minX, s.from[0], s.to[0]);
          maxX = Math.max(maxX, s.from[0], s.to[0]);
          minY = Math.min(minY, s.from[1], s.to[1]);
          maxY = Math.max(maxY, s.from[1], s.to[1]);
          minZ = Math.min(minZ, s.from[2], s.to[2]);
          maxZ = Math.max(maxZ, s.from[2], s.to[2]);
        }
      }

      const cx = (minX + maxX) / 2;
      const cy = (minY + maxY) / 2;
      const cz = (minZ + maxZ) / 2;
      const span = Math.max(
        40,
        Math.hypot(maxX - minX, maxY - minY, maxZ - minZ)
      );
      const cam = cameraRef.current;
      const fovRad = ((cam?.fov ?? 45) * Math.PI) / 180;
      const dist = (span / 2) / Math.tan(fovRad / 2) * 1.35;

      orbitRef.current = {
        ...orbitRef.current,
        target: new THREE.Vector3(cx, cy, cz),
        radius: Math.max(40, Math.min(200_000, dist)),
      };
      updateCamera();
    }, [segments, turtle.pos, updateCamera]);

    const resetView = useCallback(() => {
      orbitRef.current = DEFAULT_ORBIT();
      updateCamera();
    }, [updateCamera]);

    const exportPng = useCallback(() => {
      const renderer = rendererRef.current;
      const scene = sceneRef.current;
      const cam = cameraRef.current;
      if (!renderer || !scene || !cam) return;
      renderer.render(scene, cam);
      const url = renderer.domElement.toDataURL('image/png');
      const a = document.createElement('a');
      a.href = url;
      a.download = 'logomocja-3d.png';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }, []);

    useImperativeHandle(ref, () => ({ fitToDrawing, resetView, exportPng }), [
      fitToDrawing,
      resetView,
      exportPng,
    ]);

    // Initialize WebGL scene once
    useEffect(() => {
      const container = containerRef.current;
      if (!container) return;

      let renderer: THREE.WebGLRenderer;
      try {
        renderer = new THREE.WebGLRenderer({
          antialias: true,
          preserveDrawingBuffer: true,
        });
      } catch {
        setWebglError(
          'Widok 3D wymaga obsługi WebGL, która jest niedostępna w tej przeglądarce lub środowisku. Tryb 2D działa normalnie.'
        );
        return;
      }

      if (!renderer.getContext()) {
        setWebglError(
          'Nie udało się zainicjalizować kontekstu WebGL dla widoku 3D. Tryb 2D działa normalnie.'
        );
        renderer.dispose();
        return;
      }

      const rect = container.getBoundingClientRect();
      const w = Math.max(100, rect.width);
      const h = Math.max(100, rect.height);

      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      renderer.setSize(w, h);
      renderer.domElement.style.display = 'block';
      renderer.domElement.style.width = '100%';
      renderer.domElement.style.height = '100%';
      container.insertBefore(renderer.domElement, container.firstChild);

      const scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(45, w / h, 0.5, 500_000);
      camera.up.set(0, 0, 1);

      const gridGroup = new THREE.Group();
      const gridHelper = new THREE.GridHelper(400, 20, 0x88929b, 0x88929b);
      gridHelper.rotation.x = Math.PI / 2; // rotate from XZ to XY plane (Z is up)
      (gridHelper.material as THREE.Material).transparent = true;
      (gridHelper.material as THREE.Material).opacity = 0.24;
      gridGroup.add(gridHelper);

      // Axes: X (ochre/red), Y (teal/green), Z (blue)
      const axesGroup = new THREE.Group();
      const makeAxis = (to: [number, number, number], hex: number) => {
        const geo = new THREE.BufferGeometry().setFromPoints([
          new THREE.Vector3(0, 0, 0),
          new THREE.Vector3(...to),
        ]);
        const mat = new THREE.LineBasicMaterial({ color: hex });
        return new THREE.Line(geo, mat);
      };
      axesGroup.add(makeAxis([120, 0, 0], 0xc1763d));
      axesGroup.add(makeAxis([0, 120, 0], 0x16866a));
      axesGroup.add(makeAxis([0, 0, 120], 0x2b6fb3));
      gridGroup.add(axesGroup);
      scene.add(gridGroup);

      const linesGroup = new THREE.Group();
      scene.add(linesGroup);

      // 3D Turtle marker: cone pointing +Y (heading), wings along X (right), dorsal fin along +Z (up)
      const turtleGroup = new THREE.Group();
      const bodyGeo = new THREE.ConeGeometry(5, 16, 4);
      const bodyMat = new THREE.MeshBasicMaterial({ color: 0x16866a });
      const bodyMesh = new THREE.Mesh(bodyGeo, bodyMat);
      turtleGroup.add(bodyMesh);

      const finGeo = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(0, -4, 0),
        new THREE.Vector3(0, 4, 0),
        new THREE.Vector3(0, -4, 7),
      ]);
      const finMat = new THREE.MeshBasicMaterial({
        color: 0xc1763d,
        side: THREE.DoubleSide,
      });
      const finMesh = new THREE.Mesh(finGeo, finMat);
      turtleGroup.add(finMesh);
      scene.add(turtleGroup);

      sceneRef.current = scene;
      cameraRef.current = camera;
      rendererRef.current = renderer;
      linesGroupRef.current = linesGroup;
      gridGroupRef.current = gridGroup;
      turtleGroupRef.current = turtleGroup;

      const ro = new ResizeObserver(() => {
        const r = container.getBoundingClientRect();
        const nw = Math.max(100, r.width);
        const nh = Math.max(100, r.height);
        camera.aspect = nw / nh;
        camera.updateProjectionMatrix();
        renderer.setSize(nw, nh);
        for (const m of materialsRef.current) {
          m.resolution.set(nw, nh);
        }
        renderer.render(scene, camera);
      });
      ro.observe(container);

      updateCamera();

      return () => {
        ro.disconnect();
        if (renderer.domElement.parentNode === container) {
          container.removeChild(renderer.domElement);
        }
        renderer.dispose();
        rendererRef.current = null;
      };
    }, [updateCamera]);

    // Update theme & grid visibility
    useEffect(() => {
      const scene = sceneRef.current;
      const grid = gridGroupRef.current;
      if (scene) {
        scene.background = new THREE.Color(isDark ? '#111418' : '#f7f6f2');
      }
      if (grid) {
        grid.visible = showGrid;
      }
      updateCamera();
    }, [isDark, showGrid, updateCamera]);

    // Rebuild 3D segments when segments change
    useEffect(() => {
      const group = linesGroupRef.current;
      const container = containerRef.current;
      if (!group || !container) return;

      while (group.children.length > 0) {
        const child = group.children[0] as Line2;
        group.remove(child);
        child.geometry.dispose();
        (child.material as LineMaterial).dispose();
      }
      materialsRef.current = [];

      const rect = container.getBoundingClientRect();
      const resW = Math.max(100, rect.width);
      const resH = Math.max(100, rect.height);

      // Group segments by color + width for batched Line2 rendering
      const buckets = new Map<string, { color: string; width: number; segs: Segment[] }>();
      for (const s of segments) {
        const key = `${s.color}|${s.width}`;
        let b = buckets.get(key);
        if (!b) {
          b = { color: s.color, width: s.width, segs: [] };
          buckets.set(key, b);
        }
        b.segs.push(s);
      }

      for (const b of buckets.values()) {
        // Line2 renders a continuous polyline, so for disconnected segments we create individual or connected strips
        // Wait: LineSegments2 is for disconnected pairs! Let's check or render polylines when contiguous!
        let currentStrip: number[] = [];
        let lastEnd: [number, number, number] | null = null;

        const flushStrip = () => {
          if (currentStrip.length < 6) return;
          const geo = new LineGeometry();
          geo.setPositions(currentStrip);
          const mat = new LineMaterial({
            color: new THREE.Color(b.color).getHex(),
            linewidth: b.width,
            resolution: new THREE.Vector2(resW, resH),
          });
          materialsRef.current.push(mat);
          const line = new Line2(geo, mat);
          line.computeLineDistances();
          group.add(line);
          currentStrip = [];
        };

        for (const seg of b.segs) {
          if (
            lastEnd &&
            lastEnd[0] === seg.from[0] &&
            lastEnd[1] === seg.from[1] &&
            lastEnd[2] === seg.from[2]
          ) {
            currentStrip.push(seg.to[0], seg.to[1], seg.to[2]);
          } else {
            flushStrip();
            currentStrip = [
              seg.from[0],
              seg.from[1],
              seg.from[2],
              seg.to[0],
              seg.to[1],
              seg.to[2],
            ];
          }
          lastEnd = seg.to;
        }
        flushStrip();
      }

      updateCamera();
    }, [segments, updateCamera]);

    // Update 3D turtle position and orientation
    useEffect(() => {
      const tg = turtleGroupRef.current;
      if (!tg) return;
      tg.position.set(turtle.pos[0], turtle.pos[1], turtle.pos[2]);

      const m = new THREE.Matrix4();
      const xAxis = new THREE.Vector3(...turtle.right);
      const yAxis = new THREE.Vector3(...turtle.heading);
      const zAxis = new THREE.Vector3(...turtle.up);
      m.makeBasis(xAxis, yAxis, zAxis);
      tg.quaternion.setFromRotationMatrix(m);

      updateCamera();
    }, [turtle, updateCamera]);

    const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
      if ((e.target as HTMLElement).closest('.viewport-controls')) return;
      e.currentTarget.setPointerCapture(e.pointerId);
      const isPan = e.button === 2 || e.shiftKey;
      dragRef.current = {
        active: true,
        mode: isPan ? 'pan' : 'orbit',
        lastX: e.clientX,
        lastY: e.clientY,
      };
    };

    const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
      if (!dragRef.current.active) return;
      const dx = e.clientX - dragRef.current.lastX;
      const dy = e.clientY - dragRef.current.lastY;
      dragRef.current.lastX = e.clientX;
      dragRef.current.lastY = e.clientY;

      if (dragRef.current.mode === 'orbit') {
        orbitRef.current.theta -= dx * 0.008;
        orbitRef.current.phi = Math.max(
          0.05,
          Math.min(Math.PI - 0.05, orbitRef.current.phi - dy * 0.008)
        );
      } else {
        const cam = cameraRef.current;
        if (cam) {
          const panScale = orbitRef.current.radius * 0.0015;
          const right = new THREE.Vector3();
          const up = new THREE.Vector3();
          cam.matrixWorld.extractBasis(right, up, new THREE.Vector3());
          orbitRef.current.target.addScaledVector(right, -dx * panScale);
          orbitRef.current.target.addScaledVector(up, dy * panScale);
        }
      }
      updateCamera();
    };

    const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
      dragRef.current.active = false;
      try {
        e.currentTarget.releasePointerCapture(e.pointerId);
      } catch {
        // ignore
      }
    };

    const handleWheel = (e: React.WheelEvent<HTMLDivElement>) => {
      e.preventDefault();
      const factor = e.deltaY < 0 ? 0.9 : 1.11;
      orbitRef.current.radius = Math.max(
        15,
        Math.min(200_000, orbitRef.current.radius * factor)
      );
      updateCamera();
    };

    if (webglError) {
      return (
        <div className="viewport-stage viewport-fallback" role="alert">
          <div className="viewport-fallback-box">
            <h3>Widok 3D niedostępny</h3>
            <p>{webglError}</p>
          </div>
        </div>
      );
    }

    return (
      <div
        className="viewport-stage"
        ref={containerRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        onContextMenu={(e) => e.preventDefault()}
        onWheel={handleWheel}
        aria-label="Obszar rysowania 3D"
      >
        <div className="viewport-controls" role="toolbar" aria-label="Sterowanie widokiem 3D">
          <button
            type="button"
            className="vp-btn"
            onClick={() => {
              orbitRef.current.radius = Math.max(15, orbitRef.current.radius * 0.8);
              updateCamera();
            }}
            aria-label="Przybliż kamerę"
            title="Przybliż"
          >
            +
          </button>
          <button
            type="button"
            className="vp-btn"
            onClick={() => {
              orbitRef.current.radius = Math.min(200_000, orbitRef.current.radius * 1.25);
              updateCamera();
            }}
            aria-label="Oddal kamerę"
            title="Oddal"
          >
            −
          </button>
          <button
            type="button"
            className="vp-btn vp-btn-text"
            onClick={fitToDrawing}
            title="Dopasuj bryłę do widoku"
          >
            <FitIcon size={14} />
            <span>Dopasuj</span>
          </button>
          <button
            type="button"
            className="vp-btn vp-btn-text"
            onClick={resetView}
            title="Przywróć domyślną kamerę"
          >
            <ResetIcon size={14} />
            <span>Reset</span>
          </button>
          <button
            type="button"
            className={`vp-btn vp-btn-text${showGrid ? ' is-pressed' : ''}`}
            onClick={() => setShowGrid((g) => !g)}
            aria-pressed={showGrid}
            title="Pokaż lub ukryj siatkę i osie"
          >
            <span>Siatka i osie</span>
          </button>
        </div>
      </div>
    );
  }
);

Viewport3D.displayName = 'Viewport3D';
