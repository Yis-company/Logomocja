import React, {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react';
import { Segment, TurtleState } from '../logo/types';
import { FitIcon, ResetIcon } from './Icons';

export interface ViewportHandle {
  fitToDrawing: () => void;
  resetView: () => void;
  exportPng: () => void;
}

interface Viewport2DProps {
  segments: Segment[];
  turtle: TurtleState;
  isDark: boolean;
}

interface Camera2D {
  cx: number; // world X at canvas center
  cy: number; // world Y at canvas center
  zoom: number; // pixels per world unit
}

export const Viewport2D = forwardRef<ViewportHandle, Viewport2DProps>(
  ({ segments, turtle, isDark }, ref) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [camera, setCamera] = useState<Camera2D>({ cx: 0, cy: 0, zoom: 1 });
    const [showGrid, setShowGrid] = useState(true);
    const dragRef = useRef<{
      active: boolean;
      startX: number;
      startY: number;
      origCx: number;
      origCy: number;
    }>({ active: false, startX: 0, startY: 0, origCx: 0, origCy: 0 });

    const fitToDrawing = useCallback(() => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      const w = Math.max(200, rect.width);
      const h = Math.max(200, rect.height);

      let minX = turtle.pos[0];
      let maxX = turtle.pos[0];
      let minY = turtle.pos[1];
      let maxY = turtle.pos[1];
      if (segments.length === 0) {
        minX = -150;
        maxX = 150;
        minY = -150;
        maxY = 150;
      } else {
        for (const s of segments) {
          minX = Math.min(minX, s.from[0], s.to[0]);
          maxX = Math.max(maxX, s.from[0], s.to[0]);
          minY = Math.min(minY, s.from[1], s.to[1]);
          maxY = Math.max(maxY, s.from[1], s.to[1]);
        }
      }

      const spanX = Math.max(40, maxX - minX);
      const spanY = Math.max(40, maxY - minY);
      const pad = 0.82;
      const zoom = Math.max(
        0.02,
        Math.min(12, Math.min((w * pad) / spanX, (h * pad) / spanY))
      );
      setCamera({
        cx: (minX + maxX) / 2,
        cy: (minY + maxY) / 2,
        zoom,
      });
    }, [segments, turtle.pos]);

    const resetView = useCallback(() => {
      setCamera({ cx: 0, cy: 0, zoom: 1 });
    }, []);

    const exportPng = useCallback(() => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const url = canvas.toDataURL('image/png');
      const a = document.createElement('a');
      a.href = url;
      a.download = 'logomocja-2d.png';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }, []);

    useImperativeHandle(ref, () => ({ fitToDrawing, resetView, exportPng }), [
      fitToDrawing,
      resetView,
      exportPng,
    ]);

    const draw = useCallback(() => {
      const canvas = canvasRef.current;
      const container = containerRef.current;
      if (!canvas || !container) return;

      const dpr = window.devicePixelRatio || 1;
      const rect = container.getBoundingClientRect();
      const w = Math.max(1, Math.floor(rect.width));
      const h = Math.max(1, Math.floor(rect.height));

      if (canvas.width !== w * dpr || canvas.height !== h * dpr) {
        canvas.width = w * dpr;
        canvas.height = h * dpr;
      }

      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      ctx.save();
      ctx.scale(dpr, dpr);

      // Background
      ctx.fillStyle = isDark ? '#111418' : '#f7f6f2';
      ctx.fillRect(0, 0, w, h);

      const toScreenX = (wx: number) => w / 2 + (wx - camera.cx) * camera.zoom;
      const toScreenY = (wy: number) => h / 2 - (wy - camera.cy) * camera.zoom;

      // Adaptive grid
      if (showGrid) {
        let step = 50;
        const targetPx = 60;
        const rawStep = targetPx / camera.zoom;
        const pow10 = Math.pow(10, Math.floor(Math.log10(rawStep)));
        const norm = rawStep / pow10;
        if (norm < 1.5) step = pow10;
        else if (norm < 3.5) step = 2 * pow10;
        else if (norm < 7.5) step = 5 * pow10;
        else step = 10 * pow10;

        const minWX = camera.cx - w / (2 * camera.zoom);
        const maxWX = camera.cx + w / (2 * camera.zoom);
        const minWY = camera.cy - h / (2 * camera.zoom);
        const maxWY = camera.cy + h / (2 * camera.zoom);

        ctx.strokeStyle = isDark ? 'rgba(255,255,255,0.055)' : 'rgba(20,24,31,0.06)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        for (
          let x = Math.floor(minWX / step) * step;
          x <= maxWX;
          x += step
        ) {
          const sx = Math.round(toScreenX(x)) + 0.5;
          ctx.moveTo(sx, 0);
          ctx.lineTo(sx, h);
        }
        for (
          let y = Math.floor(minWY / step) * step;
          y <= maxWY;
          y += step
        ) {
          const sy = Math.round(toScreenY(y)) + 0.5;
          ctx.moveTo(0, sy);
          ctx.lineTo(w, sy);
        }
        ctx.stroke();
      }

      // Origin crosshair (0, 0)
      const ox = toScreenX(0);
      const oy = toScreenY(0);
      ctx.strokeStyle = isDark ? 'rgba(255,255,255,0.22)' : 'rgba(20,24,31,0.22)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(ox - 10, oy);
      ctx.lineTo(ox + 10, oy);
      ctx.moveTo(ox, oy - 10);
      ctx.lineTo(ox, oy + 10);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(ox, oy, 3, 0, Math.PI * 2);
      ctx.fillStyle = isDark ? 'rgba(255,255,255,0.35)' : 'rgba(20,24,31,0.35)';
      ctx.fill();

      // Segments
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      for (const seg of segments) {
        ctx.strokeStyle = seg.color;
        ctx.lineWidth = seg.width;
        ctx.beginPath();
        ctx.moveTo(toScreenX(seg.from[0]), toScreenY(seg.from[1]));
        ctx.lineTo(toScreenX(seg.to[0]), toScreenY(seg.to[1]));
        ctx.stroke();
      }

      // Turtle marker
      const tx = toScreenX(turtle.pos[0]);
      const ty = toScreenY(turtle.pos[1]);
      // heading in world: (hx, hy) -> screen: (hx, -hy)
      const angle = Math.atan2(-turtle.heading[1], turtle.heading[0]);
      ctx.save();
      ctx.translate(tx, ty);
      ctx.rotate(angle);
      ctx.beginPath();
      ctx.moveTo(11, 0);
      ctx.lineTo(-8, -6.5);
      ctx.lineTo(-5, 0);
      ctx.lineTo(-8, 6.5);
      ctx.closePath();
      ctx.fillStyle = turtle.penDown ? turtle.color : 'transparent';
      ctx.strokeStyle = isDark ? '#f0f2f5' : '#14181f';
      ctx.lineWidth = 1.75;
      if (turtle.penDown) ctx.fill();
      ctx.stroke();
      ctx.restore();

      ctx.restore();
    }, [camera, isDark, segments, showGrid, turtle]);

    useEffect(() => {
      draw();
    }, [draw]);

    useEffect(() => {
      const container = containerRef.current;
      if (!container) return;
      const ro = new ResizeObserver(() => draw());
      ro.observe(container);
      return () => ro.disconnect();
    }, [draw]);

    const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
      e.currentTarget.setPointerCapture(e.pointerId);
      dragRef.current = {
        active: true,
        startX: e.clientX,
        startY: e.clientY,
        origCx: camera.cx,
        origCy: camera.cy,
      };
    };

    const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
      if (!dragRef.current.active) return;
      const dx = e.clientX - dragRef.current.startX;
      const dy = e.clientY - dragRef.current.startY;
      setCamera((prev) => ({
        ...prev,
        cx: dragRef.current.origCx - dx / prev.zoom,
        cy: dragRef.current.origCy + dy / prev.zoom,
      }));
    };

    const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
      dragRef.current.active = false;
      try {
        e.currentTarget.releasePointerCapture(e.pointerId);
      } catch {
        // ignore
      }
    };

    const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
      e.preventDefault();
      const factor = e.deltaY < 0 ? 1.12 : 1 / 1.12;
      setCamera((prev) => ({
        ...prev,
        zoom: Math.max(0.02, Math.min(25, prev.zoom * factor)),
      }));
    };

    return (
      <div className="viewport-stage" ref={containerRef}>
        <canvas
          ref={canvasRef}
          className="viewport-canvas"
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          onWheel={handleWheel}
          aria-label="Obszar rysowania 2D"
        />
        <div className="viewport-controls" role="toolbar" aria-label="Sterowanie widokiem 2D">
          <button
            type="button"
            className="vp-btn"
            onClick={() =>
              setCamera((p) => ({ ...p, zoom: Math.min(25, p.zoom * 1.25) }))
            }
            aria-label="Przybliż widok"
            title="Przybliż"
          >
            +
          </button>
          <button
            type="button"
            className="vp-btn"
            onClick={() =>
              setCamera((p) => ({ ...p, zoom: Math.max(0.02, p.zoom / 1.25) }))
            }
            aria-label="Oddal widok"
            title="Oddal"
          >
            −
          </button>
          <button
            type="button"
            className="vp-btn vp-btn-text"
            onClick={fitToDrawing}
            title="Dopasuj rysunek do ekranu"
          >
            <FitIcon size={14} />
            <span>Dopasuj</span>
          </button>
          <button
            type="button"
            className="vp-btn vp-btn-text"
            onClick={resetView}
            title="Przywróć domyślny widok"
          >
            <ResetIcon size={14} />
            <span>Reset</span>
          </button>
          <button
            type="button"
            className={`vp-btn vp-btn-text${showGrid ? ' is-pressed' : ''}`}
            onClick={() => setShowGrid((g) => !g)}
            aria-pressed={showGrid}
            title="Pokaż lub ukryj siatkę"
          >
            <span>Siatka</span>
          </button>
        </div>
      </div>
    );
  }
);

Viewport2D.displayName = 'Viewport2D';
