import React from 'react';
import { STANDARD_PROGRAMS, StandardProgram } from '../data/standardPrograms';
import { MiniPreview } from './MiniPreview';

interface ExamplesViewProps {
  onSelectExample: (program: StandardProgram) => void;
}

export const ExamplesView: React.FC<ExamplesViewProps> = ({ onSelectExample }) => {
  const programs2d = STANDARD_PROGRAMS.filter((p) => p.mode === '2d');
  const programs3d = STANDARD_PROGRAMS.filter((p) => p.mode === '3d');

  const renderGroup = (title: string, items: StandardProgram[]) => (
    <section className="examples-section" aria-label={title}>
      <h2 className="section-heading">{title}</h2>
      <div className="examples-grid">
        {items.map((prog) => (
          <article key={prog.id} className="example-row">
            <div className="example-thumb">
              <MiniPreview source={prog.source} mode={prog.mode} width={132} height={92} />
            </div>
            <div className="example-info">
              <div className="example-title-row">
                <h3>{prog.title}</h3>
                <span className="mode-tag">{prog.mode.toUpperCase()}</span>
              </div>
              <p className="example-sub">{prog.subtitle}</p>
              <button
                type="button"
                className="btn btn-secondary btn-sm"
                onClick={() => onSelectExample(prog)}
              >
                Wczytaj do pracowni
              </button>
            </div>
          </article>
        ))}
      </div>
    </section>
  );

  return (
    <div className="page-scroll">
      <div className="page-container">
        <header className="page-header">
          <h1>Przykłady standardowe</h1>
          <p className="page-lead">
            Trzynaście klasycznych programów w języku Logo — od pierwszego kwadratu po fraktale i bryły w przestrzeni 3D.
          </p>
        </header>
        {renderGroup('Tryb 2D — płaszczyzna', programs2d)}
        {renderGroup('Tryb 3D — przestrzeń', programs3d)}
      </div>
    </div>
  );
};
