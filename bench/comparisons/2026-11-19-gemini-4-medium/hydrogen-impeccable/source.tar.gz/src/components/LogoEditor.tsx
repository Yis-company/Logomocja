import React, { useMemo, useRef } from 'react';
import {
  isReservedWord,
  lookupCommand,
  PROC_END_KEYWORDS,
  PROC_START_KEYWORDS,
} from '../logo/keywords';
import { LogoError } from '../logo/types';

interface LogoEditorProps {
  value: string;
  onChange: (next: string) => void;
  activeLine: number | null;
  error: LogoError | null;
  readOnly?: boolean;
  ariaLabel?: string;
}

type HighlightKind =
  | 'plain'
  | 'comment'
  | 'command'
  | 'keyword'
  | 'number'
  | 'color'
  | 'bracket'
  | 'var'
  | 'op';

interface HighlightSpan {
  text: string;
  kind: HighlightKind;
}

function tokenizeLineForHighlight(line: string): HighlightSpan[] {
  const spans: HighlightSpan[] = [];
  let i = 0;
  const n = line.length;

  while (i < n) {
    const ch = line[i];

    // Comment
    if (ch === ';') {
      spans.push({ text: line.slice(i), kind: 'comment' });
      break;
    }

    // Whitespace
    if (ch === ' ' || ch === '\t' || ch === '\r') {
      let j = i + 1;
      while (j < n && (line[j] === ' ' || line[j] === '\t' || line[j] === '\r')) j++;
      spans.push({ text: line.slice(i, j), kind: 'plain' });
      i = j;
      continue;
    }

    // Color literal "..."
    if (ch === '"') {
      let j = i + 1;
      while (j < n && line[j] !== '"') j++;
      if (j < n) j++;
      spans.push({ text: line.slice(i, j), kind: 'color' });
      i = j;
      continue;
    }

    // Brackets / parens
    if (ch === '[' || ch === ']' || ch === '(' || ch === ')') {
      spans.push({ text: ch, kind: 'bracket' });
      i++;
      continue;
    }

    // Operators / comparisons
    if (ch === '+' || ch === '-' || ch === '*' || ch === '/' || ch === '<' || ch === '>' || ch === '=' || ch === ',') {
      let j = i + 1;
      if ((ch === '<' || ch === '>') && j < n && (line[j] === '=' || (ch === '<' && line[j] === '>'))) {
        j++;
      }
      spans.push({ text: line.slice(i, j), kind: 'op' });
      i = j;
      continue;
    }

    // Legacy :var
    if (ch === ':') {
      let j = i + 1;
      while (j < n && /[\p{L}\p{N}_]/u.test(line[j])) j++;
      spans.push({ text: line.slice(i, j), kind: 'var' });
      i = j;
      continue;
    }

    // Number
    if ((ch >= '0' && ch <= '9') || (ch === '.' && i + 1 < n && line[i + 1] >= '0' && line[i + 1] <= '9')) {
      let j = i + 1;
      while (j < n && ((line[j] >= '0' && line[j] <= '9') || line[j] === '.')) j++;
      spans.push({ text: line.slice(i, j), kind: 'number' });
      i = j;
      continue;
    }

    // Word / identifier
    if (/[\p{L}_]/u.test(ch)) {
      let j = i + 1;
      while (j < n && /[\p{L}\p{N}_]/u.test(line[j])) j++;
      if (line.slice(i, j).toLowerCase() === 'ma' && j < n && line[j] === ':') {
        j++;
      }
      const word = line.slice(i, j);
      const lower = word.toLowerCase();
      let kind: HighlightKind = 'var';
      if (
        PROC_START_KEYWORDS.has(lower) ||
        PROC_END_KEYWORDS.has(lower) ||
        lower === 'ma:' ||
        lower === 'nrpowt' ||
        lower === 'repcount'
      ) {
        kind = 'keyword';
      } else if (lookupCommand(lower) !== null || isReservedWord(lower)) {
        kind = 'command';
      }
      spans.push({ text: word, kind });
      i = j;
      continue;
    }

    spans.push({ text: ch, kind: 'plain' });
    i++;
  }

  return spans;
}

export const LogoEditor: React.FC<LogoEditorProps> = ({
  value,
  onChange,
  activeLine,
  error,
  readOnly = false,
  ariaLabel = 'Edytor kodu Logo',
}) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const preRef = useRef<HTMLPreElement>(null);
  const gutterRef = useRef<HTMLDivElement>(null);

  const lines = useMemo(() => value.split('\n'), [value]);
  const highlightedLines = useMemo(
    () => lines.map((line) => tokenizeLineForHighlight(line)),
    [lines]
  );

  const syncScroll = () => {
    const ta = textareaRef.current;
    if (!ta) return;
    if (preRef.current) {
      preRef.current.scrollTop = ta.scrollTop;
      preRef.current.scrollLeft = ta.scrollLeft;
    }
    if (gutterRef.current) {
      gutterRef.current.scrollTop = ta.scrollTop;
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab' && !e.shiftKey && !e.ctrlKey && !e.metaKey && !e.altKey) {
      e.preventDefault();
      const ta = e.currentTarget;
      const start = ta.selectionStart;
      const end = ta.selectionEnd;
      const next = value.slice(0, start) + '  ' + value.slice(end);
      onChange(next);
      requestAnimationFrame(() => {
        ta.selectionStart = ta.selectionEnd = start + 2;
      });
    } else if (e.key === 'Escape') {
      e.currentTarget.blur();
    }
  };

  return (
    <div className="editor-shell">
      <div className="editor-body">
        <div className="editor-gutter" ref={gutterRef} aria-hidden="true">
          {lines.map((_, idx) => {
            const lineNum = idx + 1;
            const isExec = activeLine === lineNum;
            const isErr = error?.line === lineNum;
            return (
              <div
                key={lineNum}
                className={`editor-gutter-line${isExec ? ' is-active' : ''}${isErr ? ' is-error' : ''}`}
              >
                {lineNum}
              </div>
            );
          })}
        </div>

        <div className="editor-stage">
          <pre className="editor-highlight" ref={preRef} aria-hidden="true">
            {highlightedLines.map((spans, idx) => {
              const lineNum = idx + 1;
              const isExec = activeLine === lineNum;
              const isErr = error?.line === lineNum;
              const rawLine = lines[idx];
              const errColIdx = isErr && error ? Math.max(0, Math.min(rawLine.length, error.column - 1)) : -1;

              return (
                <div
                  key={lineNum}
                  className={`editor-code-line${isExec ? ' is-active' : ''}${isErr ? ' is-error' : ''}`}
                >
                  {spans.length === 0 ? (
                    '\u200B'
                  ) : (
                    spans.map((sp, sIdx) => (
                      <span key={sIdx} className={`tok-${sp.kind}`}>
                        {sp.text}
                      </span>
                    ))
                  )}
                  {isErr && errColIdx >= 0 && (
                    <span
                      className="editor-col-marker"
                      style={{ left: `calc(${errColIdx}ch + 12px)` }}
                    />
                  )}
                </div>
              );
            })}
          </pre>

          <textarea
            ref={textareaRef}
            className="editor-textarea"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            onScroll={syncScroll}
            onKeyDown={handleKeyDown}
            readOnly={readOnly}
            spellCheck={false}
            autoCapitalize="off"
            autoComplete="off"
            autoCorrect="off"
            wrap="off"
            aria-label={ariaLabel}
          />
        </div>
      </div>

      {error && (
        <div className="editor-error-banner" role="alert">
          <span className="editor-error-loc">
            Wiersz {error.line}, kolumna {error.column}
          </span>
          <span className="editor-error-msg">{error.message}</span>
        </div>
      )}
    </div>
  );
};
