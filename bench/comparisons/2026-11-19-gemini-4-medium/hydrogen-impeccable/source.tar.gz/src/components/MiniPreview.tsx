import React, { useMemo } from 'react';
import { Mode } from '../logo/types';
import { runProgram } from '../logo/vm';

interface MiniPreviewProps {
  source: string;
  mode: Mode;
  width?: number;
  height?: number;
}

export const MiniPreview: React.FC<MiniPreviewProps> = ({
  source,
  mode,
  width = 160,
  height = 112,
}) => {
  const { lines, viewBox } = useMemo(() => {
    const res = runProgram(source, mode);
    if (res.segments.length === 0) {
      return { lines: [], viewBox: '0 0 100 100' };
    }

    const project = (p: [number, number, number]): [number, number] => {
      if (mode === '2d') {
        return [p[0], -p[1]];
      }
      // Isometric-like projection for 3D preview (+Z up)
      const angle = Math.PI / 6;
      const sx = (p[0] - p[1]) * Math.cos(angle);
      const sy = -(p[2] + (p[0] + p[1]) * Math.sin(angle) * 0.55);
      return [sx, sy];
    };

    let minX = Infinity;
    let maxX = -Infinity;
    let minY = Infinity;
    let maxY = -Infinity;

    const projected = res.segments.map((s) => {
      const a = project(s.from);
      const b = project(s.to);
      minX = Math.min(minX, a[0], b[0]);
      maxX = Math.max(maxX, a[0], b[0]);
      minY = Math.min(minY, a[1], b[1]);
      maxY = Math.max(maxY, a[1], b[1]);
      return {
        x1: a[0],
        y1: a[1],
        x2: b[0],
        y2: b[1],
        color: s.color,
        width: s.width,
      };
    });

    const spanX = Math.max(10, maxX - minX);
    const spanY = Math.max(10, maxY - minY);
    const pad = Math.max(spanX, spanY) * 0.14;
    const vb = `${minX - pad} ${minY - pad} ${spanX + pad * 2} ${spanY + pad * 2}`;
    const strokeScale = Math.max(spanX, spanY) / 110;

    return {
      lines: projected.map((l) => ({
        ...l,
        strokeWidth: Math.max(0.7, l.width * 0.7 * strokeScale),
      })),
      viewBox: vb,
    };
  }, [source, mode]);

  return (
    <svg
      width={width}
      height={height}
      viewBox={viewBox}
      className="mini-preview-svg"
      aria-hidden="true"
    >
      {lines.map((l, idx) => (
        <line
          key={idx}
          x1={l.x1}
          y1={l.y1}
          x2={l.x2}
          y2={l.y2}
          stroke={l.color}
          strokeWidth={l.strokeWidth}
          strokeLinecap="round"
        />
      ))}
    </svg>
  );
};
