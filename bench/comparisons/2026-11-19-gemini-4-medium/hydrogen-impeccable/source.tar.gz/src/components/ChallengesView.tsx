import React, { useState } from 'react';
import { CHALLENGES, Challenge, ChallengeCheckResult, checkChallenge } from '../data/challenges';
import { Mode } from '../logo/types';
import { CheckIcon, PlayIcon } from './Icons';
import { LogoEditor } from './LogoEditor';
import { MiniPreview } from './MiniPreview';

interface ChallengesViewProps {
  completed: Record<string, boolean>;
  onMarkCompleted: (id: string) => void;
  onOpenInStudio: (source: string, mode: Mode) => void;
}

export const ChallengesView: React.FC<ChallengesViewProps> = ({
  completed,
  onMarkCompleted,
  onOpenInStudio,
}) => {
  const [selectedId, setSelectedId] = useState<string>(CHALLENGES[0].id);
  const [drafts, setDrafts] = useState<Record<string, string>>(() => {
    const init: Record<string, string> = {};
    for (const ch of CHALLENGES) init[ch.id] = ch.starterCode;
    return init;
  });
  const [showHint, setShowHint] = useState(false);
  const [result, setResult] = useState<ChallengeCheckResult | null>(null);

  const active: Challenge =
    CHALLENGES.find((c) => c.id === selectedId) ?? CHALLENGES[0];
  const code = drafts[active.id] ?? active.starterCode;
  const completedCount = CHALLENGES.filter((c) => completed[c.id]).length;

  const handleSelect = (ch: Challenge) => {
    setSelectedId(ch.id);
    setResult(null);
    setShowHint(false);
  };

  const handleCheck = () => {
    const res = checkChallenge(active, code);
    setResult(res);
    if (res.passed) {
      onMarkCompleted(active.id);
    }
  };

  return (
    <div className="challenges-layout">
      <aside className="challenges-sidebar" aria-label="Lista wyzwań">
        <div className="challenges-sidebar-head">
          <h2>Wyzwania</h2>
          <span className="challenges-progress tabular">
            {completedCount} / {CHALLENGES.length}
          </span>
        </div>
        <ul className="challenges-list">
          {CHALLENGES.map((ch) => {
            const isDone = Boolean(completed[ch.id]);
            const isSelected = ch.id === active.id;
            return (
              <li key={ch.id}>
                <button
                  type="button"
                  className={`challenge-nav-item${isSelected ? ' is-selected' : ''}`}
                  onClick={() => handleSelect(ch)}
                  aria-current={isSelected ? 'true' : undefined}
                >
                  <span className="challenge-nav-title">{ch.title}</span>
                  <span className="challenge-nav-meta">
                    <span className="mode-tag">{ch.mode.toUpperCase()}</span>
                    {isDone && (
                      <span className="challenge-done-badge" title="Zadanie zaliczone">
                        <CheckIcon size={13} />
                      </span>
                    )}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      </aside>

      <div className="challenges-main">
        <div className="challenge-detail-header">
          <div>
            <div className="challenge-title-line">
              <h1>{active.title}</h1>
              <span className="mode-tag">{active.mode.toUpperCase()}</span>
              <span className="difficulty-tag">{active.difficulty}</span>
            </div>
            <p className="challenge-desc">{active.description}</p>
            <div className="challenge-hint-row">
              <button
                type="button"
                className="btn btn-ghost btn-sm"
                onClick={() => setShowHint((h) => !h)}
                aria-expanded={showHint}
              >
                {showHint ? 'Ukryj podpowiedź' : 'Pokaż podpowiedź'}
              </button>
              <button
                type="button"
                className="btn btn-ghost btn-sm"
                onClick={() => onOpenInStudio(code, active.mode)}
              >
                Otwórz w pracowni
              </button>
            </div>
            {showHint && <p className="challenge-hint-box">{active.hint}</p>}
          </div>

          <div className="challenge-target-box">
            <span className="challenge-preview-label">Wzór docelowy</span>
            <MiniPreview
              source={active.referenceSource}
              mode={active.mode}
              width={160}
              height={120}
            />
          </div>
        </div>

        <div className="challenge-work-area">
          <div className="challenge-editor-pane">
            <div className="challenge-toolbar">
              <button type="button" className="btn btn-primary" onClick={handleCheck}>
                <PlayIcon size={14} />
                <span>Sprawdź rozwiązanie</span>
              </button>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => {
                  setDrafts((d) => ({ ...d, [active.id]: active.starterCode }));
                  setResult(null);
                }}
              >
                Przywróć szablon
              </button>
            </div>
            <div className="challenge-editor-wrap">
              <LogoEditor
                value={code}
                onChange={(next) => setDrafts((d) => ({ ...d, [active.id]: next }))}
                activeLine={null}
                error={null}
                ariaLabel={`Edytor rozwiązania dla zadania ${active.title}`}
              />
            </div>
          </div>

          <div className="challenge-result-pane">
            <div className="challenge-preview-card">
              <span className="challenge-preview-label">Twój rysunek</span>
              <MiniPreview source={code} mode={active.mode} width={220} height={170} />
            </div>

            {result && (
              <div
                className={`challenge-verdict ${result.passed ? 'is-pass' : 'is-fail'}`}
                role="status"
              >
                <strong>{result.passed ? 'Zaliczone' : 'Jeszcze nie'}</strong>
                <p>{result.reason}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
