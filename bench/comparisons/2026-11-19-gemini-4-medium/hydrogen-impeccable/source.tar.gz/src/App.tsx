import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { ChallengesView } from './components/ChallengesView';
import { ExamplesView } from './components/ExamplesView';
import {
  DownloadIcon,
  MoonIcon,
  PauseIcon,
  PlayIcon,
  ResetIcon,
  ShareIcon,
  StepIcon,
  SunIcon,
  UploadIcon,
} from './components/Icons';
import { LogoEditor } from './components/LogoEditor';
import { ReferenceView } from './components/ReferenceView';
import { Viewport2D, ViewportHandle } from './components/Viewport2D';
import { Viewport3D } from './components/Viewport3D';
import { STANDARD_PROGRAMS, StandardProgram } from './data/standardPrograms';
import { LogoError, Mode, RunResult, Segment, TurtleState } from './logo/types';
import { createExecution, LogoVM, runProgram } from './logo/vm';
import {
  buildPermalink,
  downloadTextFile,
  loadCompletedChallenges,
  loadDraft,
  loadSavedMode,
  loadTheme,
  parsePermalinkFromHash,
  saveCompletedChallenge,
  saveDraft,
  saveMode,
  saveTheme,
  ThemeSetting,
} from './utils/storage';

type TabRoute = 'pracownia' | 'przyklady' | 'wyzwania' | 'slownik';
type ExecStatus = 'idle' | 'running' | 'paused' | 'done' | 'error';

const INITIAL_TURTLE: TurtleState = {
  pos: [0, 0, 0],
  heading: [0, 1, 0],
  right: [1, 0, 0],
  up: [0, 0, 1],
  penDown: true,
  color: '#16866a',
  width: 3,
};

const DEFAULT_2D = STANDARD_PROGRAMS.find((p) => p.id === 'kwadrat')!.source;
const DEFAULT_3D = STANDARD_PROGRAMS.find((p) => p.id === 'schody')!.source;

function parseTabFromHash(): TabRoute {
  const hash = window.location.hash.replace(/^#\/?/, '').split('?')[0];
  if (hash === 'przyklady') return 'przyklady';
  if (hash === 'wyzwania') return 'wyzwania';
  if (hash === 'slownik') return 'slownik';
  return 'pracownia';
}

declare global {
  interface Window {
    logomocja?: {
      version: string;
      run: (source: string, mode: Mode) => RunResult;
      open: (source: string, mode: Mode) => Promise<RunResult>;
    };
  }
}

export const App: React.FC = () => {
  const permalinkInit = useMemo(() => parsePermalinkFromHash(), []);

  const [tab, setTab] = useState<TabRoute>(() =>
    permalinkInit ? 'pracownia' : parseTabFromHash()
  );
  const [mode, setMode] = useState<Mode>(() =>
    permalinkInit ? permalinkInit.mode : loadSavedMode()
  );
  const [drafts, setDrafts] = useState<Record<Mode, string>>(() => ({
    '2d':
      permalinkInit && permalinkInit.mode === '2d'
        ? permalinkInit.code
        : loadDraft('2d') ?? DEFAULT_2D,
    '3d':
      permalinkInit && permalinkInit.mode === '3d'
        ? permalinkInit.code
        : loadDraft('3d') ?? DEFAULT_3D,
  }));
  const [cleanBaseline, setCleanBaseline] = useState<Record<Mode, string>>(() => ({
    '2d': loadDraft('2d') ?? DEFAULT_2D,
    '3d': loadDraft('3d') ?? DEFAULT_3D,
  }));

  const [themeSetting, setThemeSetting] = useState<ThemeSetting>(() => loadTheme());
  const [systemDark, setSystemDark] = useState<boolean>(() =>
    typeof window !== 'undefined' &&
    window.matchMedia('(prefers-color-scheme: dark)').matches
  );

  const [completedChallenges, setCompletedChallenges] = useState<
    Record<string, boolean>
  >(() => loadCompletedChallenges());

  // Execution state
  const [execStatus, setExecStatus] = useState<ExecStatus>('idle');
  const [segments, setSegments] = useState<Segment[]>([]);
  const [turtle, setTurtle] = useState<TurtleState>(INITIAL_TURTLE);
  const [activeLine, setActiveLine] = useState<number | null>(null);
  const [error, setError] = useState<LogoError | null>(null);
  const [opsCount, setOpsCount] = useState(0);
  const [speed, setSpeed] = useState(75); // 1..100
  const [mobilePane, setMobilePane] = useState<'code' | 'view'>('code');

  const [pendingConfirm, setPendingConfirm] = useState<{
    label: string;
    targetMode: Mode;
    source: string;
  } | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const vmRef = useRef<LogoVM | null>(null);
  const timerRef = useRef<number | null>(null);
  const viewportRef = useRef<ViewportHandle>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const isDark =
    themeSetting === 'dark' || (themeSetting === 'system' && systemDark);
  const currentCode = drafts[mode];

  // Sync theme attribute on <html>
  useEffect(() => {
    document.documentElement.dataset.theme = isDark ? 'dark' : 'light';
  }, [isDark]);

  // Listen to system color scheme
  useEffect(() => {
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const handler = (e: MediaQueryListEvent) => setSystemDark(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  // Listen to hash changes
  useEffect(() => {
    const onHash = () => {
      const pl = parsePermalinkFromHash();
      if (pl) {
        setMode(pl.mode);
        setDrafts((d) => ({ ...d, [pl.mode]: pl.code }));
        setTab('pracownia');
        return;
      }
      setTab(parseTabFromHash());
    };
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  const navigateTab = (next: TabRoute) => {
    setTab(next);
    window.location.hash = `#/${next}`;
  };

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    window.setTimeout(() => {
      setToast((curr) => (curr === msg ? null : curr));
    }, 2400);
  }, []);

  const stopTimer = useCallback(() => {
    if (timerRef.current !== null) {
      window.clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const resetExecution = useCallback(() => {
    stopTimer();
    vmRef.current = null;
    setExecStatus('idle');
    setSegments([]);
    setTurtle(INITIAL_TURTLE);
    setActiveLine(null);
    setError(null);
    setOpsCount(0);
  }, [stopTimer]);

  const syncFromVm = useCallback((vm: LogoVM) => {
    setSegments([...vm.getSegments()]);
    setTurtle(vm.getTurtle());
    setOpsCount(vm.getOps());
    setActiveLine(vm.getNextLine());
    setError(vm.error);
  }, []);

  const runInstant = useCallback(
    (src: string, targetMode: Mode): RunResult => {
      stopTimer();
      vmRef.current = null;
      const res = runProgram(src, targetMode);
      const { vm } = createExecution(src, targetMode);
      if (vm) {
        vm.runToEnd();
        setTurtle(vm.getTurtle());
        setOpsCount(vm.getOps());
      } else {
        setTurtle(INITIAL_TURTLE);
        setOpsCount(0);
      }
      setSegments(res.segments);
      setActiveLine(null);
      setError(res.error);
      setExecStatus(res.error ? 'error' : 'done');
      return res;
    },
    [stopTimer]
  );

  // Run initial program on mount (permalink or default)
  useEffect(() => {
    runInstant(currentCode, mode);
    requestAnimationFrame(() => {
      viewportRef.current?.fitToDrawing();
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Animation loop when execStatus === 'running'
  useEffect(() => {
    if (execStatus !== 'running') {
      stopTimer();
      return;
    }

    let cancelled = false;
    const tick = () => {
      if (cancelled || !vmRef.current) return;
      const vm = vmRef.current;

      // Batch size scales with speed (1..100)
      const batch = speed >= 98 ? 10_000 : speed >= 80 ? 25 : speed >= 60 ? 6 : 1;
      const delay =
        speed >= 98
          ? 0
          : speed >= 60
          ? 16
          : Math.round(320 - ((speed - 1) / 59) * 290);

      for (let i = 0; i < batch; i++) {
        const out = vm.step();
        if (out.done) {
          syncFromVm(vm);
          setActiveLine(null);
          setExecStatus(out.error ? 'error' : 'done');
          return;
        }
      }

      syncFromVm(vm);
      timerRef.current = window.setTimeout(tick, delay);
    };

    timerRef.current = window.setTimeout(tick, 0);
    return () => {
      cancelled = true;
      stopTimer();
    };
  }, [execStatus, speed, stopTimer, syncFromVm]);

  const handleRun = useCallback(() => {
    if (speed >= 98) {
      runInstant(currentCode, mode);
      return;
    }
    stopTimer();
    const { vm, error: parseErr } = createExecution(currentCode, mode);
    if (parseErr || !vm) {
      vmRef.current = null;
      setSegments([]);
      setTurtle(INITIAL_TURTLE);
      setActiveLine(null);
      setError(parseErr);
      setOpsCount(0);
      setExecStatus('error');
      return;
    }
    vmRef.current = vm;
    setError(null);
    setSegments([]);
    setTurtle(INITIAL_TURTLE);
    setOpsCount(0);
    setActiveLine(vm.getNextLine());
    setExecStatus('running');
  }, [currentCode, mode, runInstant, speed, stopTimer]);

  const handleStep = useCallback(() => {
    stopTimer();
    let vm = vmRef.current;
    if (!vm || execStatus === 'done' || execStatus === 'error' || execStatus === 'idle') {
      const created = createExecution(currentCode, mode);
      if (created.error || !created.vm) {
        vmRef.current = null;
        setSegments([]);
        setTurtle(INITIAL_TURTLE);
        setActiveLine(null);
        setError(created.error);
        setOpsCount(0);
        setExecStatus('error');
        return;
      }
      vm = created.vm;
      vmRef.current = vm;
      setError(null);
      setSegments([]);
      setTurtle(INITIAL_TURTLE);
      setOpsCount(0);
      setActiveLine(vm.getNextLine());
      setExecStatus('paused');
      return;
    }

    const out = vm.step();
    syncFromVm(vm);
    if (out.done) {
      setActiveLine(null);
      setExecStatus(out.error ? 'error' : 'done');
    } else {
      setExecStatus('paused');
    }
  }, [currentCode, execStatus, mode, stopTimer, syncFromVm]);

  const handlePauseResume = useCallback(() => {
    if (execStatus === 'running') {
      stopTimer();
      setExecStatus('paused');
    } else if (execStatus === 'paused') {
      setExecStatus('running');
    }
  }, [execStatus, stopTimer]);

  // Keyboard shortcuts
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (tab !== 'pracownia') return;
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        handleRun();
      } else if (e.key === 'F10' || (e.altKey && e.key.toLowerCase() === 'k')) {
        e.preventDefault();
        handleStep();
      } else if (e.key === 'F8' || (e.altKey && e.key.toLowerCase() === 'p')) {
        e.preventDefault();
        handlePauseResume();
      } else if (e.altKey && e.key.toLowerCase() === 'r') {
        e.preventDefault();
        resetExecution();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handlePauseResume, handleRun, handleStep, resetExecution, tab]);

  const handleCodeChange = (next: string) => {
    if (execStatus === 'running' || execStatus === 'paused') {
      stopTimer();
      vmRef.current = null;
      setActiveLine(null);
      setExecStatus('idle');
    }
    setDrafts((d) => ({ ...d, [mode]: next }));
    saveDraft(mode, next);
  };

  const handleModeSwitch = (nextMode: Mode) => {
    if (nextMode === mode) return;
    stopTimer();
    vmRef.current = null;
    setMode(nextMode);
    saveMode(nextMode);
    runInstant(drafts[nextMode], nextMode);
    requestAnimationFrame(() => {
      viewportRef.current?.fitToDrawing();
    });
  };

  const applyProgramToStudio = useCallback(
    (source: string, targetMode: Mode) => {
      setMode(targetMode);
      saveMode(targetMode);
      setDrafts((d) => ({ ...d, [targetMode]: source }));
      setCleanBaseline((b) => ({ ...b, [targetMode]: source }));
      saveDraft(targetMode, source);
      setTab('pracownia');
      window.location.hash = '#/pracownia';
      runInstant(source, targetMode);
      requestAnimationFrame(() => {
        viewportRef.current?.fitToDrawing();
      });
    },
    [runInstant]
  );

  const requestLoadProgram = (label: string, source: string, targetMode: Mode) => {
    const existing = drafts[targetMode];
    const baseline = cleanBaseline[targetMode];
    const isDirty = existing !== baseline && existing.trim() !== '';
    if (isDirty) {
      setPendingConfirm({ label, targetMode, source });
    } else {
      applyProgramToStudio(source, targetMode);
    }
  };

  const handleSelectExample = (prog: StandardProgram) => {
    requestLoadProgram(prog.title, prog.source, prog.mode);
  };

  const handleFileOpen = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const content = typeof reader.result === 'string' ? reader.result : '';
      requestLoadProgram(file.name, content, mode);
    };
    reader.readAsText(file, 'utf-8');
  };

  const handleCopyPermalink = async () => {
    const url = buildPermalink(mode, currentCode);
    try {
      await navigator.clipboard.writeText(url);
      showToast('Skopiowano link do programu.');
    } catch {
      window.location.hash = new URL(url).hash;
      showToast('Zaktualizowano adres URL w pasku przeglądarki.');
    }
  };

  const cycleTheme = () => {
    const order: ThemeSetting[] = ['system', 'light', 'dark'];
    const next = order[(order.indexOf(themeSetting) + 1) % order.length];
    setThemeSetting(next);
    saveTheme(next);
  };

  // Expose window.logomocja testing hook
  useEffect(() => {
    window.logomocja = {
      version: '1.0.0',
      run: (source: string, m: Mode) => runProgram(source, m),
      open: (source: string, m: Mode) => {
        setMode(m);
        saveMode(m);
        setDrafts((d) => ({ ...d, [m]: source }));
        setCleanBaseline((b) => ({ ...b, [m]: source }));
        saveDraft(m, source);
        setTab('pracownia');
        const res = runInstant(source, m);
        return new Promise<RunResult>((resolve) => {
          requestAnimationFrame(() => {
            viewportRef.current?.fitToDrawing();
            requestAnimationFrame(() => {
              resolve(res);
            });
          });
        });
      },
    };
    return () => {
      delete window.logomocja;
    };
  }, [runInstant]);

  const themeLabel =
    themeSetting === 'system'
      ? 'Motyw: System'
      : themeSetting === 'light'
      ? 'Motyw: Jasny'
      : 'Motyw: Ciemny';

  const headingDeg = Math.round(
    ((Math.atan2(turtle.heading[0], turtle.heading[1]) * 180) / Math.PI + 360) %
      360
  );

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="topbar-left">
          <a
            href="#/pracownia"
            className="brand"
            onClick={(e) => {
              e.preventDefault();
              navigateTab('pracownia');
            }}
          >
            <svg width="20" height="20" viewBox="0 0 32 32" aria-hidden="true">
              <rect width="32" height="32" rx="6" fill="var(--accent)" />
              <polygon points="16,6 25,24 16,20 7,24" fill="var(--bg)" />
            </svg>
            <span>Logomocja</span>
          </a>

          <nav className="nav-tabs" aria-label="Główna nawigacja">
            {(
              [
                ['pracownia', 'Pracownia'],
                ['przyklady', 'Przykłady'],
                ['wyzwania', 'Wyzwania'],
                ['slownik', 'Słownik'],
              ] as [TabRoute, string][]
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                className={`nav-tab${tab === id ? ' is-active' : ''}`}
                onClick={() => navigateTab(id)}
                aria-current={tab === id ? 'page' : undefined}
              >
                {label}
              </button>
            ))}
          </nav>
        </div>

        <div className="topbar-right">
          {tab === 'pracownia' && (
            <>
              <div className="mode-switch" role="group" aria-label="Tryb rysowania">
                <button
                  type="button"
                  className={`mode-btn${mode === '2d' ? ' is-active' : ''}`}
                  onClick={() => handleModeSwitch('2d')}
                  aria-pressed={mode === '2d'}
                >
                  2D
                </button>
                <button
                  type="button"
                  className={`mode-btn${mode === '3d' ? ' is-active' : ''}`}
                  onClick={() => handleModeSwitch('3d')}
                  aria-pressed={mode === '3d'}
                >
                  3D
                </button>
              </div>

              <div className="file-actions">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".logo,.txt"
                  className="sr-only"
                  onChange={handleFileOpen}
                  aria-label="Wczytaj plik .logo"
                />
                <button
                  type="button"
                  className="icon-action-btn"
                  onClick={() => fileInputRef.current?.click()}
                  title="Otwórz plik .logo"
                  aria-label="Otwórz plik .logo"
                >
                  <UploadIcon size={15} />
                  <span className="hide-sm">Otwórz</span>
                </button>
                <button
                  type="button"
                  className="icon-action-btn"
                  onClick={() =>
                    downloadTextFile(
                      `logomocja-${mode}.logo`,
                      currentCode
                    )
                  }
                  title="Pobierz jako plik .logo"
                  aria-label="Pobierz jako plik .logo"
                >
                  <DownloadIcon size={15} />
                  <span className="hide-sm">.logo</span>
                </button>
                <button
                  type="button"
                  className="icon-action-btn"
                  onClick={() => viewportRef.current?.exportPng()}
                  title="Eksportuj rysunek jako PNG"
                  aria-label="Eksportuj rysunek jako PNG"
                >
                  <DownloadIcon size={15} />
                  <span className="hide-sm">PNG</span>
                </button>
                <button
                  type="button"
                  className="icon-action-btn"
                  onClick={handleCopyPermalink}
                  title="Kopiuj link do programu"
                  aria-label="Kopiuj link do programu"
                >
                  <ShareIcon size={15} />
                  <span className="hide-sm">Link</span>
                </button>
              </div>
            </>
          )}

          <button
            type="button"
            className="icon-action-btn"
            onClick={cycleTheme}
            title={themeLabel}
            aria-label={themeLabel}
          >
            {isDark ? <MoonIcon size={15} /> : <SunIcon size={15} />}
            <span className="hide-md">
              {themeSetting === 'system'
                ? 'System'
                : themeSetting === 'light'
                ? 'Jasny'
                : 'Ciemny'}
            </span>
          </button>
        </div>
      </header>

      {pendingConfirm && (
        <div className="confirm-bar" role="alertdialog" aria-label="Potwierdzenie wczytania">
          <span>
            Masz niezapisane zmiany w trybie {pendingConfirm.targetMode.toUpperCase()}.
            Czy zastąpić je plikiem „{pendingConfirm.label}”?
          </span>
          <div className="confirm-actions">
            <button
              type="button"
              className="btn btn-primary btn-sm"
              onClick={() => {
                applyProgramToStudio(
                  pendingConfirm.source,
                  pendingConfirm.targetMode
                );
                setPendingConfirm(null);
              }}
            >
              Tak, wczytaj
            </button>
            <button
              type="button"
              className="btn btn-secondary btn-sm"
              onClick={() => setPendingConfirm(null)}
            >
              Anuluj
            </button>
          </div>
        </div>
      )}

      {toast && (
        <div className="toast-pill" role="status">
          {toast}
        </div>
      )}

      <main className="main-area">
        {tab === 'pracownia' && (
          <div className="workspace">
            <div className="mobile-pane-tabs" role="tablist" aria-label="Widok na telefonie">
              <button
                type="button"
                role="tab"
                aria-selected={mobilePane === 'code'}
                className={`mobile-pane-tab${mobilePane === 'code' ? ' is-active' : ''}`}
                onClick={() => setMobilePane('code')}
              >
                Kod programu
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={mobilePane === 'view'}
                className={`mobile-pane-tab${mobilePane === 'view' ? ' is-active' : ''}`}
                onClick={() => setMobilePane('view')}
              >
                Rysunek ({mode.toUpperCase()})
              </button>
            </div>

            <section
              className={`pane-editor${mobilePane === 'code' ? ' is-mobile-visible' : ''}`}
              aria-label="Edytor programu"
            >
              <div className="exec-bar">
                <div className="exec-buttons">
                  <button
                    type="button"
                    className="btn btn-primary"
                    onClick={handleRun}
                    title="Uruchom program (Ctrl/Cmd + Enter)"
                  >
                    <PlayIcon size={14} />
                    <span>Uruchom</span>
                  </button>
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={handleStep}
                    title="Wykonaj jeden krok (F10 lub Alt + K)"
                  >
                    <StepIcon size={14} />
                    <span>Krok</span>
                  </button>
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={handlePauseResume}
                    disabled={execStatus !== 'running' && execStatus !== 'paused'}
                    title="Pauza lub wznowienie (F8 lub Alt + P)"
                  >
                    <PauseIcon size={14} />
                    <span>{execStatus === 'paused' ? 'Wznów' : 'Pauza'}</span>
                  </button>
                  <button
                    type="button"
                    className="btn btn-ghost"
                    onClick={resetExecution}
                    title="Resetuj rysunek i stan żółwia (Alt + R)"
                  >
                    <ResetIcon size={14} />
                    <span>Reset</span>
                  </button>
                </div>

                <label className="speed-control">
                  <span>Prędkość</span>
                  <input
                    type="range"
                    min={1}
                    max={100}
                    value={speed}
                    onChange={(e) => setSpeed(Number(e.target.value))}
                    aria-label="Prędkość animacji"
                  />
                </label>
              </div>

              <div className="editor-container">
                <LogoEditor
                  value={currentCode}
                  onChange={handleCodeChange}
                  activeLine={activeLine}
                  error={error}
                />
              </div>

              <div className="shortcuts-strip" aria-label="Skróty klawiszowe">
                <span>Ctrl+Enter: Uruchom</span>
                <span>F10 / Alt+K: Krok</span>
                <span>F8 / Alt+P: Pauza</span>
                <span>Alt+R: Reset</span>
              </div>
            </section>

            <section
              className={`pane-viewport${mobilePane === 'view' ? ' is-mobile-visible' : ''}`}
              aria-label="Scena żółwia"
            >
              <div className="viewport-frame">
                {mode === '2d' ? (
                  <Viewport2D
                    ref={viewportRef}
                    segments={segments}
                    turtle={turtle}
                    isDark={isDark}
                  />
                ) : (
                  <Viewport3D
                    ref={viewportRef}
                    segments={segments}
                    turtle={turtle}
                    isDark={isDark}
                  />
                )}
              </div>

              <div className="telemetry-bar" aria-label="Stan żółwia">
                <span className="telemetry-item tabular">
                  <strong>Pozycja:</strong> {turtle.pos[0].toFixed(1)},{' '}
                  {turtle.pos[1].toFixed(1)}
                  {mode === '3d' ? `, ${turtle.pos[2].toFixed(1)}` : ''}
                </span>
                <span className="telemetry-item tabular">
                  <strong>Kierunek:</strong> {headingDeg}°
                </span>
                <span className="telemetry-item">
                  <strong>Pisak:</strong>{' '}
                  <span
                    className="pen-swatch"
                    style={{ backgroundColor: turtle.color }}
                    aria-hidden="true"
                  />
                  {turtle.penDown ? `opuszczony (${turtle.width}px)` : 'podniesiony'}
                </span>
                <span className="telemetry-item tabular">
                  <strong>Odcinki:</strong> {segments.length}
                </span>
                <span className="telemetry-item tabular">
                  <strong>Operacje:</strong> {opsCount}
                </span>
              </div>
            </section>
          </div>
        )}

        {tab === 'przyklady' && (
          <ExamplesView onSelectExample={handleSelectExample} />
        )}

        {tab === 'wyzwania' && (
          <ChallengesView
            completed={completedChallenges}
            onMarkCompleted={(id) =>
              setCompletedChallenges(saveCompletedChallenge(id, true))
            }
            onOpenInStudio={(src, m) => applyProgramToStudio(src, m)}
          />
        )}

        {tab === 'slownik' && <ReferenceView />}
      </main>
    </div>
  );
};

export default App;
