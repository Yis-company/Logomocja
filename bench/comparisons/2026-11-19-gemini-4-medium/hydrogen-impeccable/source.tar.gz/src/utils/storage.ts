import { Mode } from '../logo/types';

export type ThemeSetting = 'system' | 'light' | 'dark';

const KEYS = {
  DRAFT_2D: 'logomocja:draft:2d',
  DRAFT_3D: 'logomocja:draft:3d',
  MODE: 'logomocja:mode',
  THEME: 'logomocja:theme',
  CHALLENGES: 'logomocja:challenges',
} as const;

export function loadDraft(mode: Mode): string | null {
  try {
    return localStorage.getItem(mode === '2d' ? KEYS.DRAFT_2D : KEYS.DRAFT_3D);
  } catch {
    return null;
  }
}

export function saveDraft(mode: Mode, source: string): void {
  try {
    localStorage.setItem(mode === '2d' ? KEYS.DRAFT_2D : KEYS.DRAFT_3D, source);
  } catch {
    // ignore quota errors
  }
}

export function loadSavedMode(): Mode {
  try {
    const v = localStorage.getItem(KEYS.MODE);
    return v === '3d' ? '3d' : '2d';
  } catch {
    return '2d';
  }
}

export function saveMode(mode: Mode): void {
  try {
    localStorage.setItem(KEYS.MODE, mode);
  } catch {
    // ignore
  }
}

export function loadTheme(): ThemeSetting {
  try {
    const v = localStorage.getItem(KEYS.THEME);
    if (v === 'light' || v === 'dark' || v === 'system') return v;
    return 'system';
  } catch {
    return 'system';
  }
}

export function saveTheme(theme: ThemeSetting): void {
  try {
    localStorage.setItem(KEYS.THEME, theme);
  } catch {
    // ignore
  }
}

export function loadCompletedChallenges(): Record<string, boolean> {
  try {
    const raw = localStorage.getItem(KEYS.CHALLENGES);
    if (!raw) return {};
    return JSON.parse(raw) as Record<string, boolean>;
  } catch {
    return {};
  }
}

export function saveCompletedChallenge(id: string, passed: boolean): Record<string, boolean> {
  const current = loadCompletedChallenges();
  if (passed) {
    current[id] = true;
    try {
      localStorage.setItem(KEYS.CHALLENGES, JSON.stringify(current));
    } catch {
      // ignore
    }
  }
  return current;
}

function encodeBase64Url(text: string): string {
  const bytes = new TextEncoder().encode(text);
  let bin = '';
  for (let i = 0; i < bytes.length; i++) {
    bin += String.fromCharCode(bytes[i]);
  }
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function decodeBase64Url(encoded: string): string | null {
  try {
    let b64 = encoded.replace(/-/g, '+').replace(/_/g, '/');
    while (b64.length % 4 !== 0) b64 += '=';
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) {
      bytes[i] = bin.charCodeAt(i);
    }
    return new TextDecoder().decode(bytes);
  } catch {
    return null;
  }
}

export function buildPermalink(mode: Mode, source: string): string {
  const url = new URL(window.location.href);
  const encoded = encodeBase64Url(source);
  url.hash = `#/?mode=${mode}&code=${encoded}`;
  return url.toString();
}

export function parsePermalinkFromHash(): { mode: Mode; code: string } | null {
  const hash = window.location.hash;
  if (!hash) return null;
  const qIndex = hash.indexOf('?');
  if (qIndex === -1) return null;
  const params = new URLSearchParams(hash.slice(qIndex + 1));
  const codeParam = params.get('code');
  if (!codeParam) return null;
  const decoded = decodeBase64Url(codeParam);
  if (decoded === null) return null;
  const modeParam = params.get('mode');
  const mode: Mode = modeParam === '3d' ? '3d' : '2d';
  return { mode, code: decoded };
}

export function downloadTextFile(filename: string, content: string): void {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
