import { Mode, Segment, Vec3 } from '../logo/types';
import { runProgram } from '../logo/vm';

export interface Challenge {
  id: string;
  title: string;
  mode: Mode;
  difficulty: 'Podstawowy' | 'Średni' | 'Przestrzenny';
  description: string;
  hint: string;
  starterCode: string;
  referenceSource: string;
}

export interface ChallengeCheckResult {
  passed: boolean;
  reason: string;
  userSegments: Segment[];
  expectedSegments: Segment[];
}

export const CHALLENGES: Challenge[] = [
  {
    id: 'ch-kwadrat',
    title: 'Kwadrat o boku 100',
    mode: '2d',
    difficulty: 'Podstawowy',
    description:
      'Narysuj kwadrat o boku 100 jednostek, zaczynając od środka układu i skręcając w prawo.',
    hint: 'Użyj pętli `powtorz 4 [ ... ]` z poleceniami `np 100` oraz `pw 90`.',
    starterCode: `; Narysuj kwadrat o boku 100\npowtorz 4 [\n  \n]`,
    referenceSource: `powtorz 4 [np 100 pw 90]`,
  },
  {
    id: 'ch-trojkat',
    title: 'Trójkąt równoboczny',
    mode: '2d',
    difficulty: 'Podstawowy',
    description:
      'Narysuj trójkąt równoboczny o boku 120 jednostek (skręcając w prawo).',
    hint: 'Żółw obraca się o kąt zewnętrzny trójkąta: 360 / 3 = 120 stopni.',
    starterCode: `; Trójkąt równoboczny o boku 120\n`,
    referenceSource: `powtorz 3 [np 120 pw 120]`,
  },
  {
    id: 'ch-szesciokat',
    title: 'Sześciokąt foremny',
    mode: '2d',
    difficulty: 'Podstawowy',
    description:
      'Narysuj sześciokąt foremny o boku 70 jednostek, skręcając w prawo.',
    hint: 'Sześć boków po 70 jednostek i obrót o 360 / 6 = 60 stopni.',
    starterCode: `; Sześciokąt foremny o boku 70\n`,
    referenceSource: `powtorz 6 [np 70 pw 60]`,
  },
  {
    id: 'ch-dwa-kwadraty',
    title: 'Dwa rozłączne kwadraty',
    mode: '2d',
    difficulty: 'Średni',
    description:
      'Narysuj dwa osobne kwadraty o boku 60: pierwszy od (0, 0), drugi przesunięty o 100 jednostek w prawo (podnieś pisak podczas przejścia!).',
    hint: 'Po pierwszym kwadracie wykonaj `pod pw 90 np 100 lw 90 opu`, a potem narysuj drugi kwadrat.',
    starterCode: `; Dwa kwadraty o boku 60 bez linii łączącej\n`,
    referenceSource: `powtorz 4 [np 60 pw 90]\npod pw 90 np 100 lw 90 opu\npowtorz 4 [np 60 pw 90]`,
  },
  {
    id: 'ch-gwiazda',
    title: 'Gwiazda pięcioramienna',
    mode: '2d',
    difficulty: 'Średni',
    description:
      'Narysuj pięcioramienną gwiazdę o długości ramienia 150 jednostek.',
    hint: 'Pięć powtórzeń: `np 150` i skręt w prawo o `144` stopnie.',
    starterCode: `; Gwiazda pięcioramienna o ramieniu 150\n`,
    referenceSource: `powtorz 5 [np 150 pw 144]`,
  },
  {
    id: 'ch-schody-3d',
    title: 'Schody w 3D',
    mode: '3d',
    difficulty: 'Przestrzenny',
    description:
      'Narysuj 3-stopniowe schody w przestrzeni: każdy stopień to krok naprzód o 40 i wzniesienie w górę o 30.',
    hint: 'W pętli `powtorz 3`: `np 40`, potem `gora 90 np 30 dol 90`.',
    starterCode: `; 3-stopniowe schody w przestrzeni 3D\n`,
    referenceSource: `powtorz 3 [np 40 gora 90 np 30 dol 90]`,
  },
];

function segLength(s: Segment): number {
  return Math.hypot(
    s.to[0] - s.from[0],
    s.to[1] - s.from[1],
    s.to[2] - s.from[2]
  );
}

function sampleSegments(segments: Segment[], step = 4): Vec3[] {
  const pts: Vec3[] = [];
  for (const s of segments) {
    const len = segLength(s);
    const steps = Math.max(2, Math.ceil(len / step));
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      pts.push([
        s.from[0] + (s.to[0] - s.from[0]) * t,
        s.from[1] + (s.to[1] - s.from[1]) * t,
        s.from[2] + (s.to[2] - s.from[2]) * t,
      ]);
    }
  }
  return pts;
}

function minDistToSegments(p: Vec3, segments: Segment[]): number {
  let minSq = Infinity;
  for (const s of segments) {
    const dx = s.to[0] - s.from[0];
    const dy = s.to[1] - s.from[1];
    const dz = s.to[2] - s.from[2];
    const lenSq = dx * dx + dy * dy + dz * dz;
    let t = 0;
    if (lenSq > 0) {
      t =
        ((p[0] - s.from[0]) * dx +
          (p[1] - s.from[1]) * dy +
          (p[2] - s.from[2]) * dz) /
        lenSq;
      if (t < 0) t = 0;
      else if (t > 1) t = 1;
    }
    const px = s.from[0] + t * dx - p[0];
    const py = s.from[1] + t * dy - p[1];
    const pz = s.from[2] + t * dz - p[2];
    const dSq = px * px + py * py + pz * pz;
    if (dSq < minSq) minSq = dSq;
  }
  return Math.sqrt(minSq);
}

export function checkChallenge(
  challenge: Challenge,
  userSource: string
): ChallengeCheckResult {
  const expectedRes = runProgram(challenge.referenceSource, challenge.mode);
  const expectedSegments = expectedRes.segments;
  const userRes = runProgram(userSource, challenge.mode);

  if (userRes.error) {
    return {
      passed: false,
      reason: `Błąd w wierszu ${userRes.error.line}, kolumna ${userRes.error.column}: ${userRes.error.message}`,
      userSegments: userRes.segments,
      expectedSegments,
    };
  }

  const userSegments = userRes.segments;
  if (userSegments.length === 0) {
    return {
      passed: false,
      reason: 'Rysunek jest pusty — żółw nie narysował żadnego odcinka.',
      userSegments,
      expectedSegments,
    };
  }

  const tol = 2.5;
  const expPts = sampleSegments(expectedSegments);
  const usrPts = sampleSegments(userSegments);

  let expCovered = 0;
  for (const p of expPts) {
    if (minDistToSegments(p, userSegments) <= tol) expCovered++;
  }
  const coverage = expCovered / expPts.length;

  let usrCovered = 0;
  for (const p of usrPts) {
    if (minDistToSegments(p, expectedSegments) <= tol) usrCovered++;
  }
  const precision = usrCovered / usrPts.length;

  const refLen = expectedSegments.reduce((acc, s) => acc + segLength(s), 0);
  const userLen = userSegments.reduce((acc, s) => acc + segLength(s), 0);
  const lenRatioDiff = Math.abs(userLen - refLen) / Math.max(1, refLen);

  if (coverage < 0.96) {
    return {
      passed: false,
      reason: `Brakuje części oczekiwanego kształtu (pokrycie wzorca: ${Math.round(coverage * 100)}%).`,
      userSegments,
      expectedSegments,
    };
  }

  if (precision < 0.96) {
    return {
      passed: false,
      reason: 'Narysowano dodatkowe odcinki poza oczekiwanym kształtem (sprawdź użycie `pod` / `opu` lub kąty).',
      userSegments,
      expectedSegments,
    };
  }

  if (lenRatioDiff > 0.05) {
    return {
      passed: false,
      reason: `Łączna długość ścieżki (${userLen.toFixed(0)}) różni się od wzorcowej (${refLen.toFixed(0)}).`,
      userSegments,
      expectedSegments,
    };
  }

  return {
    passed: true,
    reason: 'Zadanie zaliczone! Kształt i wymiary zgadzają się z wzorcem.',
    userSegments,
    expectedSegments,
  };
}
