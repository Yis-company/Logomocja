export interface CommandDoc {
  polish: string[];
  english: string[];
  argument: string;
  meaning: string;
  example: string;
  only3d?: boolean;
}

export const COMMAND_DOCS: CommandDoc[] = [
  {
    polish: ['np', 'naprzod', 'naprzód'],
    english: ['fd', 'forward'],
    argument: 'wyrażenie',
    meaning: 'Przesuwa żółwia naprzód o podaną liczbę jednostek.',
    example: 'np 100',
  },
  {
    polish: ['ws', 'wstecz'],
    english: ['bk', 'back'],
    argument: 'wyrażenie',
    meaning: 'Przesuwa żółwia wstecz o podaną liczbę jednostek.',
    example: 'ws 50',
  },
  {
    polish: ['pw', 'prawo'],
    english: ['rt', 'right'],
    argument: 'wyrażenie',
    meaning: 'Obraca żółwia w prawo o podaną liczbę stopni.',
    example: 'pw 90',
  },
  {
    polish: ['lw', 'lewo'],
    english: ['lt', 'left'],
    argument: 'wyrażenie',
    meaning: 'Obraca żółwia w lewo o podaną liczbę stopni.',
    example: 'lw 45',
  },
  {
    polish: ['pod', 'podnies', 'podnieś'],
    english: ['pu', 'penup'],
    argument: 'brak',
    meaning: 'Podnosi pisak — ruchy żółwia nie zostawiają śladu.',
    example: 'pod np 40 opu',
  },
  {
    polish: ['opu', 'opusc', 'opuść'],
    english: ['pd', 'pendown'],
    argument: 'brak',
    meaning: 'Opuszcza pisak — żółw znów rysuje odcinki.',
    example: 'opu np 80',
  },
  {
    polish: ['kolor'],
    english: ['color'],
    argument: 'literał koloru ("#rrggbb")',
    meaning: 'Ustawia kolor pisaka jako 6-cyfrowy zapis szesnastkowy w cudzysłowie.',
    example: 'kolor "#16866a"',
  },
  {
    polish: ['grubosc', 'grubość'],
    english: ['width'],
    argument: 'wyrażenie (liczba całkowita 1–12)',
    meaning: 'Ustawia grubość linii od 1 do 12 pikseli.',
    example: 'grubosc 3',
  },
  {
    polish: ['powtorz', 'powtórz'],
    english: ['repeat'],
    argument: 'wyrażenie (0–10000), następnie [ ciało ]',
    meaning: 'Wykonuje polecenia w nawiasach kwadratowych podaną liczbę razy. Wewnątrz pętli dostępna jest wartość nrpowt (repcount).',
    example: 'powtorz 4 [np 80 pw 90]',
  },
  {
    polish: ['niech'],
    english: ['let'],
    argument: 'nazwa, następnie wyrażenie',
    meaning: 'Tworzy lub zmienia wartość zmiennej globalnej (poza procedurą) lub lokalnej (wewnątrz procedury).',
    example: 'niech bok 60',
  },
  {
    polish: ['jeśli', 'jesli'],
    english: ['if'],
    argument: 'warunek, następnie [ ciało ]',
    meaning: 'Wykonuje blok poleceń, jeśli warunek jest spełniony.',
    example: 'jeśli x > 10 [np x]',
  },
  {
    polish: ['jeżeli', 'jezeli'],
    english: ['ifelse'],
    argument: 'warunek, następnie [ ciało1 ] [ ciało2 ]',
    meaning: 'Wykonuje pierwszy blok, gdy warunek jest spełniony, albo drugi w przeciwnym razie.',
    example: 'jeżeli x > 0 [kolor "#16866a"] [kolor "#c1763d"]',
  },
  {
    polish: ['stop'],
    english: ['stop'],
    argument: 'brak',
    meaning: 'Kończy bieżącą procedurę; użyte na poziomie głównym kończy cały program.',
    example: 'jeśli dł < 5 [stop]',
  },
  {
    polish: ['dom'],
    english: ['home'],
    argument: 'brak',
    meaning: 'Wraca żółwiem do początku układu (0, 0, 0) i początkowej orientacji (+Y, góra +Z). Jeśli pisak jest opuszczony, rysuje linię powrotu.',
    example: 'dom',
  },
  {
    polish: ['czyść', 'czysc'],
    english: ['cs', 'clearscreen'],
    argument: 'brak',
    meaning: 'Usuwa wszystkie narysowane dotąd odcinki, nie zmieniając pozycji ani ustawień pisaka.',
    example: 'czyść',
  },
  {
    polish: ['gora', 'góra'],
    english: ['pitchup'],
    argument: 'wyrażenie',
    meaning: 'Unosi dziób żółwia w górę o podaną liczbę stopni (tylko w trybie 3D).',
    example: 'gora 90',
    only3d: true,
  },
  {
    polish: ['dol', 'dół'],
    english: ['pitchdown'],
    argument: 'wyrażenie',
    meaning: 'Opuszcza dziób żółwia w dół o podaną liczbę stopni (tylko w trybie 3D).',
    example: 'dol 45',
    only3d: true,
  },
  {
    polish: ['pp', 'przechylprawo'],
    english: ['rr', 'rollright'],
    argument: 'wyrażenie',
    meaning: 'Przechyla żółwia w prawo wokół jego osi kierunku (tylko w trybie 3D).',
    example: 'pp 90',
    only3d: true,
  },
  {
    polish: ['pl', 'przechyllewo'],
    english: ['rl', 'rollleft'],
    argument: 'wyrażenie',
    meaning: 'Przechyla żółwia w lewo wokół jego osi kierunku (tylko w trybie 3D).',
    example: 'pl 30',
    only3d: true,
  },
];

export const DIALECT_LIMITS = [
  { label: 'Maksymalna długość kodu', value: '50 000 znaków' },
  { label: 'Maksymalna liczba tokenów', value: '10 000 tokenów' },
  { label: 'Głębokość zagnieżdżenia nawiasów [ ]', value: '32 poziomy' },
  { label: 'Aktywne ramki wywołań i pętli', value: '32 ramki jednocześnie' },
  { label: 'Liczba wykonanych operacji', value: '10 000 operacji' },
  { label: 'Liczba zapamiętanych odcinków', value: '10 000 odcinków' },
  { label: 'Zakres współrzędnych X, Y, Z', value: 'od −100 000 do +100 000' },
  { label: 'Grubość pisaka', value: 'liczba całkowita od 1 do 12' },
  { label: 'Liczba powtórzeń w pętli', value: 'liczba całkowita od 0 do 10 000' },
];
