---
name: Logomocja
description: Polskojęzyczne studio rysowania żółwia w 2D i 3D na wzór pracowni kreślarskiej.
colors:
  primary: "#16866a"
  primary-hover: "#116b54"
  secondary-ochre: "#c1763d"
  paper-bg: "#f7f6f2"
  surface-stone: "#eeede8"
  surface-elevated: "#ffffff"
  ink: "#14181f"
  ink-muted: "#4b5360"
  border: "#dad7ce"
  error: "#c23028"
  success: "#157f53"
typography:
  headline:
    fontFamily: "-apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Noto Sans\", sans-serif"
    fontSize: "24px"
    fontWeight: 700
    lineHeight: 1.25
    letterSpacing: "-0.02em"
  body:
    fontFamily: "-apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Noto Sans\", sans-serif"
    fontSize: "14px"
    fontWeight: 400
    lineHeight: 1.5
  label:
    fontFamily: "ui-monospace, \"SFMono-Regular\", Menlo, Consolas, \"Liberation Mono\", monospace"
    fontSize: "13.5px"
    fontWeight: 400
    lineHeight: 1.55
rounded:
  sm: "4px"
  md: "6px"
  lg: "10px"
  xl: "12px"
spacing:
  xs: "4px"
  sm: "8px"
  md: "12px"
  lg: "20px"
components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.surface-elevated}"
    rounded: "{rounded.md}"
    padding: "0 12px"
    height: "32px"
  button-primary-hover:
    backgroundColor: "{colors.primary-hover}"
  button-secondary:
    backgroundColor: "{colors.surface-elevated}"
    textColor: "{colors.ink}"
    rounded: "{rounded.md}"
    padding: "0 12px"
    height: "32px"
  nav-tab:
    backgroundColor: "transparent"
    textColor: "{colors.ink-muted}"
    rounded: "{rounded.md}"
    padding: "5px 10px"
---

# Design System: Logomocja

## Overview

**Creative North Star: "Szkolna Pracownia Kreślarska"**

Logomocja is a restrained, task-focused Polish Logo programming studio. Rather than imitating a retro terminal or wrapping controls in decorative chrome, the interface treats the screen as a clean drafting table: warm paper canvas for drawing, stone-tinted toolbars for execution and navigation, and crisp 1px borders separating the code editor from the 2D/3D turtle stage.

Both light and dark themes share the same spatial grammar and semantic color roles. Color is reserved for primary actions, active mode/navigation states, syntax categories, and turtle pen strokes.

**Key Characteristics:**
- Warm drafting-paper light ground and deep charcoal-slate dark ground with zero decorative gradients.
- Split desktop workspace (44% editor, 56% viewport) collapsing cleanly into mobile tabs below 900px.
- Monospace reserved strictly for Logo code, line numbers, keyboard shortcuts, and tabular telemetry.

## Colors

The palette pairs neutral paper/slate surfaces with Logomocja's signature teal-green primary and warm ochre secondary accents.

### Primary
- **Logomocja Teal** (`primary`): Used for primary execution actions (`Uruchom`), active 2D/3D mode toggle, focus rings, and the default turtle pen.
- **Deep Teal** (`primary-hover`): Hover state for primary buttons and command syntax tokens.

### Secondary
- **Drafting Ochre** (`secondary-ochre`): Used for structural Logo keywords (`oto`, `już`, `nrpowt`), the X-axis in 3D, and unsaved-draft confirmation borders.

### Neutral
- **Drafting Paper** (`paper-bg`): Main viewport and page background in light mode.
- **Stone Mist** (`surface-stone`): Top bar, editor gutter, execution bar, and telemetry strip.
- **Crisp Sheet** (`surface-elevated`): Code editor stage, example cards, and active nav tabs.
- **Slate Ink** (`ink`) & **Muted Slate** (`ink-muted`): Primary body/code text and secondary labels.
- **Hairline Rule** (`border`): 1px structural dividers across panes and tables.

### Named Rules
**The Restrained Accent Rule.** Saturated teal and ochre appear only on primary actions, active toggles, syntax tokens, and drawn turtle geometry—never as decorative panel fills.

## Typography

**Body & UI Font:** System UI sans-serif stack (`-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Noto Sans", sans-serif`)
**Code & Telemetry Font:** System Monospace (`ui-monospace, "SFMono-Regular", Menlo, Consolas, "Liberation Mono", monospace`)

**Character:** Familiar, fast-rendering native Polish typography with `tabular-nums` on line numbers, coordinates, and challenge progress counters.

### Hierarchy
- **Headline** (700, 24px, line-height 1.25, tracking -0.02em): View titles (`Przykłady standardowe`, `Słownik języka Logomocja`).
- **Title** (600–700, 15–20px): Section headings, challenge titles, topbar brand.
- **Body** (400, 14px, line-height 1.5, max 65–72ch in prose): Descriptions, reference explanations, UI copy.
- **Code / Label** (400, 13.5px, line-height 21px): Logo editor, line numbers, command table aliases, shortcut strip.

## Layout

Desktop (`> 900px`) uses a full-height (`100dvh`) shell with a 48px topbar and a 2-column CSS grid (`minmax(340px, 44%) 1fr`) in the workspace, plus a 260px sidebar + main area in Challenges. Below `900px`, the workspace switches between `Kod programu` and `Rysunek` tabs so both editor and canvas remain full-screen and legible on 390px phones.

## Elevation & Depth

Surfaces are flat by default and separated by 1px hairline borders (`border`). Only floating viewport controls and transient toast pills use a subtle soft shadow (`0 2px 8px rgba(20, 24, 31, 0.08)`).

## Shapes

Controls use a consistent 6px border radius (`rounded.md`); cards, challenge panels, and reference tables use 10–12px (`rounded.lg` / `rounded.xl`); inner mode-toggle pills use 4px (`rounded.sm`).

## Components

### Buttons
- **Shape:** 6px radius, 32px height (`28px` for compact `.btn-sm`).
- **Primary:** Teal fill with crisp white ink, 150ms hover transition.
- **Secondary / Ghost:** Elevated surface with 1px border (secondary) or transparent with muted ink (ghost).
- **Focus:** 2px solid teal outline with 2px offset (`:focus-visible`).

### Navigation
- Horizontal tab strip in the 48px topbar (`Pracownia`, `Przykłady`, `Wyzwania`, `Słownik`) with active state marked by elevated surface and 1px border.

## Do's and Don'ts

### Do:
- **Do** use 1px borders to separate workspace panes, toolbars, and cards.
- **Do** apply `tabular-nums` to all numeric coordinates, line numbers, and counters.
- **Do** keep Polish diacritics crisp using native system fonts with zero external font requests.

### Don't:
- **Don't** add thick (>1px) colored left/right accent borders on alerts or cards.
- **Don't** use emoji or Unicode glyphs in place of SVG icons.
- **Don't** introduce decorative gradients or blur-glass panels.
