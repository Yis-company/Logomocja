import { describe, expect, test } from 'bun:test';
import { CHALLENGES, checkChallenge } from '../src/data/challenges';
import { STANDARD_PROGRAMS } from '../src/data/standardPrograms';
import { runProgram } from '../src/logo/vm';

describe('Logomocja interpreter — standard programs', () => {
  for (const prog of STANDARD_PROGRAMS) {
    test(`runs standard program "${prog.id}" (${prog.mode}) without error`, () => {
      const res = runProgram(prog.source, prog.mode);
      expect(res.error).toBeNull();
      expect(res.segments.length).toBeGreaterThan(0);
    });
  }

  test('2D flat programs produce identical coordinates in 2D and 3D', () => {
    for (const prog of STANDARD_PROGRAMS.filter((p) => p.mode === '2d')) {
      const r2 = runProgram(prog.source, '2d');
      const r3 = runProgram(prog.source, '3d');
      expect(r2.error).toBeNull();
      expect(r3.error).toBeNull();
      expect(r2.segments).toEqual(r3.segments);
    }
  });
});

describe('Logomocja interpreter — lexical & expression rules', () => {
  test('case-insensitive Polish and English aliases', () => {
    const a = runProgram('NP 50 PW 90 FD 30 RT 90', '2d');
    const b = runProgram('naprzód 50 prawo 90 forward 30 right 90', '2d');
    expect(a.error).toBeNull();
    expect(b.error).toBeNull();
    expect(a.segments).toEqual(b.segments);
  });

  test('binary operator whitespace rule', () => {
    expect(runProgram('np 10 - 5', '2d').segments[0]?.to[1]).toBe(5);
    expect(runProgram('np 10-5', '2d').segments[0]?.to[1]).toBe(5);

    const errLeftSpace = runProgram('np 10 -5', '2d');
    expect(errLeftSpace.error).not.toBeNull();
    expect(errLeftSpace.segments.length).toBe(0);

    const errRightSpace = runProgram('np 10- 5', '2d');
    expect(errRightSpace.error).not.toBeNull();
    expect(errRightSpace.segments.length).toBe(0);
  });

  test('precedence, associativity, and stacked unary signs', () => {
    const r1 = runProgram('np 20 - 5 - 3', '2d');
    expect(r1.segments[0]?.to[1]).toBe(12);

    const r2 = runProgram('np 2 + 3 * 4', '2d');
    expect(r2.segments[0]?.to[1]).toBe(14);

    const r3 = runProgram('np -(3 - 5)', '2d');
    expect(r3.segments[0]?.to[1]).toBe(2);

    const r4 = runProgram('np - -2', '2d');
    expect(r4.segments[0]?.to[1]).toBe(2);
  });

  test('rejects invalid numbers like 1e3, 0x10, NaN, Infinity', () => {
    expect(runProgram('np 1e3', '2d').error).not.toBeNull();
    expect(runProgram('np 0x10', '2d').error).not.toBeNull();
    expect(runProgram('np NaN', '2d').error).not.toBeNull();
    expect(runProgram('np Infinity', '2d').error).not.toBeNull();
  });

  test('exact floating-point comparisons', () => {
    const res = runProgram('jeśli 0.1 + 0.2 = 0.3 [np 50]', '2d');
    expect(res.error).toBeNull();
    expect(res.segments.length).toBe(0);
  });
});

describe('Logomocja interpreter — 3D, procedures, variables, and errors', () => {
  test('3D commands fail at parse time in 2D mode', () => {
    const res = runProgram('np 10\ngora 90\nnp 10', '2d');
    expect(res.error).toEqual({
      message: expect.any(String),
      line: 2,
      column: 1,
    });
    expect(res.segments.length).toBe(0);
  });

  test('3D pitch and roll geometry', () => {
    const res = runProgram('gora 90 np 50', '3d');
    expect(res.error).toBeNull();
    expect(res.segments[0].to[2]).toBeCloseTo(50, 6);

    const rollRes = runProgram('pp 90 gora 90 np 40', '3d');
    expect(rollRes.error).toBeNull();
    expect(rollRes.segments[0].to[0]).toBeCloseTo(40, 6);
  });

  test('nrpowt is lexically scoped to repeat', () => {
    expect(runProgram('np nrpowt', '2d').error).not.toBeNull();
    const procErr = runProgram('oto f\n  np nrpowt\njuż\npowtorz 2 [f]', '2d');
    expect(procErr.error).not.toBeNull();
    expect(procErr.segments.length).toBe(0);
  });

  test('unassigned variable fails at runtime and keeps drawn segments', () => {
    const code = `np 50
jeśli 1 > 2 [niech x 10]
np x`;
    const res = runProgram(code, '2d');
    expect(res.error).not.toBeNull();
    expect(res.error?.line).toBe(3);
    expect(res.error?.column).toBe(4);
    expect(res.segments.length).toBe(1);
  });

  test('legacy procedure header and :param syntax', () => {
    const code = `oto kw :bok
  powtorz 4 [np :bok pw 90]
już
kw 40`;
    const res = runProgram(code, '2d');
    expect(res.error).toBeNull();
    expect(res.segments.length).toBe(4);
  });

  test('czyść clears kept segments and dom returns to origin', () => {
    const code = `np 50
czyść
np 30
dom`;
    const res = runProgram(code, '2d');
    expect(res.error).toBeNull();
    expect(res.segments.length).toBe(2);
    expect(res.segments[0].from).toEqual([0, 50, 0]);
    expect(res.segments[1].to).toEqual([0, 0, 0]);
  });

  test('literal width check is parse-time; variable width check is run-time', () => {
    const parseErr = runProgram('np 50\ngrubosc 15', '2d');
    expect(parseErr.error).not.toBeNull();
    expect(parseErr.error?.line).toBe(2);
    expect(parseErr.error?.column).toBe(9);
    expect(parseErr.segments.length).toBe(0);

    const runErr = runProgram('np 50\nniech w 15\ngrubosc w', '2d');
    expect(runErr.error).not.toBeNull();
    expect(runErr.error?.line).toBe(3);
    expect(runErr.error?.column).toBe(9);
    expect(runErr.segments.length).toBe(1);
  });

  test('operation limit (10,000) stops at runtime and keeps drawn segments', () => {
    const code = `powtorz 10000 [np 1 pw 1]`;
    const res = runProgram(code, '2d');
    expect(res.error).not.toBeNull();
    expect(res.segments.length).toBeGreaterThan(0);
    expect(res.segments.length).toBeLessThan(10_000);
  });
});

describe('Logomocja challenges', () => {
  for (const ch of CHALLENGES) {
    test(`reference solution passes "${ch.id}"`, () => {
      const res = checkChallenge(ch, ch.referenceSource);
      expect(res.passed).toBe(true);
    });
  }

  test('wrong drawing fails with Polish reason', () => {
    const res = checkChallenge(CHALLENGES[0], 'np 50');
    expect(res.passed).toBe(false);
    expect(res.reason.length).toBeGreaterThan(5);
  });
});
