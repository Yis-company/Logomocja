---
version: 1
slug: "index-html"
primary_target: "index.html"
related_targets: []
---

# Logomocja Studio — Surface Brief

- **Scope:** Main Operate workspace (`Pracownia`) plus integrated views (`Przykłady`, `Wyzwania`, `Słownik`)
- **Mode:** operate
- **Audience:** Polish-speaking learners, students, educators, and Logo hobbyists on desktop and mobile.
- **Job:** Write, debug, step through, and share 2D and 3D Logo turtle programs, solve challenges, and consult the Polish dialect reference.

## Direction contract

- **THESIS:** A precision Polish Logo studio that pairs a syntax-aware code editor with a live 2D/3D turtle stage, refusing toy-like gradients or terminal costumes in favor of crisp drafting-table clarity.
- **OWN-WORLD:** Warm drafting paper (`#f7f6f2`) and stone-mist toolbars (`#eeede8`) in light mode, deep slate (`#111418` / `#181c22`) in dark mode, anchored by Logomocja teal (`#16866a`) and ochre (`#c1763d`), system sans UI + tabular monospace code.
- **STORY:** The learner opens the studio, immediately sees a working Logo program and its drawn figure, runs or steps through commands while watching the active line and turtle telemetry update, and switches seamlessly between 2D, 3D, examples, challenges, and reference.
- **FIRST VIEWPORT:** 48px top navigation/mode bar (`2D` / `3D`, `Pracownia`, `Przykłady`, `Wyzwania`, `Słownik`, share/export, theme); split workspace below with execution toolbar + syntax-highlighted editor on the left and pan/zoom/orbit turtle viewport + live coordinate telemetry bar on the right.
- **FORM:** Candidate 3 (Polish Drafting & Textbook Studio), `seed:f63f1789f40a9fd3`.
- **FINISH:** unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, DESIGN.md, and every shipping raster carrying its provenance
