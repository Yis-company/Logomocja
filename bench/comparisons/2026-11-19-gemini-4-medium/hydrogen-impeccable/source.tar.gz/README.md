# Logomocja

Polskojęzyczne studio programowania żółwia w 2D i 3D inspirowane klasycznym środowiskiem Logomocja. Działa w całości po stronie przeglądarki, bez kont, serwera ani zapytań sieciowych w czasie działania.

## Wymagania

- [Bun](https://bun.sh/) (v1.1+)

## Uruchomienie, budowanie i testy

```bash
# Instalacja zależności
bun install

# Uruchomienie serwera deweloperskiego
bun run dev

# Uruchomienie testów interpretera i zadań
bun run test

# Budowanie statycznej wersji produkcyjnej do katalogu dist/
bun run build

# Budowanie pod niestandardowym prefiksem ścieżki (np. podkatalogiem na serwerze statycznym)
BASE_PATH=/Logomocja/builds/x/ bun run build
```

## Najważniejsze możliwości

- **Tryby 2D i 3D:** płaszczyzna XY oraz przestrzeń XYZ (WebGL, z bezpiecznym komunikatem zastępczym przy braku WebGL).
- **Edytor i debugger:** numeracja wierszy, podświetlanie składni dialektu Logo, oznaczanie błędów z numerem wiersza i kolumny, podświetlanie aktualnie wykonywanego wiersza, praca krokowa, pauza/wznowienie i regulacja prędkości.
- **13 programów standardowych:** wbudowane przykłady 2D i 3D z ochroną przed przypadkowym nadpisaniem niezapisanych zmian.
- **6 wyzwań:** zadania praktyczne z automatycznym sprawdzaniem geometrii i zapisem postępów w `localStorage`.
- **Udostępnianie i pliki:** linki bezpośrednie (permalink), eksport do PNG oraz zapis/odczyt plików `.logo`.
- **Słownik języka:** kompletna dokumentacja poleceń, wyrażeń, zmiennych, procedur, limitów i skrótów klawiszowych.
