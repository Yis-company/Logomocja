# Product

<!-- impeccable:product-schema 1 -->

## Platform

web

## Stack

delegated: Vite + React + TypeScript + Three.js (WebGL 3D) + HTML5 Canvas (2D), built with `bun run build` and tested with `bun test`. Uses hash-based routing and `BASE_PATH` support for static sub-path hosting with zero runtime network requests.

## Users

- **Primary (inferred from brief):** Polish-speaking learners, students, educators, and nostalgia-driven hobbyists exploring Logo turtle geometry in 2D and 3D on desktop and mobile phones.
- **Situation:** Learning programming fundamentals, experimenting with recursion and 3D spatial orientation, solving guided drawing challenges, and sharing creations via URL or `.logo` files.

## Product Purpose

Logomocja is a self-contained Polish-language web studio for turtle drawing inspired by the classic Polish Logomocja environment. Users write Logo programs, execute or step through them command-by-command, inspect 2D plane or 3D spatial drawings, solve built-in challenges, consult the Polish command reference, and share or export their work—all client-side with no accounts, backend, or runtime network access.

## Positioning

A faithful, bilingual-alias (Polish + English) Logo dialect with exact deterministic semantics across flat 2D and full 3D space (pitch & roll), paired with a step-by-step debugger, inline Polish diagnostics, interactive challenges, and 13 classic standard programs.

## Operating Context

- Desktop and mobile browsers (light and dark themes, system-aware with manual toggle).
- Fully offline/static runtime; drafts and challenge progress persist in `localStorage`.
- Supports permalink URLs (`open` & auto-run), PNG export, and `.logo` file import/export.

## Capabilities and Constraints

- **Modes:** 2D (XY plane) and 3D (right-handed XYZ space with WebGL; graceful fallback message if WebGL is unavailable while 2D remains functional).
- **Language:** Exact Logo dialect (case-insensitive Polish/English keywords, `:name` and `name` variables, `oto...już` procedures, `powtorz`/`nrpowt`, `jeśli`/`jeżeli`, unary/binary arithmetic with strict whitespace rules, exact comparisons, parse-time vs run-time error distinction, 1-based line/column errors in Polish, and strict resource limits).
- **Workspace:** Syntax-highlighted editor with line numbers, active execution line highlight, inline error marker; Run, Step, Pause/Resume, Reset, and animation speed control; 2D pan/zoom/fit/origin; 3D orbit/pan/zoom/reset/grid/axes; 13 verbatim standard programs with unsaved-draft protection; ≥5 auto-checked challenges; full Polish command reference; keyboard shortcuts.
- **Delivery contract:** `window.logomocja` API (`version`, `run(source, mode)`, `open(source, mode)`), `BASE_PATH` build support, `bun run test` passing.

## Brand Commitments

- **Name:** Logomocja
- **Language:** Polish UI and Polish error messages throughout.
- **Default pen colour (from brief):** `#16866a` (classic teal-green), width `3`.

## Evidence on Hand

- 13 verbatim standard programs (7 in 2D, 6 in 3D) specified in the brief.
- Complete lexical, syntactic, geometric, and limit specification in the brief.
- No external backend, accounts, or network assets.

## Product Principles

1. **Tool disappears into the task:** Clear workspace split between code editor and turtle viewport, familiar controls, fast feedback.
2. **Exactness first:** Deterministic interpreter, identical coordinates for flat programs in 2D and 3D, precise 1-based error reporting.
3. **Safe exploration:** Never silently overwrite unsaved drafts when loading examples or permalinks; persist drafts per mode.
4. **Accessible everywhere:** Keyboard-operable controls with visible focus, responsive layout from 390px phone to desktop, light & dark themes.
